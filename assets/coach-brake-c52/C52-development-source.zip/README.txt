C52 D2 FAILED DEVELOPMENT STUDY — NOT FABRICATION RELEASE

Run from the train-review repository using Python3.12, CadQuery2.7, NumPy and SciPy:
1. python cad/coach-brake-c52/build_c52.py
2. python cad/coach-brake-c52/independent_review.py (if rebuilding independent records)
3. python cad/coach-brake-c52/check_c52.py
4. python cad/coach-brake-c52/issue_c52.py
5. python cad/coach-brake-c52/draw_c52.py
6. python cad/coach-brake-c52/finalize_c52.py

Required unchanged baseline: cad/coach-truck-c5/checkpoint.brep, parts.json and drawing-edges.json. These large shared files are intentionally not duplicated in this compact source package. The independent calculations also use their documented C5 source paths. STEP contains the final module plus14 explicitly named C5 context parts, including proposed drilled support holes in two context webs only. Baseline C5 geometry is not overwritten.

Units: canonical CAD and drawing edges mm; schema3 viewer meshes inches. model-states.json.gz contains column-major4x4 transforms in inches, applied to the base model. These are beam/link closure states; they do not prove installed motion clearance.

The70mm friction reference is NOT a purchased component and its contact envelope fails. Final nominal physical interferences are retained in verification.json. The OEM bearing profile is a dimensional envelope with an assumed internal spherical form, not manufacturer CAD. Complete welds, locator joints, yoke, springs, stops, axle and all operating qualifications remain unresolved.
