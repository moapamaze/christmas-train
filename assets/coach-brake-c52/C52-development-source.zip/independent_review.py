from pathlib import Path
import hashlib
import json,math,numpy as np
from scipy.optimize import root,minimize_scalar,brentq
from scipy.spatial.transform import Rotation
BASE=Path(__file__).resolve().parent
CONTRACT=BASE/'geometry-contract.json'
P=json.loads(CONTRACT.read_text())
O=np.array(P['beam']['reference_centre']); B=np.array(P['hangers']['lower_reference']+[P['lateral_locator']['moving_reference']])-O; A=np.array(P['hangers']['upper_fixed']+[P['lateral_locator']['fixed']]); lens=np.linalg.norm(B+O-A,axis=1)
def pose(dx,yd):
 yaw=math.radians(yd)
 def f(v):
  rot=Rotation.from_euler('xyz',[v[2],v[3],yaw]); pts=rot.apply(B)+O+[dx,v[0],v[1]]
  return (np.sum((pts-A)**2,axis=1)-lens*lens)/(2*lens)
 sol=root(f,np.zeros(4),tol=1e-10);v=sol.x
 return Rotation.from_euler('xyz',[v[2],v[3],yaw]).as_matrix(),O+np.array([dx,v[0],v[1]])
phis=np.linspace(-math.radians(25),math.radians(25),2001)
def clearance(dx,yd,mean,rd,lat,side,region,width=70):
 R,T=pose(dx,yd); rr=math.radians(rd);a=np.array([0,math.cos(rr),math.sin(rr)]); c=np.array([600,lat,300+mean]); by=R[:,1];v=by-a*np.dot(by,a);vv=v@v;ab=a@by
 band=(430,530)if region=='rim' else(430,450); rad=300 if region=='rim' else 320
 low,high=(band if side>0 else(-band[1],-band[0]))
 def val(ph,ret=False):
  ph=np.asarray(ph); p=np.array([400-300*np.cos(ph),np.full_like(ph,side*490),300*np.sin(ph)]) #relative O=(200,0,300); head-centre circleX600
  q=R@p+T[:,None]-c[:,None] if ph.ndim else R@p+T-c
  aq=a@q; qp=q-a[:,None]*aq if ph.ndim else q-a*aq
  yl=np.maximum(-width/2,(low-aq)/ab); yh=np.minimum(width/2,(high-aq)/ab)
  yy=np.clip(-(v@qp)/vv,yl,yh)if vv>1e-15 else np.clip(np.zeros_like(aq),yl,yh)
  pp=qp+v[:,None]*yy if ph.ndim else qp+v*yy
  ds=np.sqrt(np.sum(pp*pp,axis=0))-rad
  ds=np.where(yl<=yh,ds,np.inf)
  return (ds,yy,aq+ab*yy)if ret else ds
 vals=val(phis);idx=np.argmin(vals);best=vals[idx];ph=phis[idx]
 if np.isfinite(best) and np.isfinite(float(val(phis[max(0,idx-2)]))) and np.isfinite(float(val(phis[min(len(phis)-1,idx+2)]))):
  z=minimize_scalar(lambda x:float(val(x)),bounds=(phis[max(0,idx-2)],phis[min(len(phis)-1,idx+2)]),method='bounded',options={'xatol':1e-12})
  if z.fun<best:best=z.fun;ph=z.x
 d,y,ax=val(ph,True)
 return float(d),float(math.degrees(ph)),float(y),float(ax)
def worst(dx,width=70):
 out=[]
 for rd in [-2,0,2]:
  edge=620*abs(math.sin(math.radians(rd)))
  for mean in sorted(set([-40+edge,0,35-edge])):
   for lat in [-3,0,3]:
    for yd in [-.3,0,.3]:
     for side in [-1,1]:
      for reg in ['rim','flange']:
       q=clearance(dx,yd,mean,rd,lat,side,reg,width)
       out.append(dict(gap_mm=q[0],phi_deg=q[1],shoe_y_offset=q[2],axial=q[3],mean=mean,roll=rd,lat=lat,yaw=yd,side=side,region=reg))
 return sorted(out,key=lambda z:z['gap_mm'])

def transformed(points,R,T):
 return (np.asarray(points)-O)@R.T+T

def linkage(R,T):
 g=P['crosshead_and_lever']; pt=transformed(g['beam_drive_reference'],R,T)
 pivot=np.array([g['bellcrank_axis']['x'],0,g['bellcrank_axis']['z']]); ia,oa=g['nominal_lever_arms']
 def endpoint(t,arm):return pivot+np.array([arm*math.sin(t),0,arm*math.cos(t)])
 theta=brentq(lambda t:np.linalg.norm(endpoint(t,oa)-pt)-g['output_link_length'],-.4,.4)
 inp=endpoint(theta,ia);out=endpoint(theta,oa);z=g['crosshead_reference'][2]
 x=inp[0]+math.sqrt(g['input_link_length']**2-(z-inp[2])**2)
 return {'bellcrank_angle_rad':theta,'bellcrank_angle_deg':math.degrees(theta),'crosshead_x_mm':x,
         'bellcrank_input_centre_mm':inp.tolist(),'bellcrank_output_mm':out.tolist(),
         'beam_drive_mm':pt.tolist(),'output_link_unit_from_beam':((out-pt)/np.linalg.norm(out-pt)).tolist()}

def serial_pose(name,R,T):
 lower=transformed(P['hangers']['lower_reference'],R,T); locator=transformed(P['lateral_locator']['moving_reference'],R,T)
 actual=np.vstack([lower,locator]);res=np.linalg.norm(actual-A,axis=1)-lens
 return {'name':name,'beam_reference_origin_mm':O.tolist(),'beam_origin_mm':T.tolist(),'beam_translation_mm':(T-O).tolist(),
         'rotation_matrix':R.tolist(),'rotation_extrinsic_xyz_deg':Rotation.from_matrix(R).as_euler('xyz',degrees=True).tolist(),
         'transform_rule':'p_world = rotation_matrix @ (p_reference - beam_reference_origin_mm) + beam_origin_mm',
         'hanger_lower_mm':lower.tolist(),'hanger_upper_fixed_mm':P['hangers']['upper_fixed'],
         'locator_moving_mm':locator.tolist(),'locator_fixed_mm':P['lateral_locator']['fixed'],
         'head_pin_mm':transformed(P['heads']['reference_pin_centres'],R,T).tolist(),
         'link_length_residual_max_mm':float(max(abs(res))),**linkage(R,T)}

def contact_case(name,mean,rd,wear=(0,0)):
 rr=math.radians(rd);a=np.array([0,math.cos(rr),math.sin(rr)]); c=np.array([600,0,300+mean]);heads=np.array(P['heads']['reference_pin_centres'])
 def f(q):
  R=Rotation.from_euler('xyz',q[3:]).as_matrix();T=O+q[:3];lo=transformed(B+O,R,T);hp=transformed(heads,R,T)
  e=list(np.linalg.norm(lo-A,axis=1)-lens)
  for h,w in zip(hp,wear):
   v=h-c;v=v-a*(v@a);e.append(np.linalg.norm(v)-(355-w))
  return e
 sol=root(f,[sum(wear)/2+mean*mean/710,0,0,0,0,0],tol=1e-10)
 if max(abs(np.array(f(sol.x))))>1e-6:raise RuntimeError('contact closure failed')
 R=Rotation.from_euler('xyz',sol.x[3:]).as_matrix();T=O+sol.x[:3];s=serial_pose(name,R,T); hp=transformed(heads,R,T)
 hm=[]
 for h in hp:
  v=c-h;v=v-a*(v@a);xx=v/np.linalg.norm(v);zz=np.cross(xx,a);mat=np.column_stack([xx,a,zz]);
  hm.append({'head_world_rotation_matrix':mat.tolist(),'head_relative_beam_rotation_matrix':(R.T@mat).tolist()})
 s.update({'state_kind':'Conditional applied two-head seating; not a release pose','mean_axle_heave_mm':mean,'axle_roll_deg':rd,
 'journal_heave_probe_mm':[mean-620*math.sin(rr),mean+620*math.sin(rr)],'wear_standoff_probe_mm':list(wear),
 'contact_closure_max_mm':float(max(abs(np.array(f(sol.x))))),'head_attitudes':hm,
 'within_configured_yaw':abs(s['rotation_extrinsic_xyz_deg'][2])<=.3,
 'within_configured_x_travel':-5-1e-6<=sol.x[0]<=15+1e-6})
 return s

def enrich_witness(row,dx):
 R,T=pose(dx,row['yaw']);ph=math.radians(row['phi_deg']);pt=R@np.array([400-300*math.cos(ph),row['side']*490+row['shoe_y_offset'],300*math.sin(ph)])+T
 rr=math.radians(row['roll']);a=np.array([0,math.cos(rr),math.sin(rr)]);c=np.array([600,row['lat'],300+row['mean']]);rad=300 if row['region']=='rim' else 320
 row.update({'world_point_mm':pt.tolist(),'wheel_axis_point_mm':c.tolist(),'wheel_axis_unit':a.tolist(),'wheel_radial_distance_mm':row['gap_mm']+rad,'retained_blank_radial_interval_mm':[250,300] if row['region']=='rim' else [300,320]})
 return row

def clean(x):
 if isinstance(x,float)and not math.isfinite(x):return None
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,dict):return{k:clean(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return[clean(v)for v in x]
 return x

def run():
 if P['revision']!='C52-GEOM-D2':raise RuntimeError('This bounded issue freezes D2; re-review changed contract before regeneration.')
 # Four independent link constraints, with X travel and yaw as free coordinates.
 def dist4(q):
  R=Rotation.from_euler('xyz',q[3:]).as_matrix();pts=transformed(B+O,R,O+q[:3]);return np.linalg.norm(pts-A,axis=1)-lens
 eps=1e-6;q=np.zeros(6);J=np.column_stack([(dist4(q+np.eye(6)[i]*eps)-dist4(q-np.eye(6)[i]*eps))/(2*eps)for i in range(6)])
 states=[]
 for x,name in [(-5,'released_beam'),(0,'nominal_applied'),(15,'full_development_travel')]:
  for yd in [-.3,0,.3]:
   R,T=pose(x,yd);s=serial_pose(name+('_yaw_%+.1f'%yd),R,T);s['prescribed_x_translation_mm']=x;s['prescribed_yaw_deg']=yd;states.append(s)
 released=next(s for s in states if s['prescribed_x_translation_mm']==-5 and s['prescribed_yaw_deg']==0)
 zero=released['crosshead_x_mm']-3
 for s in states:s['piston_position_from_nominal_zero_mm']=s['crosshead_x_mm']-zero
 contacts=[contact_case(*a)for a in [('level',0,0),('jounce35',35,0),('working_rebound40',-40,0),('accessible_rebound30',-30,0),('captured_drop60',-60,0),('roll_plus2',0,2),('roll_minus2',0,-2),('split_journal_stops',-2.5,math.degrees(math.asin(75/1240))),('differential_standoff4',0,0,(0,4))]]
 contract_hash=hashlib.sha256(CONTRACT.read_bytes()).hexdigest()
 kin={'issue':'C52-D2 independent finite closure','status':'BEAM LINKAGE CLOSURE ONLY; RELEASED HEAD FIT FAILS',
 'geometry_revision':P['revision'],'geometry_sha256':contract_hash,'constraint_rank_at_nominal':int(np.linalg.matrix_rank(J)),
 'constraint_count':4,'remaining_rigid_body_mobility':2,'nominal_constraint_jacobian':J.tolist(),
 'zero_stroke_crosshead_x_mm':zero,'piston_release_nominal_mm':3,'catalogue_total_stroke_mm':57.15,
 'sampled_piston_min_mm':min(s['piston_position_from_nominal_zero_mm']for s in states),
 'sampled_piston_max_mm':max(s['piston_position_from_nominal_zero_mm']for s in states),
 'states':states,'conditional_contact_states':contacts,
 'limits':['Closure does not establish solid clearance, component strength, release clearance or a selected friction interface.',
 'Three spherical-ended hangers and one spherical-ended locator have four independent constraints at the reference pose; finite samples are not a global singularity proof.',
 'Head attitudes in contact cases are ideal seated orientations. A frame-centering spring does not automatically produce them during release.',
 'Axle roll/lateral values are analyst probes. Exact upright-box/right-locating-bearing/left-floating-bearing compatibility is not proven by the axle-line surrogate.',
 'Stand-off changes are hypothetical geometric probes, not qualified lining wear limits.',
 'The zero-stroke value is a kinematic datum, not a released rod cut or yoke engagement dimension.']}
 (BASE/'kinematics.json').write_text(json.dumps(clean(kin),indent=2)+'\n')
 release=worst(-5,70);rim=min((r for r in release if r['region']=='rim'),key=lambda r:r['gap_mm']);flange=min((r for r in release if r['region']=='flange'),key=lambda r:r['gap_mm'])
 rim=enrich_witness(rim,-5);flange=enrich_witness(flange,-5)
 simple={'x_translation_mm':-5,'yaw_deg':0,'mean_heave_mm':40,'roll_deg':0,'lateral_mm':0,'head_side':1,
 'inner_face_radial_gap_mm':clearance(-5,0,40,0,0,1,'rim',70)[0],
 'status':'Illustrative+40mm heave is beyond current+35mm jounce; not a retained operating case.'}
 alternative=[]
 for xx in [-19,-22]:
  rows=worst(xx,70);alternative.append({'retraction_mm':-xx,'status':'Unadopted sensitivity outside D2 beam travel; does not change the frozen candidate',
   'tread_witness':min((r for r in rows if r['region']=='rim'),key=lambda r:r['gap_mm']),
   'flange_witness':min((r for r in rows if r['region']=='flange'),key=lambda r:r['gap_mm'])})
 rec={'issue':'C52-D2 independent review','status':'FAILED RELEASE CLEARANCE / UNMATCHED FRICTION PAIR / DO NOT FABRICATE',
 'geometry_revision':P['revision'],'geometry_sha256':contract_hash,
 'source_hashes':{str(f.relative_to(BASE.parent)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [CONTRACT,Path(__file__),BASE.parent/'coach-truck-c5'/'build_c5.py']},
 'review_scope':'Independent finite rigid-link closure and full inner-face arc release screen; bounded read-only review of mechanics. No OEM fit or operating acceptance.',
 'conditional_successes':{'four_link_constraint_rank':4,'remaining_mobility':'Beam application and small yaw',
 'finite_motion_samples':len(states),'maximum_link_length_residual_mm':max(s['link_length_residual_max_mm']for s in states),
 'nominal_release_to_max_chamber_travel_mm':next(s['crosshead_x_mm']for s in states if s['prescribed_x_translation_mm']==15 and s['prescribed_yaw_deg']==0)-released['crosshead_x_mm'],
 'catalogue_stroke_mm':57.15,'nominal_zero_stroke_crosshead_x_mm':zero,
 'piston_range_across_sampled_yaw_mm':[kin['sampled_piston_min_mm'],kin['sampled_piston_max_mm']],
 'stroke_note':'Nominal zero-yaw release is3mm into stroke; yaw moves it about0.011mm lower. Set a further allowance if a strict3mm minimum is required. Stroke closure alone does not establish a usable brake.'},
 'decisive_failure':{'definition':'Negative signed radial gap is a point on the reference lining inner face lying inside the retained wheel/flange blank.',
 'reference_shape':{'axial_width_mm':70,'inner_radius_mm':300,'outer_radius_mm':340,'half_arc_deg':25,'pin_x_mm':245,'head_cylinder_centre_x_mm':600},
 'release_model':'Head neutral attitude fixed relative to the moving beam. Beam itself uses exact four-link closure, including induced pitch, roll, lateral shift and prescribed yaw.',
 'sampling':'2001 angular samples across−25..+25degrees; continuous analytical minimization across axial width, with local angular refinement. Negative witnesses establish failure; no continuous positive-clearance certification is made.',
 'state_set':'Axle roll−2,0,+2deg; each roll uses mean heave at both journal-stop bounds and0; lateral−3,0,+3mm; beam yaw−0.3,0,+0.3deg; both heads. Per-end nominal heave stays within−40..+35mm. Roll/lateral remain unapproved probes.',
 'configured_retraction_mm':5,'zero_roll_zero_yaw_zero_lateral_working_rebound_witness':{'mean_heave_mm':-40,'gap_mm':clearance(-5,0,-40,0,0,1,'rim',70)[0],'note':'Failure persists at the current regular working rebound without the unapproved axle-roll/lateral probes or beam yaw.'},'tread_penetration_witness':rim,'flange_penetration_witness':flange,
 'important_correction':'The earlier centreline5mm gap/yaw calculation is withdrawn as a released-shoe clearance claim. The complete curved face must be checked.',
 'illustrative_root_case':simple,'unadopted_larger_retraction_probes':alternative},
 'mechanics_review':{'consistent':'The reviewed D1 mechanics formulation uses signed four-link reactions, two shoe normals, the actual inclined actuator output link and a circular-contact resultant whose moment about its head pivot vanishes. These are conditional equilibrium screens.',
 'concrete_corrections_sent':['Use frozenD2−5/+15 stops rather than hardcodedD1−3/+20.','Identify rotation-vector output correctly; it must not be consumed as EulerXYZ.','Use rounded median area for rounded HSS torsion, or explicitly label the rectangular-area approximation.'],
 'limits':['Centering/return spring curves and forces are not established.','Static equilibrium and gross stress comparisons do not clear local joints, fatigue, wheel/shoe thermal compatibility or failure cases.','Applied ideal seating does not establish released attitude tracking.']},
 'next_decision':'Select a documented compatible stock wheel/friction pair and then redesign/verify the release mechanism, or proceed to the alternative disc architecture. Do not substitute an unqualified narrower lining to claim a pass.',
 'evidence_files':['geometry-contract.json','kinematics.json','independent_review.py'],
 'not_completed':['Physical solid collision proof of all proposed parts','Released head tracking or sufficient qualified retraction','Compatible stock friction insert and finished wheel profile','Force-rated centering, return springs and stops','Fabrication or operating release']}
 (BASE/'independent-review.json').write_text(json.dumps(clean(rec),indent=2)+'\n')
 (BASE/'independent-review.md').write_text(f'''C52 D2 fails released-shoe clearance and is not for fabrication. Even with zero axle roll, lateral displacement and beam yaw, the ordinary−40 mm regular rebound causes9.851 mm toe intrusion at the configured5 mm release.\n\nThe three spherical-ended hangers and transverse locator provide four independent constraints, leaving beam application and small yaw. Nine finite-motion samples close, and the nominal −5 to+15 mm beam movement uses {rec['conditional_successes']['nominal_release_to_max_chamber_travel_mm']:.3f} mm of the57.15 mm chamber stroke. These are linkage results, not a usable-brake finding.\n\nWith the70 mm wide, R300, ±25° reference face held at neutral attitude relative to the beam, the configured5 mm retraction leaves a tread intrusion witness of {-rim['gap_mm']:.3f} mm and a flange intrusion witness of {-flange['gap_mm']:.3f} mm. The former uses−40 mm mean heave, zero axle roll and−0.3° beam yaw; the latter uses−18.362 mm mean heave,+2° roll,+3 mm lateral displacement and−0.3° beam yaw. Both are at the lower toe of the positive-Y reference shoe. The complete cases and frozen source hash are in independent-review.json. Axle roll/lateral limits remain analyst probes.\n\nThe previous centreline gap/yaw check is withdrawn as a release-clearance claim. Ideal spherical-head alignment during application does not make a frame-centred head follow the wheel while released. Larger19 mm retraction still produces a6.297 mm flange intrusion witness for this reference shape; it is an unadopted sensitivity, not a modification.\n\nA documented compatible stock wheel/friction pair and a resolved release mechanism are required, or the disc alternative should be developed. No narrower unqualified lining is selected.\n''')
 print(json.dumps({'revision':P['revision'],'rank':kin['constraint_rank_at_nominal'],'states':len(states),'contact_states':len(contacts),'max_link_residual_mm':rec['conditional_successes']['maximum_link_length_residual_mm'],'stroke_used_mm':rec['conditional_successes']['nominal_release_to_max_chamber_travel_mm'],'tread_witness_mm':rim['gap_mm'],'flange_witness_mm':flange['gap_mm'],'written':['kinematics.json','independent-review.json','independent-review.md']},indent=2))
if __name__=='__main__':run()
