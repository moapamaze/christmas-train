"""Bounded exact nominal BREP interference audit; records all positive volume pairs."""
from pathlib import Path
import cadquery as cq,json,time
H=Path(__file__).resolve().parent;B=H.parent/'coach-truck-c5'
M={p['id']:p for p in json.loads((H/'parts.json').read_text())};S=dict(zip(M,list(cq.importers.importBrep(str(H/'checkpoint.brep')).val())))
BM={p['id']:p for p in json.loads((B/'parts.json').read_text())};BS=dict(zip(BM,list(cq.importers.importBrep(str(B/'checkpoint.brep')).val())))
for k in ['SF-L-WEB2','SF-R-WEB1']:
 for x in[160,250]:
  for z in[370,410]:BS[k]=BS[k].cut(cq.Solid.makeCylinder(8.75,1600,cq.Vector(x,-800,z),cq.Vector(0,1,0)))
def bb(s):
 b=s.BoundingBox();return [(getattr(b,a+'min'),getattr(b,a+'max'))for a in'xyz']
BB={k:bb(v)for k,v in S.items()};BBB={k:bb(v)for k,v in BS.items()}
def overlap(a,b):return all(min(x[1],y[1])-max(x[0],y[0])>1e-5 for x,y in zip(a,b))
def pair(a,b,s,t):
 try:
  v=s.intersect(t).Volume()
  if v>1e-3:return{'a':a,'b':b,'overlap_mm3':v}
 except Exception as e:return{'a':a,'b':b,'error':str(e)}
 return None
checks=0;rows=[];keys=list(S)
for i,a in enumerate(keys):
 for b in keys[i+1:]:
  if not overlap(BB[a],BB[b]):continue
  checks+=1;r=pair(a,b,S[a],S[b])
  if r:rows.append(r)
 if i%50==0:print('INTERNAL',i,'checks',checks,'positive',len(rows),flush=True)
context=[];cc=0
for a,s in S.items():
 for b,t in BS.items():
  if '-BRAKE-'in b or '-TORQUE-'in b or b.startswith('AXLE'):continue
  if not overlap(BB[a],BBB[b]):continue
  cc+=1;r=pair(a,b,s,t)
  if r:context.append(r)
print('DONE',checks,len(rows),cc,len(context),flush=True)
record={'status':'DEVELOPMENT AUDIT; positive intersections require explicit classification, not a clearance pass','module_part_count':len(S),'valid_parts':sum(s.isValid()for s in S.values()),'nominal_module_exact_intersections_tested':checks,'nominal_module_positive_pairs':rows,'retained_C5_exact_intersections_tested':cc,'retained_C5_positive_pairs':context,'excluded_C5':'Old BRAKE/TORQUE hardware and AXLE1/2 superseded proposal omitted; other retained660-checkpoint members tested after bbox prefilter','sampling':'Nominal applied rigid pose only. Independent fullarc released/contact review is separate. No continuous sweep proof.'}
(H/'nominal-intersections.json').write_text(json.dumps(record,indent=2))
