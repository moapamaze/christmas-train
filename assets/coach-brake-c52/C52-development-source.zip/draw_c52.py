"""C5.2 drawing issue generated from canonical CAD edges and parameters.

No drawn part is used as geometry input. Solid outlines are exact CAD edges;
colored occupancy boxes are explicitly identified planning envelopes.
"""
from pathlib import Path
import html
import re
import json
import math
import textwrap
import gzip

H = Path(__file__).resolve().parent
OUT = H.parents[1] / "dist/assets/coach-brake-c52"
OUT.mkdir(parents=True, exist_ok=True)
INK = "#21443e"
GRAY = "#6a7c77"
ACC = "#a34b27"
TEAL = "#167d88"
PALE = "#eaf3f2"
WARM = "#fff1e6"
LIGHT = "#edf0eb"
PAGE_W, PAGE_H = 2000, 1400


def esc(value):
    return html.escape(str(value))


def tx(x, y, value, size=19, weight="normal", color=INK, anchor="start"):
    value=re.sub(r'([a-z])(\d)', r'\1 \2',str(value))
    value=re.sub(r'(\d)(mm|kg|kN|N/mm)',r'\1 \2',value)
    value=re.sub(r'([:;])(?=\S)',r'\1 ',value)
    value=re.sub(r'(?<=[A-Za-z])(Ø|±|≤|≥)',r' \1',value)
    value=value.replace('pertruck','per truck').replace('atY','at Y').replace('SKF22218E','SKF 22218 E').replace('SKF22216E','SKF 22216 E')
    return (f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" '
            f'font-weight="{weight}" fill="{color}" text-anchor="{anchor}">'
            f'{esc(value)}</text>')


def ln(x1, y1, x2, y2, color=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<path d="M{x1:.2f},{y1:.2f}L{x2:.2f},{y2:.2f}" fill="none" '
            f'stroke="{color}" stroke-width="{width}"{attr}/>')


def rect(x, y, w, h, fill="none", stroke=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"{attr}/>')


def circle(x, y, r, fill="white", stroke=INK, width=1.2):
    return (f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')


def lines(x, y, rows, size=19, leading=30, color=INK):
    return "".join(tx(x, y + i * leading, row, size, color=color)
                   for i, row in enumerate(rows))


def paragraph(x, y, value, width=65, size=19, leading=29, color=INK):
    return lines(x, y, textwrap.wrap(value, width), size, leading, color)


def title(x, y, value, subtitle=None):
    result = tx(x, y, value, 22, "bold")
    if subtitle:
        result += tx(x, y + 29, subtitle, 17, color=GRAY)
    return result


def dim(a, b, label, vertical=False, label_shift=0, size=18):
    x1, y1 = a
    x2, y2 = b
    result = ln(x1, y1, x2, y2, ACC, 1.4)
    for x, y in (a, b):
        result += ln(x - 5, y - 5, x + 5, y + 5, ACC, 1.4)
    if vertical:
        x, y = (x1 + x2) / 2 - 13 + label_shift, (y1 + y2) / 2
        result += (f'<text transform="translate({x:.2f},{y:.2f}) rotate(-90)" '
                   f'font-size="{size}" fill="{ACC}" text-anchor="middle">'
                   f'{esc(label)}</text>')
    else:
        result += tx((x1 + x2) / 2 + label_shift, (y1 + y2) / 2 - 10,
                     label, size, color=ACC, anchor="middle")
    return result


def leader(target, elbow, end, label, anchor="start", color=ACC, size=18):
    result = ln(*target, *elbow, color) + ln(*elbow, *end, color)
    result += circle(*target, 3, color, color)
    result += tx(end[0], end[1] - 8, label, size, "bold", color, anchor)
    return result


def table(x, y, widths, headers, rows, row_h=35, size=17):
    total=sum(widths); result=rect(x,y,total,row_h,INK,INK); xx=x
    for width,value in zip(widths,headers):
        result+=tx(xx+12,y+row_h*.7,value,size,"bold","white"); xx+=width
    yy=y+row_h
    for i,row in enumerate(rows):
        wrapped=[textwrap.wrap(str(v),max(10,int((w-24)/(size*.54)))) or [""] for w,v in zip(widths,row)]
        height=max(row_h,12+max(map(len,wrapped))*size*1.2)
        result+=rect(x,yy,total,height,LIGHT if i%2==0 else "white","none"); xx=x
        for width,values in zip(widths,wrapped):
            for n,value in enumerate(values):result+=tx(xx+12,yy+size+7+n*size*1.2,value,size)
            xx+=width
        yy+=height
    return result+rect(x,y,total,yy-y,"none","#ccd7d2")


class Projection:
    """Orthographic projection of an unmodified CAD-edge cache."""
    def __init__(self, edges, ids, axes, box, bounds=None):
        self.edges, self.ids, self.axes = edges, list(ids), axes
        a, b = axes
        pp = [p for pid in self.ids for edge in edges.get(pid, []) for p in edge]
        if not pp:
            raise ValueError(f"No CAD edges for projection: {self.ids}")
        self.bounds = bounds or ((min(p[a] for p in pp), max(p[a] for p in pp)),
                                 (min(p[b] for p in pp), max(p[b] for p in pp)))
        (u0, u1), (v0, v1) = self.bounds
        x, y, w, h = box
        self.scale = min(w / max(u1 - u0, .0001), h / max(v1 - v0, .0001))
        self.ox = x + (w - (u1 - u0) * self.scale) / 2 - u0 * self.scale
        self.oy = y + (h + (v1 - v0) * self.scale) / 2 + v0 * self.scale

    def xy(self, point):
        return self.ox + point[0] * self.scale, self.oy - point[1] * self.scale

    def draw(self, ids=None, color=INK, width=1.1, opacity=1, shift=(0, 0, 0)):
        a, b = self.axes
        result = f'<g opacity="{opacity}">'
        for pid in (self.ids if ids is None else ids):
            for edge in self.edges.get(pid, []):
                points = [self.xy((p[a] + shift[a], p[b] + shift[b])) for p in edge]
                result += ('<polyline points="' + " ".join(f"{u:.2f},{v:.2f}" for u, v in points)
                           + f'" fill="none" stroke="{color}" stroke-width="{width}"/>')
        return result + "</g>"

    def envelope(self, bounds, fill=PALE, stroke=TEAL, dash="8 5", width=1.5):
        (u0, u1), (v0, v1) = bounds
        x, y = self.xy((u0, v1))
        return rect(x, y, (u1 - u0) * self.scale, (v1 - v0) * self.scale,
                    fill, stroke, width, dash)


def sheet(name, heading, body, notes):
    source = ('<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="1400" '
              'viewBox="0 0 2000 1400"><rect width="2000" height="1400" fill="white"/>'
              '<g font-family="DejaVu Sans,Arial,sans-serif">')
    source += tx(50, 45, "PULSIPHER FARMS  /  PASSENGER COACH ENGINEERING", 19, "bold")
    source += tx(50, 91, heading, 31, "bold")
    source += tx(50, 124, "C5.2 D2  ·  MM  ·  NOMINAL COMPONENT FIT AND RELEASED SUSPENSION CLEARANCE FAIL; DO NOT FABRICATE", 17, color=ACC)
    source += ln(50, 143, 1950, 143, INK, 1.5) + body
    source += ln(50, 1190, 1950, 1190, INK, 1.5)
    source += lines(50, 1223, notes, 17, 27)
    source += ln(50, 1347, 1950, 1347, INK, 1.5)
    source += tx(50, 1377, name + "  ·  CAD: geometry-contract.json / parts.json / drawing-edges.json", 16)
    source += tx(1950, 1377, "Failed fit / clearance: verification.json / independent-review.json", 16, anchor="end")
    source += "</g></svg>"
    # SVG carries the precise edges; PNG is its compact preview. Public gzip avoids
    # duplicating several megabytes of line geometry in the static deployment.
    with gzip.GzipFile(filename=str(OUT / (name + ".svg.gz")),mode='wb',mtime=0) as f:
        f.write(source.encode())
    (OUT / (name + '.svg')).unlink(missing_ok=True)
    import cairosvg
    cairosvg.svg2png(bytestring=source.encode(), write_to=str(OUT / (name + ".png")), output_width=1600, output_height=1120)


# Sheet content is populated from the final geometry contract and canonical edge cache.

if not all((H/name).exists()for name in('drawing-edges.json','parts.json','geometry-contract.json')):
    print('C52_DRAWINGS_WAITING_FOR_CANONICAL_CAD')
    raise SystemExit(0)
E=json.loads((H/'drawing-edges.json').read_text())
P=json.loads((H/'geometry-contract.json').read_text())
M={p['id']:p for p in json.loads((H/'parts.json').read_text())}
# Existing C5 CAD cache is in inches. Convert only the retained wheel blanks and
# sideframe web references to mm; they are context, not new C52 components.
C5=H.parent/'coach-truck-c5'
C5E=json.loads((C5/'drawing-edges.json').read_text())
context_ids=['A2L-WHEEL-BLANK','A2R-WHEEL-BLANK','SF-L-WEB1','SF-L-WEB2','SF-R-WEB1','SF-R-WEB2']
for k in context_ids:
    E['CTX-'+k]=[[[v*25.4 for v in p] for p in line] for line in C5E[k]]
    M['CTX-'+k]={'id':'CTX-'+k,'group':'context'}
K=json.loads((H/'kinematics.json').read_text())


def bbox(pid):
    pts=[p for line in E.get(pid,[])for p in line]
    return {a:(min(p[i]for p in pts),max(p[i]for p in pts))for i,a in enumerate('xyz')}if pts else None
B={k:bbox(k)for k in M};B={k:v for k,v in B.items()if v}
def mid(k,a):return sum(B[k][a])/2

def color(k):
    group=M[k].get('group','')
    if group=='context':return '#b0bec1'
    if group=='friction-reference':return '#be6b30'
    if group in ('maintenance-reference','spring-reference'):return TEAL
    if group=='actuator-reference':return '#a45c31'
    if group in ('purchased-bearing','bearing-retainer','hardware'):return '#657a85'
    return INK

def draw(p,ids=None,width=1):
    return ''.join(p.draw([k],color(k),width)for k in(ids or p.ids))
def clipped(p,body,area,cid):
    x,y,w,h=area
    return f'<defs><clipPath id="{cid}">{rect(x,y,w,h,"white","none")}</clipPath></defs><g clip-path="url(#{cid})">{body}</g>'
def dimat(p,a,b,label,vertical=False):return dim(p.xy(a),p.xy(b),label,vertical=vertical,size=17)
def label_to(p,q,end,label,color=ACC,size=17):
    target=p.xy(q);return leader(target,(end[0]-18,end[1]),end,label,color=color,size=size)

# Main projected assembly uses only the positive axle development module and its adjacent truck references.
ids=[k for k in B if B[k]['x'][1]>0]
plan_box=(70,225,910,625);side_box=(1040,225,900,625)
plan=Projection(E,ids,(1,0),plan_box,((-760,760),(0,1000)))
side=Projection(E,ids,(0,2),side_box,((0,1000),(0,680)))
s=title(60,190,'PLAN — REFERENCE AXLE MODULE','Applied reference; grey is retained C5 wheel / sideframe context.')
s+=title(1040,190,'SIDE — ACTUATION AND REACTION','The wheelset rotates. Brake rigging remains nonrotating.')
s+=clipped(plan,draw(plan,[k for k in ids if k.startswith('CTX-')],.9)+draw(plan,[k for k in ids if not k.startswith('CTX-')],1.1),plan_box,'m01plan')
s+=clipped(side,draw(side,[k for k in ids if k.startswith('CTX-A2')],1)+draw(side,[k for k in ids if not k.startswith('CTX-')],1.1),side_box,'m01side')
beam=P['beam'];head=P['heads'];act=P['actuator'];lever=P['crosshead_and_lever']
y0,y1=beam['span_y'];xc=beam['reference_centre'][0]
s+=dimat(plan,(y0,65),(y1,65),f'{y1-y0:g} beam length')
hp=head['reference_pin_centres'];ys=sorted(p[1]for p in hp)
s+=dimat(plan,(ys[0],950),(ys[-1],950),f'{ys[-1]-ys[0]:g} head pin centres')
ref=P['reference_axle'];xax=ref['x'];zax=ref['z']
s+=label_to(side,(xax+160,zax+170),(1640,235),'Ø600 / Ø640 FLANGE STOCK',color='#456a80',size=16)
s+=label_to(side,(xax,zax),(1700,815),'WHEEL ROTATES',color='#456a80')
s+=label_to(side,(200,500),(1055,270),'SUPPORT → SIDEFRAME',size=16)
s+=label_to(side,(340,430),(1055,320),'MGM 3420051 REFERENCE',size=16)
s+=label_to(side,(202,430),(1055,365),'82.6 MIN CAGING PROJECTION',color=TEAL,size=15)
s+=label_to(side,(535,430),(1610,335),'GUIDED CROSSHEAD',size=16)
s+=label_to(side,(400,180),(1570,760),'LEVER / FRAME PIVOT',size=16)
s+=label_to(side,(130,375),(1055,710),'150 PITCH HANGER',size=16)
s+=label_to(plan,(350,200),(680,865),'BEAM / HEAD SUPPORT',size=16)
# Three solved crosshead locations communicate finite actuation without implying
# that the head clears the wheel during suspension travel.
states=[q for q in K['states'] if abs(q['prescribed_yaw_deg'])<1e-9]
xs=[q['crosshead_x_mm'] for q in states]
s+=dimat(side,(min(xs),645),(max(xs),645),f'{max(xs)-min(xs):.2f} solved crosshead travel')
s+=label_to(side,(hp[-1][0],hp[-1][2]),(1075,820),'SHOE / FRICTION FIT HOLD')
s+=table(60,900,[320,590],['MEMBER / INTERFACE','CANONICAL DEVELOPMENT DIMENSION'],[
 ['Beam stock',beam['material'].split(';')[0]],
 ['Head joint','GE20ES-2RS: Ø20 bore / Ø35 outside / 16 inner width'],
 ['Three hangers',f"{P['hangers']['link_pitch']:g} centre pitch; {M['HANGER2']['definition']['plate_t']:g} plate"],
 ['Beam reference',beam['reference_state'].split(';')[0]],
 ['Development translation',f"{beam['development_x_travel_from_reference'][0]:g} to +{beam['development_x_travel_from_reference'][1]:g} relative to reference; wear take-up HOLD"]],row_h=41,size=16)
s+=table(1040,900,[330,570],['ACTUATION','SOURCE / LIMIT'],[
 ['MGM 3420051',f"Type 20/24; catalogue stroke {act['stroke']:g}"],
 ['Rod alignment','Keep within the OEM ±3° through stroke'],
 ['Caging access',f"Minimum bolt projection {act['caging_min_projection_beyond_rear_nut']:g}; full tool / removal corridor HOLD"],
 ['Linkage motion',f'{max(xs)-min(xs):.2f} solved travel / 57.15 catalogue stroke; released head FAILS'],
 ['Normal force path','Head → beam → drive → chamber / bracket']
 ],row_h=41,size=16)
sheet('C52-M01','TREAD BRAKE — ONE-AXLE MODULE AND ACTUATION',s,[
 'Vertical friction reaction: head → beam → hangers → upper support → existing sideframe. Maximum actuator output governs attachment design.',
 'Friction insert is a contact reference only. No compatible stock shoe is selected for the 600 mm wheel and nominal 80 mm usable tread band.',
 'Locator end joints, purchased yoke, centering springs and full maintenance access are incomplete interfaces; no assembly release is implied.',
 'Released FAIL: ordinary −40 mm rebound gives 9.8507 mm toe intrusion; combined probes give 18.744 mm flange intrusion. independent-review.json.'
])

# Detail selections are spatial, taken from the same exact edge cache; no replacement shapes are drawn.
head_ids=[k for k in B if k.startswith('HEAD1-')]
hanger_ids=[k for k in B if k.startswith(('HANGER2','H2-'))]
if not head_ids or not hanger_ids:
    raise ValueError('Canonical CAD detail selections need review before D01 issue')
head_box=(65,235,900,550);hang_box=(1060,235,830,325)
ph=Projection(E,head_ids,(0,2),head_box)
pg=Projection(E,hanger_ids,(0,2),hang_box)
s=title(60,190,'HEAD / CAGE / RETENTION — SIDE','Development parts with unresolved fit; friction reference is orange.')
s+=title(1040,190,'SPHERICAL-ENDED HANGER — SIDE','Fixed-length link and unqualified retention / joint candidates.')
s+=clipped(ph,draw(ph),head_box,'d01head')+clipped(pg,draw(pg),hang_box,'d01hanger')
# Separate actual lower-joint pieces along the pin axis; this is a display-only exploded arrangement.
loz=min(B[k]['z'][0]for k in hanger_ids)
joint_ids=[k for k in hanger_ids if k in ['H2-PIN-LOW','H2-LOW-CHEEK-1','H2-PIN-LOW-INNER-SPACER-1','HANGER2-BUSH0-INNER','HANGER2-BUSH0-OUTER','H2-PIN-LOW-INNER-SPACER1','H2-LOW-CHEEK1','H2-PIN-LOW-WASHER','H2-PIN-LOW-NUT']]
if len(joint_ids)>1:
    cursor=0;shifts={}
    for k in sorted(joint_ids,key=lambda q:mid(q,'y')):
        shifts[k]=(0,cursor-B[k]['y'][0],0);cursor+=B[k]['y'][1]-B[k]['y'][0]+14
    z0=min(B[k]['z'][0]for k in joint_ids);z1=max(B[k]['z'][1]for k in joint_ids)
    ep=Projection(E,joint_ids,(1,2),(1060,650,830,135),((0,cursor-14),(z0,z1)))
    s+=tx(1040,605,'LOWER JOINT — COMPONENTS SEPARATED ALONG PIN AXIS',18,'bold')
    s+=tx(1040,630,'Display offsets only; assembled clamp stack and retention record govern.',16,color=GRAY)
    for n,k in enumerate(sorted(joint_ids,key=lambda q:mid(q,'y')),1):
        s+=ep.draw([k],color(k),1.15,shift=shifts[k])
        xx,_=ep.xy((mid(k,'y')+shifts[k][1],z0))
        s+=tx(xx,812,str(n),14,color=GRAY,anchor='middle')
    short_names={'H2-PIN-LOW':'screw','H2-LOW-CHEEK-1':'cheek','H2-LOW-CHEEK1':'cheek','H2-PIN-LOW-INNER-SPACER-1':'spacer','H2-PIN-LOW-INNER-SPACER1':'spacer','HANGER2-BUSH0-INNER':'inner ball','HANGER2-BUSH0-OUTER':'outer ring','H2-PIN-LOW-WASHER':'washer','H2-PIN-LOW-NUT':'nut'}
    legend=' · '.join(str(n)+' '+short_names[k]for n,k in enumerate(sorted(joint_ids,key=lambda q:mid(q,'y')),1))
    s+=tx(1040,834,legend,13,color=GRAY)

# Dimensions and leaders are attached to the exact projected assembly.
s+=dimat(pg,(82,300),(82,450),'150 bearing centres',vertical=True)
s+=label_to(ph,(245,300),(690,275),'Ø20 PIN / Ø35 HEAD BORE',size=17)
s+=label_to(ph,(300,400),(690,330),'R300 REFERENCE FACE',size=17)
s+=label_to(ph,(280,180),(690,745),'70 WIDTH; SHOE UNSELECTED',size=17)
s+=label_to(pg,(130,450),(1580,260),'GE20ES-2RS',size=17)
s+=label_to(pg,(145,300),(1580,545),'Ø20 × 40 SHOULDER / M16',size=16)
# Dimensions below the views are source data, not scaled from a raster.
s+=table(60,845,[320,590],['HEAD / SHOE','CURRENT DEFINITION'],[
 ['Head pivot','GE20ES-2RS: Ø20 bore / Ø35 outside / 16 inner width'],
 ['Reference insert',f"{head['reference_insert_only']['axial_width']:g} wide / R{head['reference_insert_only']['inner_radius']:g}; NOT A SELECTED SHOE"],
 ['Retention candidates','Stop cage, pivot hardware and spring references; mating fit FAILS'],
 ['Stock shoe HOLD','600 mm wheel / 80 mm usable band; documented 24 in shoes are wider'],
 ['Centering springs','Specification, preload, limits and fatigue remain open'],
 ['Head motion','Released suspension clearance FAILS; stop and centering interfaces incomplete']
 ],row_h=43,size=16)
s+=table(1040,845,[330,570],['JOINT / SUPPORT','CURRENT DEFINITION'],[
 ['Hanger link',f"{P['hangers']['link_pitch']:g} pitch / Ø{P['hangers']['eye_outer_diameter']:g} eyes / {M['HANGER2']['definition']['plate_t']:g} plate"],
 ['Spherical bearing','GE20ES-2RS: Ø20 bore / Ø35 outside / 16 inner width'],
 ['Pivot candidate','ISO 7379: Ø20 shoulder / M16 thread / 40 shoulder length'],
 ['Retention plates','2 plate; 3 × Ø4.5 holes on Ø46 PCD each side; M4 × 8 candidate screws'],
 ['Upper support',P['upper_support']['stock_section'].split(';')[0]],
 ['Fabrication status','Fits, weld procedure, strength and fatigue are not released']
 ],row_h=43,size=16)
sheet('C52-D01','TREAD BRAKE — HEAD, HANGERS AND RETAINED JOINTS',s,[
 'The catalogue bearing radial limit is not an assembly allowable. Housing, shoulder transition, clamp, spacer contact and welded eye require separate proof.',
 'Shoulder joint: nominal 42.5 clamp stack > 40.25 maximum shoulder. Inner spacers clamp the ball; outer rings have separate retained plates.',
 'M4 retention screws: six per eye, 6 mm blind engagement. Candidate locking, articulation clearance and detached-part containment remain unqualified.',
 'Nominal component fit and released suspension clearance FAIL. Do not fabricate; verification.json / independent-review.json record the failures.'
])
print('C52_M01_D01_WRITTEN',len(ids),len(head_ids),len(hanger_ids))
