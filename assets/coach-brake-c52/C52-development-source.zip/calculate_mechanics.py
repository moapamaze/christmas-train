"""C5.2 preliminary mechanics; requires the versioned geometry contract.
Units: N, mm, rad. No rail-brake rating or fatigue life is assigned.
"""
import json, math, hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import root, brentq
from scipy.spatial.transform import Rotation
from scipy.integrate import quad

BASE=Path(__file__).resolve().parent
G_BYTES=(BASE/'geometry-contract.json').read_bytes()
G=json.loads(G_BYTES)
CAD_BYTES=(BASE/'build_c52.py').read_bytes()
REVIEW_BYTES=(BASE/'independent-review.json').read_bytes()
REVIEW=json.loads(REVIEW_BYTES)
SHAFT_HALFSPAN=float(G['crosshead_and_lever']['bellcrank_axis']['bearing_centres_y'][1])  # bearing centres, not shaft overall extent
UPPER_HALFSPAN=float(G['upper_support']['span_y'][1])
LBF=4.4482216152605; GRAV=9.80665
ORIGIN=np.array(G['beam']['reference_centre'],float)
LOW=np.array(G['hangers']['lower_reference']+[G['lateral_locator']['moving_reference']],float)
UP=np.array(G['hangers']['upper_fixed']+[G['lateral_locator']['fixed']],float)
LL=np.linalg.norm(UP-LOW,axis=1)
HEADS=np.array(G['heads']['reference_pin_centres'],float)
DRIVE=np.array(G['crosshead_and_lever']['beam_drive_reference'],float)
PIVOT=np.array([G['crosshead_and_lever']['bellcrank_axis']['x'],0,G['crosshead_and_lever']['bellcrank_axis']['z']],float)
INARM=float(G['crosshead_and_lever']['nominal_lever_arms'][0])
OUTARM=float(G['crosshead_and_lever']['nominal_lever_arms'][1])
OUTPUTL=float(G['crosshead_and_lever']['output_link_length'])
INPUTL=float(G['crosshead_and_lever']['input_link_length'])
CROSS=np.array(G['crosshead_and_lever']['crosshead_reference'],float)

def transform(points,q):
    return Rotation.from_rotvec(q[3:]).apply(np.asarray(points)-ORIGIN)+ORIGIN+q[:3]

def axle(mean,roll):
    a=np.array([0,math.cos(roll),math.sin(roll)])
    c=np.array([600,0,300+mean],float)
    return c,a

def perpendicular(v,a): return v-a*np.dot(v,a)

def solve_pose(mean,roll,wear=(0,0),travel=None,yaw=0):
    c,a=axle(mean,roll)
    def fun(q):
        lo=transform(LOW,q); hh=transform(HEADS,q)
        residual=list(np.linalg.norm(UP-lo,axis=1)-LL)
        if travel is None:
            residual += [np.linalg.norm(perpendicular(h-c,a))-(355-w) for h,w in zip(hh,wear)]
        else: residual += [q[0]-travel,(q[5]-yaw)*500]
        return residual
    guess=np.zeros(6)
    guess[0]=sum(wear)/2+mean*mean/710 if travel is None else travel
    guess[5]=yaw
    sol=root(fun,guess,tol=1e-10)
    err=float(np.max(np.abs(fun(sol.x))))
    if not sol.success and err>1e-6: raise RuntimeError((sol.message,err))
    return sol.x,err

def lever_for_pose(q):
    p=transform(DRIVE,q)
    def point(theta,arm): return PIVOT+np.array([arm*math.sin(theta),0,arm*math.cos(theta)])
    def f(theta): return np.linalg.norm(point(theta,OUTARM)-p)-OUTPUTL
    theta=brentq(f,-.2,.65)
    o=point(theta,OUTARM); i=point(theta,INARM)
    dz=CROSS[2]-i[2]
    xx=i[0]+math.sqrt(INPUTL**2-dz**2)
    uin=np.array([xx-i[0],0,dz])/INPUTL
    uout=(o-p)/np.linalg.norm(o-p)
    mi=np.cross(i-PIVOT,uin)[1]
    mo=np.cross(o-PIVOT,uout)[1]
    ratio=mi/(uin[0]*mo)
    return dict(theta_rad=theta,stroke_mm=xx-CROSS[0],output_point=o,input_point=i,
                input_unit=uin,output_unit=uout,output_force_per_input=ratio,
                beam_X_force_per_input=ratio*uout[0],input_link_each_per_input=1/(2*uin[0]))

def head_unit(p,c,a,mu,direction):
    rv=perpendicular(p-c,a); D=np.linalg.norm(rv); n0=rv/D
    t0=np.cross(a,n0)
    # A freely seating head cannot transmit a moment about its spherical centre.
    # Solve a single-resultant circular-contact surrogate; distributed contact remains HOLD.
    f=lambda phi:D*math.sin(phi)-direction*mu*(300-D*math.cos(phi))
    phi=brentq(f,-.4,.4)
    n=math.cos(phi)*n0+math.sin(phi)*t0
    t=np.cross(a,n)
    v=n+direction*mu*t
    contact=c+a*np.dot(p-c,a)+300*n
    residual=np.linalg.norm(np.cross(contact-p,v))
    return v,phi,D,residual

def rounded_properties(b,h,t,r):
    def solid(B,H,R):
        def width(z):
            zz=abs(z)
            return B if zz<=H/2-R else B-2*R+2*math.sqrt(max(0,R*R-(zz-(H/2-R))**2))
        points=[-H/2+R,H/2-R] if R else []
        area=quad(lambda z:width(z),-H/2,H/2,points=points,epsabs=1e-7)[0]
        ix=quad(lambda z:width(z)*z*z,-H/2,H/2,points=points,epsabs=1e-5)[0]
        iz=quad(lambda z:width(z)**3/12,-H/2,H/2,points=points,epsabs=1e-5)[0]
        return np.array([area,ix,iz])
    vals=solid(b,h,r)-solid(b-2*t,h-2*t,max(0,r-t))
    return dict(A=vals[0],Ix=vals[1],Iz=vals[2],Sx=vals[1]/(h/2),Sz=vals[2]/(b/2),b=b,h=h,t=t,
                assumed_outer_corner_radius=r,median_area=(b-t)*(h-t)-(4-math.pi)*max(0,r-t/2)**2)

def stress_section(sec,forces,moments):
    fx,fy,fz=forces;mx,my,mz=moments
    normal=abs(fy)/sec['A']+abs(mx)/sec['Sx']+abs(mz)/sec['Sz']
    shear=abs(fx)/(2*sec['b']*sec['t'])+abs(fz)/(2*sec['h']*sec['t'])+abs(my)/(2*sec['median_area']*sec['t'])
    return dict(normal_MPa=normal,average_shear_sum_MPa=shear,vm_average_shear_screen_MPa=math.sqrt(normal**2+3*shear**2))

B,H=G['beam']['section_outside_xz'];TN=G['beam']['nominal_wall'];TD=TN*.93
SEC=rounded_properties(B,H,TD,3*TN)
UPSEC=rounded_properties(76.2,76.2,TD,3*TN)

def statics(q,mean,roll,mu,direction,actforce,weight_mass=75):
    lo=transform(LOW,q);hh=transform(HEADS,q);drive=transform(DRIVE,q)
    c,a=axle(mean,roll); lv=lever_for_pose(q)
    cols=[]; directions=[]; cp=[]
    for p,anchor in zip(lo,UP):
        u=(anchor-p)/np.linalg.norm(anchor-p);directions.append(u);cols.append(np.r_[u,np.cross(p-ORIGIN,u)])
    for p in hh:
        u,phi,D,rr=head_unit(p,c,a,mu,direction);directions.append(u);cols.append(np.r_[u,np.cross(p-ORIGIN,u)])
        cp.append(dict(phi_deg=math.degrees(phi),axis_to_pin_mm=D,contact_line_residual_mm=rr))
    mat=np.array(cols).T
    af=actforce*lv['output_force_per_input']*lv['output_unit']
    wp=transform(np.array([205,0,300]),q); wf=np.array([0,0,-weight_mass*GRAV])
    ext=np.r_[af+wf,np.cross(drive-ORIGIN,af)+np.cross(wp-ORIGIN,wf)]
    unknown=np.linalg.solve(mat,-ext)
    residual=mat@unknown+ext
    loads=[(p,u*f,'link'+str(i)) for i,(p,u,f) in enumerate(zip(lo,directions[:4],unknown[:4]))]
    loads += [(p,u*f,'head'+str(i)) for i,(p,u,f) in enumerate(zip(hh,directions[4:],unknown[4:]))]
    loads += [(drive,af,'drive'),(wp,wf,'weight')]
    # Beam section resultant: loads beyond cut Y; actual end-bracket loads included.
    # Global axes used; at <=.3deg yaw this is a close screen; local transformation below removes that approximation.
    rot=Rotation.from_rotvec(q[3:]);ctr=ORIGIN+q[:3]
    local=[(rot.inv().apply(p-ctr),rot.inv().apply(f),name) for p,f,name in loads]
    cuts=sorted(set([-450,450,0]+[max(-450,min(450,p[1]+d)) for p,f,n in local for d in(-.01,.01)]))
    best=None
    for cut in cuts:
        rr=np.array([0,cut,0]); ff=np.zeros(3);mm=np.zeros(3)
        for p,f,name in local:
            if p[1]>cut:ff+=f;mm+=np.cross(p-rr,f)
        st=stress_section(SEC,ff,mm)
        row=dict(cut_y_mm=cut,force_N=ff.tolist(),moment_Nmm=mm.tolist(),**st)
        if best is None or st['vm_average_shear_screen_MPa']>best['vm_average_shear_screen_MPa']:best=row
    pinforces=[float(abs(f)*np.linalg.norm(u)) for f,u in zip(unknown,directions)]
    pinforces += [float(np.linalg.norm(af)),float(actforce*lv['input_link_each_per_input'])]
    return dict(link_signed_N=unknown[:4].tolist(),shoe_normal_N=unknown[4:].tolist(),
                shoe_resultant_N=[float(unknown[4+i]*np.linalg.norm(directions[4+i])) for i in range(2)],
                beam_drive_force_N=af.tolist(),condition_number=float(np.linalg.cond(mat)),
                equilibrium_force_residual_N=float(np.max(np.abs(residual[:3]))),
                equilibrium_moment_residual_Nmm=float(np.max(np.abs(residual[3:]))),
                max_pin_resultant_N=max(pinforces),pin_resultants_N=pinforces,
                head_contact_surrogate=cp,beam_peak=best,
                link_vectors_N=[(unknown[i]*directions[i]).tolist() for i in range(4)],
                applied_points_mm=lo.tolist(),head_points_mm=hh.tolist())

def pin_screen(F,d=19.928,span=None):
    span=float(G['hangers']['clevis_reaction_centroid_span']) if span is None else span
    M=F*span/4
    bend=32*M/(math.pi*d**3); shear=F/(2*math.pi*d*d/4)
    return dict(force_N=F,diameter_screen_mm=d,support_centroid_span_mm=span,
                conservative_point_load_bending_Nmm=M,bending_MPa=bend,double_shear_MPa=shear,
                vm_MPa=math.sqrt(bend*bend+3*shear*shear),
                comparison_yield_MPa=1080,comparison_basis='Nominal ISO property class12.9 yield value; supplier certificate, shoulder stress concentration and fatigue remain HOLD')

def member_reactions_and_sections(loads,halfspan,section,solid_diameter=None):
    """Ideal two radial supports; bound torque split rather than invent end stiffness."""
    ff=sum((f for p,f,m in loads),np.zeros(3))
    mm=sum((np.cross(p,f)+m for p,f,m in loads),np.zeros(3))
    left=np.array([(-ff[0]-mm[2]/halfspan)/2,-ff[1],(-ff[2]+mm[0]/halfspan)/2])
    right=np.array([(-ff[0]+mm[2]/halfspan)/2,0,(-ff[2]-mm[0]/halfspan)/2])
    best=None;end_cases=[]
    for frac in(0,.5,1):
      ml=np.array([0,-mm[1]*frac,0]);mr=np.array([0,-mm[1]*(1-frac),0])
      all_loads=loads+[(np.array([0,-halfspan,0]),left,ml),(np.array([0,halfspan,0]),right,mr)]
      cuts=sorted(set([-halfspan+.001,halfspan-.001,0]+[max(-halfspan+.001,min(halfspan-.001,p[1]+d)) for p,f,m in loads for d in(-.001,.001)]))
      for y in cuts:
        force=np.zeros(3);moment=np.zeros(3);point=np.array([0,y,0])
        for p,f,m in all_loads:
          if p[1]>y:force+=f;moment+=np.cross(p-point,f)+m
        if solid_diameter:
          dia=solid_diameter;area=math.pi*dia**2/4
          sig=abs(force[1])/area+32*math.hypot(moment[0],moment[2])/(math.pi*dia**3)
          tau=16*abs(moment[1])/(math.pi*dia**3)+4*math.hypot(force[0],force[2])/(3*area)
          st=dict(normal_MPa=sig,conservative_shear_sum_MPa=tau,vm_MPa=math.sqrt(sig*sig+3*tau*tau))
        else:
          st=stress_section(section,force,moment);st['vm_MPa']=st['vm_average_shear_screen_MPa']
        row=dict(cut_y_mm=y,left_torque_fraction=frac,force_N=force.tolist(),moment_Nmm=moment.tolist(),**st)
        if best is None or st['vm_MPa']>best['vm_MPa']:best=row
      end_cases.append(dict(left_force_N=left.tolist(),right_force_N=right.tolist(),left_moment_Nmm=ml.tolist(),right_moment_Nmm=mr.tolist()))
    return dict(peak=best,end_reactions=end_cases,model='Two radial supports, one axial locator; torque split0/50/100percent sensitivity. Actual attachment stiffness is not established.')

def support_and_shaft(q,F,case):
    upper_origin=np.array(G['upper_support']['centre'],float)
    up_loads=[(p-upper_origin,-np.array(f),np.zeros(3)) for p,f in zip(UP[:3],case['link_vectors_N'][:3])]
    upper=member_reactions_and_sections(up_loads,UPPER_HALFSPAN,UPSEC)
    lv=lever_for_pose(q);shaftloads=[]
    for y in(-130,130):
      p=lv['input_point']+np.array([0,y,0]);f=F*lv['input_link_each_per_input']*lv['input_unit']
      shaftloads.append((p-PIVOT,f,np.zeros(3)))
    shaftloads.append((lv['output_point']-PIVOT,-F*lv['output_force_per_input']*lv['output_unit'],np.zeros(3)))
    shaft=member_reactions_and_sections(shaftloads,SHAFT_HALFSPAN,None,G['crosshead_and_lever']['bellcrank_axis']['shaft_diameter'])
    shaft['superseded_50_8_same_support_peak']=member_reactions_and_sections(shaftloads,SHAFT_HALFSPAN,None,50.8)['peak']
    return upper,shaft

def weld_group(lines,force,forcepoint,leg,free_moment=None):
    """Elastic line weld, effective throat leg/sqrt2; no directional factor."""
    throat=leg/math.sqrt(2);samples=[];area=0;centroid=np.zeros(3)
    for p0,p1 in lines:
      p0=np.array(p0,float);p1=np.array(p1,float);length=np.linalg.norm(p1-p0);aa=length*throat
      area+=aa;centroid+=aa*(p0+p1)/2
      for u in np.linspace(0,1,41):samples.append(p0+u*(p1-p0))
    centroid/=area;J=np.zeros((3,3))
    nodes,weights=np.polynomial.legendre.leggauss(4)
    for p0,p1 in lines:
      p0=np.array(p0,float);p1=np.array(p1,float);aa=np.linalg.norm(p1-p0)*throat
      for u,w in zip((nodes+1)/2,weights/2):
        r=p0+u*(p1-p0)-centroid;J+=aa*w*(np.dot(r,r)*np.eye(3)-np.outer(r,r))
    moment=np.cross(np.array(forcepoint)-centroid,force)+(np.zeros(3) if free_moment is None else free_moment);omega=np.linalg.solve(J,moment)
    peak=max(np.linalg.norm(force/area+np.cross(omega,p-centroid)) for p in samples)
    return dict(leg_mm=leg,throat_mm=throat,effective_area_mm2=area,centroid_mm=centroid.tolist(),moment_Nmm=moment.tolist(),peak_elastic_traction_MPa=peak,
      comparison_MPa=.3*70*6.894757293168361,comparison_basis='E70 fillet-weld ASD nominal0.60Fexx dividedbyOmega2; static comparison only, no fatigue/local-wall qualification')

def plain(obj):
    if isinstance(obj,np.ndarray):return obj.tolist()
    if isinstance(obj,np.generic):return obj.item()
    if isinstance(obj,dict):return {k:plain(v) for k,v in obj.items()}
    if isinstance(obj,(tuple,list)):return [plain(v) for v in obj]
    return obj

def run():
    poses=[]
    definitions=[('level',0,0,(0,0),'operating geometry probe'),('jounce35',35,0,(0,0),'at nominal jounce stop'),
       ('regular_rebound40',-40,0,(0,0),'at regular rebound probe'),('accessible_rebound30',-30,0,(0,0),'at accessible rebound probe'),
       ('captured_drop60',-60,0,(0,0),'abnormal captured-drop sensitivity; not an operating state'),
       ('roll_plus2',0,math.radians(2),(0,0),'explicit axle-roll sensitivity; not an accepted limit'),
       ('roll_minus2',0,math.radians(-2),(0,0),'explicit axle-roll sensitivity; not an accepted limit'),
       ('split_journal_stops',-2.5,math.asin(75/1240),(0,0),'journal ends35/-40; exceeds2deg screening assumption; not accepted'),
       ('wear4_both',0,0,(4,4),'4mm unadjusted lining/head stand-off sensitivity; not an allowed wear limit'),
       ('wear4_one',0,0,(0,4),'differential4mm stand-off sensitivity; not an allowed wear limit')]
    for name,mean,roll,wear,status in definitions:
        q,err=solve_pose(mean,roll,wear)
        lv=lever_for_pose(q);heads=transform(HEADS,q);c,a=axle(mean,roll)
        poses.append(dict(name=name,mean_heave_mm=mean,axle_roll_deg=math.degrees(roll),wear_probe_mm=list(wear),status=status,
          pose_translation_mm=q[:3].tolist(),pose_rotation_vector_deg=np.degrees(q[3:]).tolist(),closure_residual_mm=err,
          journal_heave_mm=[mean-620*math.sin(roll),mean+620*math.sin(roll)],
          wheel_centre_heave_mm=[mean-480*math.sin(roll),mean+480*math.sin(roll)],
          head_tread_axial_offset_mm=[float(np.dot(p-c,a)-s*490) for p,s in zip(heads,(-1,1))],
          beam_yaw_within_0_3_deg=abs(math.degrees(q[5]))<=.3,
          beam_x_within_development_stop=G['beam']['development_x_travel_from_reference'][0]-1e-6<=q[0]<=G['beam']['development_x_travel_from_reference'][1]+1e-6,
          lever=plain(lv),q=q))
    envelopes=[];cases=[]
    pressure_inputs=[('service100_theoretical',100*20*LBF),('service125_theoretical',125*20*LBF),
                     ('combined125_plus_spring1in_upper', (125*20+1280*1.1)*LBF)]
    for p in poses:
      for mu in(.15,.25,.35):
       for direction in(-1,1):
        for pname,F in pressure_inputs:
         s=statics(p['q'],p['mean_heave_mm'],math.radians(p['axle_roll_deg']),mu,direction,F)
         upper,shaft=support_and_shaft(p['q'],F,s)
         s['upper_member_screen']=upper;s['shaft_screen']=shaft
         cases.append(dict(pose=p['name'],load=pname,mu=mu,wheel_rotation_sign=direction,actuator_input_N=F,**s))
    for p in poses:p.pop('q')
    maxbeam=max(cases,key=lambda c:c['beam_peak']['vm_average_shear_screen_MPa'])
    maxpin=max(cases,key=lambda c:c['max_pin_resultant_N'])
    maxhanger=max(cases,key=lambda c:max(abs(x) for x in c['link_signed_N'][:3]))
    maxupper=max(cases,key=lambda c:c['upper_member_screen']['peak']['vm_MPa'])
    maxshaft=max(cases,key=lambda c:c['shaft_screen']['peak']['vm_MPa'])
    nominal=[c for c in cases if c['pose']=='level' and c['load']=='combined125_plus_spring1in_upper' and c['mu']==.35]
    pure=[]
    for travel in(G['beam']['development_x_travel_from_reference'][0],0,10,G['beam']['development_x_travel_from_reference'][1]):
      for yaw in(-.3,0,.3):
       q,err=solve_pose(0,0,travel=travel,yaw=math.radians(yaw));lv=lever_for_pose(q)
       pure.append(dict(x_translation_mm=travel,prescribed_yaw_deg=yaw,closure_residual_mm=err,
         translation_mm=q[:3].tolist(),rotation_vector_deg=np.degrees(q[3:]).tolist(),lever=plain(lv)))
    demand=[]
    for mass in(13200,11000):
      for decel in(.5,.7):
       wheel_torque=1.05*mass*decel*.3/8
       for mu in(.15,.25,.35):
        N=wheel_torque/(.3*mu)
        for ratio in(2,2.5):
          p_req=2*N/(.85*ratio*20*LBF)
          demand.append(dict(mass_kg=mass,deceleration_m_s2=decel,grade=0,mu=mu,nominal_ratio=ratio,
             assumed_efficiency=.85,required_normal_per_wheel_N=N,required_theoretical_pressure_psi=p_req,
             outputs=[dict(pressure_psi=p,normal_per_wheel_N=p*20*LBF*.85*ratio/2,
                torque_per_wheel_Nm=p*20*LBF*.85*ratio/2*mu*.3) for p in(100,125)]))
    # One head at stop is not in the six-equilibrium two-contact solution.
    Fmax=pressure_inputs[-1][1]*2.5
    fault=dict(status='Single-head contact / opposite head missing is NOT qualified. The free-yaw two-contact solution cannot be reused.',
       horizontal_force_probe_N=Fmax,assumed_single_contact_y_mm=490,
       yaw_restraint_moment_Nmm=Fmax*490,stop_force_if900mm_couple_N=Fmax*490/900,
       nominal_weak_axis_bending_if_full_force_reaches_single_head_MPa=Fmax*490/SEC['Sz'],
       note='Actual stop geometry and altered hanger/shaft/weld forces must be established. This is a demand probe, not a failed-part prediction.')
    welds=[]
    # Credit only straight flats for an outer corner radius3tnom; no arc length credit.
    tube_lines=[([180.95,0,461.9],[219.05,0,461.9]),([238.1,0,480.95],[238.1,0,519.05]),([219.05,0,538.1],[180.95,0,538.1]),([161.9,0,519.05],[161.9,0,480.95])]
    plate_lines=[([140,0,350],[285,0,350]),([140,0,350],[140,0,440]),([285,0,350],[285,0,525])]
    for name,lines in [('upper_HSS_to_endplate',tube_lines),('endplate_to_sideweb_three_supported_edges',plate_lines)]:
      best=None
      for c in cases:
       for r in c['upper_member_screen']['end_reactions']:
        for side in('left','right'):
         offset_y=(1 if side=='left' else -1)*G['upper_support']['endplates']['thickness'] if name.startswith('endplate_') else 0
         w=weld_group(lines,-np.array(r[side+'_force_N']),[200,offset_y,500],6,-np.array(r[side+'_moment_Nmm']))
         w.update(case_pose=c['pose'],case_load=c['load'],mu=c['mu'],rotation_sign=c['wheel_rotation_sign'],side=side)
         if best is None or w['peak_elastic_traction_MPa']>best['peak_elastic_traction_MPa']:best=w
      welds.append(dict(name=name,paths_x_y_z_local_mm=lines,physical_y_planes_mm=G['upper_support']['endplates']['inside_web_y'] if name.startswith('endplate_') else G['upper_support']['span_y'],peak=best,
        status='PROPOSED WELD PATH accepted as candidate metadata only; final CAD contains fit-up bolts but not a completed webpatch/weld connection. No upper-edge weld credited above the sideweb.',
        limits='Weld preparation/access, actual corner weld length, filler/WPS, endplate bending, local HSS wall/sideweb distortion and fatigue are not qualified. Upper support loads only; actuator/shaft frame loads are separate.'))
    hanger=max(max(abs(x) for x in c['link_signed_N'][:3]) for c in cases)
    link_t=float(G['hangers']['link_plate_thickness'])
    linkgross=dict(force_N=hanger,eye_OD_mm=55,bearing_OD_mm=35,plate_thickness_mm=link_t,
      net_tension_MPa=hanger/((55-35)*link_t),two_plane_shearout_MPa=hanger/(2*(55-35)/2*link_t),
      bearing_outer_ring_projected_MPa=hanger/(35*12),status='Nominal gross eye screen; machined housing fits, grooves, retention and stress concentration are not included.')
    groups=[]
    for pname,F in pressure_inputs:
      cc=[c for c in cases if c['load']==pname]
      groups.append(dict(load=pname,input_N=F,main_beam_max_vm_MPa=max(c['beam_peak']['vm_average_shear_screen_MPa'] for c in cc),
        upper_member_max_vm_MPa=max(c['upper_member_screen']['peak']['vm_MPa'] for c in cc),
        shaft_max_vm_MPa=max(c['shaft_screen']['peak']['vm_MPa'] for c in cc),
        main_beam_normal_reversal_range_upper_bound_MPa=2*max(c['beam_peak']['normal_MPa'] for c in cc)))
    result=dict(issue='C5.2 mechanics development screen',geometry_revision=G['revision'],
       geometry_sha256=hashlib.sha256(G_BYTES).hexdigest(),
       geometry_reconciliation=dict(shaft_bearing_centres_y_mm=[-SHAFT_HALFSPAN,SHAFT_HALFSPAN],shaft_bearing_source='build_c52.py PIVOT-HOUSING and PIVOT-BUSH centreline',cad_source_sha256=hashlib.sha256(CAD_BYTES).hexdigest(),upper_member_end_y_mm=G['upper_support']['span_y'],hanger_plate_mm=G['hangers']['link_plate_thickness'],pin_centroid_span_mm=G['hangers']['clevis_reaction_centroid_span']),
       independent_release_failure=dict(source='independent-review.json',source_sha256=hashlib.sha256(REVIEW_BYTES).hexdigest(),configured_retraction_mm=REVIEW['decisive_failure']['configured_retraction_mm'],ordinary_rebound_witness=REVIEW['decisive_failure']['zero_roll_zero_yaw_zero_lateral_working_rebound_witness'],status='FAILED / BLOCKING; no axle-roll, lateral-offset or beam-yaw sensitivity needed for this witness'),
       status='CONDITIONAL APPLIED-CONTACT SCREEN / UNRATED / NOT FABRICATION RELEASED',
       basis=dict(pressure_psi=[100,125],nominal_type20_area_in2=20,
         pressure_output_status='P times nominal area is an analytical sensitivity, not MGM rated output or a certified upper bound. Maximum permissible pressure and force at stroke below1in are unresolved.',
         spring_probe_lbf=1280*1.1,spring_probe_stroke_in=1,
         spring_source_status='MGM indexed current catalogue nominal1280lbf at1in plus10percent tolerance; not maximum across full stroke.',
         compounding='Combined service plus spring screened because anti-compounding is not established; this does not bound all credible output.',
         structural_efficiency_credit=1.0,moving_assembly_weight_probe_kg=75,weight_CG_reference_mm=[205,0,300],
         weight_status='Analyst probe pending CAD mass; no spring-centering force credited or included.',
         material_comparison=dict(HSS='ASTM A500 Grade C candidate; supplier certification HOLD',Fy_MPa=345,elastic_comparison_MPa=345/1.67,
         comparison_status='Elastic static screening comparison only, not a railway acceptance criterion')),
       beam_section=dict(**SEC,nominal_wall_mm=TN,design_wall_mm=TD,
         notes='Rounded section integrated with assumed outercorner3tnom and innercornerRout−tdesign; actual corner/catalogue properties and stock procurement remain HOLD. No holes deducted.'),
       upper_support_section=UPSEC,demand_pressure_sensitivities=demand,finite_contact_poses=poses,
       pure_motion_poses=pure,case_count=len(cases),cases=cases,
       summary=dict(max_beam_vm_case=maxbeam,max_pin_case=maxpin,max_hanger_case=maxhanger,
         max_upper_member_case=maxupper,max_shaft_case=maxshaft,
         max_upper_member_vm_MPa=maxupper['upper_member_screen']['peak']['vm_MPa'],
         max_shaft_vm_MPa=maxshaft['shaft_screen']['peak']['vm_MPa'],
         max_beam_vm_MPa=maxbeam['beam_peak']['vm_average_shear_screen_MPa'],
         max_beam_normal_MPa=max(c['beam_peak']['normal_MPa'] for c in cases),
         max_link_abs_N=[max(abs(c['link_signed_N'][i]) for c in cases) for i in range(4)],
         max_shoe_normal_N=max(max(c['shoe_normal_N']) for c in cases),
         min_shoe_normal_N=min(min(c['shoe_normal_N']) for c in cases),
         max_equilibrium_force_residual_N=max(c['equilibrium_force_residual_N'] for c in cases),
         max_equilibrium_moment_residual_Nmm=max(c['equilibrium_moment_residual_Nmm'] for c in cases),
         beam_cases_over_elastic_comparison=sum(c['beam_peak']['vm_average_shear_screen_MPa']>345/1.67 for c in cases),
         negative_shoe_contact_cases=sum(min(c['shoe_normal_N'])<0 for c in cases)),
       pin_screen=pin_screen(maxpin['max_pin_resultant_N']),single_head_stop_probe=fault,
       nominal_pin_stack=dict(bearing_inner_width_mm=16,spacers_each_mm=4,cheeks_each_mm=8,washer_mm=2.5,clamped_stack_mm=42.5,maximum_shoulder_length_mm=40.25,washer_bore_mm=20.5,nominal_stack_exceeds_shoulder_by_mm=2.25,status='Nominal shoulder bottoming avoided; controlled tolerances, actual fillets, torque and qualified locking remain HOLD. M4 retainer rings retain the bearing outer race only and are not the brake-force path.'),
       applied_load_group_summary=groups,proposed_weld_screens=welds,hanger_eye_gross_screen=linkgross,
       shaft_comparison=dict(diameter_mm=G['crosshead_and_lever']['bellcrank_axis']['shaft_diameter'],
         bearing_centres_y_mm=[-SHAFT_HALFSPAN,SHAFT_HALFSPAN],
         superseded_50_8_same_load_and_support_VM_MPa=max(c['shaft_screen']['superseded_50_8_same_support_peak']['vm_MPa'] for c in cases),
         superseded_50_8_status=f'Rejected gross comparison under the same current{2*SHAFT_HALFSPAN:.0f}mm bearing span; previous305.771MPa result used the superseded320mm assumed bearing span.',
         assumed_material_yield_MPa=345,elastic_comparison_MPa=345/1.67,
         maximum_VM_MPa=maxshaft['shaft_screen']['peak']['vm_MPa'],
         comparison_exceeded=maxshaft['shaft_screen']['peak']['vm_MPa']>345/1.67,
         limitation='Shaft grade/condition, keyways, clamping hubs, fretting and fatigue are not qualified. The345MPa value is an analyst comparison, not a documented1045 property.'),
       fatigue_screen=dict(status='NO FATIGUE LIFE OR ACCEPTED DETAIL CATEGORY',
         method='Report nominal gross stress scales and a conservative reversal-range upper bound2timesmaxabsolute normal stress. No stress concentration, weld category, measured cycle spectrum or damage sum is available.',
         consequences='On/off service, opposite rotation, parking load persistence, impacts and released-head interference need distinct spectra. Passing a static catalogue or gross-section comparison does not establish durability.'),
       failure_and_hold_flags=[{'id':'released_head_contact','status':'FAILED / BLOCKING','reason':'Independent full-arc check gives9.850688mm tread intrusion at ordinary40mm rebound,5mm retraction, zero axle roll/lateral offset/beam yaw. Centre-distance closure is not a release-clearance proof.'},
         {'id':'stock_shoe_wheel_pair','status':'HOLD / BLOCKING','reason':'No compatible stock friction insert and finished wheel profile selected.'},
         {'id':'credible_actuator_output','status':'HOLD / BLOCKING','reason':'MGM maximum operating pressure and spring output below1in stroke are not established; current combined load is a conditional probe.'},
         {'id':'shaft_elastic_comparison','status':'FAILED' if maxshaft['shaft_screen']['peak']['vm_MPa']>345/1.67 else 'CONDITIONAL GROSS SCREEN ONLY','reason':'See shaft comparison; hubs, keyways and fatigue remain open.'},
         {'id':'actual_mount_and_weld_path','status':'HOLD','reason':'Proposed weld paths are screened separately; adopted geometry, local walls and actuator/shaft frame attachment still require matching checks.'},
         {'id':'single_head_stop','status':'HOLD / COMPARISON EXCEEDED','reason':'Single-head contact changes load path and imposes21.3kNm yaw-restraint probe; two-head equilibrium does not qualify stops.'}],
       nominal_combined_cases=nominal,
       limitations=['RELEASED HEAD CLEARANCE IS NOT ESTABLISHED: neutral head centering can cause toe/heel interference during wheel heave despite positive nominal centre gap. No release-state pass is implied.',
       'No compatible friction insert has been selected; circular reference contact is an analytical surrogate.',
       'Point contact/resultant surrogate checks seating moments, not pressure distribution or lining stress.',
       'Hanger forces may reverse; all links must carry compression and tension.',
       'Head centering springs, return springs and travel-stop forces require actual parts and force curves.',
       '75kg deadweight is separate from final CAD mass; gravity and actuator inclination are included.',
       'Combined bending plus average shear/torsion screen is not a local-wall, buckling, notch, weld or fatigue proof.',
       'One-shoe contact at a yaw stop is a different load path; stop detail and contact loss remain open.',
       'Axle roll probes are generated from one axle line; journal travel and wheel-centre travel are not interchanged.',
       'No brake adhesion, thermal endurance, stopping-distance, parking-grade or vehicle safety rating is assigned.'],
       sources=[{'url':'https://steeltubeinstitute.org/resources/astm-a500/','supports':'A500 Grade C50ksi yield;0.93 designwall'},
        {'url':'https://www.aisc.org/globalassets/continuing-education/quiz-handouts/specifying-hss-article.pdf','supports':'A500 designwall context; not railqualification'},
        {'url':'https://live-catalog.jwwinco.com/pdf/winco/US/7379.pdf?dispositiontype=attachment','supports':'Shoulderpin dimensions/class12.9 and torque caution'},
        {'path':'actuator-evidence.json','supports':'MGM catalogue evidence/unknown pressure and force limits'},
        {'path':'joint-components.json','supports':'Spherical bearing and shoulder pin candidates'}])
    return plain(result)

def write_markdown(out):
    s=out['summary']; comparison=345/1.67
    rows=[]
    for q in out['applied_load_group_summary']:
      rows.append(f"| {q['load']} | {q['input_N']/1000:.3f} | {q['main_beam_max_vm_MPa']:.1f} | {q['upper_member_max_vm_MPa']:.1f} | {q['shaft_max_vm_MPa']:.1f} |")
    demands=[]
    for r in out['demand_pressure_sensitivities']:
      if r['mass_kg']==13200 and r['deceleration_m_s2']==.7:
       demands.append(f"| {r['mu']:.2f} | {r['nominal_ratio']:.1f}:1 | {r['required_normal_per_wheel_N']/1000:.3f} | {r['required_theoretical_pressure_psi']:.1f} | {r['outputs'][0]['normal_per_wheel_N']/1000:.3f} | {r['outputs'][1]['normal_per_wheel_N']/1000:.3f} |")
    motions=out['pure_motion_poses'];minimum=min(p['lever']['stroke_mm'] for p in motions);maximum=max(p['lever']['stroke_mm'] for p in motions)
    welds='\n'.join(f"| {w['name']} | {w['peak']['peak_elastic_traction_MPa']:.1f} | {w['peak']['comparison_MPa']:.1f} |" for w in out['proposed_weld_screens'])
    text=f'''# C5.2 conditional applied-contact mechanics — {out['geometry_revision']}

**UNRATED. Not released for fabrication or service.** The applied-force model is useful for sizing, but it does not establish a working brake. Independent full-arc checks found released-head/tread-flange interference. No compatible stock shoe and finished wheel profile have been selected. The maximum credible MGM output is also unresolved. At the ordinary40 mm rebound,5 mm configured retraction and zero axle roll, lateral offset and beam yaw, the independent reference-face check finds **{abs(out['independent_release_failure']['ordinary_rebound_witness']['gap_mm']):.3f} mm tread intrusion**.

This report reads `geometry-contract.json`, hash `{out['geometry_sha256']}`. `calculate_mechanics.py` reproduces the JSON and this note with Python, NumPy and SciPy. Geometry may subsequently strengthen or relocate a part; that change must be matched to a new calculation before a screen is reused.

## What was calculated

The reference axle is X600/Z300 mm. One chamber operates two articulated heads through a guided crosshead, twin input links, a 250/100 mm crank and one output link. The output link attaches at the beam lug X270/Z300; its inclination produces a downward force as well as application force. At nominal geometry, horizontal beam force is 2.5 times chamber force and downward force is 0.384615 times chamber force.

The beam uses a candidate 8×3×1/4-inch HSS, 900 mm long, centred X200/Z300. The upper support is candidate 3×3×1/4-inch HSS. Grade C, supplier, availability and actual section properties remain procurement holds. Calculations use 0.93×6.35 = 5.9055 mm design wall, plus an assumed outer corner radius 3×nominal wall. Both bending inertias and rounded median torsion area are integrated. Holes, local brackets and weld notches are not included in the gross section.

Four fixed-length spherical links constrain the beam: three hangers and one lateral locator. Finite closure allows longitudinal application and small yaw; the beam therefore approximately equalizes the two contacts. It is not forced to carry exactly half the load at each head. Head seating uses distance perpendicular to one actual axle line. Journal travel at Y±620 and wheel-centre travel at Y±480 are recorded separately. Rotation outputs are rotation vectors, not Euler angles.

There are {out['case_count']} applied-contact cases: three friction coefficients, both wheel-rotation directions and three input probes over ten geometry cases. These include ordinary heave cases and explicitly labelled captured-drop, axle-roll, split-stop and differential-wear sensitivities. They are not all approved operating states. A 75 kg moving-assembly gravity probe is included at reference X205/Z300, pending final CAD mass. Centering/return spring forces are not included because their parts and force curves are unresolved.

The six signed equilibrium unknowns are four link forces and two shoe normals. Maximum checked force residual is {s['max_equilibrium_force_residual_N']:.2g} N; moment residual is {s['max_equilibrium_moment_residual_Nmm']:.2g} N·mm. Negative link force means compression. All hangers must carry both signs. The circular head-resultant surrogate balances moment about the head pin; it does not prove lining pressure distribution, edge contact or the released shape.

## Pressure and actuator limits

Type20 area × assumed pressure gives 8.896 kN at100 psi and11.121 kN at125 psi. **These are theoretical sensitivities, not rated MGM output or a certified upper bound.** The combined probe adds the published nominal1-inch spring point1280 lbf with its +10% tolerance: total17.384 kN input. Spring output below1 inch and maximum permitted operating pressure remain unverified. Anti-compounding is not established, so simultaneous service and spring application is explicitly probed. Efficiency is not credited to reduce structural load.

D2 motion from−5 to+15 mm, including yaw±0.3°, requires approximately {maximum-minimum:.2f} mm of the57.15 mm chamber stroke. That is only a linkage closure result. It does not clear the released shoe or establish a valid rod-cut/setup dimension. Depending on setup, nominal contact can occur below the first published1-inch spring point; that published value cannot be treated as the maximum spring force.

For the13,200 kg coach at0.7 m/s², level track,600 mm wheels and assumed1.05 rotating-mass factor, wheel torque demand is363.825 N·m. The table uses an **assumed85% linkage efficiency** for demand only. It does not include a grade, route duty or adhesion qualification.

| Block friction μ | Nominal ratio | Required normal/wheel, kN | Required theoretical pressure, psi | Normal/wheel at100 psi, kN | At125 psi, kN |
|---|---:|---:|---:|---:|---:|
{chr(10).join(demands)}

The JSON also contains11,000 kg and0.5 m/s² cases. Actual friction is a property of the selected block/wheel pair and conditions; it is not a chosen constant that establishes performance.

## Conditional gross member screens

| Input probe | Input, kN | Main-beam VM screen, MPa | Upper-support VM screen, MPa | Crankshaft VM screen, MPa |
|---|---:|---:|---:|---:|
{chr(10).join(rows)}

The HSS comparison is345/1.67 = {comparison:.1f} MPa, an elastic static screening convention, not railway acceptance criteria. Main-beam and upper-support values combine biaxial normal stress with a conservative sum of average shear and closed-cell torsional shear. Local wall bending, buckling, holes and welded-detail fatigue remain open. Upper-support end torsion is checked with0/50/100% distribution; actual connection stiffness is not asserted.

The frozen D2 {out['shaft_comparison']['diameter_mm']:.1f} mm shaft, with actual bearing centresY±{SHAFT_HALFSPAN:.0f} mm, reaches {s['max_shaft_vm_MPa']:.1f} MPa before keyways and notches: {'above' if out['shaft_comparison']['comparison_exceeded'] else 'below'} the {comparison:.1f} MPa gross-section comparison. The superseded50.8 mm candidate under the same loads and current support spacing reaches {out['shaft_comparison']['superseded_50_8_same_load_and_support_VM_MPa']:.1f} MPa and is rejected by that comparison. The earlier305.8 MPa result used an assumed320 mm bearing span; current CAD has{2*SHAFT_HALFSPAN:.0f} mm. Material, hubs, keys, bearing attachments and fatigue remain open. The revised shaft supports atY±205 require a new support-top-plate transition to the existing rails; that local connection is not qualified by this shaft screen. The comparison uses an assumed345 MPa yield; no unsupported1045 strength is claimed.

Peak absolute hanger forces are {s['max_link_abs_N'][0]/1000:.2f}, {s['max_link_abs_N'][1]/1000:.2f} and {s['max_link_abs_N'][2]/1000:.2f} kN; lateral locator peak is{s['max_link_abs_N'][3]/1000:.3f} kN. The third hanger's asymmetric location and the inclined driven link create a substantial pitch reaction. A55 mm eye with35 mm bearing bore in{out['hanger_eye_gross_screen']['plate_thickness_mm']:.0f} mm plate has a nominal net stress of{out['hanger_eye_gross_screen']['net_tension_MPa']:.1f} MPa; machined grooves, fit, retention and eye stress concentration are not included.

The maximum pivot load is{out['pin_screen']['force_N']/1000:.2f} kN. A19.928 mm minimum-diameter screen with{out['pin_screen']['support_centroid_span_mm']:.0f} mm clevis support-centroid span gives{out['pin_screen']['bending_MPa']:.1f} MPa bending plus{out['pin_screen']['double_shear_MPa']:.1f} MPa double-shear stress, or{out['pin_screen']['vm_MPa']:.1f} MPa VM. Bending is not omitted. This assumes full shoulder material through both shear planes; actual grip, shoulder fillets, tightening limit, retention and fatigue remain to be matched. The nominal pin stack is16 mm bearing inner ring + two4 mm spacers + two8 mm cheeks +2.5 mm washer =42.5 mm, exceeding the40.25 mm maximum shoulder by2.25 mm; the20.5 mm washer bore clears the shoulder tip. Nominal bottoming is addressed, while controlled fits, tightening and locking remain HOLD. The sixM4 eye-retainer screws retain the outer race and are not assigned the primary brake-force path. Catalogue bearing radial static limit146 kN is not a fabricated-joint allowable load.

## Proposed weld details and remaining load path

The following are **proposed paths accepted as candidate metadata only; final CAD has fit-up bolts but no completed webpatch/weld connection**, using6 mm E70 fillets and an elastic line-weld model. The HSS-end screen credits only straight flats, excluding rounded corner arcs. Endplate-to-sideweb paths run along X140..285/Z350, X140/Z350..440 and X285/Z350..525. No weld is credited at the free top edgeZ550, which lies above the sideweb. The HSS weld planes areY±526 and the web planesY±538. The endplate-to-web screen includes the12 mm offset between those planes. Upper-member bending uses the1052 mm actual tube-end span.

| Proposed joint | Peak elastic weld traction, MPa | Static comparison, MPa |
|---|---:|---:|
{welds}

These weld figures cover the upper hanger support reactions only. They do not establish the actuator bracket, crankshaft-bearing supports, hanger clevis-to-HSS local walls or sideframe fatigue capacity. Actual weld access, fit-up, filler/WPS, local plate bending and member wall checks remain necessary. The mechanism must not be described as having a complete verified mounting load path while these joints are open.

## Blocking cases and fatigue

A single head contacting while the other is absent or held clear is a different load path. The combined probe requires21.3 kN·m of yaw restraint; a900 mm restraint couple would carry23.7 kN. A simple full-force single-head bending probe gives270.3 MPa in the main beam, above the elastic comparison. No capacity is assigned to the stops or catchers. A drop catcher does not preserve a functioning brake after a reaction-path failure.

The reported stress levels are not a fatigue-life result. The JSON includes nominal reversal-range upper bounds, but no accepted weld category, stress concentration, service cycle count or damage sum. Repeated service stops, reverse-direction braking, persistent parking load, shocks and released-head interference need separate treatment. The present released-head interference and incompatible stock shoe/wheel interface are blocking findings, regardless of favourable gross-member numbers.

## Traceable inputs

- [Versioned geometry contract](geometry-contract.json), [full calculations](mechanics-calculations.json), [reproduction script](calculate_mechanics.py).
- [Actuator evidence](actuator-evidence.json), [joint component candidates](joint-components.json), [independent release review](independent-review.json).
- [Steel Tube Institute A500 guidance](https://steeltubeinstitute.org/resources/astm-a500/) supports Grade C and design-wall convention; it does not establish rail acceptance.
- [JW Winco ISO7379 sheet](https://live-catalog.jwwinco.com/pdf/winco/US/7379.pdf?dispositiontype=attachment) provides the shoulder-screw dimensions/class and warns against setting torque from property class alone.
- [Timken/Aurora spherical-bearing catalogue](https://cad.timken.com/en/viewitems/metric-spherical-bearings/es-2rs-spherical-plain-bearings-metric-open-sealed) provides the component geometry and radial static limit, not an assembly rating.
'''
    (BASE/'mechanics-calculations.md').write_text(text)

if __name__=='__main__':
    out=run();(BASE/'mechanics-calculations.json').write_text(json.dumps(out,indent=2))
    write_markdown(out)
    print(json.dumps({k:out['summary'][k] for k in ['max_beam_vm_MPa','max_beam_normal_MPa','max_link_abs_N','max_shoe_normal_N','min_shoe_normal_N','beam_cases_over_elastic_comparison','negative_shoe_contact_cases']},indent=2))
    print('pin',out['pin_screen'])
    print('motion',[(p['x_translation_mm'],p['prescribed_yaw_deg'],p['lever']['stroke_mm']) for p in out['pure_motion_poses']])
