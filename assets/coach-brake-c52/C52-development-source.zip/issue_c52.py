"""Issue cached C52 development CAD with selected unchanged C5 context.
Run build_c52.py first. No fitted brake or release-clearance claim is made.
"""
from pathlib import Path
import json,gzip,copy,math
import cadquery as cq
from OCP.BRepTools import BRepTools
import numpy as np
from scipy.spatial.transform import Rotation
H=Path(__file__).resolve().parent;B=H.parent/'coach-truck-c5';OUT=H.parents[1]/'dist/assets/coach-brake-c52';MM=25.4
M={p['id']:p for p in json.loads((H/'parts.json').read_text())};S=dict(zip(M,list(cq.importers.importBrep(str(H/'checkpoint.brep')).val())))
def bounds(s):
 b=s.BoundingBox();return {a:[getattr(b,a+'min'),getattr(b,a+'max')]for a in'xyz'}
# Backfill the explicitly requested washer addition when issuing the prior frozen330-part checkpoint.
for side in[-1,1]:
 for x in[160,250]:
  for z in[370,410]:
   for label,wy in [('HEAD',523 if side>0 else -526),('NUT',550 if side>0 else -553)]:
    k=f'SUPPORT-WASHER-{label}-{side}-{x}-{z}'
    if k in S:continue
    s=cq.Solid.makeCylinder(15,3,cq.Vector(x,wy,z),cq.Vector(0,1,0)).cut(cq.Solid.makeCylinder(8.75,3,cq.Vector(x,wy,z),cq.Vector(0,1,0)))
    S[k]=s;M[k]={'id':k,'group':'hardware','material':'Steel washer candidate','kinematics':'fixed','definition':{'nominal':'M16flatwasher30OD/17.5ID/3thick; fills nominalclampstackgap'},'bounds_mm':bounds(s),'volume_mm3':s.Volume(),'mass_kg':s.Volume()*7850e-9,'catalogue_reference_only':False}
(H/'parts.json').write_text(json.dumps(list(M.values()),indent=2));cq.exporters.export(cq.Compound.makeCompound(list(S.values())),str(H/'checkpoint.brep'))
BM={p['id']:p for p in json.loads((B/'parts.json').read_text())};BS=dict(zip(BM,list(cq.importers.importBrep(str(B/'checkpoint.brep')).val())))
contextids=['A2L-WHEEL-BLANK','A2R-WHEEL-BLANK','SF-L-WEB2','SF-R-WEB1']+[k for k in BS if k.startswith('CB-')and'WELD'not in k]
contextids+=['CTX-CROSS609.6','CTX-BODY-BOLSTER']
for k in contextids:
 s=BS[k];i='C5-REFERENCE-'+k;role='Unmodified C5 reference. Short axle not issued. Context is not newC52 fabrication.'
 if k in ['SF-L-WEB2','SF-R-WEB1']:
  for x in[160,250]:
   for z in[370,410]:s=s.cut(cq.Solid.makeCylinder(8.75,1600,cq.Vector(x,-800,z),cq.Vector(0,1,0)))
  role='C5 web with proposed four17.5mm supportboltholes atX160/250,Z370/410. SourceC5 unchanged; localweb/hole/weld strength HOLD.'
 S[i]=s
 M[i]={'id':i,'group':'retained-C5-reference','material':'Retained C5 context only','kinematics':'fixed','definition':{'source_id':k,'role':role},'bounds_mm':bounds(s),'volume_mm3':s.Volume(),'mass_kg':None,'catalogue_reference_only':True}
colors={'fixed-support':'#8595a3','moving-beam':'#d18f3c','fabricated-link':'#a8b4bd','head-carrier':'#329878','friction-reference':'#cf5f4d','actuator-reference':'#8b7bac','maintenance-reference':'#cc77aa','spring-reference':'#bb66aa','retained-C5-reference':'#9aada3'}
model={'schemaVersion':3,'units':'inches','title':'C52 D2 / FAILED RELEASE-FIT / one axle development module','coordinate_system':'Source mm converted to inches; X coach longitudinal, Y across track, Z upward; positive axle centre(600,0,300)mm. Nominal appliedreference only.','parts':[],'groups':[],'notes':['FAILED RELEASE/FIT. Reference friction insert is unselected and neutral released heads collide at bounded suspension cases.','One axle module only. Selected unchanged C5 wheels/webs/crossbeam/bodymembers are grey reference.','Incomplete locator, actuator yoke, spring, stop, shaft retention and weld details are explicit development interfaces.']}
for k,s in S.items():
 BRepTools.Clean_s(s.wrapped)
 vv,ff=s.tessellate(1.5,.4);g=M[k]['group'];b={a:[v/MM for v in M[k]['bounds_mm'][a]]for a in'xyz'}
 model['parts'].append({'id':k,'name':k.replace('-',' '),'group':g,'color':colors.get(g,'#9ba7ae'),'opacity':.22 if g=='retained-C5-reference'else .5 if 'reference'in g else 1,'display_only':M[k]['catalogue_reference_only'],'positions':[round(v/MM,5)for p in vv for v in[p.x,p.y,p.z]],'indices':[j for f in ff for j in f],'bounds_in':b,'centre_in':[sum(b[a])/2 for a in'xyz'],'dimensions_xyz_in':[b[a][1]-b[a][0]for a in'xyz'],'metadata':{'definition':M[k]['definition'],'material':{'candidate':M[k]['material']},'kinematics':M[k]['kinematics'],'solid_mass_kg':M[k]['mass_kg'],'engineering_status':'FAILED RELEASE/FIT DEVELOPMENT; NOT RELEASED'}})
explode={'moving-beam':[0,0,-2],'fabricated-link':[0,0,2],'head-carrier':[2,0,0],'friction-reference':[4,0,0],'hardware':[0,3,0],'purchased-bearing':[0,2,0],'bearing-retainer':[0,2.5,0],'lever':[1,0,-2],'crosshead':[2,0,1]}
model['groups']=[{'id':g,'label':g.replace('-',' '),'explosion_vector_in':explode.get(g,[0,0,0]),'default_visible':True}for g in sorted(set(m['group']for m in M.values()))]
model['notes'].append('Exploded view uses illustrative group separation only; it is not an assembly sequence or clearance proof.')
with gzip.open(OUT/'model-applied.json.gz','wt',compresslevel=9)as f:json.dump(model,f,separators=(',',':'))
print('MESH',len(model['parts']),flush=True)
# Exact finite rigid-link transformations from independent closure, without assumed released head tracking.
K=json.loads((H/'kinematics.json').read_text());I=np.eye(3)
def tr(R=I,t=(0,0,0)):
 A=np.eye(4);A[:3,:3]=R;A[:3,3]=np.asarray(t)/MM;return [round(x,10)for x in A.T.flatten()]
def about(R,o,n):return tr(R,np.asarray(n)-R@np.asarray(o))
def between(a,b,c,d):
 a,b,c,d=map(np.asarray,[a,b,c,d]);u=(b-a)/np.linalg.norm(b-a);v=(d-c)/np.linalg.norm(d-c);cross=np.cross(u,v);ss=np.linalg.norm(cross);co=np.dot(u,v)
 R=I if ss<1e-12 else Rotation.from_rotvec(cross/ss*math.atan2(ss,co)).as_matrix()
 return about(R,a,c)
stateout=[]
for st in K['states']:
 R=np.array(st['rotation_matrix']);origin=st['beam_origin_mm'];beam=about(R,[200,0,300],origin);ang=st['bellcrank_angle_rad'];RL=Rotation.from_euler('y',ang).as_matrix();lever=about(RL,[400,0,180],[400,0,180]);cross=tr(I,[st['crosshead_x_mm']-535,0,0]);tf={}
 for k,m in M.items():
  kin=m['kinematics'];a=tr()
  if kin=='beam'or kin.startswith('head'):a=beam
  elif kin=='lever':a=lever
  elif kin=='crosshead':a=cross
  elif kin.startswith('hanger'):
   idx=int(kin[-1])-1;p0=[130,-350,300]if idx==0 else[130,350,300]if idx==1 else[270,250,300]
   p1=[p0[0],p0[1],450];a=between(p0,p1,st['hanger_lower_mm'][idx],p1)
  elif kin.startswith('input'):
   y=float(kin[5:]);end=st['bellcrank_input_centre_mm'];a=between([400,y,430],[535,y,430],[end[0],y,end[2]],[st['crosshead_x_mm'],y,430])
  elif kin=='output':a=between([270,0,300],[400,0,280],st['beam_drive_mm'],st['bellcrank_output_mm'])
  elif kin=='locator':a=between([130,0,240],[130,-400,240],st['locator_moving_mm'],st['locator_fixed_mm'])
  tf[k]=a
 stateout.append({'name':st['name'],'beam_x_mm':st['prescribed_x_translation_mm'],'yaw_deg':st['prescribed_yaw_deg'],'piston_mm':st['piston_position_from_nominal_zero_mm'],'part_transforms':tf})
with gzip.open(OUT/'model-states.json.gz','wt',compresslevel=9)as f:json.dump({'base_model':'model-applied.json.gz','matrix_order':'column-major, translations in inches','status':'Beam/link kinematics only; head pose stays neutral with beam. This intentionally does NOT invent axle-following release behavior.','states':stateout},f,separators=(',',':'))
assembly=cq.Assembly(name='C52_D2_FAILED_FIT_DEVELOPMENT_WITH_C5_REFERENCE')
for k,s in S.items():assembly.add(s,name=k)
assembly.save(str(H/'C52-module-D2.step'))
with(H/'C52-module-D2.step').open('rb')as fi,gzip.open(OUT/'C52-module-D2.step.gz','wb',compresslevel=9)as fo:fo.write(fi.read())
(H/'context-record.json').write_text(json.dumps({'source':'../coach-truck-c5/checkpoint.brep','source_ids':contextids,'module_part_count':len(S)-len(contextids),'reference_part_count':len(contextids),'state_count':len(stateout),'status':'FAIL; C5web context has proposed4holes each,baseC5unchanged; oneaxlemodule only'},indent=2))
print('ISSUED',len(S),flush=True)
