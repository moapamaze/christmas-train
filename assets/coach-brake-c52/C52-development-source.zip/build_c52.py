"""C52 development solids. Purchased envelopes are explicitly marked; no fabricated OEM internals."""
from pathlib import Path
import json,math,gzip,hashlib,time
import cadquery as cq
import numpy as np
H=Path(__file__).resolve().parent; B=H.parent/'coach-truck-c5'; OUT=H.parents[1]/'dist/assets/coach-brake-c52';OUT.mkdir(parents=True,exist_ok=True)
P=json.loads((H/'geometry-contract.json').read_text());S={};M={};MM=25.4
def box(x,y,z):return cq.Solid.makeBox(x[1]-x[0],y[1]-y[0],z[1]-z[0],cq.Vector(x[0],y[0],z[0]))
def cyl(r,L,p,axis=(0,0,1)):return cq.Solid.makeCylinder(r,L,cq.Vector(*p),cq.Vector(*axis))
def ring(od,di,L,p,axis=(0,0,1)):return cyl(od/2,L,p,axis).cut(cyl(di/2,L,p,axis))
def bounds(s):
 b=s.BoundingBox();return {a:[getattr(b,a+'min'),getattr(b,a+'max')]for a in'xyz'}
def add(k,g,s,d=None,mat='Steel development stock',kin='fixed',density=7850,proxy=False):
 assert s.isValid(),k
 S[k]=s;M[k]={'id':k,'group':g,'material':mat,'kinematics':kin,'definition':d or{},'bounds_mm':bounds(s),'volume_mm3':s.Volume(),'mass_kg':None if proxy else s.Volume()*density/1e9,'catalogue_reference_only':proxy}
def tube_y(w,h,t,L,c):
 x,y,z=c;outer=box([x-w/2,x+w/2],[y-L/2,y+L/2],[z-h/2,z+h/2]);inner=box([x-w/2+t,x+w/2-t],[y-L/2-1,y+L/2+1],[z-h/2+t,z+h/2-t]);return outer.cut(inner)
def tube_x(w,h,t,xr,y,z):return box(xr,[y-w/2,y+w/2],[z-h/2,z+h/2]).cut(box([xr[0]-1,xr[1]+1],[y-w/2+t,y+w/2-t],[z-h/2+t,z+h/2-t]))
def rod(r,a,b):
 v=cq.Vector(*b)-cq.Vector(*a);return cyl(r,v.Length,a,v.normalized().toTuple())
def xz_poly(points,y,t):return cq.Workplane(cq.Plane(origin=(0,y,0),xDir=(1,0,0),normal=(0,-1,0))).polyline(points).close().extrude(-t).val()
def hole_y(s,p,dia,L=100):return s.cut(cyl(dia/2,L,(p[0],p[1]-L/2,p[2]),(0,1,0)))
def eye(p,od=55,di=35,w=12):return ring(od,di,w,(p[0],p[1]-w/2,p[2]),(0,1,0))
def bush(k,p,kin):
 x,y,z=p
 ball=cq.Solid.makeSphere(14.5,cq.Vector(x,y,z),angleDegrees1=-90,angleDegrees2=90).intersect(box([x-16,x+16],[y-8,y+8],[z-16,z+16])).cut(cyl(10,18,(x,y-9,z),(0,1,0)))
 outer=cyl(17.5,12,(x,y-6,z),(0,1,0)).cut(cq.Solid.makeSphere(14.55,cq.Vector(x,y,z),angleDegrees1=-90,angleDegrees2=90))
 add(k+'-OUTER','purchased-bearing',outer,{'sku':'GE20ES-2RS','d_D_B_C_mm':[20,35,16,12],'role':'External dimensions only verified; assumedR14.5 sphericalrace is NOT manufacturerCAD'},'Bearing steel OEM envelope',kin,proxy=True)
 add(k+'-INNER','purchased-bearing',ball,{'sku':'GE20ES-2RS','role':'Innerwidth16 andbore20 captured; assumed sphericalprofile, notOEMinternalgeometry'},'Bearing steel OEM envelope','beam' if k.startswith('HEAD') else kin,proxy=True)
def retainer_holes(sh,p):
 x,y,z=p
 for side,offset in[(-1,60),(1,0)]:
  for deg in[offset,offset+120,offset+240]:
   t=math.radians(deg);xx=x+23*math.cos(t);zz=z+23*math.sin(t)
   sh=sh.cut(cyl(1.65,6,(xx,y+side*6,zz),(0,-side,0)))
 return sh
def retainers(k,p,kin):
 x,y,z=p
 for side,offset in[(-1,60),(1,0)]:
  yy=y+6 if side>0 else y-8;sh=ring(55,29,2,(x,yy,z),(0,1,0))
  for j,deg in enumerate([offset,offset+120,offset+240]):
   t=math.radians(deg);xx=x+23*math.cos(t);zz=z+23*math.sin(t)
   sh=sh.cut(cyl(2.25,4,(xx,yy-1,zz),(0,1,0)))
   screw=cyl(2,8,(xx,y+side*8,zz),(0,-side,0)).fuse(cyl(3.5,3,(xx,y+side*8,zz),(0,side,0)))
   add(k+f'-M4-{side}-{j}','hardware',screw,{'nominal':'M4x8;6mm blind engagement in eye; heads andlocking process candidate','role':'Retains outer bearingring, doesnotclampinnerball'},kin=kin)
  add(k+f'-PLATE{side}','bearing-retainer',sh,{'plate_t':2,'three_clearance_holes':4.5,'PCD':46,'role':'Positiveouter-ringretainer;6mm threadengagement/locking qualification HOLD'},kin=kin)
def pin(k,p,kin):
 x,y,z=p
 sh=cyl(10,40,(x,y-20,z),(0,1,0)).fuse(cyl(15,14,(x,y-34,z),(0,1,0))).fuse(cyl(8,22,(x,y+20,z),(0,1,0)))
 add(k,'hardware',sh,{'sku':'ISO7379-20-M16-40','shoulder':40,'thread':'M16; exact tightening and procurement held','shoulder_fit':'20f9 catalogue; mating fits require drawing'},'Class12.9 shoulder screw candidate',kin)
 for sg in[-1,1]:add(k+f'-INNER-SPACER{sg}','hardware',ring(28,20.2,4,(x,y+(8 if sg>0 else-12),z),(0,1,0)),{'role':'Spacer clamps bearing inner ring; does not clamp outer housing'},kin=kin)
 add(k+'-WASHER','hardware',ring(32,20.5,2.5,(x,y+20,z),(0,1,0)),{'role':'Clamped stack42.5 exceeds40.25maxshoulder; washer clears shoulder tip'},kin=kin)
 nut=cq.Workplane('XZ').polygon(6,27.7).extrude(13).val().rotate((0,0,0),(1,0,0),180) if False else ring(27.7,16,13,(x,y+22.5,z),(0,1,0))
 add(k+'-NUT','hardware',nut,{'role':'M16 all-metal prevailing-torque nut envelope; exact OEM/locking torque held'},kin=kin)
def clevis(k,p,attachx,kin='fixed'):
 x,y,z=p
 for side in[-1,1]:
  yr=[y-20,y-12]if side<0 else [y+12,y+20]
  shape=cyl(27.5,8,(x,yr[0],z),(0,1,0)).fuse(box(sorted([x,attachx]),yr,[z-22,z+22]))
  shape=hole_y(shape,p,20.5)
  add(k+f'-CHEEK{side}','fabricated-clevis',shape,{'plate_t':8,'bore':20.5,'weld_attachment_x':attachx},kin=kin)
def dogbone(k,a,b,kin):
 v=np.asarray(b)-np.asarray(a);L=float(np.linalg.norm(v));perp=np.array([-v[2],0,v[0]])/L*15
 pts=[(a[0]+perp[0],a[2]+perp[2]),(b[0]+perp[0],b[2]+perp[2]),(b[0]-perp[0],b[2]-perp[2]),(a[0]-perp[0],a[2]-perp[2])]
 sh=xz_poly(pts,a[1]-6,12).fuse(cyl(27.5,12,(a[0],a[1]-6,a[2]),(0,1,0))).fuse(cyl(27.5,12,(b[0],b[1]-6,b[2]),(0,1,0)))
 for p in[a,b]:sh=retainer_holes(hole_y(sh,p,35),p)
 add(k,'fabricated-link',sh,{'eye_pitch':L,'plate_t':12,'eye_OD':55,'bearing_bore':35,'bearing_retention':'Two bolted external retaining rings; fit/grease detail held'},kin=kin)
 for j,p in enumerate([a,b]):
  bush(k+f'-BUSH{j}',p,kin)
  retainers(k+f'-RETAIN{j}',p,kin)
def arc_sector(ax,y0,z,r0,r1,a,w):
 def p(r,deg):t=math.radians(deg);return(ax-r*math.cos(t),z+r*math.sin(t))
 pl=cq.Plane(origin=(0,y0,0),xDir=(1,0,0),normal=(0,-1,0))
 return cq.Workplane(pl).moveTo(*p(r0,-a)).threePointArc(p(r0,0),p(r0,a)).lineTo(*p(r1,a)).threePointArc(p(r1,0),p(r1,-a)).close().extrude(-w).val()
# Actual moving stock beam and welded-end brackets.
add('BEAM-HSS','moving-beam',tube_y(76.2,203.2,6.35,900,(200,0,300)),{'stock':'HSS8x3x1/4','nominal_wall':6.35,'A500_design_wall_factor':.93,'corner_model':'Square nominal corners; exact mill radius held'},kin='beam')
for side in[-1,1]:
 y=side*450
 add(f'BEAM-END{side}','moving-beam',box([161.9,238.1],sorted([y,y+side*10]),[198.4,401.6]),{'plate_t':10,'role':'End closure and head-bracket load spread'},kin='beam')
for i,p in enumerate(P['hangers']['lower_reference']):clevis(f'H{i+1}-LOW',p,161.9 if p[0]<200 else 238.1,'beam')
clevis('DRIVE-LOW',P['crosshead_and_lever']['beam_drive_reference'],238.1,'beam')
# Upper cross support is separate from original frame; endplates and bolts form real load paths.
add('UPPER-HSS','fixed-support',tube_y(76.2,76.2,6.35,1052,(200,0,500)),{'stock':'HSS3x3x1/4','fit':'Between12mm endplates; support/weld strength pending'})
for side in[-1,1]:
 yr=[526,538]if side>0 else [-538,-526];sh=box([140,285],yr,[350,550])
 for x in[160,250]:
  for z in[370,410]:sh=sh.cut(cyl(8.75,14,(x,yr[0]-1,z),(0,1,0)))
 add(f'SUPPORT-END{side}','fixed-support',sh,{'plate_t':12,'bolt_holes':17.5,'existing_web':'Requires four matching holes, actual C5 web patch supplied separately'})
 for x in[160,250]:
  for z in[370,410]:
   if side>0:
    sh=cyl(8,55,(x,523,z),(0,1,0)).fuse(cyl(12,10,(x,513,z),(0,1,0)))
   else:sh=cyl(8,55,(x,-523,z),(0,-1,0)).fuse(cyl(12,10,(x,-513,z),(0,-1,0)))
   add(f'SUPPORT-BOLT{side}-{x}-{z}','hardware',sh,{'nominal':'M16x55 through bolt;8.8 candidate; thread/nut retention to specify'})
   ny=553 if side>0 else-566
   add(f'SUPPORT-NUT{side}-{x}-{z}','hardware',ring(27.7,16,13,(x,ny,z),(0,1,0)),{'nominal':'M16nut envelope'})
   for label,wy in [('HEAD',523 if side>0 else -526),('NUT',550 if side>0 else -553)]:
    add(f'SUPPORT-WASHER-{label}-{side}-{x}-{z}','hardware',ring(30,17.5,3,(x,wy,z),(0,1,0)),{'nominal':'M16 flat washer,30OD/17.5ID/3thick; fills actual clampstack gap'})
for i,p in enumerate(P['hangers']['upper_fixed']):
 clevis(f'H{i+1}-UP',p,161.9 if p[0]<200 else 238.1)
 # Vertical cheek connection to actual upper RHS, rather than a floating eye.
 for sg in[-1,1]:
  yr=[p[1]-20,p[1]-12]if sg<0 else [p[1]+12,p[1]+20]
  add(f'H{i+1}-UP-GUSSET{sg}','fixed-support',box([min(p[0],200),max(p[0],200)],yr,[472,500]),{'role':'Upper clevis-to-crossmember bracket; weld sizing pending'})
for i,(a,b)in enumerate(zip(P['hangers']['lower_reference'],P['hangers']['upper_fixed'])):
 dogbone(f'HANGER{i+1}',a,b,f'hanger{i+1}')
 pin(f'H{i+1}-PIN-LOW',a,'beam');pin(f'H{i+1}-PIN-UP',b,'fixed')
# Locator with separate real-height joints. Its exact spherical eye geometry is added as a link envelope.
la=P['lateral_locator']['moving_reference'];lb=P['lateral_locator']['fixed']
add('LOCATOR-ROD','locator',rod(10,la,lb),{'eye_pitch':400,'role':'Spherical-ended20mm rod; end bearing housings and exact catalogue ends still to detail'},kin='locator')
add('LOCATOR-MOVING-EAR','moving-beam',box([110,170],[-12,12],[218,262]).cut(cyl(10.25,26,(130,-13,240),(0,1,0))),{'role':'Rear beam locator ear, welded to rear HSSwall'},kin='beam')
add('LOCATOR-FRAME-BRACKET','fixed-support',box([80,142],[-412,-388],[218,262]).cut(cyl(10.25,26,(130,-413,240),(0,1,0))),{'role':'Anchor from existing crossbeam frontfaceX80; attachment bolts/welds pending'})
# Controlled spherical heads, retaining pins, actual steel backing; green insert is a HOLD reference only.
for side in[-1,1]:
 hp=[245,side*490,300];kin=f'head{side}'
 yr=[hp[1]-35,hp[1]+35]
 back=arc_sector(600,yr[0],300,340,348,25,70).fuse(cyl(27.5,12,(245,hp[1]-6,300),(0,1,0)))
 back=retainer_holes(hole_y(back,hp,35),hp)
 add(f'HEAD{side}-CARRIER','head-carrier',back,{'backing_radial_thickness':8,'head_bore':35,'reference_only_interface':'Friction-block bolt/key pattern not selected'},kin=kin)
 bush(f'HEAD{side}-BEARING',hp,kin)
 retainers(f'HEAD{side}-BEARING-RETAINER',hp,kin)
 clevis(f'HEAD{side}-FORK',hp,210,'beam');pin(f'HEAD{side}-PIN',hp,'beam')
 # End support arms continue from the beam end plate to both cheeks.
 for sg in[-1,1]:
  y1=hp[1]+sg*16;ya,yb=sorted([side*450,y1]);add(f'HEAD{side}-ARM{sg}','moving-beam',box([200,220],[ya,yb],[278,322]),{'role':'20mm plate head-fork support from beam end; local weld/bending pending'},kin='beam')
 add(f'HEAD{side}-FRICTION-HOLD','friction-reference',arc_sector(600,yr[0],300,300,340,25,70),{'status':'NOTSELECTED; not manufactured or installed; neutral release can collide during suspension travel','stock_mismatch':'V23790.4wide/R304.8 rejected for600 wheel/80tread'},'Friction insert reference only',kin,proxy=True)
 # Stop-cage rear plate and centering-anchor tabs are fabricated; unselected springs remain declared.
 add(f'HEAD{side}-STOP-CAGE','moving-beam',box([205,213],[hp[1]-30,hp[1]+30],[258,342]).cut(box([204,214],[hp[1]-18,hp[1]+18],[278,322])),{'role':'Head stop/centering support; exact stop screw clearances not qualified'},kin='beam')
 for sz in[-1,1]:
  for sy in[-1,1]:
   p0=(217,hp[1]+sy*24,300+sz*32);p1=(252,hp[1]+sy*24,300+sz*24)
   add(f'HEAD{side}-CENTER-SPRING-REF{sz}-{sy}','spring-reference',rod(3,p0,p1),{'role':'Declared centering spring working line only, NOT spring geometry or selected stiffness/preload'},'Spring procurement reference', 'beam',proxy=True)
# Fixed central steel support; frame loads go to the new upper transverse support.
for side in[-1,1]:
 y=side*180
 add(f'ACT-RAIL{side}','fixed-support',tube_x(50,50,6,[200,650],y,500),{'stock':'50mm square structural tube candidate; final US section/weld screen pending'})
 add(f'PIVOT-POST{side}','fixed-support',box([375,425],[y-25,y+25],[210,500]).cut(box([381,419],[y-19,y+19],[209,501])),{'role':'Closed fabricated50x50x6 post, shaft support below'})
 sh=cyl(52.5,50,(400,y-25,180),(0,1,0)).fuse(box([375,425],[y-25,y+25],[180,225]));sh=hole_y(sh,(400,y,180),76.2)
 add(f'PIVOT-HOUSING{side}','fixed-support',sh,{'bore':76.2,'bush':'Stockbronze sleeve2.5inID/3inOD×2in nominal, exactSKU/fits HOLD'})
 add(f'PIVOT-BUSH{side}','purchased-bearing',ring(76.2,63.55,50,(400,y-25,180),(0,1,0)),{'role':'Catalogue-size bronze sleeve procurement placeholder'},'Bronze reference','fixed',proxy=True)
shaft=cyl(31.75,460,(400,-230,180),(0,1,0))
for y in[-130,0,130]:shaft=shaft.cut(box([423.8125,440],[y-25,y+25],[172.0625,187.9375]))
add('LEVER-SHAFT','lever',shaft,{'stock':'2.5in shaft; grade/heat treatment and torque joint HOLD','keyways':'5/8in square candidate; exact standard/keyfit not released'},kin='lever')
for y,label in[(-130,'L'),(130,'R'),(0,'OUT')]:
 hub=ring(110,63.5,50,(400,y-25,180),(0,1,0)).cut(box([431.75,440],[y-26,y+26],[172.0625,187.9375]))
 armend=430 if y else 280
 sh=hub.fuse(box([382,418],[y-6,y+6],[180,armend])).fuse(cyl(27.5,12,(400,y-6,armend),(0,1,0)))
 sh=hole_y(sh,(400,y,armend),35)
 add('LEVER-'+label,'lever',sh,{'input_arm':250 if y else 100,'role':'Fabricated lever with keyed hub; key/hub fixing strength and retention HOLD'},kin='lever')
 add('LEVER-KEY-'+label,'hardware',box([423.8125,439.6875],[y-25,y+25],[172.0625,187.9375]),{'stock':'5/8in squarekey,50length; material/fit HOLD'},kin='lever')
 bush('LEVER-'+label+'-BUSH',(400,y,armend),'lever')
for side in[-1,1]:
 y=side*213
 add(f'SHAFT-COLLAR{side}','hardware',ring(85,63.5,16,(400,y-8,180),(0,1,0)),{'role':'Stock split shaft collar envelope; actualclamp screw/retention not selected'},kin='lever')
# Manufacturer body is a known maximum catalogue cylinder, not invented internal geometry.
add('MGM3420051-BODY-REFERENCE','actuator-reference',cyl(186.436/2,211.836,(243.164,0,430),(1,0,0)),{'sku':'MGM3420051','status':'Catalogue body-envelope proxy; clamp/hose/drain/cagingworkspace incomplete'},'Purchased actuator reference','fixed',proxy=True)
mp=box([455,467],[-205,205],[315,545]).cut(cyl(25,14,(454,0,430),(1,0,0)))
for y in[-60.325,60.325]:mp=mp.cut(cyl(8.75,14,(454,y,430),(1,0,0)))
for y in[-180,180]:mp=mp.cut(box([454,468],[y-25,y+25],[475,525]))
add('MGM-MOUNT-PLATE','fixed-support',mp,{'plate_t':12,'stud_pitch':120.65,'stud_clearance':17.5,'status':'Thread revision and maximum bracketthickness confirm before fabrication'})
for y in[-60.325,60.325]:add(f'MGM-STUD-{y}','actuator-reference',cyl(8,43.434,(455,y,430),(1,0,0)),{'status':'Catalogue stud envelope; M16versus5/8revision HOLD'},'Purchased actuator reference',proxy=True)
add('MGM-CAGING-MINIMUM-REF','maintenance-reference',cyl(8,82.6,(160.564,0,430),(1,0,0)),{'status':'Minimumcagingprojection only; rear nut and wrench/removal workspace additional'},'Maintenance envelope only',proxy=True)
for x in[495,640]:
 add(f'GUIDE-CROSSBAR{x}','fixed-support',tube_y(50,50,6,360,(x,0,500)),{'role':'Crossheadguide support bridges between longitudinal rails'})
 for y in[-65,65]:
  sh=box([x-5,x+5],[y-20,y+20],[405,475]).cut(cyl(12.75,12,(x-6,y,430),(1,0,0)))
  add(f'GUIDE-SUPPORT{x}-{y}','fixed-support',sh,{'bore':25.5,'role':'Guide shaft support attached atcrossbarbottom; clampingfasteners pending'})
for y in[-65,65]:
 add(f'GUIDE-SHAFT{y}','hardware',cyl(12.7,135,(500,y,430),(1,0,0)),{'stock':'1in precision shaft; grade/finish procurement pending'})
 add(f'CROSSHEAD-BUSH{y}','purchased-bearing',ring(38.1,25.45,40,(515,y,430),(1,0,0)),{'role':'1in-ID bronze sleeve size proposal, actualSKU/fit HOLD'},'Bronze reference','crosshead',proxy=True)
 add(f'CROSSHEAD-HOUSING{y}','crosshead',box([515,555],[y-25,y+25],[405,455]).cut(cyl(19.05,42,(514,y,430),(1,0,0))),{'bore':38.1,'role':'Machined steel bush housing'},kin='crosshead')
add('CROSSHEAD-FRONT-BAR','crosshead',box([555,567],[-155,155],[415,445]),{'plate_t':12},kin='crosshead')
ear=box([520,565],[-6.35,6.35],[415,445]);ear=hole_y(ear,(535,0,430),16.1)
add('CROSSHEAD-CHAMBER-EAR','crosshead',ear,{'plate_t':12.7,'pin_clearance':16.1,'mates':'MGM8292002P14.2875forkgap,15.875pin; purchasedprofile HOLD'},kin='crosshead')
for y in[-130,130]:
 clevis(f'CROSSHEAD-EYE{y}',(535,y,430),555,'crosshead')
 dogbone(f'INPUT-LINK{y}',(400,y,430),(535,y,430),f'input{y}')
 pin(f'INPUT-PIN-LEVER{y}',(400,y,430),'lever');pin(f'INPUT-PIN-CROSSHEAD{y}',(535,y,430),'crosshead')
dogbone('OUTPUT-LINK',(270,0,300),(400,0,280),'output')
pin('OUTPUT-PIN-BEAM',(270,0,300),'beam');pin('OUTPUT-PIN-LEVER',(400,0,280),'lever')
add('MGM-ROD-REFERENCE','actuator-reference',cyl(7.9375,68,(467,0,430),(1,0,0)),{'role':'Cut-to-fit rod reference line; actualzero-strokecut/threadengagement determinedfromclosureandmeasuredyoke'},'Purchased rod reference','crosshead',proxy=True)
# Bounded D2 physical fit repair. These are actual cuts/forks, not collision exclusions.
def replace(k,shape,note):
 assert shape.isValid(),k
 S[k]=shape;M[k]['bounds_mm']=bounds(shape);M[k]['volume_mm3']=shape.Volume()
 if M[k]['mass_kg'] is not None:M[k]['mass_kg']=shape.Volume()*7850e-9
 M[k]['definition']['D2_fit_repair']=note
for label,y,end in [('L',-130,430),('R',130,430),('OUT',0,280)]:
 k='LEVER-'+label
 sh=ring(110,63.5,50,(400,y-25,180),(0,1,0))
 for sy in [-1,1]:
  yy=y-20 if sy<0 else y+12
  plate=box([382,418],[yy,yy+8],[180,end]).fuse(cyl(27.5,8,(400,yy,end),(0,1,0)))
  sh=sh.fuse(plate)
 sh=hole_y(sh,(400,y,180),63.5,60);sh=hole_y(sh,(400,y,end),20.5,60)
 sh=sh.cut(box([423.8125,440],[y-26,y+26],[172.0625,187.9375]))
 replace(k,sh,'Two8mm forkplates,24mm innergap,32mm reactioncentroid span; one GE20 in separate link. Hub bore recut after fusion.')
 for old in [k+'-BUSH-INNER',k+'-BUSH-OUTER']:S.pop(old);M.pop(old)
# Crosshead bar is beyond the eye; shafts pass through actual clearance bores.
bar=box([570,582],[-155,155],[415,445])
for y in[-65,65]:bar=bar.cut(cyl(13,14,(569,y,430),(1,0,0)))
replace('CROSSHEAD-FRONT-BAR',bar,'Moved beyond link eye toX570; two26mm guide-shaft clearance bores.')
for y in[-65,65]:
 k=f'CROSSHEAD-HOUSING{y}'
 extension=box([555,570],[y-25,y+25],[405,455]).cut(cyl(13,17,(554,y,430),(1,0,0)))
 replace(k,S[k].fuse(extension),'Housing extends toX570frontbar; guide clearance continues.')
for y in[-130,130]:
 for sy in[-1,1]:
  k=f'CROSSHEAD-EYE{y}-CHEEK{sy}';yy=y-20 if sy<0 else y+12
  sh=cyl(27.5,8,(535,yy,430),(0,1,0)).fuse(box([535,570],[yy,yy+8],[408,452]))
  replace(k,hole_y(sh,(535,y,430),20.5),'Ear reaches actualfrontbar at570; same20.5bore.')
replace('CROSSHEAD-CHAMBER-EAR',hole_y(box([520,570],[-6.35,6.35],[415,445]),(535,0,430),16.1),'12.7mm ear reachesfrontbar; purchasedyoke remainsHOLD.')
replace('MGM-ROD-REFERENCE',cyl(7.9375,53,(467,0,430),(1,0,0)),'Threaded rod reference ends atX520; missing measured yoke is an explicit unconnected interface.')
mp=S['MGM-MOUNT-PLATE']
for y in[-130,130]:mp=mp.cut(box([454,468],[y-38,y+38],[390,470]))
replace('MGM-MOUNT-PLATE',mp,'Actual twin input-link clearance windows76Yx80Z. Plate/local loadpath strength HOLD.')
# Move shaft supports outward to clear actual pivot pin heads/nuts; contractupdated.
for side in[-1,1]:
 dy=side*25
 for stem in ['PIVOT-POST','PIVOT-HOUSING','PIVOT-BUSH']:
  k=f'{stem}{side}';replace(k,S[k].translate((0,dy,0)),'Bearing/post centreY'+str(side*205)+'; transition/local strength HOLD.')
 # Coped post-to-housing and flat top butt against new overhead transition plate.
 k=f'PIVOT-POST{side}';y=side*205
 coped=S[k].cut(cyl(52.5,52,(400,y-26,180),(0,1,0))).intersect(box([370,430],[y-26,y+26],[100,475]))
 replace(k,coped,'Circular lowercope meets housing; topZ475 abuts transitionplate, no overlapping tube volumes.')
 yr=[155,230]if side>0 else[-230,-155]
 add(f'PIVOT-TOP-TRANSITION{side}','fixed-support',box([370,430],yr,[475,487]),{'plate_t':12,'role':'Bearingpost-to-rail transition, candidate weld/loadspread HOLD'})
 k=f'SHAFT-COLLAR{side}';replace(k,S[k].translate((0,dy,0)),'Collar centreY'+str(side*238)+'; actual split/cap screws stillHOLD.')
shaft=cyl(31.75,510,(400,-255,180),(0,1,0))
for y in[-130,0,130]:shaft=shaft.cut(box([423.8125,440],[y-25,y+25],[172.0625,187.9375]))
replace('LEVER-SHAFT',shaft,'2.5in candidate shaft,endsY±255,bearingcentres±205.')
# Stock weld junctions terminate at mating faces; no volume overlap credited as weld.
for side in[-1,1]:
 k=f'ACT-RAIL{side}';replace(k,S[k].intersect(box([238.1,651],[-300,300],[400,600])),'Butts upperHSSfrontfaceX238.1; weld specificationHOLD.')
 k=f'PIVOT-TOP-TRANSITION{side}';replace(k,S[k].cut(S[f'ACT-RAIL{side}']),'Transitiontrimmed to matingrail wall; weld strengthHOLD.')
for x in[495,640]:
 k=f'GUIDE-CROSSBAR{x}';replace(k,S[k].intersect(box([450,680],[-155,155],[450,550])),'Crossbar terminates at longitudinalrail innerfacesY±155.')
replace('LOCATOR-MOVING-EAR',S['LOCATOR-MOVING-EAR'].intersect(box([100,161.9],[-30,30],[200,280])),'Rear ear terminates at HSSrearfaceX161.9; actuallocatorendjoints remainHOLD.')
for i,p in enumerate(P['hangers']['upper_fixed']):
 for sg in[-1,1]:
  k=f'H{i+1}-UP-GUSSET{sg}';s=S[k].cut(S['UPPER-HSS']).cut(S[f'H{i+1}-UP-CHEEK{sg}'])
  replace(k,s,'Coped to actualupperHSS andclevis surfaces; candidatewelds not represented as overlap.')
# One head support bracket perhead; separate forkcheeks butt against it.
for side in[-1,1]:
 hp=[245,side*490,300];ya,yb=sorted([side*460,side*510]);k=f'HEAD{side}-ARM-1'
 arm=box([200,217],[ya,yb],[278,322]);replace(k,arm,'Single17mm rearbridge fromendclosure;0.5mm nominalgap toeye/retainer rear. ToleranceHOLD.')
 S.pop(f'HEAD{side}-ARM1');M.pop(f'HEAD{side}-ARM1')
 for sy in[-1,1]:
  k=f'HEAD{side}-FORK-CHEEK{sy}';replace(k,S[k].cut(arm),'Forkrear coped to20mmrearbridge; samepinlocation/span.')
 k=f'HEAD{side}-STOP-CAGE';replace(k,S[k].cut(arm),'Stopcageblanktrimmed to bridge; stop screws/springattachments remainincomplete.')
 carrier=S[f'HEAD{side}-CARRIER']
 for sy in[-1,1]:
  yy=[hp[1]-20.5,hp[1]-11.5]if sy<0 else[hp[1]+11.5,hp[1]+20.5]
  carrier=carrier.cut(box([209,274],yy,[272,328]))
 for sy in[-1,1]:
  yy=hp[1]+6 if sy>0 else hp[1]-8.1
  carrier=carrier.cut(cyl(27.6,2.1,(245,yy,300),(0,1,0)))
 replace(f'HEAD{side}-CARRIER',carrier,'Machined rear reliefs around forkcheeks atnominal; attitude/sweep qualificationHOLD.')
# Orient left-side pin heads inboard and thread tails outboard, avoiding the chamber/guide housing.
for prefix,p in [('INPUT-PIN-LEVER-130',(400,-130,430)),('INPUT-PIN-CROSSHEAD-130',(535,-130,430)),('HEAD-1-PIN',(245,-490,300))]:
 for k in list(S):
  if k==prefix or k.startswith(prefix+'-'):
   replace(k,S[k].rotate(p,(p[0]+1,p[1],p[2]),180),'Left pin reversed; inboard head, outboard thread tail. Original pin dimensions retained.')
for side in[-1,1]:
 k=f'BEAM-END{side}';s=S[k].cut(cyl(16,24,(245,side*455-12,300),(0,1,0)))
 replace(k,s,'16mm-radius frontedge relief for retained head pin; local endplate strength HOLD.')
print('SOLIDS',len(S),'VALID',sum(s.isValid()for s in S.values()),flush=True)
parts=list(M.values());(H/'parts.json').write_text(json.dumps(parts,indent=2))
cq.exporters.export(cq.Compound.makeCompound(list(S.values())),str(H/'checkpoint.brep'))
def edges(s):
 out=[]
 for e in s.Edges():
  try: pts=e.sample(32 if e.geomType()!='LINE'else 2)[0];out.append([[p.x,p.y,p.z]for p in pts])
  except:pass
 return out
(H/'drawing-edges.json').write_text(json.dumps({k:edges(s)for k,s in S.items()}))
model={'schemaVersion':3,'units':'inches','title':'C52 development module / nominal applied reference','parts':[],'groups':[],'notes':['Preliminary fabricated components with explicitly identified purchased envelopes and unselected friction insert.','Release suspension contact and unresolved retaining details remain HOLD.']}
colors={'fixed-support':'#8595a3','moving-beam':'#d18f3c','fabricated-link':'#a8b4bd','head-carrier':'#329878','friction-reference':'#cf5f4d','actuator-reference':'#8b7bac','maintenance-reference':'#cc77aa','spring-reference':'#bb66aa'}
for k,s in S.items():
 vv,ff=s.tessellate(1.0,.15);g=M[k]['group'];b={a:[v/MM for v in M[k]['bounds_mm'][a]]for a in'xyz'}
 model['parts'].append({'id':k,'name':k.replace('-',' '),'group':g,'color':colors.get(g,'#9ba7ae'),'positions':[round(v/MM,5)for p in vv for v in[p.x,p.y,p.z]],'indices':[j for f in ff for j in f],'bounds_in':b,'centre_in':[sum(b[a])/2 for a in'xyz'],'dimensions_xyz_in':[b[a][1]-b[a][0]for a in'xyz'],'metadata':M[k]})
model['groups']=[{'id':g,'label':g,'explosion_vector_in':[0,0,0]}for g in sorted(set(p['group']for p in parts))]
model['coordinate_system']='X longitudinal, Y across track, Z upward; source millimetres converted to inches. Intermediate module; run issue_c52.py for published context and records.'
with gzip.open(OUT/'model-applied.json.gz','wt',compresslevel=9)as f:json.dump(model,f,separators=(',',':'))
print('MESH',flush=True)
assembly=cq.Assembly(name='C52_DEVELOPMENT_ONE_AXLE_MODULE')
for k,s in S.items():assembly.add(s,name=k)
assembly.save(str(H/'C52-module-D2.step'))
with(H/'C52-module-D2.step').open('rb')as fi,gzip.open(OUT/'C52-module-D2.step.gz','wb',compresslevel=9)as fo:fo.write(fi.read())
print('EXPORTED',flush=True)
