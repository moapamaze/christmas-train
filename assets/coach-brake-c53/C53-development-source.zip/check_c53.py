from pathlib import Path
import json,math
import cadquery as cq
H=Path(__file__).resolve().parent
M=json.loads((H/'parts.json').read_text());S=list(cq.importers.importBrep(str(H/'checkpoint.brep')).val());positive=[];tests=0;contacts=[]
for i,(a,A) in enumerate(zip(M,S)):
 if a['group']=='supplier-reference':continue
 ba=a['bounds_mm']
 for b,B in zip(M[i+1:],S[i+1:]):
  if b['group']=='supplier-reference' or a['group']==b['group']=='retained-C5-reference':continue
  bb=b['bounds_mm']
  if not all(min(ba[k][1],bb[k][1])-max(ba[k][0],bb[k][0])>1e-5 for k in 'xyz'):continue
  tests+=1
  try:v=A.intersect(B).Volume()
  except Exception as e:positive.append({'a':a['id'],'b':b['id'],'error':str(e)});continue
  if v>1e-3:
   cls='unresolved nominal interference'
   ids={a['id'],b['id']}
   receiver=next((i for i in ids if i.startswith('HUB-REDUCER-') or i.startswith('BEARING-REDUCER-') or i in ['CARRIER-BARREL','TORQUE-LINK']),None)
   screw=next((i for i in ids if i.startswith('HUB-RETAINER-M6-') or i.startswith('SLEEVE-END-M6-') or i.startswith('CARRIER-COVER-M4-') or i.startswith('LINK-RETAIN-M4')),None)
   if receiver and screw and ((receiver.startswith('HUB-REDUCER') and screw.startswith('HUB-RETAINER')) or (receiver.startswith('BEARING-REDUCER') and screw.startswith('SLEEVE-END')) or (receiver=='CARRIER-BARREL' and screw.startswith('CARRIER-COVER')) or (receiver=='TORQUE-LINK' and screw.startswith('LINK-RETAIN'))):cls='intentional nominal major-thread cylinder overlaps receiving tap-drill cylinder; no threadhelices modeled'
   if a['group']=='retained-C5-reference' or b['group']=='retained-C5-reference':cls='context interference'
   positive.append({'a':a['id'],'b':b['id'],'intersection_mm3':v,'classification':cls})
r={'valid_count':sum(s.isValid() for s in S),'part_count':len(S),'exact_pair_tests':tests,'positive_pairs':positive,'scope':'Nominal customparts and dimensionalbearing envelopes; schematic supplier projections excluded. No missingOEMshape clearance pass.'}
(H/'nominal-audit.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
