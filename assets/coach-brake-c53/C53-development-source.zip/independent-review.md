# C5.3 independent review

The final 141-part candidate passes the bounded custom-part checks below. It remains a development design: the exact rotor section and chamber are incomplete, maximum output is unresolved, and no fabrication or operating rating is assigned.

| Independent check | Result | Limit |
|---|---:|---|
| Closed-form link positions |18,468 vertically admissible development poses close |Independent lateral ±3 mm is a probe; complete journal constraint/tolerance closure is not approved |
| Carrier clock range |−4.455688° to+1.721170° |Working study envelope only |
| Minimum effective torque arm |135.672727 mm |Use actual arm rather than a constant 150 mm |
| Closed-form versus Newton clock |3.61e-14° maximum difference |Arithmetic agreement |
| Independent 6×6 statics comparison |1.46e-10 N maximum reaction difference |Rigid equilibrium, not capacity |
| Nine actual custom-part poses |145 exact intersection tests;0 positive pairs |Discrete poses; no complete supplier or continuous sweep proof |
| Tightest retainer-to-clevis clearance |0.650866 mm |Small nominal gap; tolerance, flexure, wear and manufacturing acceptance remain open |
| Selected load-path contacts |15 actual shared-face connections; zero solid overlap |No weld or joint strength credit |
| Endplate backing |100% of footprint on retained sideframe web |Local web/fatigue not qualified |
| Fillet-toe room |7.2 mm tube-to-plate;12 mm plate-to-web |Space for6 mm candidate fillets only |

The nine exact-shape poses combine roll −2/0/+2° with ordinary rebound/mid/jounce. Centre heave is limited so both journal heights stay within−40..+35 mm. Their lateral translation preserves the right locating journal's Y coordinate; the left floating bearing takes the projection change. Matrices are in `independent-motion-states.json`. The wider analytical grid is identified separately as a development probe; Cartesian heave/roll overtravel is never called ordinary motion.

The first motion check found four real retainer-screw head clashes. Flush countersunk retainers removed those modeled interferences. The superseded evidence is retained in `independent-motion-before-countersink.json`; the final check is `independent-motion-check.json`.

The corrected barrel saddles have finite curved contact, and the outboard fork reaches the permanent barrel through a separate saddle bridge. The removable cover is relieved and is not credited as a welded load path. The bearing reducer now has actual external split shaft clamps; axial end screws alone were not treated as shaft clamping.

The hub's proposed axial restraint uses the closed shaft-key pocket, key ends, sleeve pocket wall and outboard retainer; two plates retain the hub to its sleeve. This explicitly needs key-end bearing, screw, fit, thermal-growth and axle-fatigue checks. No axial capacity is inferred merely from a key's torque function.

The 120 mm bearing/hub bores clear the nominal 110 mm wheel seat after the axlebox, journal nut/retainers and one wheel are removed. Actual fits, installation order, clamping, wheel-shop procedure and runout remain held. A closed inboard rotor is not replaceable on the coach with its wheel installed.

The exact Webb friction annulus/hat profile and true mounting datum,325.12 mm rotor versus330 mm caliper drawing compatibility, full TSE chamber/wear/caging envelope, mirrored brake coexistence and maximum actuator output remain unresolved. High-torque sensitivity failures in the mechanics report are not erased by these geometric checks.

Reproduce with `independent_motion_check.py`, `independent_contact_check.py`, then `independent_check.py`. The main generator checks that the final motion/contact records use the same checkpoint hash. Manufacturer-envelope proxies are excluded from a claim of exact installed fit.
