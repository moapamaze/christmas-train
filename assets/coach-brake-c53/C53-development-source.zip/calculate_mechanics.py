"""C53 D1 demand, heat and conditional load-path record. No component or joint rating.
Run beside the output files; stdlib only. Geometry-specific loads stay open.
"""
from carrier_statics import carrier_screen
from pathlib import Path
import json, math, hashlib
BASE=Path(__file__).resolve().parent
G=9.80665; V=7.5*0.44704; R=.3; K=1.05; N=8
SOURCES=[
 {'id':'WEBB-R32','url':'https://cdn.prod.website-files.com/692683b9a358dca80ef39017/69609994c6c39d1d62295d61_SD-131%20Webb%20ADB%20ROTOR%20flyer%20R32.pdf','primary':True,'supports':'Webb 55030PK-65: 325.12 mm diameter, 34.036 mm thickness, 148.59 mm overall depth, 168.91 mm pilot and eight M14 x 2 holes on 195.834 mm PCD. Internal profile and controlled hub mating-face offset remain open.'},
 {'id':'NSK-6824','url':'https://www.nsk.com/engineering/products/bearings/ball-bearings/deep-groove-ball-bearings/single-row-deep-groove-ball-bearings/6824dd-apn.html','primary':True,'supports':'Selected thin bearing development candidate NSK 6824DD: 120 x 150 x 16 mm, Cr 32 kN, C0r 35.5 kN. Catalogue-only procurement evidence; no installed rating.'},
 {'id':'AISC-HSS','url':'https://www.aisc.org/globalassets/continuing-education/quiz-handouts/specifying-hss-article.pdf','primary':True,'supports':'0.93 nominal-wall convention for A500 section-property screening; not railway qualification.'},
 {'id':'NSK-6024','url':'https://www.oss.nsk.com/eu/6024ddu-apn.html','primary':True,'supports':'Superseded, packaging-obstructed NSK 6024DDU comparison: 120 x 180 x 28 mm, Cr 97 kN, C0r 80 kN, 2,200 rpm and 2.08 kg. Catalogue ratings are not an installation acceptance.'},
 {'id':'H-L949','url':'https://www.hendrickson-intl.com/getattachment/54c582a0-10e2-4fe2-9e8f-f4e33f9fccb4/L949.pdf','revision':'Rev T 08-26','primary':True,'supports':'PAN17 caliper, rotor, pad and current replacement chamber part numbers. Page 11 pad row says 20/24; page 15 current chamber row says 22/24; variant reconciliation remains open.'},
 {'id':'W-GA','url':'https://www.wabco-customercentre.com/catalog/docs/6401750720____053_dascheck_j4_page-1---notset_tif.pdf','primary':True,'supports':'40175072/73 family mounting detail and 10,000 Nm transferable mounting-torque note. Drawing references 330 mm disc; exact 325 mm installation must be reconciled.'},
 {'id':'H-L1272','url':'https://www.hendrickson-intl.com/getattachment/155d9e36-24d4-49e4-84c7-7ac5002024c0/L1272.pdf','revision':'Returned PDF November 2016 Rev-','primary':True,'supports':'Hendrickson 325 mm PAN17 package; chamber/caliper wear movement approximately 1 in and full suspension/hose clearance.'},
 {'id':'TSE-HOT','url':'https://www.tsebrakes.com/brake-chambers/hot-high-output-technology','primary':True,'supports':'Public HOT family information; exact 4627/4628 GA and force envelope not found.'},
 {'id':'TSE-2026','url':'https://www.tsebrakes.com/medias/iw/TSE-SalesSheetsTSE-HOT-Web-2026.pdf','primary':True,'supports':'Current public family sheet; not an exact 22/24 force or dimensional record.'},
 {'id':'TSE-QR','url':'https://www.tsebrakes.com/medias/iw/Quick-Reference-Guide.pdf','primary':True,'supports':'Public options list; selected suffixes and full force envelope not given.'},
 {'id':'TSE-INSTALL','url':'https://www.tsebrakes.com/medias/iw/TSE_Disc_Brake_Installation_Instructions_1_1_1.pdf','primary':True,'supports':'Disc-chamber service, caging access, lower drain and hose installation. Its 90–120 psi caging instruction is not a maximum working-pressure rating.'}
]
def calculate():
 carrier=carrier_screen()
 demands=[]; energies=[]; grades=[]
 for label,m in [('regular',13200),('accessible',11000)]:
  for a in(.5,.7):
   tw=K*m*a*R/N
   demands.append(dict(coach=label,mass_kg=m,deceleration_m_s2=a,grade_fraction=0,
     rail_force_translational_N=m*a,adhesion_ratio_translational_a_over_g=a/G,
     rotating_allowance_factor=K,torque_per_axle_Nm=2*tw,torque_per_disc_Nm=tw,
     tread_tangential_force_per_wheel_N=tw/R,initial_power_per_disc_W=K*m*a*V/N,
     effective_radius_probes=[dict(effective_radius_mm=re*1000,tangential_pad_force_total_N=tw/re,
       pad_normal_probes=[dict(mu=mu,summed_both_faces_normal_N=tw/(re*mu),normal_each_face_if_equal_N=tw/(2*re*mu)) for mu in(.3,.4,.5)]) for re in(.12,.13,.14)]))
  energies.append(dict(coach=label,mass_kg=m,speed_m_s=V,grade_fraction=0,rotating_allowance_factor=K,
    full_stop_heat_coach_J=.5*K*m*V*V,full_stop_heat_per_axle_J=.5*K*m*V*V/4,
    full_stop_heat_per_disc_J=.5*K*m*V*V/N,heat_per_disc_from_10m_vertical_descent_J=m*G*10/N))
  for grade in(0,.01,.02,.03):
   sine=grade/math.sqrt(1+grade*grade)
   grades.append(dict(coach=label,grade_rise_over_run=grade,parking_torque_per_disc_Nm=m*G*sine*R/N,
     steady_downhill_heat_power_per_disc_W=m*G*sine*V/N,
     status='Illustrative grade sensitivity only; no route grade, parking margin or continuous thermal rating selected.'))
 link_probes=[]
 for torque,label in[(363.825,'regular 0.7 m/s2 equal-share working demand'),(1000,'normalization only'),(10000,'OEM mounting-interface comparison only, NOT actual output bound')]:
  for arm in(.1,.15,.2):
   link_probes.append(dict(torque_Nm=torque,torque_basis=label,perpendicular_moment_arm_m=arm,
     axial_link_force_N=torque/arm,status='Lever-arm sensitivity; not a chosen link, joint or geometry-specific reaction.'))
 hashes={}
 for rel in('../coach-brake-c51/research-calculations.json','../coach-truck-c5/design-record.json','../coach-brake-c52/joint-components.json','component-evidence.json'):
  p=BASE/rel
  if p.exists():hashes[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
 return dict(issue='C53 mechanics D1',status='CONDITIONAL LOAD SCREENS / HIGH PROBE FAILURES / MAXIMUM OUTPUT OPEN / UNRATED',
  date='2026-10-19',basis=dict(masses_kg={'regular':13200,'accessible':11000},axles_per_coach=4,
    wheels_per_coach=8,selected_disc_count_per_coach=8,wheel_diameter_mm=600,speed_mph=7.5,
    equal_sharing='Ideal equal torque/energy sharing among 8 discs; pressure balance and actual torque variation not established.',
    rotational_inertia_factor=K,rotational_factor_status='Assumed allowance, not a measured or certified upper bound.',
    energy_assignment='All modeled kinetic energy assigned to the brakes; no rolling/aerodynamic loss credited.',source_hashes=hashes),
  component_basis=dict(caliper_left='Hendrickson S-39094-L / WABCO40175072',caliper_right='S-39094-R / WABCO40175073',
    rotor='Webb 55030PK-65',rotor_nominal_mm=[325.12,34.036],rotor_interface=dict(pilot_mm=168.91,bolt_count=8,bolt_thread='M14 x 2',bolt_pcd_mm=195.834,overall_depth_mm=148.59,hub='Custom hub with removable split reducer; not a matched Hendrickson hub',interchange_status='S-33391 has a different 220 mm pilot / eight M16 interface and is not assumed interchangeable.' ),pad_kit='S-41159-1 / WABCO232 lining',
    development_chamber_left='S-40979-L / TSE2224TLD2H-4627',development_chamber_right='S-40979-R / TSE2224TLD2H-4628',
    chamber_size='22/24, current L949 Rev T replacement row',
    variant_status='Commercial PAN17 calipers and current replacement chamber identifiers inform the development basis. Exact compatibility with the Webb 325.12 mm rotor, custom hub, lining and chamber remains conditional; this is not a matched complete commercial assembly. No 18/24 or legacy 20/24 force curve is substituted.',
    caliper_mount_note=dict(bolts='6 x M14 x 1.5 class 10.9',minimum_engagement_mm=18,assembly_torque_Nm=[205,225],
      maximum_transferable_mounting_torque_Nm=10000,
      interpretation='Specific OEM mounting-interface note; not rated braking performance, a torque-limiting device, or a certified upper bound on chamber output. Custom carrier, hub, link and frame joints are not covered.'),
    effective_pad_radius_mm=None,effective_radius_status='120/130/140 mm are analytical sensitivities, not dimensions inferred from 325 mm rotor OD. Actual torque-weighted pad radius is required.'),
  maximum_output=dict(status='UNRESOLVED / BLOCKS STRENGTH ACCEPTANCE',maximum_permitted_service_pressure_bar=None,
    service_force_over_full_working_stroke_N=None,spring_force_minimum_and_maximum_over_full_stroke_N=None,
    caliper_input_to_clamp_or_torque_transfer=None,simultaneous_service_plus_spring_bound_N=None,
    selected_design_torque_bound_Nm=None,
    reason='Public exact 22/24 GA, allowable pressure and force curves were not located in the bounded primary-source search. Nominal chamber size times an assumed pressure is not used as a fabricated maximum.',
    prohibited_substitutions=['TSE generic caging 90–120 psi is not maximum service pressure.','A general spring-force warning is not a maximum output rating.','Legacy WABCO 20/24 or MGM 20/24 curves are not the selected TSE 22/24 curve.','10,000 Nm transferable mount torque is not a cap on generated torque.'],
    needed_cases=['Full service output through actual usable stroke and pressure-fault envelope.','Spring parking/emergency minimum and maximum through stroke.','Simultaneous service and spring application until anti-compounding behavior is established.','Both rotation directions, hot/cold/wet friction and pressure-control failures.']),
  service_demands=demands,kinetic_heat=energies,grade_sensitivities=grades,
  alternative_four_disc_comparison=dict(selected=False,regular_0_7_torque_each_Nm=727.65,
    regular_7_5mph_heat_each_J=.5*K*13200*V*V/4,reason='One disc per axle doubles each unit torque and heat relative to the selected 8-disc sharing basis.'),
  torque_link_sensitivities=link_probes,
  architecture=dict(selected_location='Inboard, between wheels; exact planes and service envelopes owned by geometry contract.',
    rotor_path='Wheel/axle -> retained rotor hub torque joint -> bolted rotor -> pads.',
    reaction_path='Pads -> OEM caliper/carrier bolts -> custom axle-aligned carrier -> short articulated torque restraint -> new transverse frame crossmember -> structural inner sideframe webs.',
    carrier_support='Two spaced rolling-bearing stations on the rotating axle, with one axial locating station and one floating station, proposed. Bearings align/support the carrier; they are not the brake-torque restraint.',
    actual_bearing_part=carrier['selected_bearing']['part'],bearing_centres_mm=carrier['geometry']['bearing_centres_y_mm'],torque_link_endpoints_mm=[[600,170,450],carrier['geometry']['fixed_frame_pin_mm']],
    mount_capacity_status='No bearing, pin, bracket, weld, axle or rotor-hub torque capacity assigned before geometry and credible maximum output are known.',
    tilt_issue=dict(probe_degrees=2,rotor_radius_mm=162.56,rigid_upright_mount_edge_plane_error_mm=162.56*math.sin(math.radians(2)),
      interpretation='Geometric mismatch sensitivity if rotor tilts relative to a rigid upright-box caliper. Not an approved axle-roll limit. OEM wear slide is not automatically angular accommodation.'),
    failure_consequence='Loss of the single active torque restraint can allow carrier rotation, loss of controlled braking and hose/component damage. A catcher is not credited as an independent functioning brake.'),
  serviceability=dict(routine='Reserve physical pad extraction, adjuster access, chamber removal/caging and hose clearance; actual clearances await CAD.',
    rotor_replacement='Inboard one-piece rotor replacement requires wheelset removal and shop rail-wheel removal/reinstallation as adopted by root. No on-car or tool-less rotor swap is claimed.',
    wheelset_work='The final procedure must define safe support, press-fit removal/reinstallation limits, wheelset dimensions, runout, torque-joint inspection and required examination before return to service.',
    oem_wear_reservation_mm=25.4,wear_reservation_status='Conservative family application-guide reservation; exact caliper GA 21 mm axial movement must be reconciled with the installed assembly.',
    do_not='Do not split or machine an OEM friction ring to avoid the documented wheel-removal procedure.'),
  alternatives=[dict(option='Commercial air-disc family with custom rotor hub and carrier',finding='Preferred development path: keeps caliper actuation and wear adjustment commercial, while Webb rotor compatibility, exact chamber data and custom hub/carrier remain unqualified interfaces.'),
    dict(option='Mechanical caliper plus MGM chamber',finding='Not chosen: adds unverified lever/input interface, stroke, wear take-up and force transfer; the prior MGM maximum force remained unresolved.'),
    dict(option='Hydraulic caliper with air/hydraulic interface',finding='Not chosen: adds intensifier/master-cylinder displacement, hydraulic pressure/volume and leak/failure behavior, plus a separately established spring-parking function.'),
    dict(option='Twiflex MXA service plus MXK spring parking',finding='C51 alternative has documented separate pneumatic service/spring units; it needs two calipers, rotor match and independent duty/environment qualification. No train fit or rating was established.')],
  carrier_load_screen=carrier,
  limitations=['No rotor temperature, fade, thermal fatigue or repeated-stop/descending-route rating.','No adhesion/slide-control, stopping distance or parking-grade acceptance.','No strength or fatigue pass from working demand.','No geometry collision or maintenance-envelope pass from this calculation.'],sources=SOURCES)
def write_md(j):
 from mechanics_report import write_report
 write_report(j, BASE, SOURCES)
if __name__=='__main__':
 j=calculate()
 assert len(j['service_demands'])==4
 assert abs(j['service_demands'][1]['torque_per_disc_Nm']-363.825)<1e-8
 assert j['maximum_output']['selected_design_torque_bound_Nm'] is None
 assert j['architecture']['bearing_centres_mm'] == j['carrier_load_screen']['geometry']['bearing_centres_y_mm']
 (BASE/'mechanics-calculations.json').write_text(json.dumps(j,indent=2)+'\n')
 write_md(j)
 bearing=j['carrier_load_screen']['selected_bearing']
 page_record=dict(issue='C53 bearing candidate',status='Catalogue development candidate; not a rated assembly or verified inventory',page_parts=[dict(part=bearing['part'],name='Sealed thin-section carrier bearing',role='Two coaxial carrier-support stations per brake unit',availability='Manufacturer catalogue evidence only; stock and delivery not verified.',availability_as_of='2026-10-19',fit_status='120 x 150 x 16 mm development envelope on custom split sleeve. High torque probes exceed catalogue static reference; unreleased installation.',source_url=bearing['source_url'])])
 (BASE/'carrier-components.json').write_text(json.dumps(page_record,indent=2)+'\n')
 print(json.dumps({'status':j['status'],'case_count':len(j['service_demands']),'regular_per_disc_torque_Nm':j['service_demands'][1]['torque_per_disc_Nm'],'regular_per_disc_heat_J':j['kinetic_heat'][0]['full_stop_heat_per_disc_J']},indent=2))
