"""Elastic demand screens for the explicitly proposed C53 connections.

No assumed bolt friction, weld allowable or key length becomes a capacity.
"""
import math

def weld_group(points, force, moment, force_point, leg):
    segments=[]; length=0.; sx=0.; sz=0.
    for p,q in zip(points,points[1:]+points[:1]):
        L=math.hypot(q[0]-p[0],q[1]-p[1]); mid=[(p[0]+q[0])/2,(p[1]+q[1])/2]
        segments.append((p,q,L,mid)); length+=L; sx+=L*mid[0]; sz+=L*mid[1]
    cx,cz=sx/length,sz/length
    jxx=jzz=jxz=0.
    for p,q,L,mid in segments:
        x,z=mid[0]-cx,mid[1]-cz; dx,dz=q[0]-p[0],q[1]-p[1]
        jxx+=L*(x*x+dx*dx/12); jzz+=L*(z*z+dz*dz/12); jxz+=L*(x*z+dx*dz/12)
    fx,fy,fz=force; mx,my,mz=moment
    dx,dy,dz=force_point[0]-cx,force_point[1],force_point[2]-cz
    mx+=dy*fz-dz*fy; my+=dz*fx-dx*fz; mz+=dx*fy-dy*fx
    determinant=jxx*jzz-jxz*jxz
    a=(mz*jzz+mx*jxz)/determinant
    b=(-mx*jxx-mz*jxz)/determinant
    throat=leg/math.sqrt(2); stresses=[]
    for x,z in points:
        x-=cx; z-=cz
        vx=(fx/length+my*z/(jxx+jzz))/throat
        vz=(fz/length-my*x/(jxx+jzz))/throat
        normal=(fy/length+a*x+b*z)/throat
        stresses.append(dict(traction_XYZ_MPa=[vx,normal,vz],resultant_MPa=math.sqrt(vx*vx+normal*normal+vz*vz)))
    return dict(leg_mm=leg,effective_throat_mm=throat,line_length_mm=length,
        centroid_XZ_mm=[cx,cz],line_integrals_x2_z2_xz_mm3=[jxx,jzz,jxz],
        transferred_force_N=force,transferred_moment_at_group_centroid_Nmm=[mx,my,mz],
        peak_ideal_elastic_traction_MPa=max(q['resultant_MPa'] for q in stresses),
        endpoint_tractions=stresses,allowable_MPa=None)

def connection_screens(data, nominal_cases):
    frame=data['frame_support']; centre=frame['centre']; bx,bz=frame['section_outside_xz_mm']
    tube=[[centre[0]-bx/2,centre[2]-bz/2],[centre[0]+bx/2,centre[2]-bz/2],
          [centre[0]+bx/2,centre[2]+bz/2],[centre[0]-bx/2,centre[2]+bz/2]]
    parent=frame['endplate_polygon_xz']; out=[]
    for q in nominal_cases:
        f=[-v for v in q['link_force_world_N']]
        offset=[data['link']['fixed_frame'][i]-centre[i] for i in range(3)]
        ty=offset[2]*f[0]-offset[0]*f[2]
        # Symmetric two-brake loading: each end transfers one brake resultant
        # and one bracket's torsional moment. No end-fixity bending is credited.
        out.append(dict(torque_each_of_two_brakes_Nm=q['torque_per_disc_Nm'],
            tube_to_endplate=weld_group(tube,f,[0,ty,0],[centre[0],0,centre[2]],6),
            endplate_to_inner_web=weld_group(parent,f,[0,ty,0],[centre[0],-frame['endplate_thickness_provisional'],centre[2]],6)))
    hub=[]; radius=data['rotor']['mount_pcd']/2; n=data['rotor']['mount_holes']
    for q in nominal_cases:
        t=q['torque_per_disc_Nm']*1000
        hub.append(dict(torque_per_disc_Nm=q['torque_per_disc_Nm'],
            ideal_equal_rotor_bolt_tangential_N=t/(n*radius),
            inner_100mm_key_tangential_N=t/50,outer_120mm_key_tangential_N=t/60,
            inner_key_shear_stress_coefficient_MPa_mm=t/(50*28),
            outer_key_shear_stress_coefficient_MPa_mm=t/(60*28),
            solid_100mm_axle_pure_torsion_MPa=16*t/(math.pi*100**3)))
    return dict(welds=dict(basis='Candidate continuous 6 mm fillets on the declared tube-end rectangle and parent-web endplate polygon; elastic line-group demand only.',
        cases=out,limitations=['Candidate beads are not a qualified WPS, effective weld length, allowable stress or approved joint.',
            'Tube corner radius, returns, start/stop details, load introduction, residual stress, parent-wall yielding/punching and fatigue remain open.',
            'Symmetric end sharing of torsion is assumed; actual endplate/web stiffness must establish that load path.',
            'Tube weld uses a rectangular perimeter approximation; parent weld uses the exact declared polygon. No acceptance from calculated stress alone.']),
        hub_and_rotor=dict(cases=hub,key_width_mm=28,key_height_mm=16,key_lengths_mm=None,
            interpretation='Two keys are in series: axle-to-sleeve and sleeve-to-hub. They are not two parallel keys sharing torque. Divide each shear coefficient by its actual loaded key length in mm.',
            limitations=['Rotor bolt load is an ideal equal-share tangential demand, with no friction credit. Actual PK bolt grade, engagement, flange thickness, preload, pilot fit and bolt bending are unresolved.',
                'Key bearing engagement, loaded length, fit and sleeve split geometry are not established by this arithmetic.',
                'The solid 100 mm axle torsion value excludes keyways, wheelset bending, stress concentrations and fatigue; it is not axle qualification.']))
