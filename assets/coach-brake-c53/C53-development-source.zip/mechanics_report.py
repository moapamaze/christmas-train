"""Readable C53 mechanics record, generated from the calculation dictionary."""
def write_report(j, base, sources):
    c = j['carrier_load_screen']; g = c['geometry']
    demand = '\n'.join(f"| {q['coach']} | {q['deceleration_m_s2']:.1f} | {q['torque_per_disc_Nm']:.3f} | {q['torque_per_axle_Nm']:.3f} |" for q in j['service_demands'])
    heat = '\n'.join(f"| {q['coach']} | {q['full_stop_heat_coach_J']/1000:.3f} | {q['full_stop_heat_per_disc_J']/1000:.3f} | {q['heat_per_disc_from_10m_vertical_descent_J']/1000:.3f} |" for q in j['kinetic_heat'])
    nominal = '\n'.join(f"| {q['torque_per_disc_Nm']:.3f} | {abs(q['axial_link_force_N'])/1000:.3f} | {q['bearing_radial_loads_N'][0]/1000:.3f} | {q['bearing_radial_loads_N'][1]/1000:.3f} |" for q in c['nominal_cases'])
    envelope = '\n'.join(f"| {q['torque_per_disc_Nm']:.3f} | {q['motion_range']} | {abs(q['worst_link']['axial_link_force_N'])/1000:.3f} | {q['worst_bearing_1']['bearing_radial_loads_N'][0]/1000:.3f} | {q['worst_bearing_2']['bearing_radial_loads_N'][1]/1000:.3f} |" for q in c['envelopes'])
    beam = '\n'.join(f"| {q['torque_each_of_two_discs_Nm']:.3f} | {q['maximum_biaxial_gross_bending_MPa']:.1f} | {q['outer_span_Bredt_torsion_MPa']:.1f} | {q['conservative_combined_VM_MPa']:.1f} | {'Above reference' if q['above_reference_yield'] else 'Below reference only'} |" for q in c['frame_crossbeam']['cases'])
    ordinary = [p for p in c['pose_cases'] if p['within_regular_journal_travel']]
    captured = [p for p in c['pose_cases'] if p['heave_mm'] == -60]
    bearing = c['selected_bearing']
    f = c['frame_crossbeam']
    weldrows = '\n'.join(f"| {q['torque_each_of_two_brakes_Nm']:.3f} | {q['tube_to_endplate']['peak_ideal_elastic_traction_MPa']:.1f} | {q['endplate_to_inner_web']['peak_ideal_elastic_traction_MPa']:.1f} |" for q in c['connections']['welds']['cases'])
    pinrows = '\n'.join(f"| {q['torque_per_disc_Nm']:.3f} | {q['motion_range']} | {q['pin_combined_VM_MPa']:.1f} | {q['link_eye_net_axial_MPa']:.1f} | {q['clevis_projected_bearing_MPa']:.1f} |" for q in c['link_and_pins']['cases'] if q['torque_per_disc_Nm'] in [363.825,10000] and q['motion_range'] in ['journal_consistent_regular','captured_extension_sensitivity'])
    text = f'''# C53 disc-brake mechanics — D1

**Unrated development record. High torque comparison cases fail the first bearing and frame-beam screens. Maximum actuator output remains unresolved.** Eight inboard discs are proposed, using axle-aligned caliper carriers and air-service/spring-parking actuation. Routine pad service is intended to remain accessible. Replacing a one-piece inboard rotor requires wheelset removal and shop rail-wheel removal/reinstallation.

The exact rotor is **Webb 55030PK-65**, nominally 325.12 × 34.036 mm, with a 168.91 mm pilot and eight M14 × 2 holes on a 195.834 mm pitch circle. It requires a custom hub. Hendrickson S-33391 has a different 220 mm pilot and eight M16 interface and is **not assumed interchangeable**. The Webb catalogue's 148.59 mm overall depth does not establish every internal web thickness or the controlled hub mating-face offset.

PAN17 calipers S-39094-L/R (WABCO 40175072/73) and S-41159-1 pads are commercial family candidates. Compatibility with this exact Webb rotor and custom hub remains conditional; this is not a matched complete commercial assembly. L949 Rev T lists 22/24 chambers S-40979-L/R / TSE 2224TLD2H-4627/4628, while its pad table retains a 20/24 reference. The exact configuration and manufacturer acceptance remain open. Earlier 18/24 or 20/24 force curves are not substituted.

## Working demand and heat

Basis: 13,200 kg regular or 11,000 kg accessible coach, four axles, eight 600 mm wheels/discs, ideal equal sharing, **level track / zero grade**, and an assumed 1.05 rotational-inertia factor. These are working demands, not maximum component loads.

| Coach | Deceleration, m/s² | Torque per disc, Nm | Torque per axle, Nm |
|---|---:|---:|---:|
{demand}

At 7.5 mph, the modeled level-track full-stop energy is:

| Coach | Entire coach, kJ | Per disc, kJ | Separate 10 m descent heat per disc, kJ |
|---|---:|---:|---:|
{heat}

The regular 0.7 m/s² case begins at 4.066 kW per disc. Illustrative effective pad radii of 120/130/140 mm give 3.032/2.799/2.599 kN total tangential pad force. Actual torque-weighted radius must come from the installed lining contact; rotor outside radius is not a substitute. The JSON distinguishes both pads' summed normal force from one-face force. Heat input does not establish temperature, fade, cooling or repeated-stop duty. Route grade and duty remain unselected.

## Output and load path

The bounded primary-source search verified the exact current 22/24 identifiers but did not locate their controlled outline, permissible pressure or full service/spring force curves. TSE's 90–120 psi caging instruction is not a maximum service-pressure rating. No assumed pressure times nominal chamber area is presented as an output bound. Compounding, pressure faults and the caliper's input-to-torque relationship remain required inputs.

The PAN17 drawing's **10,000 Nm maximum transferable mounting-interface torque** is used only as a structural comparison case. It is not rated braking performance, an actuator maximum, a torque limiter or an established required proof load. The note calls for six M14 × 1.5 class 10.9 screws, at least 18 mm engagement and 205–225 Nm tightening torque. It does not qualify custom joints. Its 330 mm disc reference also needs reconciliation with the 325.12 mm Webb rotor.

The rotor torque path is axle → custom keyed hub/reducer → bolted rotor → pads. The reaction path is pads → OEM caliper bolts → custom axle-aligned carrier → single articulated torque link → **new transverse frame crossmember → inner sideframe webs**. It does not rely on the axlebox cover or route the link through the wheel web. Two rolling bearings support and align the carrier while the axle rotates; the link restrains carrier clock rotation. Loss of that active restraint can permit carrier rotation, hose damage and loss of controlled braking. A catcher is not a second functioning brake.

## Bearing and finite-link screen

The first geometry uses bearing centres Y = {g['bearing_centres_y_mm']} mm, rotor force plane Y = 240 mm, carrier pin (600, 170, 450) mm and fixed frame pin (350, 170, 500) mm. The link is 254.951 mm long, but its nominal effective torque arm is only 147.087 mm.

The documented bearing candidate is **{bearing['part']}**, dimensions {bearing['dimensions_d_D_B_mm']} mm, catalogue Cr = {bearing['Cr_N']/1000:g} kN and C0r = {bearing['C0r_N']/1000:g} kN. Catalogue evidence does not establish current inventory or an installed rating. A 120 mm bore permits passage over the nominal 110 mm wheel seat after wheel removal. The removable split 100-to-120 mm support sleeve, shoulders, fits and race-creep prevention remain custom design requirements. The earlier 100 mm bore cannot pass that seat; a nominal 110 mm bore does not establish assembly clearance.

Nominal results below use a 120 mm effective pad radius, zero heave/roll/lateral shift, one braking direction and zero added carrier mass:

| Torque per disc, Nm | Link force, kN | Inboard radial load, kN | Outboard radial load, kN |
|---:|---:|---:|---:|
{nominal}

**High torque probes exceed the selected bearing's C0r reference.** The short bearing span magnifies the overhung pad resultant. C0r is not a design allowable; values below it do not establish bearing life, shock capacity, combined-load acceptance or installation stiffness.

The solver closes the fixed link under axle heave, roll and lateral shift and balances all six force/moment components in carrier axes. Only the inboard station locates axially. Both torque signs are checked. The grid includes heave −40/−30/0/+35 mm, roll ±2°/0, lateral ±3/0 mm and additional journal-travel boundary states. The regular rows enforce both journal heights h ± 620 sin(roll) within −40 to +35 mm; accessible rows use −30 to +35 mm. Unrestricted combined rows deliberately retain overtravel sensitivities, while −60 mm is separately labeled captured extension. Thus h = +35 mm with roll = 2° is not presented as ordinary travel: one journal would rise 56.64 mm. These are vertical-journal-travel-admissible development screens, not full kinematic acceptance. The ±3 mm independent centre-lateral probe does not establish the retained locating/floating journal arrangement's actual lateral freedom.

Vertical-journal-travel-admissible regular-grid carrier clock ranges from {min(p['carrier_clock_deg'] for p in ordinary):.3f}° to {max(p['carrier_clock_deg'] for p in ordinary):.3f}°, with minimum effective torque arm {min(p['effective_torque_arm_mm'] for p in ordinary):.3f} mm. The captured-extension minimum is {min(p['effective_torque_arm_mm'] for p in captured):.3f} mm. Load probes also use effective radius 120/130/140 mm and 0/50 kg nonrotating mass at local CG {g['nonrotating_mass_probe_cg_local_mm']} mm. The 50 kg value is not measured CAD mass or a certified upper bound. Rotor weight acts directly on the axle.

| Torque per disc, Nm | Motion probe | Maximum link, kN | Maximum inboard radial, kN | Maximum outboard radial, kN |
|---:|---|---:|---:|---:|
{envelope}

The row maxima need not occur in one pose. JSON retains each governing pose, signed reactions and locating-bearing axial load. The {c['solved_load_case_count']} solved cases have maximum force residual {c['verification']['max_force_residual_N']:.2e} N and moment residual {c['verification']['max_moment_residual_Nmm']:.2e} Nmm.

## Current frame crossmember and link

The current member is **{f['candidate']}**, section {f['nominal_section_X_Z_wall_mm']} mm, centred at {f['centre_mm']} mm and supported at Y = {f['support_y_mm']} mm. It replaces the failed initial 3 × 3 candidate. The link anchor remains outside the member at {g['fixed_frame_pin_mm']} mm, so the real rising bracket introduces eccentric torque. Both same-axle brake reactions add. The screen uses the 0.93 wall factor, a rounded-corner sensitivity with outer radius three design walls, and symmetric torsional restraint at the member ends. That assumed end restraint still requires a real qualified load path.

| Torque at each of two brakes, Nm | Biaxial bending, MPa | Torsion, MPa | Combined VM, MPa | Versus assumed 345 MPa yield |
|---:|---:|---:|---:|---|
{beam}

The 10 kNm case remains above this gross member reference. No further member iteration is represented. The actual maximum chamber/caliper torque must be established before final sizing. Rounded corners are a section-property sensitivity, not a verified supplier radius. Local member walls, gusset and endplate welds, bearing seats, fatigue and frame stiffness remain unqualified.

The actual link has a 40 × 12 mm shank, 60 mm eye outside diameter and 35 mm Aurora GE20ES-2RS bearing seat. Clevises have 10 mm cheeks and 24 mm clear gap. The custom 20 mm headed pins are screened over the actual 34 mm reaction-centroid span, using a central point-load model for bending plus double shear. Custom pin material/heat treatment has not been specified, so no pin-strength pass is assigned.

| Torque per disc, Nm | Motion probe | Pin gross VM, MPa | Eye net axial stress, MPa | Cheek projected bearing, MPa |
|---:|---|---:|---:|---:|
{pinrows}

The Aurora bearing's 146 kN radial static catalogue reference does not qualify its housing, pin or link. Eye-net, projected-bearing and ideal Euler-shank checks are conditional local screens; they do not establish interference fit, race retention, breakout, oscillatory wear or fatigue life. Exact pin cross-hole, fillet and retention details also remain required.

The declared continuous 6 mm fillets receive a separate elastic weld-line screen. Each symmetric frame end transfers one brake force resultant and one bracket's torsional moment. The tube weld uses a rectangular perimeter approximation; the parent-web weld uses the declared endplate polygon and includes the 12 mm transfer offset. No weld allowable is assigned.

| Torque at each brake, Nm | Tube-to-endplate peak ideal traction, MPa | Endplate-to-web peak ideal traction, MPa |
|---:|---:|---:|
{weldrows}

These are connection demands, not accepted weld capacities. Actual bead geometry, effective lengths, welding procedure, parent-wall load introduction, end torsional restraint and fatigue remain holds. The rotor-bolt and keyed-hub record separately gives ideal torque demand: two keys transfer torque **in series**, not as two parallel load-sharing keys. Their loaded lengths, bearing engagement and fatigue effect on the axle remain open. The 10 kNm comparison gives 12.766 kN tangential demand per rotor bolt under ideal equal sharing, and 200/166.667 kN at the 100/120 mm key interfaces respectively. No friction credit or keyway fatigue acceptance is assumed.

## Service and acceptance holds

A caliper fixed to the upright axlebox would not follow axle tilt inside its journal bearing. At 2°, the rotor edge-plane mismatch is approximately 5.67 mm. A coaxial carrier follows the axle; its frame link must articulate through finite motion. The commercial wear slide is not itself angular accommodation.

Reserve actual pad extraction, adjuster access, full-wear caliper/chamber space, hoses, caging and removal. The family application guide describes approximately 25.4 mm wear movement; the caliper drawing gives 21 mm, so the larger reservation remains pending reconciliation. Rotor service requires supported wheelset removal, controlled wheel removal/reinstallation, runout and torque-joint inspection. Do not split or alter the OEM friction ring to bypass that procedure.

No joint strength, bearing or fatigue life, thermal duty, adhesion control, stopping distance or operating rating is assigned. Exact rotor/pad/chamber pairing, custom hub, carrier and frame attachments remain unresolved engineering interfaces.

## Sources and reproduction

`calculate_mechanics.py`, `carrier_statics.py`, `connection_screens.py` and `mechanics_report.py` reproduce this note and `mechanics-calculations.json` using Python's standard library. The JSON records geometry snapshot hashes, sensitivity inputs and governing cases.

'''
    text += '\n'.join(f"- [{s['id']}]({s['url']}) — {s['supports']}" for s in sources) + '\n'
    (base/'mechanics-calculations.md').write_text(text)
