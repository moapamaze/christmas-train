"""Reproducible C53 conditional rigid-carrier statics; units N, mm, Nm.

Catalogue ratings are comparisons, not design allowables. The actual actuator
maximum is deliberately not assigned. Stdlib only; no geometry mutations.
"""
import math
import json
import hashlib
from pathlib import Path
from connection_screens import connection_screens

BASE = Path(__file__).resolve().parent
G = 9.80665
BEARINGS = {
    'NSK6824DD': dict(part='NSK 6824DD', dimensions_d_D_B_mm=[120,150,16], Cr_N=32000, C0r_N=35500,
        grease_speed_rpm=2200,mass_kg=.537,shaft_abutment_range_mm=[125,127],housing_abutment_max_mm=145,
        fillet_max_mm=1,source_url='https://www.nsk.com/engineering/products/bearings/ball-bearings/deep-groove-ball-bearings/single-row-deep-groove-ball-bearings/6824dd-apn.html'),
    'NSK6024DDU': dict(part='NSK 6024DDU', dimensions_d_D_B_mm=[120,180,28], Cr_N=97000,C0r_N=80000,
        grease_speed_rpm=2200,mass_kg=2.08,shaft_abutment_range_mm=[129,134.5],housing_abutment_max_mm=171,
        fillet_max_mm=2,source_url='https://www.oss.nsk.com/eu/6024ddu-apn.html'),
    'NSK6020DDU': dict(part='NSK 6020DDU — superseded assembly-obstructed D0', dimensions_d_D_B_mm=[100,150,24],Cr_N=66000,C0r_N=54000,
        grease_speed_rpm=2600,mass_kg=1.29,shaft_abutment_range_mm=[108,112.5],housing_abutment_max_mm=142,
        fillet_max_mm=1.5,source_url='https://www.nsk.com/engineering/products/bearings/ball-bearings/deep-groove-ball-bearings/single-row-deep-groove-ball-bearings/6020ddu-apn.html')
}

def add(a, b): return [x + y for x, y in zip(a, b)]
def sub(a, b): return [x - y for x, y in zip(a, b)]
def scale(a, k): return [x * k for x in a]
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def norm(a): return math.sqrt(dot(a, a))
def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def rx(v, a):
    c, s = math.cos(a), math.sin(a)
    return [v[0], c*v[1]-s*v[2], s*v[1]+c*v[2]]
def ry(v, a):
    c, s = math.cos(a), math.sin(a)
    return [c*v[0]+s*v[2], v[1], -s*v[0]+c*v[2]]
def transform(v, clock, roll): return rx(ry(v, clock), roll)
def inverse(v, clock, roll): return ry(rx(v, -roll), -clock)

def close_link(heave, roll_deg, lateral, geometry):
    roll = math.radians(roll_deg)
    base = geometry['reference_axle_origin_mm']
    origin = add(base, [0., lateral, heave])
    pin = geometry['carrier_pin_local_mm']
    anchor = geometry['fixed_frame_pin_mm']
    length = geometry['link_length_mm']
    clock = 0.
    for _ in range(30):
        moving = add(origin, transform(pin, clock, roll))
        delta = sub(moving, anchor)
        derivative = transform([pin[2], 0, -pin[0]], clock, roll)
        residual = dot(delta, delta) - length*length
        step = residual / (2*dot(delta, derivative))
        clock -= step
        if abs(step) < 1e-13: break
    moving = add(origin, transform(pin, clock, roll))
    residual = norm(sub(moving, anchor)) - length
    assert abs(residual) < 1e-8
    u_world = scale(sub(anchor, moving), 1/length)
    u_local = inverse(u_world, clock, roll)
    arm = cross(pin, u_local)[1]
    journal_heaves = [heave-620*math.sin(roll), heave+620*math.sin(roll)]
    return dict(heave_mm=heave, axle_roll_deg=roll_deg, lateral_mm=lateral,
        journal_heaves_y_minus_plus_620_mm=journal_heaves,
        within_regular_journal_travel=min(journal_heaves)>=-40-1e-7 and max(journal_heaves)<=35+1e-7,
        within_accessible_journal_travel=min(journal_heaves)>=-30-1e-7 and max(journal_heaves)<=35+1e-7,
        carrier_clock_deg=math.degrees(clock), moving_pin_mm=moving,
        link_unit_world=u_world, link_unit_carrier=u_local,
        signed_effective_torque_arm_mm=arm, effective_torque_arm_mm=abs(arm),
        closure_residual_mm=residual)

def case(torque, radius, mass, direction, pose, geometry):
    clock = math.radians(pose['carrier_clock_deg'])
    roll = math.radians(pose['axle_roll_deg'])
    # One resultant at the effective pad radius; no net axial pad imbalance.
    pad_position = [radius, geometry['rotor_plane_y_mm'], 0.]
    pad_force = [0., 0., -direction*torque*1000/radius]
    gravity_position = geometry['nonrotating_mass_probe_cg_local_mm']
    gravity = inverse([0., 0., -mass*G], clock, roll)
    known_moment = add(cross(pad_position, pad_force), cross(gravity_position, gravity))
    pin = geometry['carrier_pin_local_mm']
    u = pose['link_unit_carrier']
    axial = -known_moment[1] / cross(pin, u)[1]
    link_force = scale(u, axial)
    force = add(add(pad_force, gravity), link_force)
    moment = add(known_moment, cross(pin, link_force))
    y1, y2 = geometry['bearing_centres_y_mm']
    total_x, total_z = -force[0], -force[2]
    r2x = (moment[2]-y1*total_x)/(y2-y1)
    r2z = (-moment[0]-y1*total_z)/(y2-y1)
    r1 = [total_x-r2x, -force[1], total_z-r2z]
    r2 = [r2x, 0., r2z]
    force_residual = add(add(force, r1), r2)
    moment_residual = add(add(moment, cross([0,y1,0],r1)), cross([0,y2,0],r2))
    assert norm(force_residual) < 1e-7
    assert norm(moment_residual) < 1e-5
    fr = [math.hypot(r1[0],r1[2]), math.hypot(r2[0],r2[2])]
    return dict(torque_per_disc_Nm=torque, torque_direction=direction,
        effective_pad_radius_mm=radius, nonrotating_mass_probe_kg=mass,
        heave_mm=pose['heave_mm'], axle_roll_deg=pose['axle_roll_deg'], lateral_mm=pose['lateral_mm'],
        carrier_clock_deg=pose['carrier_clock_deg'], effective_torque_arm_mm=pose['effective_torque_arm_mm'],
        axial_link_force_N=axial, link_force_world_N=transform(link_force,clock,roll),
        bearing_reactions_carrier_N=[r1,r2], bearing_radial_loads_N=fr,
        locating_bearing_axial_load_N=abs(r1[1]),
        radial_load_over_catalogue_C0r=[v/geometry['bearing_C0r_N'] for v in fr],
        within_regular_journal_travel=pose['within_regular_journal_travel'],
        within_accessible_journal_travel=pose['within_accessible_journal_travel'],
        journal_heaves_y_minus_plus_620_mm=pose['journal_heaves_y_minus_plus_620_mm'],
        max_force_residual_N=norm(force_residual), max_moment_residual_Nmm=norm(moment_residual))

def rounded_inertia(width, height, radius):
    # Simpson integration of the exact rounded-rectangle strip width.
    n=4000; dz=height/n; total=0.
    for i in range(n+1):
        z=-height/2+i*dz; a=abs(z)
        w=width if a<=height/2-radius else width-2*radius+2*math.sqrt(max(0,radius**2-(a-(height/2-radius))**2))
        total+=(1 if i in (0,n) else (4 if i%2 else 2))*w*z*z
    return total*dz/3

def frame_beam_screen(data, nominal_cases):
    # Both mirrored brakes apply the same physical X reaction. Symmetric ends
    # share torsion; no cancellation of the two brake forces is credited.
    frame=data['frame_support']
    dims=frame.get('section_mm')
    if dims is None and 'section_outside_xz_mm' in frame:
        dims=frame['section_outside_xz_mm']+[frame['nominal_wall_mm']]
    if dims is None:
        # Only the explicit original contract is allowed as a historical case.
        assert frame['candidate_stock'].startswith('HSS3x3x1/4'), 'Final contract needs numeric frame_support.section_mm=[X,Z,wall].'
        dims=[76.2,76.2,6.35]
    b,h,tnom=dims; t=tnom*.93
    support=frame.get('tube_end_y',frame['span_to_inner_web_y'])
    arm=abs(support[1])-abs(data['link']['fixed_frame'][1])
    eccentricity=sub(data['link']['fixed_frame'],frame['centre'])
    eccentricity[1]=0.
    ix=(b*h**3-(b-2*t)*(h-2*t)**3)/12
    iz=(h*b**3-(h-2*t)*(b-2*t)**3)/12
    ro=3*t; ri=ro-t
    ixr=rounded_inertia(b,h,ro)-rounded_inertia(b-2*t,h-2*t,ri)
    izr=rounded_inertia(h,b,ro)-rounded_inertia(h-2*t,b-2*t,ri)
    sx,sz=ixr/(h/2),izr/(b/2)
    rm=ro-t/2
    median_area=(b-t)*(h-t)-(4-math.pi)*rm*rm
    rows=[]
    for q in nominal_cases:
        load=scale(q['link_force_world_N'],-1)
        mx=abs(load[2])*arm; mz=abs(load[0])*arm
        sigma=mx/sx+mz/sz
        ty=abs(cross(eccentricity,load)[1])
        tau=ty/(2*median_area*t)
        vm=math.sqrt(sigma*sigma+3*tau*tau)
        rows.append(dict(torque_each_of_two_discs_Nm=q['torque_per_disc_Nm'],each_frame_bracket_force_N=load,
            bracket_offset_from_member_axis_mm=eccentricity,each_bracket_moment_Y_Nmm=ty,
            maximum_biaxial_gross_bending_MPa=sigma,outer_span_Bredt_torsion_MPa=tau,
            conservative_combined_VM_MPa=vm,reference_yield_MPa=345,above_reference_yield=vm>345))
    return dict(candidate=frame['candidate_stock'],nominal_section_X_Z_wall_mm=dims,design_wall_mm=t,
        centre_mm=frame['centre'],support_y_mm=support,force_application_y_mm=[-abs(data['link']['fixed_frame'][1]),abs(data['link']['fixed_frame'][1])],
        sharp_corner_Ix_Iz_mm4=[ix,iz],rounded_outer_radius_probe_mm=ro,rounded_Sx_Sz_mm3=[sx,sz],rounded_median_area_mm2=median_area,cases=rows,
        status='CONDITIONAL NOMINAL GROSS SCREEN; failed comparisons retained; no maximum actuator load established.',
        limitations=['Both same-axle brakes apply the same physical X reaction; the forces add.',
            'Rounded corner radius is a conservative section-property sensitivity, not a verified stock-section dimension.',
            'Torsional reactions split equally between symmetric restrained ends. Actual end-joint torsional stiffness and local frame load transfer remain unqualified.',
            'Combined stress conservatively applies outer-span torsion and maximum adjacent bending together.',
            'Bracket local plate/weld bending, member-wall distortion, shear, fatigue, buckling and end attachments are not qualified by this gross screen.'])

def link_screen(data, envelopes):
    link=data['link']; d=link['pin_diameter_mm']; span=link['pin_reaction_centroid_span_mm']
    t=link['link_plate_thickness_mm']; w=link['link_shank_width_mm']
    eye=link['link_eye_outer_diameter_mm']; bore=link['bearing_d_D_B_C_mm'][1]
    cheek=link['clevis_cheek_thickness_mm']; length=data['link']['eye_spacing']
    rows=[]
    for e in envelopes:
        f=abs(e['worst_link']['axial_link_force_N'])
        moment=f*span/4 # Point load at centre is conservative versus a finite inner ring load width.
        bending=32*moment/(math.pi*d**3)
        shear=2*f/(math.pi*d*d)
        rows.append(dict(torque_per_disc_Nm=e['torque_per_disc_Nm'],motion_range=e['motion_range'],
            load_N=f,pin_simple_support_max_moment_Nmm=moment,pin_gross_bending_MPa=bending,
            pin_average_double_shear_MPa=shear,pin_combined_VM_MPa=math.sqrt(bending*bending+3*shear*shear),
            link_shank_axial_MPa=f/(w*t),link_eye_net_axial_MPa=f/((eye-bore)*t),
            clevis_projected_bearing_MPa=f/(2*d*cheek),spherical_catalogue_radial_ratio=f/146000))
    inertia=w*t**3/12
    return dict(geometry_from_contract={k:link[k] for k in ['bearing_sku','pin_diameter_mm','clevis_cheek_thickness_mm',
        'clevis_clear_gap_mm','pin_reaction_centroid_span_mm','link_plate_thickness_mm','link_shank_width_mm','link_eye_outer_diameter_mm','link_retention']},
        pin_material_strength_MPa=None,pin_status='Custom headed retained pin; no material/heat-treatment strength is assigned.',
        spherical_bearing_radial_static_reference_N=146000,
        spherical_source='../coach-brake-c52/joint-components.json, Aurora GE20ES-2RS primary catalogue record; not an interchangeable SKF rating.',
        shank_only_pinned_Euler_load_N=math.pi**2*200000*inertia/length**2,
        Euler_status='Ideal straight 40 x 12 mm steel shank, E = 200 GPa, pinned eye spacing. Not a capacity of the perforated eye, imperfect complete link or joint.',
        cases=rows,limitations=['Pin model checks bending as well as double shear using the actual 34 mm reaction-centroid span.',
            'Fits, pin contact, retaining cross-hole, fillet, fatigue and dynamic shock remain open.',
            'Eye-net and projected-bearing stresses do not establish bearing-seat interference, breakout, ring retention or fatigue capacity.',
            'Custom pin material and actual plate material certificates are required before a strength comparison can be accepted.'])

def carrier_screen():
    contract=BASE/'geometry-contract.json'
    data=json.loads(contract.read_text())
    bearing=dict(BEARINGS[data['carrier']['bearing_sku'].replace(' ','')])
    bearing.update(availability='Catalogue evidence only; current stock not verified.',
        installation='120 mm bore clears the nominal 110 mm wheel seat after wheel removal. Split 100-to-120 mm sleeve, fits, shoulders and race-creep prevention remain custom design holds.')
    assert bearing['dimensions_d_D_B_mm']==data['carrier']['bearing_d_DB']
    geometry=dict(reference_axle_origin_mm=data['base']['reference_axle_centre'],
        bearing_centres_y_mm=data['carrier']['bearing_centres_y'],bearing_C0r_N=bearing['C0r_N'],
        rotor_plane_y_mm=data['rotor']['friction_centre_y'],
        carrier_pin_local_mm=sub(data['link']['moving_reference'],data['base']['reference_axle_centre']),
        fixed_frame_pin_mm=data['link']['fixed_frame'],link_length_mm=data['link']['eye_spacing'],
        nonrotating_mass_probe_cg_local_mm=[100,data['carrier']['mount_flange_y'],0],
        basis='Actual numeric geometry-contract.json pin, bearing, rotor and frame coordinates; custom supplier interfaces remain conditional.',
        contract_sha256_at_generation=hashlib.sha256(contract.read_bytes()).hexdigest(),
        contract_revision_at_generation=data['revision'],contract_bearing_sku_at_generation=data['carrier']['bearing_sku'])
    states=set()
    for r in [-2,0,2]:
        delta=620*abs(math.sin(math.radians(r)))
        # Include valid journal-travel boundary states as well as the deliberately
        # unrestricted Cartesian combinations retained for sensitivity review.
        heights=[-60,-40,-30,0,35,-40+delta,-30+delta,35-delta]
        for h in heights:
            for lateral in [-3,0,3]: states.add((h,r,lateral))
    poses=[close_link(h,r,l,geometry) for h,r,l in sorted(states)]
    torques=[363.825,1000,3000,6000,10000]
    summary=[]; checks=0; max_fr=0; max_mr=0
    for torque in torques:
        cases=[case(torque,re,m,d,p,geometry) for p in poses for re in [120,130,140] for m in [0,50] for d in [-1,1]]
        checks+=len(cases)
        max_fr=max(max_fr,max(q['max_force_residual_N'] for q in cases))
        max_mr=max(max_mr,max(q['max_moment_residual_Nmm'] for q in cases))
        for range_name,predicate in [
            ('journal_consistent_regular',lambda q:q['within_regular_journal_travel']),
            ('journal_consistent_accessible',lambda q:q['within_accessible_journal_travel']),
            ('unrestricted_combined_sensitivity',lambda q:q['heave_mm']>=-40),
            ('captured_extension_sensitivity',lambda q:q['heave_mm']==-60)]:
            group=[q for q in cases if predicate(q)]
            summary.append(dict(torque_per_disc_Nm=torque, motion_range=range_name,
                torque_basis='Ideal equal-share service demand' if torque==363.825 else ('OEM mounting-interface comparison, not actuator maximum' if torque==10000 else 'Unrated torque sensitivity, not actuator maximum'),
                case_count=len(group),
                worst_bearing_1=max(group,key=lambda q:q['bearing_radial_loads_N'][0]),
                worst_bearing_2=max(group,key=lambda q:q['bearing_radial_loads_N'][1]),
                worst_link=max(group,key=lambda q:abs(q['axial_link_force_N'])),
                worst_locating_axial=max(group,key=lambda q:q['locating_bearing_axial_load_N'])))
    nominal=close_link(0,0,0,geometry)
    nominal_cases=[case(t,120,0,1,nominal,geometry) for t in torques]
    return dict(status='CONDITIONAL; HIGH TORQUE PROBES EXCEED BEARING STATIC REFERENCE; NOT A BRAKE RATING',
        geometry=geometry,
        selected_bearing=bearing,
        superseded_bearings=[dict(part='NSK 6020DDU',reason='100 mm closed bore cannot pass retained 110 mm wheel seat.'),
            dict(part='NSK 6022DDU',reason='110 mm nominal bore does not establish clearance over a nominal 110 mm press-fit wheel seat.'),
            dict(part='NSK 6024DDU',reason='120 mm bore solves passage, but 180 mm OD housing clashes with the chosen caliper support envelope; thin 6824DD retained as an unrated development candidate.')],
        equations=['P = O + Rx(axle roll) Ry(carrier clock) [0,170,150]; solve |P-A| = fixed link length on the branch near zero clock.',
            'Pad tangential resultant = torque/effective radius at local [effective radius,240,0]. No net axial pad imbalance is assumed.',
            'Signed link force balances local axle-axis moment. Two spaced radial-bearing reactions balance remaining force and moments; only inboard bearing locates axially.',
            'Six equilibrium residuals are checked for every solved case. C0r comparison uses radial load only; combined-load acceptance and safety factor remain open.'],
        load_grid=dict(torques_per_disc_Nm=torques,effective_radius_mm=[120,130,140],
            nonrotating_mass_probe_kg=[0,50],mass_status='0/50 kg sensitivity, not measured CAD mass or a certified upper bound. CG explicitly [100,199,0] in carrier coordinates. Rotor mass is not carried by the stationary carrier.',
            torque_directions=[-1,1],heave_mm=sorted(set(q['heave_mm'] for q in poses)),axle_roll_deg=[-2,0,2],lateral_mm=[-3,0,3],
            motion_status='Regular/accessibility rows filter BOTH journal heaves h +/- 620 sin(roll) against their respective [-40,+35]/[-30,+35] mm travel. Unrestricted combined and captured-extension rows explicitly include overtravel sensitivities; no operating limit is inferred.'),
        nominal_cases=nominal_cases,
        pose_cases=poses,envelopes=summary,solved_load_case_count=checks,
        verification=dict(max_force_residual_N=max_fr,max_moment_residual_Nmm=max_mr,
            max_length_residual_mm=max(abs(p['closure_residual_mm']) for p in poses)),
        frame_crossbeam=frame_beam_screen(data,nominal_cases),link_and_pins=link_screen(data,summary),
        connections=connection_screens(data,nominal_cases),
        limitations=['Actual TSE chamber pressure/force and caliper transfer remain unknown. These torque probes cannot establish the required maximum structural design load.',
            'The short bearing span produces a large overhang couple; catalogue C0r is not an allowable load or a full installation acceptance.',
            'No bearing life, shock factor, race fit, sleeve rigidity, thermal growth or fatigue spectrum has been qualified.',
            'No claim of zero collision or service access follows from rigid-body equilibrium.',
            'Pad-force imbalance, carrier inertia, hose loads, shock and return/caging forces are not represented by the gravity sensitivity.',
            'Pin, link, housing, custom hub, axle key and frame-end joint strength require their actual final geometry.'])

if __name__=='__main__':
    j=carrier_screen()
    print(json.dumps({'cases':j['solved_load_case_count'],'verification':j['verification'],
        'nominal':[(q['torque_per_disc_Nm'],q['bearing_radial_loads_N']) for q in j['nominal_cases']]},indent=2))
