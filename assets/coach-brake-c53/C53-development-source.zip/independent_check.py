"""Independent closed-form kinematics and selected exact C5 geometry checks.

This does not import the geometry builder and never mutates geometry.
Run after the final contract/checkpoint is stable. No operating rating is given.
"""
from pathlib import Path
import math, json, hashlib, importlib.util
import numpy as np
import cadquery as cq
H=Path(__file__).resolve().parent
B=H.parent/'coach-truck-c5'
g=json.loads((H/'geometry-contract.json').read_text())
origin=np.array(g['base']['reference_axle_centre'],float)
pin=np.array(g['link']['moving_reference'],float)-origin
anchor=np.array(g['link']['fixed_frame'],float)
L=g['link']['eye_spacing']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rx(p):
 c,s=math.cos(p),math.sin(p)
 return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def ry(p):
 c,s=math.cos(p),math.sin(p)
 return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def close(h,roll,lat):
 R=rx(math.radians(roll));O=origin+[0,lat,h]+R@np.array([0,pin[1],0])
 a=R@np.array([pin[0],0,pin[2]]);b=R@np.array([pin[2],0,-pin[0]]);D=anchor-O
 A=float(D@a);BB=float(D@b);C=float((D@D+a@a-L*L)/2);rho=math.hypot(A,BB)
 if abs(C)>rho: raise ValueError('No finite-link closure')
 phase=math.atan2(BB,A);alpha=math.acos(C/rho)
 choices=[math.atan2(math.sin(phase+s*alpha),math.cos(phase+s*alpha)) for s in[-1,1]]
 theta=min(choices,key=abs);P=O+a*math.cos(theta)+b*math.sin(theta);u=(anchor-P)/L;axis=R@np.array([0,1.,0])
 return dict(heave_mm=float(h),roll_deg=float(roll),lateral_mm=float(lat),clock_deg=math.degrees(theta),effective_arm_mm=abs(float(np.cross(P-O,u)@axis)),length_residual_mm=abs(float(np.linalg.norm(anchor-P))-L),fixed_joint_out_of_plane_deg=math.degrees(math.asin(abs(float(u[1])))),carrier_joint_out_of_plane_deg=math.degrees(math.asin(abs(float(u@axis)))),plane_normal_vector_difference=float(np.linalg.norm(R@ry(theta)@np.array([0,1,0])-axis)),moving_pin_mm=P.tolist(),unit_world=u.tolist())
def summarize(rows):
 return dict(states=len(rows),minimum_clock=min(rows,key=lambda q:q['clock_deg']),maximum_clock=max(rows,key=lambda q:q['clock_deg']),minimum_effective_arm=min(rows,key=lambda q:q['effective_arm_mm']),max_length_residual_mm=max(q['length_residual_mm']for q in rows),max_plane_normal_vector_difference=max(q['plane_normal_vector_difference']for q in rows),max_frame_joint_out_of_plane_deg=max(q['fixed_joint_out_of_plane_deg']for q in rows),max_carrier_joint_out_of_plane_deg=max(q['carrier_joint_out_of_plane_deg']for q in rows))
regular=[]
for roll in np.linspace(-2,2,81):
 travel=620*abs(math.sin(math.radians(roll)))
 for h in np.linspace(-40+travel,35-travel,76):
  for lat in [-3,0,3]:regular.append(close(h,roll,lat))
probe=[close(h,r,l)for h in[-60,-40,-30,0,35]for r in[-2,0,2]for l in[-3,0,3]]
# Separate matrix equilibrium compared with the foundation's direct formulas.
spec=importlib.util.spec_from_file_location('foundation_statics',H/'carrier_statics.py');st=importlib.util.module_from_spec(spec);spec.loader.exec_module(st)
sg=dict(reference_axle_origin_mm=origin.tolist(),carrier_pin_local_mm=pin.tolist(),fixed_frame_pin_mm=anchor.tolist(),link_length_mm=L,bearing_centres_y_mm=g['carrier']['bearing_centres_y'],rotor_plane_y_mm=g['rotor']['friction_centre_y'],nonrotating_mass_probe_cg_local_mm=[100,199,0])
sg['bearing_C0r_N']=g['carrier']['catalogue_radial_static_kN']*1000
ce=[];se=[]
for h,r,l in[(0,0,0),(-40,0,3),(35,0,-3),(-10,2,3),(10,-2,-3),(-60,0,0)]:
 q=close(h,r,l);p=st.close_link(h,r,l,sg);ce.append(abs(q['clock_deg']-p['carrier_clock_deg']))
 R=rx(math.radians(r))@ry(math.radians(q['clock_deg']));u=R.T@np.array(q['unit_world']);y1,y2=sg['bearing_centres_y_mm'];p1=np.array([0,y1,0.]);p2=np.array([0,y2,0.]);columns=[]
 for pos,F in[(p1,np.array([1.,0,0])),(p1,np.array([0,1.,0])),(p1,np.array([0,0,1.])),(p2,np.array([1.,0,0])),(p2,np.array([0,0,1.])),(pin,u)]:columns.append(np.r_[F,np.cross(pos,F)])
 A=np.stack(columns,axis=1)
 for T,d,m in[(363.825,1,0),(10000,-1,50)]:
  pad=np.array([0.,0.,-d*T*1000/120]);gravity=R.T@np.array([0,0,-m*9.80665]);knownF=pad+gravity;knownM=np.cross([120,sg['rotor_plane_y_mm'],0],pad)+np.cross(sg['nonrotating_mass_probe_cg_local_mm'],gravity)
  v=np.linalg.solve(A,-np.r_[knownF,knownM]);ref=st.case(T,120,m,d,p,sg)
  target=np.r_[ref['bearing_reactions_carrier_N'][0],ref['bearing_reactions_carrier_N'][1][0],ref['bearing_reactions_carrier_N'][1][2],ref['axial_link_force_N']];se.append(float(np.max(np.abs(v-target))))
meta=json.loads((B/'parts.json').read_text());shapes=dict(zip((p['id']for p in meta),list(cq.importers.importBrep(str(B/'checkpoint.brep')).val())))
poly=g['frame_support']['endplate_polygon_xz'];w,h=g['frame_support']['section_outside_xz_mm'];cx,_,cz=g['frame_support']['centre']
plane=cq.Plane(origin=(0,538,0),xDir=(1,0,0),normal=(0,-1,0));slice_=cq.Workplane(plane).polyline(poly).close().extrude(-12).val()
support=slice_.intersect(shapes['SF-R-WEB1']).Volume()/slice_.Volume()
def point_segment(p,a,b):
 p,a,b=np.array(p,float),np.array(a,float),np.array(b,float);t=max(0,min(1,float((p-a)@(b-a)/((b-a)@(b-a)))))
 return float(np.linalg.norm(p-a-t*(b-a)))
def edge_distance(p,polygon):return min(point_segment(p,a,b)for a,b in zip(polygon,polygon[1:]+polygon[:1]))
corners=[(cx-w/2,cz-h/2),(cx+w/2,cz-h/2),(cx+w/2,cz+h/2),(cx-w/2,cz+h/2)]
beam_margin=min(edge_distance(p,poly)for p in corners)
profile=next(p for p in meta if p['id']=='SF-R-WEB1')['metadata']['definition']['profile_xz_mm'];web_margin=min(edge_distance(p,profile)for p in poly)
rejection=g['rejected_axle_end_witness'];th=math.radians(rejection['truck_yaw_deg']);x,y,z=rejection['local_rotor_ring_point'];wp=[x*math.cos(th)-y*math.sin(th),x*math.sin(th)+y*math.cos(th),z]
inside=shapes['CTX-MAIN-863.6'].translate((0,0,-rejection['jounce_mm'])).isInside(cq.Vector(*wp),1e-7)
record=dict(revision='C53-INDEPENDENT-D1',status='BOUNDED DEVELOPMENT REVIEW; NOT A FABRICATION OR OPERATING RELEASE',source_hashes={p.name:sha(p)for p in[H/'geometry-contract.json',H/'carrier_statics.py',B/'checkpoint.brep']},kinematics=dict(method='Closed-form circle/sphere intersection, separate from production Newton solver.',vertical_journal_travel_admissible_grid=summarize(regular),grid='81 roll values[-2,+2]deg;76 centre-heave values per roll within[-40+620|sin roll|,+35-620|sin roll|]mm;lateral[-3,0,+3]mm.',unrestricted_overtravel_probe=summarize(probe),scope='Independent lateral±3 remains a development probe. Retained locating/floating journal bearing lateral closure and all physical joint tolerances remain open; vertical travel admissibility is not operating approval.',foundation_clock_difference_deg=max(ce)),equilibrium=dict(method='Independent6×6linear equilibrium for[R1x,R1y,R1z,R2x,R2z,link], withR2y=0; compared against direct foundation formulas.',cases=len(se),maximum_reaction_difference_N=max(se),scope='Rigid-body arithmetic only; unknown maximum actuator output remains open.'),support=dict(actual_parent_web_backing_fraction=support,minimum_HSS_outer_corner_to_endplate_edge_mm=beam_margin,minimum_endplate_vertex_to_parent_web_edge_mm=web_margin,candidate_weld_leg_mm=6,weld_toe_space_pass=beam_margin>=6 and web_margin>=6,wheel_X_separation_bound_mm=600-320-max(p[0]for p in poly),scope='Geometric backing and fillet-toe space only; no joint strength or fatigue rating.'),axle_end_rejection=dict(actual_girder_contains_witness=inside,world_point_mm=wp),assembly=dict(bearing_sku=g['carrier']['bearing_sku'],bearing_bore_mm=g['carrier']['bearing_d_DB'][0],wheel_seat_nominal_mm=110,nominal_diametral_slide_clearance_mm=g['carrier']['bearing_d_DB'][0]-110,service=g['service']['rotor']),holds=['Exact Webb friction band, hat section and true hub mounting datum remain unavailable.','Exact selected TSE chamber complete outline, caging/wear travel and force envelope remain unavailable.','Webb325.12 rotor and330mm caliper GA require confirmed pad-band compatibility.','Maximum output, compounding, joints, bearings, frame eccentricity, fatigue and thermal duty remain unqualified.','One right-side unit does not prove mirrored complete-brake coexistence.'])
record['source_hashes']['C53_checkpoint.brep']=sha(H/'checkpoint.brep')
record['source_hashes']['C5_checkpoint.brep']=record['source_hashes'].pop('checkpoint.brep')
record['source_hashes']['C53_parts.json']=sha(H/'parts.json')
motion=json.loads((H/'independent-motion-check.json').read_text())
contacts=json.loads((H/'independent-contact-check.json').read_text())
assert motion['source_hashes']['checkpoint.brep']==record['source_hashes']['C53_checkpoint.brep']
assert contacts['checkpoint_sha256']==record['source_hashes']['C53_checkpoint.brep']
record['custom_motion_check']=dict(record='independent-motion-check.json',states=motion['states'],exact_intersections_tested=motion['exact_intersections_tested'],positive_pairs=len(motion['positive_pairs']),minimum_link_hardware_to_clevis=motion['minimum_link_hardware_to_clevis'],acceptance='Nominal discrete geometry only. The0.651mm minimum gap has no accepted tolerance, wear or deflection allowance.')
record['selected_load_path_contacts']=dict(record='independent-contact-check.json',pairs=len(contacts['pairs']),all_have_face_contact=contacts['all_selected_pairs_have_face_contact'],maximum_overlap_mm3=contacts['maximum_solid_overlap_mm3'],acceptance='Finite shared surfaces establish geometric connection, not rated weld/joint strength.')
record['assembly']['bearing_sleeve_retention']='Separate split shaft clamps and abutments locate the reducer/inner-race stack; actual transverse bolts and axial head/tool holes are modeled. Fits, clamp preload, axial holding, creep and assembly procedure remain unqualified.'
record['assembly']['hub_axial_path']='The shaft key pocket is closed atY369..393.572. The sleeve inboard pocket wall and outboard retaining plate capture the key axially, and two retaining plates capture the hub. This is a proposed key-end/retainer load path, not an ordinary key-torque or friction-clamp axial rating. End clearances, bearing stresses, screws, thermal growth and axle fatigue remain open.'
record['corrected_findings']=['100mm bearing bore blocked by110mm wheel seat: changed to120mm bore and split reducers.','Embedded/unbacked frame anchor: lower crossbar, backed endplate and rising bracket.','Tangent-only saddle and removable-cover load path: actual curved barrel contact plus outboard saddle bridge and cover relief.','Unlocated bearing reducer: external split shaft clamps and positive abutments.','Ordinary-motion retainer-head clashes: flush countersunk retainers; revised nine-pose check has zero positive pairs.','Hub axial stops and opposing bolt-tip clearance now explicitly modeled.']
(H/'independent-review.json').write_text(json.dumps(record,indent=2)+'\n')
minimum=motion['minimum_link_hardware_to_clevis']['minimum_link_hardware_to_clevis']['distance_mm']
md=f'''# C5.3 independent review

The final141-part candidate passes the bounded custom-part checks below. It remains a development design: the exact rotor section and chamber are incomplete, maximum output is unresolved, and no fabrication or operating rating is assigned.

| Independent check | Result | Limit |
|---|---:|---|
| Closed-form link positions |18,468 vertically admissible development poses close |Independent lateral±3mm is a probe; complete journal constraint/tolerance closure is not approved |
| Carrier clock range |−4.455688° to+1.721170° |Working study envelope only |
| Minimum effective torque arm |135.672727mm |Use actual arm rather than a constant150mm |
| Closed-form versus Newton clock |{max(ce):.3g}° maximum difference |Arithmetic agreement |
| Independent6×6statics comparison |{max(se):.3g}N maximum reaction difference |Rigid equilibrium, not capacity |
| Nine actual custom-part poses |{motion['exact_intersections_tested']} exact intersection tests;{len(motion['positive_pairs'])} positive pairs |Discrete poses; no complete supplier or continuous sweep proof |
| Tightest retainer-to-clevis clearance |{minimum:.6f}mm |Small nominal gap; tolerance, flexure, wear and manufacturing acceptance remain open |
| Selected load-path contacts |{len(contacts['pairs'])} actual shared-face connections; zero solid overlap |No weld or joint strength credit |
| Endplate backing |100% of footprint on retained sideframe web |Local web/fatigue not qualified |
| Fillet-toe room |7.2mm tube-to-plate;12mm plate-to-web |Space for6mm candidate fillets only |

The nine exact-shape poses combine roll−2/0/+2° with ordinary rebound/mid/jounce. Centre heave is limited so both journal heights stay within−40..+35mm. Their lateral translation preserves the right locating journal's Y coordinate; the left floating bearing takes the projection change. Matrices are in `independent-motion-states.json`. The wider analytical grid is identified separately as a development probe; Cartesian heave/roll overtravel is never called ordinary motion.

The first motion check found four real retainer-screw head clashes. Flush countersunk retainers removed those modeled interferences. The superseded evidence is retained in `independent-motion-before-countersink.json`; the final check is `independent-motion-check.json`.

The corrected barrel saddles have finite curved contact, and the outboard fork reaches the permanent barrel through a separate saddle bridge. The removable cover is relieved and is not credited as a welded load path. The bearing reducer now has actual external split shaft clamps; axial end screws alone were not treated as shaft clamping.

The hub's proposed axial restraint uses the closed shaft-key pocket, key ends, sleeve pocket wall and outboard retainer; two plates retain the hub to its sleeve. This explicitly needs key-end bearing, screw, fit, thermal-growth and axle-fatigue checks. No axial capacity is inferred merely from a key's torque function.

The120mm bearing/hub bores clear the nominal110mm wheel seat after the axlebox, journal nut/retainers and one wheel are removed. Actual fits, installation order, clamping, wheel-shop procedure and runout remain held. A closed inboard rotor is not replaceable on the coach with its wheel installed.

The exact Webb friction annulus/hat profile and true mounting datum,325.12mm rotor versus330mm caliper drawing compatibility, full TSE chamber/wear/caging envelope, mirrored brake coexistence and maximum actuator output remain unresolved. High-torque sensitivity failures in the mechanics report are not erased by these geometric checks.

Reproduce with `independent_motion_check.py`, `independent_contact_check.py`, then `independent_check.py`. The main generator checks that the final motion/contact records use the same checkpoint hash. Manufacturer-envelope proxies are excluded from a claim of exact installed fit.
'''
for before,after in [('final141','final 141'),('Independent lateral±3','Independent lateral ±3'),('rather than a constant150','rather than a constant 150'),('Independent6×6statics','Independent 6×6 statics'),('The120','The 120'),('nominal110','nominal 110'),('roll−2','roll −2'),('atY369','at Y 369'),('The0.651','The 0.651')]:md=md.replace(before,after)
import re
md=re.sub(r'(?<=\d)(mm|N|kg)\b',r' \1',md)
(H/'independent-review.md').write_text(md)
def matrix_about_origin(R,shift):
 m=np.eye(4);m[:3,:3]=R;m[:3,3]=origin+shift-R@origin
 return m.tolist()
v0=np.array(g['link']['moving_reference'],float)-anchor
def link_matrix(moving):
 v1=np.array(moving,float)-anchor;u=v0/np.linalg.norm(v0);v=v1/np.linalg.norm(v1);a=np.cross(u,v);c=float(u@v)
 K=np.array([[0,-a[2],a[1]],[a[2],0,-a[0]],[-a[1],a[0],0]])
 R=np.eye(3)+K+K@K/(1+c);m=np.eye(4);m[:3,:3]=R;m[:3,3]=anchor-R@anchor
 return m.tolist()
states=[]
for roll in[-2,0,2]:
 zr=620*abs(math.sin(math.radians(roll)));lat=620*(1-math.cos(math.radians(roll)))
 for label,h in[('rebound',-40+zr),('mid',0),('jounce',35-zr)]:
  q=close(h,roll,lat);Ra=rx(math.radians(roll));Rc=Ra@ry(math.radians(q['clock_deg']));shift=np.array([0,lat,h])
  states.append(dict(id=f'ordinary-roll{roll:+g}-{label}',basis='Both journal heights remain[-40,+35]; lateral chosen to preserve right locating journalY620, with left floating journal taking axial shift.',heave_mm=h,roll_deg=roll,lateral_mm=lat,carrier_clock_deg=q['clock_deg'],journal_heaves_mm=[h-620*math.sin(math.radians(roll)),h+620*math.sin(math.radians(roll))],axle_matrix_row_major=matrix_about_origin(Ra,shift),carrier_matrix_row_major=matrix_about_origin(Rc,shift),link_matrix_row_major=link_matrix(q['moving_pin_mm']),link_closure_residual_mm=q['length_residual_mm']))
(H/'independent-motion-states.json').write_text(json.dumps(dict(units='mm',scope='Nine discrete ideal geometric poses; not continuous swept clearance or operating approval. Matrices act on world coordinates of nominal CAD. Frame stays fixed.',states=states),separators=(',',':'))+'\n')
print(json.dumps({'clock_comparison_deg':max(ce),'statics_comparison_N':max(se),'support':record['support']},indent=2))
