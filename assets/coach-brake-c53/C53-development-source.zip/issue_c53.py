"""Issue cached C53. Does not rebuild CAD; finalize_c53.py packages final evidence separately."""
from pathlib import Path
import json,gzip
import cadquery as cq
from OCP.BRepTools import BRepTools
H=Path(__file__).resolve().parent;OUT=H.parents[1]/'dist/assets/coach-brake-c53';OUT.mkdir(parents=True,exist_ok=True)
M=json.loads((H/'parts.json').read_text());S=list(cq.importers.importBrep(str(H/'checkpoint.brep')).val());MM=25.4
colors={'rotating-hub':'#c68b3d','bearing-sleeve':'#bd9e61','carrier':'#4f8c8a','torque-link':'#b69a4e','frame-support':'#758995','hardware':'#aab4bc','purchased-bearing':'#3b8894','retained-C5-reference':'#a4afa7','supplier-reference':'#b56867'}
model={'schemaVersion':3,'units':'inches','title':'C53 inboard disc development / one right-side unit','coordinate_system':'CAD source mm converted to inches. X coach longitudinal,Y across truck,Z upward. Axle(600,0,300)mm.','parts':[],'groups':[],'notes':['Unrated development; supplier mating contour,325/330padband,chamber and full handed-installation fit HOLD.','Actual custom metal shown; transparent purchased envelopes are not manufacturing CAD.','Explode vectors illustrate groups only, not assembly sequence.']}
for m,s in zip(M,S):
 BRepTools.Clean_s(s.wrapped);vv,ff=s.tessellate(1.5,.4);b={a:[v/MM for v in m['bounds_mm'][a]]for a in'xyz'};g=m['group'];model['parts'].append({'id':m['id'],'name':m['id'].replace('-',' '),'group':g,'color':colors.get(g,'#aab5ba'),'opacity':.18 if g=='supplier-reference'else .2 if g=='retained-C5-reference'else 1,'display_only':m['catalogue_reference_only'],'positions':[round(x/MM,5)for v in vv for x in[v.x,v.y,v.z]],'indices':[j for f in ff for j in f],'bounds_in':b,'centre_in':[sum(b[a])/2 for a in'xyz'],'dimensions_xyz_in':[b[a][1]-b[a][0]for a in'xyz'],'metadata':{'definition':m['definition'],'material':{'candidate':m['material']},'kinematics':m['kinematics'],'solid_mass_kg':m['mass_kg'],'engineering_status':'UNRATED DEVELOPMENT / SUPPLIER FIT HOLDS'}})
ex={'rotating-hub':[0,3,0],'bearing-sleeve':[0,-2,0],'carrier':[0,1,0],'torque-link':[0,0,2],'hardware':[0,2,0],'purchased-bearing':[0,-1,0],'supplier-reference':[0,4,0]}
model['groups']=[{'id':g,'label':g.replace('-',' '),'explosion_vector_in':ex.get(g,[0,0,0]),'default_visible':True}for g in sorted(set(m['group']for m in M))]
with gzip.open(OUT/'model-nominal.json.gz','wt',compresslevel=9)as f:json.dump(model,f,separators=(',',':'))
ass=cq.Assembly(name='C53_ONE_RIGHT_UNIT_UNRATED_SUPPLIER_ENVELOPES')
for m,s in zip(M,S):ass.add(s,name=m['id'])
ass.save(str(H/'C53-inboard-unit-D1.step'))
with(H/'C53-inboard-unit-D1.step').open('rb')as fi,gzip.open(OUT/'C53-inboard-unit-D1.step.gz','wb',compresslevel=9)as fo:fo.write(fi.read())
print('Issued',len(S),'parts')
