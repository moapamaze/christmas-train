"""C53 one-unit custom metal and explicitly provisional purchased envelopes. mm."""
from pathlib import Path
import json,math,gzip,time
import cadquery as cq
import numpy as np
H=Path(__file__).resolve().parent; B=H.parent/'coach-truck-c5'; O=H.parents[1]/'dist/assets/coach-brake-c53';O.mkdir(parents=True,exist_ok=True)
P=json.loads((H/'geometry-contract.json').read_text());S={};M={}
def box(x,y,z):return cq.Solid.makeBox(x[1]-x[0],y[1]-y[0],z[1]-z[0],cq.Vector(x[0],y[0],z[0]))
def cyl(r,L,p,axis=(0,1,0)):return cq.Solid.makeCylinder(r,L,cq.Vector(*p),cq.Vector(*axis))
def ring(od,di,L,p):return cyl(od/2,L,p).cut(cyl(di/2,L,p))
def bounds(s):
 b=s.BoundingBox();return {a:[getattr(b,a+'min'),getattr(b,a+'max')] for a in 'xyz'}
def add(k,g,s,d=None,kin='carrier',proxy=False,mat='Custom steel; grade/qualification HOLD'):
 if not s.isValid():raise ValueError(k)
 S[k]=s;M[k]={'id':k,'group':g,'material':mat,'kinematics':kin,'definition':d or {},'bounds_mm':bounds(s),'volume_mm3':s.Volume(),'mass_kg':None if proxy else s.Volume()*7850/1e9,'catalogue_reference_only':proxy}
def poly(p,y,t):return cq.Workplane(cq.Plane(origin=(0,y,0),xDir=(1,0,0),normal=(0,-1,0))).polyline(p).close().extrude(-t).val()
def hy(s,x,z,d,yr):return s.cut(cyl(d/2,yr[1]-yr[0],(x,yr[0],z)))
def tube(w,t,yr,x,z):return box([x-w/2,x+w/2],yr,[z-w/2,z+w/2]).cut(box([x-w/2+t,x+w/2-t],[yr[0]-1,yr[1]+1],[z-w/2+t,z+w/2-t]))
def sector(r0,r1,a,y,t):
 def pt(r,deg):q=math.radians(deg);return(600+r*math.cos(q),300+r*math.sin(q))
 pl=cq.Plane(origin=(0,y,0),xDir=(1,0,0),normal=(0,-1,0))
 return cq.Workplane(pl).moveTo(*pt(r0,-a)).threePointArc(pt(r0,0),pt(r0,a)).lineTo(*pt(r1,a)).threePointArc(pt(r1,0),pt(r1,-a)).close().extrude(-t).val()
def bolt_y(k,x,z,y,L,d=14,head=22,headt=9,sg=1,kin='carrier',role='Nominal bolt; thread omitted'):
 sh=cyl(d/2,L,(x,y,z),(0,sg,0)).fuse(cyl(head/2,headt,(x,y,z),(0,-sg,0)))
 add(k,'hardware',sh,{'diameter_mm':d,'underhead_length_mm':L,'role':role},kin)
def split(k,g,sh,definition,kin='rotating'):
 # Real axial split plane at X600. Nominal touching faces; no fictitious clearance.
 for sg in[-1,1]:
  cut=box([400,600] if sg<0 else[600,850],[0,500],[0,700])
  add(k+('-L' if sg<0 else'-R'),g,sh.intersect(cut),definition,kin)
# Custom keyed hub and split reducer. Two separate keys, at ninety degrees, transfer torque.
cy=371.572; hub=ring(230,120,22,(600,cy,300)).fuse(ring(168.91,120,10,(600,cy-10,300)))
hub=hub.cut(box([652,668],[369,396],[286,314]))
for i in range(8):
 q=math.radians(i*45+22.5);x=600+97.917*math.cos(q);z=300+97.917*math.sin(q)
 hub=hy(hub,x,z,15,[cy-1,cy+25])
 bolt_y('ROTOR-BOLT'+str(i),x,z,cy+25,43,d=14,head=22,headt=9,sg=-1,kin='rotating',role='M14x2 candidate;22hub+3washer+18thread. Webb face/depth unknown: engagement HOLD')
 add('ROTOR-WASHER'+str(i),'hardware',ring(28,15,3,(x,cy+22,z)),{'nominal':'M14 flatwasher'},'rotating')
add('CUSTOM-ROTOR-HUB','rotating-hub',hub,{'pilot_mm':168.91,'PCD_mm':195.834,'8_clearance_holes_mm':15,'mating_face_y':cy,'status':'Custom flange face provisional until exact Webb mating drawing'},'rotating')
red=ring(120,100,32,(600,361.572,300)).cut(box([586,614],[369,393.572],[342,358])).cut(box([652,668],[369,393.572],[286,314]))
split('HUB-REDUCER','rotating-hub',red,{'100_to120_split_sleeve':True,'new_axle_keyway':'28wide×8deep; fatigue/fit/torque capacity HOLD'})
add('SHAFT-TO-SLEEVE-KEY','rotating-hub',box([586,614],[369,393.572],[342,358]),{'stock':'28x16 key; material/fit HOLD'},'rotating')
add('SLEEVE-TO-HUB-KEY','rotating-hub',box([652,668],[369,393.572],[286,314]),{'stock':'28x16 key;90deg from shaftkey; thin sleeve strength HOLD'},'rotating')
# Split axial retainer on hub outboard face; actual axial bolts enter reducer.
ret=ring(140,100,4,(600,393.572,300))
for i in range(4):
 q=math.radians(45+i*90);x=600+55*math.cos(q);z=300+55*math.sin(q)
 ret=hy(ret,x,z,6.6,[393,399]);redhole=cyl(2.5,14,(x,393.572,z),(0,-1,0))
 for key in['HUB-REDUCER-L','HUB-REDUCER-R']:S[key]=S[key].cut(redhole)
 bolt_y('HUB-RETAINER-M6-'+str(i),x,z,397.572,18,d=6,head=10,headt=6,sg=-1,kin='rotating',role='M6x18 retaining bolt;14mm blind tapped hole,4mm gap to opposingtip; locking qualification HOLD')
split('HUB-AXIAL-RETAINER','rotating-hub',ret,{'role':'Split plate retains hub against pilot shoulder;4M6 axial bolts. No friction torque credited.'})
ret=ring(140,100,4,(600,357.572,300))
for i in range(4):
 q=math.radians(45+i*90);x=600+55*math.cos(q);z=300+55*math.sin(q);ret=hy(ret,x,z,6.6,[357,363])
 for key in['HUB-REDUCER-L','HUB-REDUCER-R']:S[key]=S[key].cut(cyl(2.5,14,(x,361.572,z)))
 bolt_y('HUB-RETAINER-M6-IN-'+str(i),x,z,357.572,18,d=6,head=10,headt=6,sg=1,kin='rotating',role='M6x18 inboard hub-endplate bolt;14mm blind nominal engagement; opposingtips4mmgap')
split('HUB-INBOARD-AXIAL-RETAINER','rotating-hub',ret,{'role':'Split inboard physical hub stop; complements outboard stop. Axial capacity via keyed sleeve/endplates remains HOLD'})
# Separate bearing sleeve, positive split axial-end plates, 120-bore bearing slide route.
sleeve=ring(120,100,84,(600,103,300))
# Separate split collars assemble radially AFTER the closed bearing module slides into place.
for label,ya in [('IN',83),('OUT',193)]:
 yc=ya+8;cl=ring(138,100,16,(600,ya,300)).cut(box([599.75,600.25],[ya-1,ya+17],[220,380]))
 for zc in[236,364]:
  cl=cl.cut(cyl(3.3,60,(570,yc,zc),(1,0,0))).cut(cyl(5.25,12,(620,yc,zc),(1,0,0))).cut(cyl(6,12,(568,yc,zc),(1,0,0)))
  bolt=cyl(3,40,(620,yc,zc),(-1,0,0)).fuse(cyl(5,6,(620,yc,zc),(1,0,0)))
  add('SLEEVE-CLAMP-M6-'+label+str(zc),'hardware',bolt,{'role':'Actual transverseM6clampingbolt;splitgap.5; axialholding/preload/temperature qualification HOLD'},'rotating')
  nut=cyl(5.75,6,(574,yc,zc),(1,0,0)).cut(cyl(3,6,(574,yc,zc),(1,0,0)))
  add('SLEEVE-CLAMP-NUT-'+label+str(zc),'hardware',nut,{'role':'M6recessednut;locking HOLD'},'rotating')
 for ii in range(4):
  qq=math.radians(45+ii*90);cl=cl.cut(cyl(5.25,18,(600+55*math.cos(qq),ya-1,300+55*math.sin(qq))))
 split('AXIAL-SHAFT-CLAMP-'+label,'bearing-sleeve',cl,{'role':'Actual two-piece shaftclamp outside bearingcovers. Clamps to100shaft; axial holding capacity and torque qualification HOLD'})
abut=ring(126,100,2,(600,191,300))
for ii in range(4):
 qq=math.radians(45+ii*90);abut=abut.cut(cyl(5.25,4,(600+55*math.cos(qq),190,300+55*math.sin(qq))))
split('SLEEVE-OUTBOARD-ABUTMENT','bearing-sleeve',abut,{'role':'Split2mmabutment betweenoutboard sleeveendplate191 andshaftclamp193; actual10.5mm head/tool clearance holes'})
for end,sg in[(103,1),(187,-1)]:
 for i in range(4):
  q=math.radians(45+90*i);x=600+55*math.cos(q);z=300+55*math.sin(q);sleeve=sleeve.cut(cyl(2.5,18,(x,end,z),(0,sg,0)))
split('BEARING-REDUCER','bearing-sleeve',sleeve,{'role':'Split100-to120 reducer; rotor torque does not pass through this sleeve. Fits/creep/axial preload HOLD'})
for label,ya,yb in[('INNER',103,107),('CENTRE',123,167),('OUTER',183,187)]:split('INNER-RACE-SPACER-'+label,'bearing-sleeve',ring(126,120,yb-ya,(600,ya,300)),{'role':'126OD abutment within NSK125..127 recommendation;split for assembly'})
for label,y,sg in[('IN',99,1),('OUT',187,-1)]:
 sh=ring(126,100,4,(600,y,300))
 for i in range(4):
  q=math.radians(45+i*90);x=600+55*math.cos(q);z=300+55*math.sin(q);sh=hy(sh,x,z,6.6,[y-1,y+5]);under=y if sg>0 else y+4
  bolt_y('SLEEVE-END-M6-'+label+str(i),x,z,under,22,d=6,head=10,headt=6,sg=sg,kin='rotating',role='M6×22 split endplate retaining bolt; thread envelope nominal')
 split('SLEEVE-END-'+label,'bearing-sleeve',sh,{'role':'Split axial retainer; tightening/preload procedure HOLD'})
for j,y in enumerate([115,175]):add('NSK6824DD-'+str(j+1),'purchased-bearing',ring(150,120,16,(600,y-8,300)),{'sku':'NSK6824DD','d_D_B':[120,150,16],'Cr_kN':32,'C0r_kN':35.5,'shape':'Complete annular dimensional envelope; internal race/ball geometry not supplied'},proxy=True,mat='NSK bearing external envelope')
# Machined/welded carrier barrel. Bores separate race seats and allow outboard outer-race float.
housing=ring(166,142,78,(600,107,300));housing=housing.cut(cyl(75,16,(600,107,300))).cut(cyl(75.1,20,(600,165,300)))
for y,sg in[(107,1),(185,-1)]:
 for i in range(6):
  q=math.radians(i*60);x=600+79*math.cos(q);z=300+79*math.sin(q);housing=housing.cut(cyl(1.65,10,(x,y,z),(0,sg,0)))
add('CARRIER-BARREL','carrier',housing,{'OD':166,'central_bore':142,'locating_seat':[107,123],'floating_seat':[165,185],'floating_axial_allowance_mm':4,'wall_and_fit':'Machined steel barrel; strength, tolerances, heat isolation HOLD'})
for lab,y,sg in[('IN',99,1),('OUT',185,-1)]:
 sh=ring(166,142,8,(600,y,300))
 for i in range(6):
  q=math.radians(i*60);x=600+79*math.cos(q);z=300+79*math.sin(q);sh=hy(sh,x,z,4.5,[y-1,y+9]);under=y if sg>0 else y+8
  bolt_y('CARRIER-COVER-M4-'+lab+str(i),x,z,under,18,d=4,head=7,headt=4,sg=sg,role='M4 cover bolt;10mm nominal blind thread, locking and axial bearing loads HOLD')
 add('CARRIER-COVER-'+lab,'carrier',sh,{'t':8,'bore':142,'role':'Outer-race closure; bearing1located, bearing2float4mm nominal'})
# Carrier crescent with actual six-hole pattern. Hub is on other side of rotor cup.
mount=sector(83,185,82,193,5.982)
for i,(t,r) in enumerate(P['caliper']['carrier_holes_tr']):
 x,z=600+r,300+t;mount=hy(mount,x,z,15,[192,200]);bolt_y('CALIPER-M14-'+str(i),x,z,193,24,d=14,head=22,headt=9,sg=1,role='M14x1.5 grade10.9;6mm mount+18mm OEM min engagement; exact thread depth/washer HOLD')
add('CALIPER-MOUNT-CRESCENT','carrier',mount,{'plate_t':5.982,'six_holes_tr':P['caliper']['carrier_holes_tr'],'status':'6mm candidate interface plate; stiffness/torque screen HOLD; inner radius83 follows housing OD'})
# Actual bridge webs connect mount to barrel side before its closing cover.
for sg in[-1,1]:
 # horizontal XZ tangential pads at upper/lower sides, directly shared face on barrel outer diameter
 sh=poly([(635,335 if sg>0 else 265),(680,335 if sg>0 else 265),(705,400 if sg>0 else 200),(664,414 if sg>0 else 186),(636,455 if sg>0 else 145)],155,38)
 # annular running bore remains clear; trim exact housing so parts meet rather than overlap.
 sh=sh.cut(cyl(83,40,(600,154,300))).cut(cyl(84,8,(600,185,300))).cut(sector(83,185,82,193,6))
 for tt,rr in P['caliper']['carrier_holes_tr']:sh=sh.cut(cyl(13,40,(600+rr,154,300+tt)))
 add('CARRIER-MOUNT-WEB'+str(sg),'carrier',sh,{'plate_width_y':38,'role':'Welded barrel-to-crescent web; exact weld/local strength HOLD'})
# Torque arm forks: real cheeks from barrel upper face to the moving pin; no shaft/wheel crossing.
mp=(600,170,450);fp=(350,170,500)
for sg in[-1,1]:
 yr=[148,158] if sg<0 else[182,192]
 sh=poly([(570,360),(630,360),(630,450),(600,480),(570,450)],yr[0],10);sh=hy(sh,600,450,20.5,[147,193]);sh=sh.cut(cyl(83,46,(600,147,300))).cut(cyl(84,8,(600,185,300)))
 for tt,rr in P['caliper']['carrier_holes_tr']:sh=sh.cut(cyl(13,40,(600+rr,154,300+tt)))
 add('TORQUE-FORK'+str(sg),'carrier',sh,{'plate_t':10,'clear_gap':24,'pin_centroid_span':34,'weld_root':'True R83 saddle cut from rootZ360, approx61mm arc each cheek; weld qualification HOLD'})
bridge=poly([(570,360),(630,360),(630,400),(570,400)],174,8).cut(cyl(83,8,(600,174,300)))
add('TORQUE-FORK-OUTBOARD-SADDLE','carrier',bridge,{'role':'8mm axial bridge welded to permanent barrelY174..182 and outboardcheek atY182; removable cover has1mm radial relief, no cover weld credited'})
# Stock support, full backed plates; link bracket transfers force to tube top/front faces.
add('FRAME-HSS','frame-support',tube(101.6,9.525,[-526,526],210,380),{'stock':'HSS4x4x3/8','nominal_wall':9.525,'design_wall_factor':.93,'corner_model':'Square nominal geometry; rounded-section strength sensitivity in report'},'fixed')
pts=[(150,321),(264,321),(270,330),(270,438),(150,438)]
for sg in[-1,1]:add('FRAME-ENDPLATE'+str(sg),'frame-support',poly(pts,526 if sg>0 else -538,12),{'plate_t':12,'attachment':'6mm candidate continuous fillets; backing checked against actual C5 web'},'fixed')
for sg in[-1,1]:
 yr=[148,158] if sg<0 else[182,192]
 sh=poly([(210,430.8),(260.8,430.8),(350,470),(380,500),(350,530),(320,510),(210,451)],yr[0],10);sh=hy(sh,350,500,20.5,[147,193])
 add('FRAME-LINK-CHEEK'+str(sg),'frame-support',sh,{'plate_t':10,'root':'Tube top atZ430.8; rising bracket eccentricity not suppressed'},'fixed')
add('FRAME-LINK-ROOT-PLATE','frame-support',box([210,260.8],[138,202],[430.8,442.8]).cut(box([209,261],[148,158],[430,444])).cut(box([209,261],[182,192],[430,444])),{'plate_t':12,'role':'Slotted saddle plate joins cheek roots at tube top'},'fixed')
# Spherical-ended dogbone. Bearing outer rings positively retained; actual holes and spacers.
a=np.array(fp,float);b=np.array(mp,float);v=b-a;L=np.linalg.norm(v);n=np.array([-v[2],0,v[0]])/L*20
sh=poly([(a[0]+n[0],a[2]+n[2]),(b[0]+n[0],b[2]+n[2]),(b[0]-n[0],b[2]-n[2]),(a[0]-n[0],a[2]-n[2])],164,12)
for p in[fp,mp]:sh=sh.fuse(cyl(30,12,(p[0],164,p[2])));sh=hy(sh,p[0],p[2],35,[163,177])
for p in[fp,mp]:
 for side in[-1,1]:
  for i in range(3):
   q=math.radians(i*120+(60 if side<0 else 0));x=p[0]+24*math.cos(q);z=p[2]+24*math.sin(q);sh=sh.cut(cyl(1.65,6,(x,164 if side<0 else 176,z),(0,1 if side<0 else -1,0)))
add('TORQUE-LINK','torque-link',sh,{'eye_pitch':float(L),'plate_t':12,'shank_width':40,'eye_OD':60,'bearing_bore':35},'link')
for j,p in enumerate([fp,mp]):
 x,y,z=p
 ball=cq.Solid.makeSphere(14.5,cq.Vector(*p),angleDegrees1=-90,angleDegrees2=90).intersect(box([x-16,x+16],[162,178],[z-16,z+16])).cut(cyl(10,18,(x,161,z)))
 outer=cyl(17.5,12,(x,164,z)).cut(cq.Solid.makeSphere(14.55,cq.Vector(*p),angleDegrees1=-90,angleDegrees2=90))
 add('LINK-BEARING-OUTER'+str(j),'purchased-bearing',outer,{'sku':'AuroraGE20ES-2RS','d_D_B_C':[20,35,16,12],'internal_shape':'Assumed spherical boundary, not manufacturer internal CAD'},'link',True)
 add('LINK-BEARING-INNER'+str(j),'purchased-bearing',ball,{'sku':'AuroraGE20ES-2RS','role':'Envelope including16mm innerwidth; catalogue tilt9deg'},'fixed' if j==0 else'carrier',True)
 for sg in[-1,1]:
  add('PIN-SPACER'+str(j)+str(sg),'hardware',ring(28,20.2,4,(x,158 if sg<0 else 178,z)),{'role':'Inner-ring spacer;4mm'},'fixed' if j==0 else'carrier')
  yr=160 if sg<0 else 176;ret=ring(60,29,4,(x,yr,z));outerface=160 if sg<0 else 180;direction=1 if sg<0 else -1
  for i in range(3):
   q=math.radians(i*120+(60 if sg<0 else 0));xx=x+24*math.cos(q);zz=z+24*math.sin(q)
   ret=hy(ret,xx,zz,4.5,[yr-1,yr+5]);ret=ret.cut(cq.Solid.makeCone(4.25,2.25,2,cq.Vector(xx,outerface,zz),cq.Vector(0,direction,0)))
   screw=cq.Solid.makeCone(4,2,2,cq.Vector(xx,outerface,zz),cq.Vector(0,direction,0)).fuse(cyl(2,8,(xx,outerface+direction*2,zz),(0,direction,0)))
   add('LINK-RETAIN-M4'+str(j)+str(sg)+str(i),'hardware',screw,{'role':'M4x10flush90degcountersunkhead;4mmretainerplate/6mm nominalthread; exactstock/locking/retentionstrength HOLD'},'link')
  add('LINK-RETAINER'+str(j)+str(sg),'bearing-retainer',ret,{'plate_t':4,'PCD':48,'holes':4.5,'countersink':8.5,'role':'Flushheads recover articulationgap; strengthqualification HOLD'},'link')
 pin=cyl(10,54,(x,148,z)).fuse(cyl(15,8,(x,140,z)));pin=pin.cut(cyl(2,22,(x,197,z-11),(0,0,1)))
 add('LINK-PIN'+str(j),'hardware',pin,{'diameter':20,'grip':44,'crosshole':4,'retainer':'Custom pin plus cross cotter; fits/material/locking HOLD'},'fixed' if j==0 else'carrier')
 add('LINK-PIN-WASHER'+str(j),'hardware',ring(30,20.5,2,(x,192,z)),{'role':'Pin retention washer'},'fixed' if j==0 else'carrier')
 # Actual retained crosswire envelope, not a load bearing pin.
 pts=[(-5,-18),(-.9,-14),(-.9,10),(-3,12),(-3,16),(0,19),(3,16),(3,12),(.9,10),(.9,-14),(5,-18)];wire=None
 for aa,bb in zip(pts,pts[1:]):
  aa=cq.Vector(x+aa[0],197,z+aa[1]);bb=cq.Vector(x+bb[0],197,z+bb[1]);vv=bb-aa;seg=cq.Solid.makeCylinder(.9,vv.Length,aa,vv.normalized()).fuse(cq.Solid.makeSphere(.9,aa,angleDegrees1=-90,angleDegrees2=90));wire=seg if wire is None else wire.fuse(seg)
 add('LINK-PIN-COTTER'+str(j),'hardware',wire,{'role':'Bent split-pin envelope with enlarged loop and splayed legs; crossholeY197/endY202 gives3mm end ligament. ExactSKU/bendingprocess HOLD'},'fixed' if j==0 else'carrier')
# Supplier envelopes are NOT custom fabrication definitions. Full missing contours stay held.
add('WEBB-FRICTION-ENVELOPE','supplier-reference',ring(325.12,177.12,34.036,(600,222.982,300)),{'sku':'Webb55030PK-65','verified':['325.12OD','34.036thickness'],'unverified':'Inner rubbing radius88.56 is PAN17-derived clearance reference; exact Webb friction ID/pad sweep HOLD'},'rotating',True,'Cast iron rotor reference')
add('WEBB-HAT-ENVELOPE','supplier-reference',ring(220,168.91,114.554,(600,257.018,300)),{'sku':'Webb55030PK-65','verified':['168.91pilot','148.59overall depth'],'unverified':'220hatOD and annular shell are schematic reservation ONLY; internal web/matingoffset unavailable'},'rotating',True,'Transparent supplier reservation')
# Conservative front silhouette, source-based dimensions. Its missing 3D relief is not a collision test solid.
cal=sector(85,216,72,52.882,281.5)
add('PAN17-PROJECTION-RESERVATION','supplier-reference',cal,{'sku':'HendricksonS-39094-L/R;WABCO40175072/73','GA':'330disc, outerR216, axialq[-135.4,146.1]','status':'Extruded GA projection only, not actual OEM solid. Exclude volume intersections; exact arch/chamber/hat clearance HOLD'},proxy=True,mat='Transparent PAN17 envelope')
# Selected actual C5 context, trimmed axle length for compact presentation. Holes/keyway are explicit new modifications.
meta=json.loads((B/'parts.json').read_text());meta=meta.get('parts',meta) if isinstance(meta,dict) else meta
shapes=list(cq.importers.importBrep(str(B/'checkpoint.brep')).val());lookup={p['id']:s for p,s in zip(meta,shapes)}
for key in ['AXLE2','A2R-WHEEL-BLANK','A2R-BOX','SF-R-WEB1','SF-L-WEB2']:
 s=lookup[key]
 if key=='AXLE2':s=s.intersect(box([530,670],[70,710],[230,370])).cut(box([586,614],[369,393.572],[342,360]))
 if key.startswith('SF-'):s=s.intersect(box([100,900],[-551,551],[100,610]))
 add('CTX-'+key,'retained-C5-reference',s,{'source':'C5 checkpoint.brep/'+key,'modification':'Axle shown cropped with new keyway; fatigue qualification reopened' if key=='AXLE2' else'Unchanged context subset'},'context',True,'Retained C5 reference')
# Refresh metadata after boolean alterations, then deterministic cache/edges.
for k,s in S.items():M[k]['bounds_mm']=bounds(s);M[k]['volume_mm3']=s.Volume();M[k]['mass_kg']=None if M[k]['catalogue_reference_only'] else s.Volume()*7850/1e9
(H/'parts.json').write_text(json.dumps(list(M.values()),indent=2)+'\n');cq.exporters.export(cq.Compound.makeCompound(list(S.values())),str(H/'checkpoint.brep'))
edges={}
for k,s in S.items():
 ar=[]
 for e in s.Edges():
  vs=e.Vertices()
  if e.geomType()=='LINE':pts=[v.toTuple() for v in vs]
  else:
   try:pts=[p.toTuple() for p in e.sample(max(8,min(32,int(e.Length()/12)+2)))[0]]
   except:pts=[v.toTuple() for v in vs]
  if e.IsClosed() and len(pts)>1 and pts[-1]!=pts[0]:pts.append(pts[0])
  if len(pts)>1:ar.append([[round(float(x),4) for x in p] for p in pts])
 edges[k]=ar
(H/'drawing-edges.json').write_text(json.dumps(edges,separators=(',',':')))
print(json.dumps({'parts':len(S),'mass_nonreference_kg':sum(m['mass_kg'] or 0 for m in M.values()),'all_valid':all(s.isValid() for s in S.values())}))
