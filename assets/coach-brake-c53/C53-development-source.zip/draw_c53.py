"""C5.3 drawing issue generated from canonical CAD edges and parameters.

No drawn part is used as geometry input. Solid outlines are exact CAD edges;
colored occupancy boxes are explicitly identified planning envelopes.
"""
from pathlib import Path
import html
import re
import json
import math
import textwrap
import gzip

H = Path(__file__).resolve().parent
OUT = H.parents[1] / "dist/assets/coach-brake-c53"
OUT.mkdir(parents=True, exist_ok=True)
INK = "#21443e"
GRAY = "#6a7c77"
ACC = "#a34b27"
TEAL = "#167d88"
PALE = "#eaf3f2"
WARM = "#fff1e6"
LIGHT = "#edf0eb"
PAGE_W, PAGE_H = 2000, 1400


def esc(value):
    return html.escape(str(value))


def tx(x, y, value, size=19, weight="normal", color=INK, anchor="start"):
    value=re.sub(r'([a-z])(\d)', r'\1 \2',str(value))
    value=re.sub(r'(\d)(mm|kg|kN|N/mm)',r'\1 \2',value)
    value=re.sub(r'([:;])(?=\S)',r'\1 ',value)
    value=re.sub(r'(?<=[A-Za-z])(Ø|±|≤|≥)',r' \1',value)
    value=value.replace('pertruck','per truck').replace('atY','at Y').replace('SKF22218E','SKF 22218 E').replace('SKF22216E','SKF 22216 E')
    return (f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" '
            f'font-weight="{weight}" fill="{color}" text-anchor="{anchor}">'
            f'{esc(value)}</text>')


def ln(x1, y1, x2, y2, color=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<path d="M{x1:.2f},{y1:.2f}L{x2:.2f},{y2:.2f}" fill="none" '
            f'stroke="{color}" stroke-width="{width}"{attr}/>')


def rect(x, y, w, h, fill="none", stroke=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"{attr}/>')


def circle(x, y, r, fill="white", stroke=INK, width=1.2):
    return (f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')


def lines(x, y, rows, size=19, leading=30, color=INK):
    return "".join(tx(x, y + i * leading, row, size, color=color)
                   for i, row in enumerate(rows))


def paragraph(x, y, value, width=65, size=19, leading=29, color=INK):
    return lines(x, y, textwrap.wrap(value, width), size, leading, color)


def title(x, y, value, subtitle=None):
    result = tx(x, y, value, 22, "bold")
    if subtitle:
        result += tx(x, y + 29, subtitle, 17, color=GRAY)
    return result


def dim(a, b, label, vertical=False, label_shift=0, size=18):
    x1, y1 = a
    x2, y2 = b
    result = ln(x1, y1, x2, y2, ACC, 1.4)
    for x, y in (a, b):
        result += ln(x - 5, y - 5, x + 5, y + 5, ACC, 1.4)
    if vertical:
        x, y = (x1 + x2) / 2 - 13 + label_shift, (y1 + y2) / 2
        result += (f'<text transform="translate({x:.2f},{y:.2f}) rotate(-90)" '
                   f'font-size="{size}" fill="{ACC}" text-anchor="middle">'
                   f'{esc(label)}</text>')
    else:
        result += tx((x1 + x2) / 2 + label_shift, (y1 + y2) / 2 - 10,
                     label, size, color=ACC, anchor="middle")
    return result


def leader(target, elbow, end, label, anchor="start", color=ACC, size=18):
    result = ln(*target, *elbow, color) + ln(*elbow, *end, color)
    result += circle(*target, 3, color, color)
    result += tx(end[0], end[1] - 8, label, size, "bold", color, anchor)
    return result


def table(x, y, widths, headers, rows, row_h=35, size=17):
    total=sum(widths); result=rect(x,y,total,row_h,INK,INK); xx=x
    for width,value in zip(widths,headers):
        result+=tx(xx+12,y+row_h*.7,value,size,"bold","white"); xx+=width
    yy=y+row_h
    for i,row in enumerate(rows):
        wrapped=[textwrap.wrap(str(v),max(10,int((w-24)/(size*.54)))) or [""] for w,v in zip(widths,row)]
        height=max(row_h,12+max(map(len,wrapped))*size*1.2)
        result+=rect(x,yy,total,height,LIGHT if i%2==0 else "white","none"); xx=x
        for width,values in zip(widths,wrapped):
            for n,value in enumerate(values):result+=tx(xx+12,yy+size+7+n*size*1.2,value,size)
            xx+=width
        yy+=height
    return result+rect(x,y,total,yy-y,"none","#ccd7d2")


class Projection:
    """Orthographic projection of an unmodified CAD-edge cache."""
    def __init__(self, edges, ids, axes, box, bounds=None):
        self.edges, self.ids, self.axes = edges, list(ids), axes
        a, b = axes
        pp = [p for pid in self.ids for edge in edges.get(pid, []) for p in edge]
        if not pp:
            raise ValueError(f"No CAD edges for projection: {self.ids}")
        self.bounds = bounds or ((min(p[a] for p in pp), max(p[a] for p in pp)),
                                 (min(p[b] for p in pp), max(p[b] for p in pp)))
        (u0, u1), (v0, v1) = self.bounds
        x, y, w, h = box
        self.scale = min(w / max(u1 - u0, .0001), h / max(v1 - v0, .0001))
        self.ox = x + (w - (u1 - u0) * self.scale) / 2 - u0 * self.scale
        self.oy = y + (h + (v1 - v0) * self.scale) / 2 + v0 * self.scale

    def xy(self, point):
        return self.ox + point[0] * self.scale, self.oy - point[1] * self.scale

    def draw(self, ids=None, color=INK, width=1.1, opacity=1, shift=(0, 0, 0)):
        a, b = self.axes
        result = f'<g opacity="{opacity}">'
        for pid in (self.ids if ids is None else ids):
            for edge in self.edges.get(pid, []):
                points = [self.xy((p[a] + shift[a], p[b] + shift[b])) for p in edge]
                result += ('<polyline points="' + " ".join(f"{u:.2f},{v:.2f}" for u, v in points)
                           + f'" fill="none" stroke="{color}" stroke-width="{width}"/>')
        return result + "</g>"

    def envelope(self, bounds, fill=PALE, stroke=TEAL, dash="8 5", width=1.5):
        (u0, u1), (v0, v1) = bounds
        x, y = self.xy((u0, v1))
        return rect(x, y, (u1 - u0) * self.scale, (v1 - v0) * self.scale,
                    fill, stroke, width, dash)


def sheet(name, heading, body, notes):
    source = ('<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="1400" '
              'viewBox="0 0 2000 1400"><rect width="2000" height="1400" fill="white"/>'
              '<g font-family="DejaVu Sans,Arial,sans-serif">')
    source += tx(50, 45, "PULSIPHER FARMS  /  PASSENGER COACH ENGINEERING", 19, "bold")
    source += tx(50, 91, heading, 31, "bold")
    source += tx(50, 124, "C5.3 DEVELOPMENT  ·  MILLIMETRES  ·  SUPPLIER FIT AND ASSEMBLY QUALIFICATION OPEN  ·  NOT FOR FABRICATION", 17, color=ACC)
    source += ln(50, 143, 1950, 143, INK, 1.5) + body
    source += ln(50, 1190, 1950, 1190, INK, 1.5)
    source += lines(50, 1223, notes, 17, 27)
    source += ln(50, 1347, 1950, 1347, INK, 1.5)
    source += tx(50, 1377, name + "  ·  CAD: geometry-contract.json / parts.json / drawing-edges.json", 16)
    source += tx(1950, 1377, "Development checks: verification.json / design-record.json", 16, anchor="end")
    source += "</g></svg>"
    # SVG carries the precise edges; PNG is its compact preview. Public gzip avoids
    # duplicating several megabytes of line geometry in the static deployment.
    with gzip.GzipFile(filename=str(OUT / (name + ".svg.gz")),mode='wb',mtime=0) as f:
        f.write(source.encode())
    (OUT / (name + '.svg')).unlink(missing_ok=True)
    import cairosvg
    cairosvg.svg2png(bytestring=source.encode(), write_to=str(OUT / (name + ".png")), output_width=1600, output_height=1120)


# Final sheet content is populated from the C53 geometry contract.
if not all((H/name).exists() for name in ('geometry-contract.json','parts.json','drawing-edges.json')):
    print('C53_DRAWINGS_WAITING_FOR_CANONICAL_CAD')
    raise SystemExit(0)

E=json.loads((H/'drawing-edges.json').read_text())
P=json.loads((H/'geometry-contract.json').read_text())
raw=json.loads((H/'parts.json').read_text())
M={p['id']:p for p in (raw if isinstance(raw,list) else raw['parts'])}
if set(M)!=set(E):
    raise RuntimeError('Wait for matching final C53 parts and edge caches')
MODULE_IDS=[k for k in M if not k.startswith('CTX-')]
BLUE='#326985'

def bbox(k):
    pts=[q for line in E.get(k,[])for q in line]
    return {a:(min(q[i]for q in pts),max(q[i]for q in pts))for i,a in enumerate('xyz')}
B={k:bbox(k)for k in E if E[k]}
def mid(k,a):return sum(B[k][a])/2

def part_color(k):
    g=str(M[k].get('group','')).lower();name=k.lower()
    if g=='context' or k.startswith('CTX-'):return '#b0bec1'
    if any(t in g for t in ('reference','envelope','vendor','purchased')):return ACC
    return INK

def draw(p,ids=None,width=1.05):
    return ''.join(p.draw([k],part_color(k),width)for k in (ids or p.ids))

def clipped(body,box,key):
    x,y,w,h=box
    return f'<defs><clipPath id="{key}">{rect(x,y,w,h,'white','none')}</clipPath></defs><g clip-path="url(#{key})">{body}</g>'

def dimat(p,a,b,label,vertical=False,published=False):
    out=dim(p.xy(a),p.xy(b),label,vertical=vertical,size=17)
    return out.replace(ACC,BLUE)if published else out

def label_to(p,q,end,label,color=ACC,size=17):
    return leader(p.xy(q),(end[0]-18,end[1]),end,label,color=color,size=size)

def find_ids(*words):
    return [k for k in MODULE_IDS if any(w in k.lower()for w in words)]

rotor=P['rotor'];carrier=P['carrier'];link=P['link'];caliper=P['caliper']
ax=P['base']['reference_axle_centre'];rotor_y=rotor['friction_centre_y']
plan_box=(65,245,920,575);side_box=(1045,245,900,575)
all_ids=list(B)
plan=Projection(E,all_ids,(1,0),plan_box,((-600,750),(100,950)))
side_ids=MODULE_IDS+[k for k in all_ids if k.startswith('CTX-A2R-WHEEL')]
side=Projection(E,side_ids,(0,2),side_box,((100,950),(-30,660)))
s=title(60,190,'PLAN — INBOARD BRAKE / SHORT REACTION PATH','One right-side unit; retained C5 frame / wheel context is grey.')
s+=title(1040,190,'SIDE ELEVATION — DISC, CALIPER AND REACTION','Vendor outlines are provisional; blue dimension labels are published.')
s+=clipped(draw(plan,[k for k in all_ids if k.startswith('CTX-')],.9)+draw(plan,MODULE_IDS),plan_box,'m01plan')
s+=clipped(draw(side,[k for k in side_ids if k.startswith('CTX-')],.9)+draw(side,MODULE_IDS),side_box,'m01side')
s+=dimat(plan,(carrier['bearing_centres_y'][0],115),(carrier['bearing_centres_y'][1],115),f"{carrier['bearing_centres_y'][1]-carrier['bearing_centres_y'][0]:g} bearing station pitch")
s+=dimat(side,(900,ax[2]-rotor['outside_diameter']/2),(900,ax[2]+rotor['outside_diameter']/2),f"Ø{rotor['outside_diameter']:g} rotor",vertical=True,published=True)
s+=label_to(side,(ax[0]+rotor['outside_diameter']*.353553390593,ax[2]+rotor['outside_diameter']*.353553390593),(1640,290),'PUBLISHED ROTOR DIAMETER',BLUE,16)
s+=label_to(side,(ax[0]+180,ax[2]),(1640,345),'CALIPER RELIEF / PAD SWEEP HOLD',ACC,16)
s+=label_to(plan,(rotor['catalogue_axial_envelope_y'][1],ax[0]),(590,715),'HAT FACE OFFSET HOLD',ACC,16)
s+=label_to(plan,(link['moving_reference'][1],link['moving_reference'][0]),(110,300),'CARRIER → TORQUE LINK',INK,16)
s+=label_to(plan,(link['fixed_frame'][1],link['fixed_frame'][0]),(120,850),'LINK → STRUCTURAL SUPPORT',INK,16)
s+=label_to(side,(ax[0]+190,ax[2]-240),(1600,810),'C5 WHEEL BLANK CONTEXT',GRAY,16)
s+=table(60,885,[300,620],['PUBLISHED ROTOR BASIS','WEBB 55030PK-65'],[
 ['Friction diameter / width',f"Ø{rotor['outside_diameter']:g} / {rotor['friction_thickness']:g}"],
 ['Overall U depth / pilot',f"{rotor['overall_axial_depth']:g} / Ø{rotor['pilot_diameter']:g}"],
 ['Rotor attachment',f"{rotor['mount_holes']} × {rotor['mount_thread'].replace('x', ' × ')} on Ø{rotor['mount_pcd']:g} PCD"],
 ['Not a known flange offset','Overall U depth does not establish the hub mating-face datum'],
 ['Service replacement','Wheelset out; workshop removal / reinstallation of one wheel']
 ],row_h=42,size=16)
s+=table(1040,885,[300,600],['DEVELOPMENT INTERFACE','CURRENT DEFINITION'],[
 ['PAN17 caliper','40175072 / 40175073 family; swept-band pairing conditional'],
 ['Caliper screws','6 × M14 × 1.5, class 10.9; OEM engagement / torque govern'],
 ['Carrier support',str(carrier['bearing_sku'])+'; locating and floating stations'],
 ['Torque link',f"{link['eye_spacing']:.3f} reference eye spacing; finite effective arm varies"],
 ['Air / spring chamber','Exact TSE 22/24 suffix GA, stroke and force envelope remain open']
 ],row_h=42,size=16)
sheet('C53-M01','INBOARD DISC BRAKE — ASSEMBLY AND REACTION PATH',s,[
 'Rotor / hub rotate with the axle. One spherical-ended link restrains the carrier from wheel rotation while allowing its solved suspension clock motion.',
 'Orange OEM bodies are provisional envelopes. Published exterior dimensions do not establish internal section, mating datum, pad sweep or full wear clearance.',
 'Carrier bearings align the support with the axle; they do not replace torque restraint. Ratings and nominal fit do not qualify the custom assembly.',
 'The closed inboard rotor requires wheelset-out shop service and one wheel removal. Do not split the OEM friction ring or assume an on-car replacement path.'
])

# Detail views are selected from canonical parts; never reconstruct OEM geometry.
rotor_ids=find_ids('rotor','hub','webb')
carrier_ids=[k for k in MODULE_IDS if M[k].get('group')in('carrier','bearing-sleeve')or k.startswith(('NSK','CARRIER-COVER-M4','SLEEVE-END-M6','SLEEVE-CLAMP'))]
link_ids=find_ids('torque-link','link','clevis','pin')
if not all((rotor_ids,carrier_ids,link_ids)):
    raise RuntimeError('Review canonical C53 IDs before issuing D01 detail selections')
rv=Projection(E,rotor_ids,(0,2),(75,260,520,465))
cv=Projection(E,carrier_ids,(1,2),(705,260,540,465))
lv=Projection(E,link_ids,(0,2),(1365,260,540,465))
s=title(60,190,'ROTOR / HUB — FACE','Published thread pattern; custom hub fit remains open.')
s+=title(690,190,'CARRIER — AXIAL VIEW','Locating / floating bearing arrangement and retention.')
s+=title(1350,190,'TORQUE LINK — SIDE','Spherical end joints; short reaction to the bogie frame.')
s+=clipped(draw(rv), (60,250,550,490),'d01rotor')
s+=clipped(draw(cv), (690,250,570,490),'d01carrier')
s+=clipped(draw(lv), (1350,250,570,490),'d01link')
s+=dimat(rv,(ax[0]-rotor['mount_pcd']/2,ax[2]),(ax[0]+rotor['mount_pcd']/2,ax[2]),f"Ø{rotor['mount_pcd']:g} bolt circle",published=True)
s+=label_to(cv,(carrier['bearing_centres_y'][0],ax[2]),(710,275),'LOCATING STATION',ACC,16)
s+=label_to(cv,(carrier['bearing_centres_y'][1],ax[2]),(945,760),'FLOATING OUTER RING',ACC,16)
s+=tx(60,790,'8 × M14 × 2 ROTOR THREADS',18,'bold',BLUE)
s+=tx(690,790,'6 × M14 × 1.5 CALIPER THREADS',18,'bold',BLUE)
s+=tx(1350,790,'REFERENCE GEOMETRY; ASSEMBLY LIMITS OPEN',16,'bold',ACC)
s+=table(60,845,[205,375],['ROTOR / HUB','DIMENSION / LIMIT'],[
 ['Pilot',f"Ø{rotor['pilot_diameter']:g}; final pilot fit and flange face held"],
 ['Ring thickness',f"{rotor['friction_thickness']:g}; true internal section unavailable"],
 ['Rotor fasteners','8 × M14 × 2; actual bolt grip / OEM torque must be closed'],
 ['Torque transfer','Axle / custom hub connection requires its own strength and fatigue proof'],
 ['Service','Closed rotor; wheelset out and one shop wheel removal']
 ],row_h=43,size=16)
bearing_dims=carrier['bearing_d_DB']
s+=table(690,845,[205,375],['CARRIER / BEARING','DIMENSION / LIMIT'],[
 ['Bearing',f"{carrier['bearing_sku']}: {bearing_dims[0]:g} bore / {bearing_dims[1]:g} OD / {bearing_dims[2]:g} width"],
 ['Station centres',f"Y {carrier['bearing_centres_y'][0]:g} / {carrier['bearing_centres_y'][1]:g}"],
 ['Axial arrangement','One locating; one floating outer ring; final fits / thermal motion govern'],
 ['Retention','Actual shoulders, covers and spacers are development connections'],
 ['Carrier mount','Caliper-specific 6 × M14 × 1.5 pattern; not the rotor bolt pattern']
 ],row_h=43,size=16)
s+=table(1320,845,[205,425],['TORQUE REACTION','DIMENSION / LIMIT'],[
 ['Reference link',f"{link['eye_spacing']:.3f} centre spacing; spherical ends"],
 ['Joint candidate',f"Ø{link['pin_diameter_mm']:g} pin; GE20ES-2RS; {link['link_plate_thickness_mm']:g} link plate / {link['clevis_cheek_thickness_mm']:g} cheeks / {link['clevis_clear_gap_mm']:g} fork gap"],
 ['Carrier pin',', '.join(f'{v:g}'for v in link['moving_reference'])+' (X, Y, Z)'],
 ['Frame pin',', '.join(f'{v:g}'for v in link['fixed_frame'])+' (X, Y, Z)'],
 ['Force conversion','Use the solved perpendicular moment arm, not a constant radial dimension'],
 ['Qualification','Maximum output, joints, welds, fatigue and detached-part retention remain open']
 ],row_h=43,size=16)
sheet('C53-D01','INBOARD DISC BRAKE — ROTOR, CARRIER AND RETENTION DETAILS',s,[
 'Rotor M14 × 2 and caliper M14 × 1.5 are different thread systems. Do not interchange them or treat a generic M14 note as a complete connection.',
 'Published dimensional labels are blue. Orange purchased-part shapes are simplified reference envelopes; custom members and candidate hardware are green.',
 'This sheet illustrates actual modeled members and their retained arrangement. It does not authorize manufacture from incomplete vendor mating dimensions.',
 'Scope is one right-side brake unit. Eight discs per coach is architecture only; opposite-hand chamber / hose fit and complete-vehicle installation remain open.'
])
print('C53_M01_D01_WRITTEN',len(MODULE_IDS),len(rotor_ids),len(carrier_ids),len(link_ids))
