C53 D1 development source. Requires Python3.12, CadQuery2.7,NumPy/SciPy.
Run build_c53.py; check_c53.py; issue_c53.py; independent_check.py; draw_c53.py; finalize_c53.py.
Dependency: sibling cad/coach-truck-c5/checkpoint.brep andparts.json from repository, omitted to avoid duplicatingfulltruck.
Purchased shapes are explicit schematic envelopes, notOEMfabricationCAD. See designrecord andverification.
