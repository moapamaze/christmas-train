# C53 disc-brake mechanics — D1

**Unrated development record. High torque comparison cases fail the first bearing and frame-beam screens. Maximum actuator output remains unresolved.** Eight inboard discs are proposed, using axle-aligned caliper carriers and air-service/spring-parking actuation. Routine pad service is intended to remain accessible. Replacing a one-piece inboard rotor requires wheelset removal and shop rail-wheel removal/reinstallation.

The exact rotor is **Webb 55030PK-65**, nominally 325.12 × 34.036 mm, with a 168.91 mm pilot and eight M14 × 2 holes on a 195.834 mm pitch circle. It requires a custom hub. Hendrickson S-33391 has a different 220 mm pilot and eight M16 interface and is **not assumed interchangeable**. The Webb catalogue's 148.59 mm overall depth does not establish every internal web thickness or the controlled hub mating-face offset.

PAN17 calipers S-39094-L/R (WABCO 40175072/73) and S-41159-1 pads are commercial family candidates. Compatibility with this exact Webb rotor and custom hub remains conditional; this is not a matched complete commercial assembly. L949 Rev T lists 22/24 chambers S-40979-L/R / TSE 2224TLD2H-4627/4628, while its pad table retains a 20/24 reference. The exact configuration and manufacturer acceptance remain open. Earlier 18/24 or 20/24 force curves are not substituted.

## Working demand and heat

Basis: 13,200 kg regular or 11,000 kg accessible coach, four axles, eight 600 mm wheels/discs, ideal equal sharing, **level track / zero grade**, and an assumed 1.05 rotational-inertia factor. These are working demands, not maximum component loads.

| Coach | Deceleration, m/s² | Torque per disc, Nm | Torque per axle, Nm |
|---|---:|---:|---:|
| regular | 0.5 | 259.875 | 519.750 |
| regular | 0.7 | 363.825 | 727.650 |
| accessible | 0.5 | 216.562 | 433.125 |
| accessible | 0.7 | 303.187 | 606.375 |

At 7.5 mph, the modeled level-track full-stop energy is:

| Coach | Entire coach, kJ | Per disc, kJ | Separate 10 m descent heat per disc, kJ |
|---|---:|---:|---:|
| regular | 77.902 | 9.738 | 161.810 |
| accessible | 64.918 | 8.115 | 134.841 |

The regular 0.7 m/s² case begins at 4.066 kW per disc. Illustrative effective pad radii of 120/130/140 mm give 3.032/2.799/2.599 kN total tangential pad force. Actual torque-weighted radius must come from the installed lining contact; rotor outside radius is not a substitute. The JSON distinguishes both pads' summed normal force from one-face force. Heat input does not establish temperature, fade, cooling or repeated-stop duty. Route grade and duty remain unselected.

## Output and load path

The bounded primary-source search verified the exact current 22/24 identifiers but did not locate their controlled outline, permissible pressure or full service/spring force curves. TSE's 90–120 psi caging instruction is not a maximum service-pressure rating. No assumed pressure times nominal chamber area is presented as an output bound. Compounding, pressure faults and the caliper's input-to-torque relationship remain required inputs.

The PAN17 drawing's **10,000 Nm maximum transferable mounting-interface torque** is used only as a structural comparison case. It is not rated braking performance, an actuator maximum, a torque limiter or an established required proof load. The note calls for six M14 × 1.5 class 10.9 screws, at least 18 mm engagement and 205–225 Nm tightening torque. It does not qualify custom joints. Its 330 mm disc reference also needs reconciliation with the 325.12 mm Webb rotor.

The rotor torque path is axle → custom keyed hub/reducer → bolted rotor → pads. The reaction path is pads → OEM caliper bolts → custom axle-aligned carrier → single articulated torque link → **new transverse frame crossmember → inner sideframe webs**. It does not rely on the axlebox cover or route the link through the wheel web. Two rolling bearings support and align the carrier while the axle rotates; the link restrains carrier clock rotation. Loss of that active restraint can permit carrier rotation, hose damage and loss of controlled braking. A catcher is not a second functioning brake.

## Bearing and finite-link screen

The first geometry uses bearing centres Y = [115, 175] mm, rotor force plane Y = 240 mm, carrier pin (600, 170, 450) mm and fixed frame pin (350, 170, 500) mm. The link is 254.951 mm long, but its nominal effective torque arm is only 147.087 mm.

The documented bearing candidate is **NSK 6824DD**, dimensions [120, 150, 16] mm, catalogue Cr = 32 kN and C0r = 35.5 kN. Catalogue evidence does not establish current inventory or an installed rating. A 120 mm bore permits passage over the nominal 110 mm wheel seat after wheel removal. The removable split 100-to-120 mm support sleeve, shoulders, fits and race-creep prevention remain custom design requirements. The earlier 100 mm bore cannot pass that seat; a nominal 110 mm bore does not establish assembly clearance.

Nominal results below use a 120 mm effective pad radius, zero heave/roll/lateral shift, one braking direction and zero added carrier mass:

| Torque per disc, Nm | Link force, kN | Inboard radial load, kN | Outboard radial load, kN |
|---:|---:|---:|---:|
| 363.825 | 2.474 | 3.331 | 6.279 |
| 1000.000 | 6.799 | 9.156 | 17.257 |
| 3000.000 | 20.396 | 27.467 | 51.771 |
| 6000.000 | 40.792 | 54.935 | 103.543 |
| 10000.000 | 67.987 | 91.558 | 172.572 |

**High torque probes exceed the selected bearing's C0r reference.** The short bearing span magnifies the overhung pad resultant. C0r is not a design allowable; values below it do not establish bearing life, shock capacity, combined-load acceptance or installation stiffness.

The solver closes the fixed link under axle heave, roll and lateral shift and balances all six force/moment components in carrier axes. Only the inboard station locates axially. Both torque signs are checked. The grid includes heave −40/−30/0/+35 mm, roll ±2°/0, lateral ±3/0 mm and additional journal-travel boundary states. The regular rows enforce both journal heights h ± 620 sin(roll) within −40 to +35 mm; accessible rows use −30 to +35 mm. Unrestricted combined rows deliberately retain overtravel sensitivities, while −60 mm is separately labeled captured extension. Thus h = +35 mm with roll = 2° is not presented as ordinary travel: one journal would rise 56.64 mm. These are vertical-journal-travel-admissible development screens, not full kinematic acceptance. The ±3 mm independent centre-lateral probe does not establish the retained locating/floating journal arrangement's actual lateral freedom.

Vertical-journal-travel-admissible regular-grid carrier clock ranges from -4.456° to 1.721°, with minimum effective torque arm 135.673 mm. The captured-extension minimum is 120.025 mm. Load probes also use effective radius 120/130/140 mm and 0/50 kg nonrotating mass at local CG [100, 198.982, 0] mm. The 50 kg value is not measured CAD mass or a certified upper bound. Rotor weight acts directly on the axle.

| Torque per disc, Nm | Motion probe | Maximum link, kN | Maximum inboard radial, kN | Maximum outboard radial, kN |
|---:|---|---:|---:|---:|
| 363.825 | journal_consistent_regular | 3.042 | 3.846 | 7.443 |
| 363.825 | journal_consistent_accessible | 2.956 | 3.819 | 7.443 |
| 363.825 | unrestricted_combined_sensitivity | 3.109 | 3.915 | 7.637 |
| 363.825 | captured_extension_sensitivity | 3.434 | 4.002 | 6.391 |
| 1000.000 | journal_consistent_regular | 7.731 | 10.149 | 19.162 |
| 1000.000 | journal_consistent_accessible | 7.512 | 10.080 | 19.162 |
| 1000.000 | unrestricted_combined_sensitivity | 7.903 | 10.327 | 19.671 |
| 1000.000 | captured_extension_sensitivity | 8.735 | 10.551 | 16.446 |
| 3000.000 | journal_consistent_regular | 22.472 | 29.966 | 56.006 |
| 3000.000 | journal_consistent_accessible | 21.833 | 29.765 | 56.006 |
| 3000.000 | unrestricted_combined_sensitivity | 22.975 | 30.486 | 57.504 |
| 3000.000 | captured_extension_sensitivity | 25.398 | 31.140 | 48.060 |
| 6000.000 | journal_consistent_regular | 44.584 | 59.691 | 111.272 |
| 6000.000 | journal_consistent_accessible | 43.316 | 59.293 | 111.272 |
| 6000.000 | unrestricted_combined_sensitivity | 45.582 | 60.724 | 114.253 |
| 6000.000 | captured_extension_sensitivity | 50.393 | 62.024 | 95.481 |
| 10000.000 | journal_consistent_regular | 74.067 | 99.324 | 184.960 |
| 10000.000 | journal_consistent_accessible | 71.960 | 98.663 | 184.960 |
| 10000.000 | unrestricted_combined_sensitivity | 75.725 | 101.041 | 189.919 |
| 10000.000 | captured_extension_sensitivity | 83.719 | 103.203 | 158.709 |

The row maxima need not occur in one pose. JSON retains each governing pose, signed reactions and locating-bearing axial load. The 3780 solved cases have maximum force residual 1.46e-11 N and moment residual 4.56e-09 Nmm.

## Current frame crossmember and link

The current member is **HSS4x4x3/8 inch**, section [101.6, 101.6, 9.525] mm, centred at [210, 0, 380] mm and supported at Y = [-526, 526] mm. It replaces the failed initial 3 × 3 candidate. The link anchor remains outside the member at [350, 170, 500] mm, so the real rising bracket introduces eccentric torque. Both same-axle brake reactions add. The screen uses the 0.93 wall factor, a rounded-corner sensitivity with outer radius three design walls, and symmetric torsional restraint at the member ends. That assumed end restraint still requires a real qualified load path.

| Torque at each of two brakes, Nm | Biaxial bending, MPa | Torsion, MPa | Combined VM, MPa | Versus assumed 345 MPa yield |
|---:|---:|---:|---:|---|
| 363.825 | 13.5 | 2.5 | 14.1 | Below reference only |
| 1000.000 | 37.0 | 6.8 | 38.8 | Below reference only |
| 3000.000 | 111.0 | 20.4 | 116.5 | Below reference only |
| 6000.000 | 222.0 | 40.8 | 233.0 | Below reference only |
| 10000.000 | 370.0 | 68.1 | 388.3 | Above reference |

The 10 kNm case remains above this gross member reference. No further member iteration is represented. The actual maximum chamber/caliper torque must be established before final sizing. Rounded corners are a section-property sensitivity, not a verified supplier radius. Local member walls, gusset and endplate welds, bearing seats, fatigue and frame stiffness remain unqualified.

The actual link has a 40 × 12 mm shank, 60 mm eye outside diameter and 35 mm Aurora GE20ES-2RS bearing seat. Clevises have 10 mm cheeks and 24 mm clear gap. The custom 20 mm headed pins are screened over the actual 34 mm reaction-centroid span, using a central point-load model for bending plus double shear. Custom pin material/heat treatment has not been specified, so no pin-strength pass is assigned.

| Torque per disc, Nm | Motion probe | Pin gross VM, MPa | Eye net axial stress, MPa | Cheek projected bearing, MPa |
|---:|---|---:|---:|---:|
| 363.825 | journal_consistent_regular | 34.0 | 10.1 | 7.6 |
| 363.825 | captured_extension_sensitivity | 38.4 | 11.4 | 8.6 |
| 10000.000 | journal_consistent_regular | 827.2 | 246.9 | 185.2 |
| 10000.000 | captured_extension_sensitivity | 935.0 | 279.1 | 209.3 |

The Aurora bearing's 146 kN radial static catalogue reference does not qualify its housing, pin or link. Eye-net, projected-bearing and ideal Euler-shank checks are conditional local screens; they do not establish interference fit, race retention, breakout, oscillatory wear or fatigue life. Exact pin cross-hole, fillet and retention details also remain required.

The declared continuous 6 mm fillets receive a separate elastic weld-line screen. Each symmetric frame end transfers one brake force resultant and one bracket's torsional moment. The tube weld uses a rectangular perimeter approximation; the parent-web weld uses the declared endplate polygon and includes the 12 mm transfer offset. No weld allowable is assigned.

| Torque at each brake, Nm | Tube-to-endplate peak ideal traction, MPa | Endplate-to-web peak ideal traction, MPa |
|---:|---:|---:|
| 363.825 | 5.6 | 4.3 |
| 1000.000 | 15.4 | 11.9 |
| 3000.000 | 46.2 | 35.7 |
| 6000.000 | 92.3 | 71.4 |
| 10000.000 | 153.9 | 119.1 |

These are connection demands, not accepted weld capacities. Actual bead geometry, effective lengths, welding procedure, parent-wall load introduction, end torsional restraint and fatigue remain holds. The rotor-bolt and keyed-hub record separately gives ideal torque demand: two keys transfer torque **in series**, not as two parallel load-sharing keys. Their loaded lengths, bearing engagement and fatigue effect on the axle remain open. The 10 kNm comparison gives 12.766 kN tangential demand per rotor bolt under ideal equal sharing, and 200/166.667 kN at the 100/120 mm key interfaces respectively. No friction credit or keyway fatigue acceptance is assumed.

## Service and acceptance holds

A caliper fixed to the upright axlebox would not follow axle tilt inside its journal bearing. At 2°, the rotor edge-plane mismatch is approximately 5.67 mm. A coaxial carrier follows the axle; its frame link must articulate through finite motion. The commercial wear slide is not itself angular accommodation.

Reserve actual pad extraction, adjuster access, full-wear caliper/chamber space, hoses, caging and removal. The family application guide describes approximately 25.4 mm wear movement; the caliper drawing gives 21 mm, so the larger reservation remains pending reconciliation. Rotor service requires supported wheelset removal, controlled wheel removal/reinstallation, runout and torque-joint inspection. Do not split or alter the OEM friction ring to bypass that procedure.

No joint strength, bearing or fatigue life, thermal duty, adhesion control, stopping distance or operating rating is assigned. Exact rotor/pad/chamber pairing, custom hub, carrier and frame attachments remain unresolved engineering interfaces.

## Sources and reproduction

`calculate_mechanics.py`, `carrier_statics.py`, `connection_screens.py` and `mechanics_report.py` reproduce this note and `mechanics-calculations.json` using Python's standard library. The JSON records geometry snapshot hashes, sensitivity inputs and governing cases.

- [WEBB-R32](https://cdn.prod.website-files.com/692683b9a358dca80ef39017/69609994c6c39d1d62295d61_SD-131%20Webb%20ADB%20ROTOR%20flyer%20R32.pdf) — Webb 55030PK-65: 325.12 mm diameter, 34.036 mm thickness, 148.59 mm overall depth, 168.91 mm pilot and eight M14 x 2 holes on 195.834 mm PCD. Internal profile and controlled hub mating-face offset remain open.
- [NSK-6824](https://www.nsk.com/engineering/products/bearings/ball-bearings/deep-groove-ball-bearings/single-row-deep-groove-ball-bearings/6824dd-apn.html) — Selected thin bearing development candidate NSK 6824DD: 120 x 150 x 16 mm, Cr 32 kN, C0r 35.5 kN. Catalogue-only procurement evidence; no installed rating.
- [AISC-HSS](https://www.aisc.org/globalassets/continuing-education/quiz-handouts/specifying-hss-article.pdf) — 0.93 nominal-wall convention for A500 section-property screening; not railway qualification.
- [NSK-6024](https://www.oss.nsk.com/eu/6024ddu-apn.html) — Superseded, packaging-obstructed NSK 6024DDU comparison: 120 x 180 x 28 mm, Cr 97 kN, C0r 80 kN, 2,200 rpm and 2.08 kg. Catalogue ratings are not an installation acceptance.
- [H-L949](https://www.hendrickson-intl.com/getattachment/54c582a0-10e2-4fe2-9e8f-f4e33f9fccb4/L949.pdf) — PAN17 caliper, rotor, pad and current replacement chamber part numbers. Page 11 pad row says 20/24; page 15 current chamber row says 22/24; variant reconciliation remains open.
- [W-GA](https://www.wabco-customercentre.com/catalog/docs/6401750720____053_dascheck_j4_page-1---notset_tif.pdf) — 40175072/73 family mounting detail and 10,000 Nm transferable mounting-torque note. Drawing references 330 mm disc; exact 325 mm installation must be reconciled.
- [H-L1272](https://www.hendrickson-intl.com/getattachment/155d9e36-24d4-49e4-84c7-7ac5002024c0/L1272.pdf) — Hendrickson 325 mm PAN17 package; chamber/caliper wear movement approximately 1 in and full suspension/hose clearance.
- [TSE-HOT](https://www.tsebrakes.com/brake-chambers/hot-high-output-technology) — Public HOT family information; exact 4627/4628 GA and force envelope not found.
- [TSE-2026](https://www.tsebrakes.com/medias/iw/TSE-SalesSheetsTSE-HOT-Web-2026.pdf) — Current public family sheet; not an exact 22/24 force or dimensional record.
- [TSE-QR](https://www.tsebrakes.com/medias/iw/Quick-Reference-Guide.pdf) — Public options list; selected suffixes and full force envelope not given.
- [TSE-INSTALL](https://www.tsebrakes.com/medias/iw/TSE_Disc_Brake_Installation_Instructions_1_1_1.pdf) — Disc-chamber service, caging access, lower drain and hose installation. Its 90–120 psi caging instruction is not a maximum working-pressure rating.
