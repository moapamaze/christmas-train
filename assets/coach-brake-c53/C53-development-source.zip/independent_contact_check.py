"""Selected actual shared-face checks for C53 custom load-path connectivity."""
from pathlib import Path
import json,hashlib
import cadquery as cq
H=Path(__file__).resolve().parent
meta=json.loads((H/'parts.json').read_text());S=dict(zip((p['id']for p in meta),list(cq.importers.importBrep(str(H/'checkpoint.brep')).val())))
pairs=[('TORQUE-FORK-1','CARRIER-BARREL'),('TORQUE-FORK1','TORQUE-FORK-OUTBOARD-SADDLE'),('TORQUE-FORK-OUTBOARD-SADDLE','CARRIER-BARREL')]
for side in[-1,1]:
 pairs.extend([(f'CARRIER-MOUNT-WEB{side}','CARRIER-BARREL'),(f'CARRIER-MOUNT-WEB{side}','CALIPER-MOUNT-CRESCENT'),(f'FRAME-LINK-CHEEK{side}','FRAME-HSS'),(f'FRAME-ENDPLATE{side}','FRAME-HSS')])
for side in['L','R']:
 pairs.extend([(f'HUB-INBOARD-AXIAL-RETAINER-{side}','CUSTOM-ROTOR-HUB'),(f'HUB-AXIAL-RETAINER-{side}','CUSTOM-ROTOR-HUB')])
rows=[]
for a,b in pairs:
 area=0
 for f in S[a].Faces():
  for g in S[b].Faces():
   if f.distance(g)<1e-6:area+=f.intersect(g).Area()
 row=dict(a=a,b=b,distance_mm=S[a].distance(S[b]),overlap_mm3=S[a].intersect(S[b]).Volume(),coincident_face_area_mm2=area)
 rows.append(row);print(a,b,round(area,3),flush=True)
record=dict(status='SELECTED GEOMETRIC CONTACTS ONLY — NOT JOINT STRENGTH',checkpoint_sha256=hashlib.sha256((H/'checkpoint.brep').read_bytes()).hexdigest(),part_count=len(meta),pairs=rows,all_selected_pairs_have_face_contact=all(r['coincident_face_area_mm2']>1e-3 for r in rows),maximum_solid_overlap_mm3=max(r['overlap_mm3']for r in rows),scope='Actual coincident face area distinguishes a saddle or plate joint from a mere tangent line. It does not supply weld geometry, preload, fit, strength or fatigue capacity.')
(H/'independent-contact-check.json').write_text(json.dumps(record,indent=2)+'\n')
