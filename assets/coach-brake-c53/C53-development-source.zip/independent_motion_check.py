"""Nine-pose narrow C53 exact-shape check. Excludes unverified OEM proxies."""
from pathlib import Path
import json,hashlib,math,time
import cadquery as cq
from OCP.gp import gp_Trsf
H=Path(__file__).resolve().parent;B=H.parent/'coach-truck-c5'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(folder):
 m=json.loads((folder/'parts.json').read_text());s=list(cq.importers.importBrep(str(folder/'checkpoint.brep')).val())
 return {p['id']:p for p in m},dict(zip((p['id']for p in m),s))
M,S=read(H);BM,BS=read(B)
def bounds(s):
 b=s.BoundingBox();return [(getattr(b,a+'min'),getattr(b,a+'max'))for a in'xyz']
def bbox_distance(a,b):return math.sqrt(sum(max(0,x[0]-y[1],y[0]-x[1])**2 for x,y in zip(a,b)))
def overlap(a,b):return all(min(x[1],y[1])-max(x[0],y[0])>1e-5 for x,y in zip(a,b))
states=json.loads((H/'independent-motion-states.json').read_text())['states']
fixed={k:s for k,s in S.items()if M[k]['kinematics']=='fixed' and not M[k]['catalogue_reference_only']}
context={k:s for k,s in BS.items()if BM[k]['metadata']['kinematics']=='fixed' and not any(t in k for t in['BRAKE','TORQUE'])}
physical={k:s for k,s in S.items()if not M[k]['catalogue_reference_only']}
link_ids=[k for k in physical if M[k]['kinematics']=='link']
clevis_ids=['FRAME-LINK-CHEEK-1','FRAME-LINK-CHEEK1','TORQUE-FORK-1','TORQUE-FORK1']
rows=[];positives=[];tested=0
for state in states:
 transforms={}
 for k in['axle','carrier','link']:
  tr=gp_Trsf();tr.SetValues(*[v for row in state[k+'_matrix_row_major'][:3]for v in row]);transforms[k]=cq.Location(tr)
 pose={}
 for k,s in physical.items():
  kin=M[k]['kinematics'];pose[k]=s if kin=='fixed' else s.moved(transforms['axle' if kin=='rotating' else kin])
 pb={k:bounds(s)for k,s in pose.items()};targets={**fixed,**{'C5:'+k:s for k,s in context.items()}};tb={k:bounds(s)for k,s in targets.items()}
 for a,s in pose.items():
  if M[a]['kinematics']=='fixed':continue
  for b,t in targets.items():
   if not overlap(pb[a],tb[b]):continue
   tested+=1;v=s.intersect(t).Volume()
   if v>1e-3:positives.append(dict(state=state['id'],a=a,b=b,overlap_mm3=v))
 candidates=sorted((bbox_distance(pb[a],pb[b]),a,b)for a in link_ids for b in clevis_ids)
 best=None
 for lower,a,b in candidates:
  if best is not None and lower>best['distance_mm']+1e-7:break
  d=pose[a].distance(pose[b])
  if best is None or d<best['distance_mm']:best=dict(a=a,b=b,distance_mm=d)
 # Moving link versus carrier clevis, spacers and pin must be tested separately.
 for a in link_ids:
  for b in[k for k in pose if M[k]['kinematics']=='carrier' and (k.startswith('TORQUE-FORK')or k.startswith('PIN-SPACER1')or k.startswith('LINK-PIN1'))]:
   if not overlap(pb[a],pb[b]):continue
   tested+=1;v=pose[a].intersect(pose[b]).Volume()
   if v>1e-3:positives.append(dict(state=state['id'],a=a,b=b,overlap_mm3=v))
 rows.append(dict(state=state['id'],minimum_link_hardware_to_clevis=best))
 print(state['id'],best,'positives',len(positives),flush=True)
record=dict(status='NARROW DISCRETE MOTION CHECK; NO FULL OEM CLEARANCE CLAIM',source_hashes={p.name:sha(p)for p in[H/'checkpoint.brep',H/'parts.json',H/'independent-motion-states.json']},part_count=len(M),states=len(states),fixed_C5_context_count=len(context),exact_intersections_tested=tested,positive_pairs=positives,pose_clearances=rows,minimum_link_hardware_to_clevis=min(rows,key=lambda r:r['minimum_link_hardware_to_clevis']['distance_mm']),exclusions=['Unverified rotor/caliper/chamber supplier solids and assumed spherical-bearing interiors.','Whole body yaw/tilt combinations, continuous sweep, rail/wheel profile and complete left/right mirrored brakes.','Intended spherical-pin contacts are not a clearance requirement; mechanical tolerances and flexure remain unqualified.'])
(H/'independent-motion-check.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'states':len(states),'exact_tests':tested,'positive_pairs':len(positives),'minimum':record['minimum_link_hardware_to_clevis']},indent=2))
