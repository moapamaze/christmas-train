PULSIPHER FARMS / CHRISTMAS TRAIN — PHASE 3A R0 — 17 OCTOBER 2026
PRELIMINARY ENGINEERING DEFINITION. NOT FOR FABRICATION OR CONSTRUCTION.

Current owner direction: 0% longitudinal track grade; North Pole location deferred;
passengers disembark there. This technical release excludes business projections and
ride-experience planning. Vehicle/interface development proceeds before final alignment.

START HERE
output/Christmas_Train_Phase3A_Engineering_Definition_R0.pdf — full report, sources, holds.
drawings/Stage3A_Engineering_Definition_Drawings_R0.pdf — nine subsystem sheets.
output/Christmas_Train_Phase3A_Engineering_Registers_R0.xlsx — editable calculations,
components, interfaces and sources; amber inputs are assumptions. Not supplier ratings.
research/ — primary-source registers, development notes and calculation scripts.
source/ — current design basis, interfaces, frozen Stage 2 geometry and system inputs.
qa/ — review records and limitations. Arithmetic checks are not engineering approval.

FORMATS AND LIMITS
The nine sheet DXFs are editable PAPER INCHES (17 x 11); they are not full-size
manufacturing geometry. The separate Coach_Interface_Envelopes_Inches DXF is MODEL
INCHES and contains only study envelopes. SVG and PDF are coordinated review diagrams.
No new production 3D model or native parametric CAD feature tree is included.
The website's rotating Stage 2 coaches remain space models and do not show selected
bogies, wheels, structural sections, couplings or completed control hardware.
Unselected safety-critical sizes, welds, pins and tolerances remain expressly held.

REBUILD (preserve the phase3/ directory structure)
Python 3.12 or compatible, with reportlab, pypdf and ezdxf; report generator expects
DejaVuSans.ttf and DejaVuSans-Bold.ttf in /usr/share/fonts/truetype/dejavu (adapt for OS).
From the directory containing phase3/:
  python3 phase3/research/frames_calc.py
  python3 phase3/research/brakes_couplings_calc.py
  python3 phase3/research/build_brakes_couplings_json.py
  python3 phase3/research/calculate_propulsion_utilities.py
  python3 phase3/drawings/build_Stage3A_Drawings_R0.py
  python3 phase3/build_phase3_report.py
The workbook source requires Node and the @oai/artifact-tool runtime; this authoring
library is not bundled. The delivered XLSX is independently editable in spreadsheet
software; its formula and export checks were performed here, not in desktop Excel.
Manufacturer publications are linked, not redistributed. Availability means a published
product reference only; stock, price, lead time and project-specific suitability are
unconfirmed. No outreach, orders or engineer-approved designs are represented.

REVISION CONTROL
This is the first Phase 3A issue and incorporates the owner's zero-grade instruction.
Earlier files are retained. Nonzero grade cases are off-design sensitivity only.
SHA256_MANIFEST.json records package file hashes, not engineering certification.
