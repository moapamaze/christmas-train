"""PF-TRAIN-S3A-R0: reproducible frame statics and rigid-body sensitivities.
No design factors, component capacities or operating limits are established here.
"""
import json, math
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
basis = json.loads((ROOT / 'source/design_basis.json').read_text())
c = basis['configuration']; geo = basis['geometry']; g = 9.80665
xA, xB = geo['bogie_centres_x_in']; span = xB - xA
masses = []
for label, tare, count, device in [('regular',c['regular_tare_allocation_kg'],33,0),('accessible',c['accessible_tare_allocation_kg'],14,c['mobility_device_total_kg'])]:
    for case,p in [('nominal',c['nominal_person_kg']),('stress',c['stress_person_kg'])]:
        gross = tare + count*p + device
        masses.append(dict(vehicle=label,case=case,tare_kg=tare,people=count,person_kg=p,mobility_kg=device,gross_kg=gross,weight_kN=gross*g/1000,balanced_bogie_kg=gross/2,balanced_axle_kg=gross/4))
crowd=[]
for case,p in [('nominal',100),('stress',145)]:
    payload=33*p; gross=7040+payload; x=76.5
    ra=7040/2+payload*(xB-x)/span; rb=gross-ra
    crowd.append(dict(case=case,payload_centroid_x_in=x,gross_kg=gross,front_bogie_kg=ra,rear_bogie_kg=rb,front_axle_average_kg=ra/2))
partial_mass=7040+17*145
partial_e=16*145*(32*.0254)/partial_mass
curve=[]
L=span*.0254; aframe=400*.0254/2; halfwidth=110*.0254/2
for R in [30,50,75]:
    ag=(7.5*.44704)**2/(R*g)
    sag=R-math.sqrt(R**2-(L/2)**2)
    curve.append(dict(radius_m=R,speed_mph=7.5,lateral_g=ag,body_mid_chord_offset_m=sag,frame_end_centre_throw_m=math.sqrt((R-sag)**2+aframe**2)-R,outer_rectangular_envelope_from_trackcentre_m=math.sqrt((R-sag+halfwidth)**2+aframe**2)-R,inner_rectangular_envelope_from_trackcentre_m=sag+halfwidth,partial_load_inner_side_fraction=[{'assumed_CG_height_m':h,'fraction':.5-(partial_e+h*ag)/.9144} for h in [1.2,1.5,1.8]]))
calcs=[
 {'id':'FR-C01','formula':'M=tare+n*person_mass+mobility_mass; W=M*9.80665/1000 kN; balanced bogie=M/2; axle average=M/4','inputs':{'basis':basis['revision'],'two_bogies':'two axles each; equal loads only','tare_CG_x_in':153},'results':masses,'status':'Calculated planning masses and ideal balanced averages; not allowable axle or bogie ratings.'},
 {'id':'FR-C02','formula':'RA=sum(m_i*(261-x_i)/216); RB=sum(m_i)-RA (kg mass-equivalent); forces are result*9.80665 N','inputs':{'regular_tare_kg':7040,'tare_x_in':153,'people':33,'all_people_centroid_x_in':76.5},'results':crowd,'status':'Adverse front-half crowd redistribution sensitivity at same gross mass, not a seating arrangement. Actual individual wheel loads require suspension model.'},
 {'id':'FR-C03','formula':'At front tip x=-47: RA=P*(261+47)/216; RB=P-RA; support moment=-P*92*0.0254. At cabin edge x=-3: moment=-P*48*0.0254','inputs':{'point_load_kN':1,'frame_tip_x_in':-47,'front_bogie_x_in':45,'body_front_edge_x_in':-3},'results':{'tip_RA_kN':308/216,'tip_RB_kN':-92/216,'tip_hogging_kNm':2.3368,'body_edge_hogging_kNm':1.2192},'status':'Static influence coefficients; multiply by approved platform/lift/stair loads. Does not define permitted platform occupancy.'},
 {'id':'FR-C04','formula':'Uniform cabin line load: M_mid=q*(L^2/8-a^2/2); M_support=-q*a^2/2; L=216in, a=48in','inputs':{'uniform_line_load_kN_per_m':1,'bogie_spacing_m':L,'cabin_overhang_m':48*.0254,'cabin_length_m':312*.0254},'results':{'midspan_sagging_kNm':L*L/8-(48*.0254)**2/2,'support_hogging_kNm':-(48*.0254)**2/2},'status':'Beam influence coefficients only; gross coach mass cannot be spread on frame without subtracting bogie mass and locating all equipment.'},
 {'id':'FR-C05','formula':'e=sum(m_i*y_i)/M; a/g=v^2/(R*g); rigid inner-side weight fraction=0.5-(e+h*a/g)/s, s=0.9144m proxy','inputs':{'tare_kg':7040,'passengers_one_side':16,'crew_at_centre':1,'person_kg':145,'seat_centroid_y_in':32,'assumed_effective_support_spacing_m':.9144,'assumed_CG_height_m':[1.2,1.5,1.8]},'results':{'partial_mass_kg':partial_mass,'lateral_CG_offset_m':partial_e,'curves':curve},'status':'Unapproved rigid-body sensitivity only. Nominal gauge is only a proxy for wheel contact support spacing; omits roll, wind, cant, twist, flange climb, lateral flange forces and dynamic effects. Not a safe speed or stability verification.'},
 {'id':'FR-C06','formula':'sagitta=R-sqrt(R^2-(L/2)^2); outer rectangle=sqrt((R-sagitta+width/2)^2+(length/2)^2)-R; inner=width/2+sagitta','inputs':{'bogie_spacing_m':L,'rectangle_length_m':400*.0254,'rectangle_width_m':110*.0254,'curves_m':[30,50,75]},'results':curve,'status':'Geometric rigid 400x110in rectangular envelope only. Excludes stairs, couplings, deflection, yaw compliance, rail tolerances, reverse curves and vertical transitions. Not track clearance approval.'},
 {'id':'FR-C07','formula':'L/depth = 216/3','inputs':{'bogie_span_in':216,'previous_visual_frame_depth_in':3},'results':{'span_depth_ratio':72},'status':'Packaging warning, not a member-strength calculation; prior 3in frame envelope is unengineered.'}
]
out=ROOT/'research/frames_calculations.json'
out.write_text(json.dumps({'revision':basis['revision'],'date':basis['date'],'status':basis['status'],'calculations':calcs},indent=2)+'\n')
print(json.dumps({'masses':masses,'crowd':crowd,'partial_CG_y_m':partial_e,'calculation_count':len(calcs)},indent=2))
