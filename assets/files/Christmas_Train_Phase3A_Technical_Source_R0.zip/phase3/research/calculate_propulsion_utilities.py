"""Phase 3A screening calculations; all operating assumptions explicit.
Run from any directory. No component, circuit or construction approval.
"""
import json
from pathlib import Path
PHASE3 = Path(__file__).resolve().parents[1]
BASE = json.loads((PHASE3/'source/design_basis.json').read_text())
OLD = json.loads((PHASE3/'source/Stage2_Systems_Frozen_R0.json').read_text())
g=9.80665
v=7.5*0.44704
running=0.005
starting=0.010
acceleration=0.10
traction=[]
for mass in (55000,60000,65000):
    for grade in (0,.01,.02,.03):
        f_run=mass*g*(grade+running)
        f_start=mass*g*(grade+starting)
        traction.append(dict(mass_kg=mass,grade_fraction=grade,
            case_classification='PROJECT BASIS: level track' if grade == 0 else 'OFF-DESIGN SENSITIVITY ONLY: not project requirement',
            grade_force_kN=mass*g*grade/1000,
            running_resistance_kN=mass*g*running/1000,
            starting_resistance_kN=mass*g*starting/1000,
            running_total_kN=f_run/1000,
            start_total_before_acceleration_kN=f_start/1000,
            start_with_acceleration_kN=(f_start+mass*acceleration)/1000,
            running_with_acceleration_kN=(f_run+mass*acceleration)/1000,
            wheel_power_running_with_acceleration_at7_5mph_kW=(f_run+mass*acceleration)*v/1000,
            engine_running_with_acceleration_075_efficiency_plus10kW_aux=(f_run+mass*acceleration)*v/1000/.75+10,
            wheel_power_7_5mph_kW=f_run*v/1000,
            engine_075_efficiency_plus10kW_aux=f_run*v/1000/.75+10,
            engine_070_efficiency_plus10kW_aux=f_run*v/1000/.70+10,
            engine_085_efficiency_plus10kW_aux=f_run*v/1000/.85+10,
            adhesive_mass_for_start_kg={str(mu):f_start/(g*mu) for mu in (.1,.15,.2)},
            adhesive_mass_for_start_accelerating_kg={str(mu):(f_start+mass*acceleration)/(g*mu) for mu in (.1,.15,.2)}))

# Recalculate HVAC from the preserved Stage 2 geometry and ventilation assumptions.
h=OLD['HVAC_inputs']; geo=OLD['HVAC_geometry']
hvac=[]
for kind,people in [('regular',33),('accessible',14)]:
    qoa=people*h['outside_air_L_s_person']/1000
    qdoor=h['additional_average_door_leakage_m3_s']
    dt=(h['summer_outside_F']-h['summer_inside_F'])*5/9
    dtwinter=(h['winter_inside_F']-h['winter_outside_F'])*5/9
    rho=h['air_density_kg_m3']; cp=h['air_cp_kJ_kgK']
    parts={
        'conduction_kW':geo['UA_W_K']*dt/1000,
        'glass_solar_kW':h['glazing_m2']*h['glazing_SHGC']*h['equivalent_glazing_solar_W_m2']/1000,
        'extra_roof_solar_kW':geo['floor_roof_each_m2']*h['opaque_effective_U_W_m2K']*h['additional_roof_sol_air_K']/1000,
        'people_kW':people*h['person_total_W']/1000,
        'outside_air_sensible_kW':qoa*rho*cp*dt,
        'door_leakage_sensible_kW':qdoor*rho*cp*dt,
        'lights_equipment_kW':h['lighting_equipment_W']/1000}
    latent=(qoa+qdoor)*rho*h['outside_humidity_ratio_stress_kg_kg']*h['water_vapor_latent_kJ_kg']
    loss=geo['UA_W_K']*dtwinter/1000+(qoa+qdoor)*rho*cp*dtwinter
    hvac.append(dict(coach=kind,people=people,outside_air_m3_s=qoa,components=parts,
        dry_cooling_kW=sum(parts.values())*1.15,added_humid_latent_before_allowance_kW=latent,
        humid_cooling_kW=(sum(parts.values())+latent)*1.15,
        winter_loss_before_gains_and_warmup_kW=loss,
        winter_occupied_net_kW=loss-people*.075-.2))

dry=3*hvac[0]['dry_cooling_kW']+hvac[1]['dry_cooling_kW']
humid=3*hvac[0]['humid_cooling_kW']+hvac[1]['humid_cooling_kW']
hotel={'dry_thermal_kW':dry,'humid_thermal_kW':humid,
    'electrical_COP_cases':[dict(COP=c,dry_electrical_plus3_kW=dry/c+3,humid_electrical_plus3_kW=humid/c+3) for c in (2.,2.5,3.)],
    'winter_before_gains_and_warmup_thermal_kW':3*hvac[0]['winter_loss_before_gains_and_warmup_kW']+hvac[1]['winter_loss_before_gains_and_warmup_kW'],
    'heating_example':{'resistance_per_car_kW':10,'four_cars_plus3_kW':43,'status':'load scenario, not selected heater size'},
    'outside_air_total_m3_s':3*hvac[0]['outside_air_m3_s']+hvac[1]['outside_air_m3_s'],
    'study_delivered_continuous_range_kW':[40,70],
    'nominal_voltage_candidate':'480 V three phase 60 Hz; 240 V alternative pending HVAC choice'}
hydro={'status':'kinematic illustration only; no rail duty approval or selected topology',
    'engine_rpm_example':2200,'pump_displacement_cc':60.4,'pressure_bar':420,
    'ideal_pump_flow_L_min':60.4*2200/1000,
    'ideal_hydraulic_power_kW':420*(60.4*2200/1000)/600,
    'two_motors_parallel_each_cc':80,
    'ideal_motor_rpm':(60.4*2200/1000)/2/(80/1000),
    'ideal_torque_each_Nm_at420bar':420*1.27,
    'formula_reduction':'i = F_required * wheel_radius / (motor_count * actual_motor_torque * reduction_efficiency)',
    'formula_speed':'wheel_rpm = v*60/(pi*wheel_diameter); verify motor_rpm = i*wheel_rpm throughout variable displacement range',
    'limit':'420 bar is pump maximum working pressure, not a selected continuous duty; actual power, torque, leakage, charge flow and cooling require supplier maps'}
battery={'status':'provisional energy example only; not a battery purchase specification',
    'formula_Ah':'P_W * t_h / (V_nom * DC_efficiency * usable_DoD * end_of_life_capacity_factor * temperature_factor)',
    'per_car_example':{'essential_load_W':150,'duration_h':2,'nominal_V':24,'DC_efficiency':.90,'usable_DoD':.80,'end_of_life_factor':.80,'temperature_factor':.80},
    'calculated_nameplate_Ah':150*2/(24*.9*.8*.8*.8),
    'excluded':'brake actuator/pump energy, door actuators, starting surges and battery chemistry-specific limits are not quantified; must be added from actual suppliers',
    'runtime_status':'2 hours is a screening assumption, not a governing code requirement; approved rescue/evacuation duration governs'}
out={'revision':BASE['revision'],'date':BASE['date'],'status':BASE['status'],
    'project_grade_basis':{'longitudinal_grade_fraction':0,'authority':'Owner direction: track will be laid at 0; no intentional grades.',
        'survey_hold':'Verify as-built longitudinal profile and approve residual grade/settlement tolerances; no numeric tolerance is invented.',
        'retained_off_design_sensitivities_fraction':[.01,.02,.03],'off_design_status':'Historical engineering sensitivities, not planned grades or locomotive procurement requirements.'},
    'inputs':{'mass_kg':[55000,60000,65000],'gravity_m_s2':g,'speed_mph':7.5,'speed_m_s':v,'grades_fraction':[0],'off_design_grades_fraction':[.01,.02,.03],
        'running_resistance_fraction':running,'starting_resistance_fraction':starting,'acceleration_m_s2':acceleration,
        'adhesion_coefficients':[.10,.15,.20],'drive_efficiency_scenarios':[.70,.75,.85],'traction_auxiliary_kW_assumption':10,
        'curve_and_wind_resistance':'unquantified; excluded from all numeric totals, to be added by vehicle/track integrator',
        'assumption_limits':'Resistance and adhesion numbers are sensitivity assumptions, not measured railroad values, standards or supplier ratings.'},
    'formulas':{'running_N':'M*g*(grade+c_running)+F_curve+F_wind','starting_N':'M*g*(grade+c_start)+M*a+F_curve+F_wind','wheel_kW':'F_N*v_m_s/1000','engine_kW':'wheel_kW/eta_drive + actual_aux_kW; separate hotel genset excluded','adhesive_mass_kg':'F_N/(mu*g)'},
    'project_level_track_cases':[row for row in traction if row['grade_fraction']==0],
    'project_governing_65t_level_track_case':next(row for row in traction if row['grade_fraction']==0 and row['mass_kg']==65000),
    'traction_cases':traction,'HVAC_inputs':h,'HVAC_geometry':geo,'HVAC_cases':hvac,'hotel_power':hotel,'hydrostatic_example':hydro,'emergency_battery':battery,
    'verification':{'HVAC_matches_Stage2':all(abs(hvac[i]['humid_cooling_kW']-OLD['HVAC_cases'][key]['humid_cooling_with15pct_kW'])<1e-9 for i,key in enumerate(('regular_32_plus1crew','accessible_13_plus1crew')))}}
dest=PHASE3/'research/propulsion_utilities_calculations.json'
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'output':str(dest),'HVAC':hvac,'hotel':hotel,'governing_level_track_case':out['project_governing_65t_level_track_case'],'battery_Ah':battery['calculated_nameplate_Ah'],'verification':out['verification']},indent=2))
