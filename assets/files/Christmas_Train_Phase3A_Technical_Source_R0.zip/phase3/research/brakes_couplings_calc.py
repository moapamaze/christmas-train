import json,math,pathlib
P=pathlib.Path(__file__).parent
G=9.80665
out={'status':'PRELIMINARY LEVEL-TRACK PROJECT BASIS; NONZERO GRADES OFF-DESIGN ONLY; NOT BRAKE RATINGS OR OPERATING LIMITS','project_basis':{'longitudinal_grade_fraction':0,'authority':'Latest owner direction transmitted 2026-10-17','off_design_grades_fraction':[.01,.02,.03],'grade_tolerance':'HELD: engineer to specify and verify as-built profile; no invented tolerance','parking':'Required despite zero nominal gravity component; address wind, inadvertent movement, residual as-built grade and securing'},'g_mps2':G,'stopping':[],'adhesion':[],'holding':[],'coupling':[],'articulation':[]}
for mass in (55000,60000,65000):
 for mph in (5,7.5):
  v=mph*.44704
  for grade in (0,.01,.02,.03):
   for tau in (1.5,3):
    for mode,b in [('service',.5),('emergency',.8)]:
     ag=G*grade; v1=v+ag*tau; sd=v*tau+.5*ag*tau*tau; a=b-ag
     sb=v1*v1/(2*a); st=sd+sb
     out['stopping'].append(dict(study_status='PROJECT BASIS' if grade==0 else 'OFF-DESIGN SENSITIVITY ONLY',mass_kg=mass,speed_mph=mph,grade=grade,delay_s=tau,mode=mode,brake_specific_force_mps2=b,brake_force_kN=mass*b/1000,net_deceleration_mps2=a,speed_at_full_brake_mps=v1,delay_distance_m=sd,braking_distance_m=sb,total_distance_m=st,total_distance_ft=st/.3048,total_time_s=tau+v1/a,brake_energy_kJ=(.5*mass*v*v+mass*ag*st)/1000,continuous_grade_heat_kW=mass*ag*v/1000,required_adhesion_all_weight=b/G))
 for grade in (0,.01,.02,.03):
  out['holding'].append(dict(study_status='PROJECT BASIS' if grade==0 else 'OFF-DESIGN SENSITIVITY ONLY',mass_kg=mass,grade=grade,force_kN=mass*G*grade/1000,note='No margin, wind, impact, dynamic uplift or uneven wheel load allowance'))
for alpha in (1,.75,.25):
 for mu in (.03,.05,.08,.10,.15):
  for grade in (0,.01,.02,.03):
   v=7.5*.44704;tau=3;ag=G*grade;b=min(.8,mu*G*alpha);a=b-ag;v1=v+ag*tau;sd=v*tau+.5*ag*tau*tau
   out['adhesion'].append(dict(study_status='PROJECT BASIS' if grade==0 else 'OFF-DESIGN SENSITIVITY ONLY',mass_kg=65000,speed_mph=7.5,grade=grade,delay_s=tau,mu_assumed=mu,braked_weight_fraction=alpha,commanded_brake_specific_force_mps2=.8,available_brake_specific_force_mps2=b,net_deceleration_mps2=a,total_distance_m=sd+v1*v1/(2*a) if a>1e-9 else None,note='No stop predicted' if a<=1e-9 else 'Adhesion upper bound only; assumes sufficient remaining hardware torque to reach commanded total force. See degraded_stopping for no-redistribution cases.'))
# Conservative 65t consist: locomotive14.5t, cars scaled from stress distribution to carry remaining50.5t.
stress=[11825,11825,11825,9865]; cars=[m*50500/sum(stress) for m in stress]; loco=14500
M=loco+sum(cars)
out['segment_input']={'consist_order':['Locomotive','Regular1','Regular2','Regular3','Accessible'],'loco_mass_kg':loco,'car_masses_kg':cars,'total_kg':M,'starting_accel_mps2':.15,'uphill_grade':0,'load_case_distinction':'Coupler launch c_rr=.005 and a=.15m/s2 differs from propulsion launch c_rr=.010 and a=.10m/s2. Both are preliminary cases; neither is the complete governing envelope','rolling_resistance_coeff':.005,'all_values':'assumptions for sensitivity; not actual measured allocation'}
out['coupling_off_design']=[]
for grade in (0,.01,.02,.03):
 for k in range(4):
  trail=sum(cars[k:]);start=trail*(.15+G*(grade+.005))
  bl=.15*G*loco
  bco=.8*sum(cars);bt=.8*trail
  bfail=.8*(M-cars[-1]);btf=.8*(trail-cars[-1])
  r=dict(study_status='PROJECT BASIS' if grade==0 else 'OFF-DESIGN SENSITIVITY ONLY',grade=grade,joint=['Loco-R1','R1-R2','R2-R3','R3-Accessible'][k],trailing_mass_kg=trail,starting_tension_kN=start/1000,reversing_push_compression_kN=start/1000,balanced_proportional_braking_force_kN=0,loco_only_adhesion_limited_compression_kN=trail*bl/M/1000,coaches_only_loco_unbraked_tension_kN=(bt-trail*bco/M)/1000,rear_car_unbraked_compression_kN=-(btf-trail*bfail/M)/1000,note='Quasi-static only, no impact/slack/curve resistance. Reversing push uses same opposed-motion resistance and acceleration magnitude; not a buff rating.')
  out['coupling' if grade==0 else 'coupling_off_design'].append(r)
for R in (30,50,75):
 spacing=430*.0254
 delta=spacing/R
 out['articulation'].append(dict(radius_m=R,approx_adjacent_yaw_deg=math.degrees(delta),approx_each_joint_yaw_deg=math.degrees(delta/2),method='Same-radius equal-car arc-spacing approximation; not reverse-curve articulation limit'))
out['vehicle_holding_level']=[dict(vehicle=name,mass_kg=mass,grade=0,gravity_force_kN=0,note='Parking still required. Wind, inadvertent movement, residual as-built grade, acceptance margin and securing remain to be designed.') for name,mass in zip(['Locomotive','Regular1','Regular2','Regular3','Accessible'],[loco]+cars)]
out['vehicle_holding_off_design_3pct']=[dict(study_status='OFF-DESIGN SENSITIVITY ONLY',vehicle=name,mass_kg=mass,grade=.03,force_kN=mass*G*.03/1000,note='Not project duty. Before margins, wind, uneven loading; 65t allocated consist') for name,mass in zip(['Locomotive','Regular1','Regular2','Regular3','Accessible'],[loco]+cars)]
out['degraded_stopping']=[];out['degraded_stopping_off_design']=[]
for grade in (0,.01,.02,.03):
 for name, fraction, b in [('All vehicles braking',1,.8),('Accessible coach unbraked',1-cars[-1]/M,.8*(1-cars[-1]/M)),('One regular coach unbraked',1-cars[0]/M,.8*(1-cars[0]/M)),('One regular bogie unbraked, equal bogie allocation',1-cars[0]/(2*M),.8*(1-cars[0]/(2*M))),('Locomotive unbraked',1-loco/M,.8*(1-loco/M)),('Only locomotive braking at assumed adhesion0.15',loco/M,.15*G*loco/M)]:
  v=7.5*.44704;tau=3;ag=G*grade;v1=v+ag*tau;sd=v*tau+.5*ag*tau*tau;a=b-ag
  dist=sd+v1*v1/(2*a) if a>0 else None
  out['degraded_stopping' if grade==0 else 'degraded_stopping_off_design'].append(dict(study_status='PROJECT BASIS' if grade==0 else 'OFF-DESIGN SENSITIVITY ONLY',case=name,mass_kg=M,speed_mph=7.5,grade=grade,delay_s=tau,braked_weight_fraction=fraction,brake_specific_force_mps2=b,net_deceleration_mps2=a,total_distance_m=dist,total_distance_ft=dist/.3048 if dist is not None else None,assumption='No redistribution of failed unit torque to surviving brakes; adequate adhesion except locomotive-only explicitly limited; equal bogie load assumed for bogie case. No rotating inertia, buildup/slide/fade modeling.'))
out['formulae']={'downhill_accel':'ag=g*s, small slope approximation; no resistance credit','delay':'v1=v0+ag*tau; sd=v0*tau+0.5*ag*tau^2; delay includes perception, transmission and build-up as an equivalent zero-brake interval','stop':'b=B/M; a=b-ag; sb=v1^2/(2*a) if a>0; st=sd+sb','energy':'E=0.5*M*v0^2+M*ag*st = B*sb; translational only','continuous_heat':'P=M*g*s*v; no rolling resistance or engine-brake credit','adhesion':'B_available<=mu*g*M_braked; b_effective=min(b_command,mu*g*alpha)','holding':'F_hold=M*g*s before required factors and other loads','coupler':'For downhill positive travel, C_j=sum(B_trail)-M_trail*(d+g*s)=B_trail-M_trail*B_total/M; tension positive, compression negative. Uniform grade, no resistance, quasi-static rigid train','starting':'C_j=M_trail*(a+g*s+g*c_rr); rolling coefficient is analyst input, curve resistance excluded','pin_shear':'tau_avg=F/(n*pi*d_pin^2/4); double shear n=2 only for validated symmetric joint load-sharing','pin_bearing':'p_avg=F/(d_pin*t_loaded); outer clevis ears need actual shared loads and fit','pin_bending':'sigma_b=32*M_pin/(pi*d_pin^3); M_pin from contact/clearance model, not assumed zero','member':'sigma_axial=F/A; sigma_combined includes F*eccentricity/Z; compression must check local/global buckling, Euler pi^2*E*I/(K*L)^2 only ideal elastic screening','fatigue':'Use approved fatigue detail category/S-N data, stress range, mean stress, notch, corrosion and load-cycle spectrum; Miner sum(n_i/N_i) only if governing method permits'}
# numerical identities and expected trends, not validation of design.
for r in out['stopping']:
 assert abs(r['brake_energy_kJ']-r['brake_force_kN']*r['braking_distance_m'])<1e-6
 assert r['total_distance_m']>0 and r['net_deceleration_mps2']>0
assert len(out['coupling'])==4 and all(r['grade']==0 for r in out['coupling'])
assert len(out['degraded_stopping'])==6 and all(r['grade']==0 for r in out['degraded_stopping'])
assert all(r['continuous_grade_heat_kW']==0 for r in out['stopping'] if r['grade']==0)
out['internal_checks']=[f"{len(out['stopping'])} stopping cases generated",'Energy-work identity verified for every stopping row',f"{len(out['adhesion'])} adhesion combinations generated",'Coupling sums computed from explicit mass allocation; no dynamic-impact factors applied','Primary coupling and degraded-stopping rows all use owner-directed0% grade','Nominal level grade-heat component verified zero; service/stop heat retained']
(P/'brakes_couplings_calculations.json').write_text(json.dumps(out,indent=2))
if __name__ == '__main__': print(json.dumps({'stopping_rows':len(out['stopping']),'adhesion_rows':len(out['adhesion']),'key_stops':[r for r in out['stopping'] if r['mass_kg']==65000 and r['speed_mph']==7.5 and r['grade']==0 and r['delay_s']==3],'couplings':out['coupling'],'articulation':out['articulation']},indent=2))
