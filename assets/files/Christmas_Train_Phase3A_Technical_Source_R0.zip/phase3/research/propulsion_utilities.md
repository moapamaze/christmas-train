# Phase 3A — propulsion, HVAC and electrical definition

PF-TRAIN-S3A-R0 • 17 October 2026 • PRELIMINARY — NOT FOR FABRICATION OR CONSTRUCTION

## Recommended procurement boundary

Purchase a complete, supported locomotive/powered chassis from a railway vehicle integrator, with its controlled drivetrain, powered wheelsets, friction brakes and cooling package. Diesel-hydrostatic remains the leading study architecture; hotel generation remains separate. This preserves cabin space and avoids taking HVAC power from traction unexpectedly. The 14.5 t locomotive-and-hotel allocation includes generation and is **not verified adhesive mass**. Do not order individual drivetrain parts from this list. **Owner design basis: 0% longitudinal grade, with no intentional grades.** Survey must verify the as-built profile and the responsible engineer must set residual-grade and settlement tolerances; none is invented here. The former 1–3% cases remain off-design sensitivities only, not locomotive procurement requirements.

| Path | Practical consequence | Phase 3 disposition |
|---|---|---|
| Complete engineered diesel locomotive | Supplier owns tractive effort, cooling, controls, reversing and wheelset interfaces | Preferred; evaluate custom-coach mass, not advertised passengers |
| Used locomotive plus specialist rebuilding | Condition, braking, visibility, emissions, gearing and parts can dominate conversion | Alternate only after inspection and documented rebuild scope |
| New diesel-mechanical/powershift | Efficient geared operation; converter crawl heat, reversing duty and rail final drives require matching | Retain alternate; no approved transmission application yet |
| New diesel-hydrostatic | Good low-speed control and reversing; substantial heat rejection at low road speed | Leading architecture for integrator proposal |
| New diesel-electric | Controlled axle torque and flexible packaging; added high-voltage, inverter and cooling integration | Credible specialist alternative, not farm-crew electrical fabrication |

**Jupiter identification.** Severn Lamb's catalog JUPITER publishes 914 mm gauge, 160–320 passengers, up to four coaches, 1% maximum gradient, 50 m minimum radius and 16 km/h maximum speed; diesel/LPG and enclosed bodies are offered [PU01]. It publishes no mass, engine rating or tractive-effort curve on that page. These values do not rate our coaches. Western Train's separate Jupiter has 38-inch direct-drive wheels, tender power and air brakes, with a 24-inch photograph label [PU02]; its FAQ describes diesel/Eaton hydraulic propulsion and custom gauges including 36 inches [PU03]. Neither is a verified 36-inch offer for this consist. Severn Lamb's custom electric Dayton locomotive is a different engineered product, not a higher diesel-Jupiter rating [PU17].

## Governing level-track traction screening

Reproducible calculations: `calculate_propulsion_utilities.py` reads the frozen source within this Phase 3 package. `propulsion_utilities_calculations.json` separately identifies project level-track cases and retained off-design grade sensitivities. Assumptions: g=9.80665 m/s²; 7.5 mph=3.3528 m/s; rolling resistance=0.005 of weight; starting resistance=0.010. These are sensitivity inputs, not measured performance. Curve and wind resistance remain **unquantified and excluded**. Starting and steady-running requirements remain nonzero on level track. The 65-t whole-train sensitivity does not increase any coach/frame structural allowable.

F_run=M g×0.005; F_start=M g×0.010; acceleration adds M a; P_wheel=F_run v. The table omits acceleration. Engine screen=P_wheel/0.75+10 kW assumed traction auxiliaries; hotel generation is separate. Saved calculations also test 0.70/0.85 efficiencies, not guaranteed architecture performance.

| Mass t | Project grade | Run kN | Start kN | Wheel kW at 7.5 mph | Engine kW |
|---:|---:|---:|---:|---:|---:|
|55|0%|2.70|5.39|9.0|22.1|
|60|0%|2.94|5.88|9.9|23.2|
|65|0%|3.19|6.37|10.7|24.2|

**At 65 t on level track, starting requires 6.37 kN before acceleration and curves.** Adding the study acceleration of 0.10 m/s² raises the starting force to **12.87 kN**. Once rolling at that acceleration, force is 9.69 kN, wheel power at 7.5 mph is 32.48 kW, and the same engine allowance is 53.31 kW. Starting force at zero speed must not be confused with continuous power at travel speed. Acceleration is a screening assumption, not an approved passenger operating limit.

| Assumed adhesion coefficient | Driven mass for 65-t start, no acceleration | Driven mass for start plus 0.10 m/s² |
|---:|---:|---:|
|0.10|6.50 t|13.13 t|
|0.15|4.33 t|8.75 t|
|0.20|3.25 t|6.56 t|

The 14.5 t locomotive-and-hotel allocation is not measured driven mass: the generator, tender, nonpowered axles and fuel distribution may reduce adhesive weight. Level operation substantially reduces the traction requirement, but wheel loads, CG, contamination, starting on curves and braking still govern integration. Verify actual resistance and adhesion; do not automatically downsize the engine from this screening calculation. Gearing and wheel torque, auxiliary demand, cooling and transient power require supplier confirmation.

The saved 1–3% cases are retained **only as off-design sensitivity/history**. They do not define the planned railway or override the owner's zero-grade instruction. Any measured residual longitudinal grade must be compared with engineer-approved as-built tolerances and the integrated vehicle's verified performance. Drainage must be designed alongside the level track without silently introducing a track grade.

## Real components and matching limits

| Candidate | Documented evidence | Matching decision |
|---|---|---|
| Cummins F3.8 154 | 115 kW; peak 620 Nm at 1600 rpm [PU04]. Cummins rail guide lists 115 kW at 2200 and 2500 rpm for intermodal/maintenance use [PU05] | Investigate 2200-rpm calibration or a lower appropriate rating against level-track duty. Not a locomotive emissions/application approval. The 115-kW example is not a required or selected rating |
| Danfoss H1P060 + H1B080 | Pump 60.4 cc/rev, 3500 rpm rated, 420 bar maximum working; motor 16–80 cc, 1.27 Nm/bar theoretical, 3200 rpm rated at maximum displacement [PU06–07] | Real hydrostatic chain candidate; OEM to select controls, topology, reductions and duty. Independent brakes required |
| Allison 1000/2000 | Family published 154–272 kW and up to 950 Nm [PU08] | Family maxima do not select a model or establish rail duty. Application engineering, full reverse/crawl thermal data and exact rating required before adoption |
| Danfoss EM-PMI240-T180-4400 | Class F at 65°C coolant: 80 kW, 175 Nm continuous, 4400 rpm nominal; nominal 500 VAC, inverter supplied. Minimum coolant 20 L/min; derate above 65°C [PU09] | Published power exceeds the present level-track screen; actual low-speed torque, gearing and duty maps still govern. Two motors can distribute torque but do not double diesel power |
| Danfoss EC-C1200-450+MC180 | 150 kVA/180 A nominal; 750 VDC nominal link; liquid cooling up to 65°C, minimum 10 L/min [PU10] | Candidate motor controller; supplier must match actual bus, motor map and controls. Do not adopt MC350 peak claims: that version requires coolant ≤40°C |
| Gmeinder GGT190EHA/497 +190E/327 | Railway axle-gearbox reference, 12,150 Nm maximum input, 2720 rpm, ratios 4.97/3.27, for 760-mm locomotive [PU11] | Specialist capability reference only; not a 914-mm drop-in axle or selected ratio |

Hydrostatic example at 2200 rpm: H1P060 theoretical flow=132.88 L/min; at 420 bar, ideal hydraulic power=93.02 kW. Two 80-cc motors in parallel would each turn 830.5 rpm and develop theoretical 533.4 Nm before losses. This demonstrates a coherent scale, not continuous operating approval. Required reduction is F×wheel radius/(motor count×actual torque×gear efficiency); wheel diameter and actual efficiency remain hold points. The 420-bar value is the pump's maximum working limit, **not a prescribed setting**. Case drain, charge pressure, filtration, overspeed, torque limiting and measured cooler duty require manufacturer calculation.

A diesel-electric proposal needs diesel→matched generator/rectifier→protected DC link→inverters→motors→rail reductions. The motor datasheet alone does not supply that system. No generator/inverter/brake combination is represented as matched or available from stock.

## Thermal and hotel power definition

Retain 33 thermal occupants in each regular car and 14 in the accessible car; 7.5 L/s/person ventilation remains a **study assumption requiring an applicable basis**, not a code claim. Total outdoor air=0.8475 m³/s before doors. No ventilation reduction is used to make equipment fit. Summer 110°F outside/75°F inside; winter 30°F/68°F. Clear shell 7.7724×2.6416×2.2 m; glass 9 m²; opaque U=0.7, glass U=2.7 W/m²K; SHGC=0.5; glass incident solar=500 W/m²; additional roof sol-air=20 K. These are test inputs, not purchased material properties or local design-weather verification.

| Coach | Dry cooling incl. 15% kW | Humid stress incl. 15% kW | Winter loss before gains/warmup kW |
|---|---:|---:|---:|
| Regular, 33 people |16.96|22.70|8.74|
| Accessible, 14 people |10.49|13.28|5.10|
| Three regular + accessible |61.35|81.39|31.31|

Humid stress adds outside-minus-inside humidity ratio 0.006 kg/kg to **both ventilation and 0.03 m³/s per-car average door/leakage air**. Passenger total=120 W/person, including 45 W latent. Door-opening volume/time, North Pole dwell with doors open, duct pressure, window performance and thermal bridges need refinement. The station location does not block this work. Keep compressor input and thermal cooling distinct.

At assumed delivered COP 2.5 plus 3 kW other electrical demand, train running demand is 27.54 kW dry/35.56 kW humid; at COP 2.0 it becomes 33.68/43.69 kW. Four assumed 10-kW resistance heaters plus other loads need 43 kW. Actual fan power must not be double-counted; measured compressor starts/drive harmonics govern transient sizing.

Northwest Rail Electric NW-64-CN is a roughly five-ton condenser for rail/tourist applications [PU13]. Its nominal ~17.6 kW does not establish delivered high-ambient capacity; a matched evaporator/ventilation/heater package and regular-car humid capacity are unresolved. Konvekta HVAC 5401 publishes 16 kW at ta=ti=40°C, 7.2 kW heating, 400 VAC and 275 kg (240 kg optional) [PU12]. Neither rating condition matches 110°F/75°F. One 5401 is not demonstrated to satisfy the regular car, and 400V/60Hz compatibility is unverified. Obtain high-ambient sensible/latent output, compressor input/start data and current US configuration before selection.

Stadco 6-42T4F19 publishes 42/40/38 kW intermittent/prime/continuous at 240/480V three-phase, 60Hz; 6-80T4F19 gives 80/74/70 kW [PU14]. Reference conditions are 80°F and 500 ft; vendor derating is required. Published approximate envelopes/masses are 72×32×30 in/1790 lb and 103×36×32 in/3126 lb. The 42 model is marginal against humid/heat cases before derating; the 80 model warrants a site-rated offer. The proposed 50 model remains under development [PU15]. Keep the **40–70 kW delivered-continuous investigation envelope**; no generator is selected. Separate source and load step analysis follows manufacturer application guidance [PU16].

## Installation interfaces and release holds

E01 conceptual single-line: isolated shore inlet and diesel genset → mechanically/electrically interlocked break-before-make transfer → main isolation/protection → protected articulated trainline → each coach lockable disconnect → HVAC/heating, lighting and low-voltage chargers. Study 480V three-phase/60Hz; retain 240V alternative. No paralleling. Shore-connected interlock inhibits movement. Neutral switching and the one appropriate neutral-earth bond arrangement require the responsible engineer's source/earthing design; do not bond neutrals in every car. Dedicated protective-earth continuity bonds vehicles; couplers/rails are not protective conductors. Trainline connectors need dead-before-disconnect interlocks, environmental rating, strain relief and articulation checks.

Each coach has independent battery-backed emergency lighting, communications and specified essential controls. Preliminary energy formula: Ah=P×hours/(V×efficiency×usable discharge×end-of-life factor×temperature factor). An illustrative 150 W for 2 h at 24 V, 0.90 efficiency and three 0.80 factors gives 27.13 Ah. This is **not** a selected battery or mandated duration; brake/door energy, surge loads, chemistry and approved rescue time remain unresolved. Brake power/failure behavior must be defined independently of hotel AC.

Before wiring schedules: approve topology, available fault current, protective coordination, earth-fault behavior, cable length/ambient/grouping/flex duty, phase balance, voltage drop, connector rating, HVAC starting kVA, and manufacturer minimum circuit/maximum protection data. Do not guess breakers or wire sizes.

Before locomotive fabrication: supplier-certified tractive-effort/speed maps, powered axle loads, reductions, failure behavior, emissions application, fuel map and cooling/exhaust installation limits. Fuel capacity derives from actual duty consumption plus approved reserve; no guessed gallon tank. Radiator/oil-cooler intake and discharge must work at standstill in dust under the decorative shell; provide service withdrawal paths. Keep both diesel exhausts and heat away from occupied-air intakes and queues in stationary/reverse winds. Verify sound/vibration, aftertreatment heat, fire separation, condensate discharge and inspection access. Qualified vehicle/HVAC/electrical engineers and the integrator complete these designs; farm crew can fit approved finishes and supports after interface release.

Source register PU01–PU17, URLs, dates and limitations are in `propulsion_utilities.json`. All accessed 2026-10-17; no contacts, stock confirmation, quotations or orders made.
