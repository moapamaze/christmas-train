# Phase 3A — Track, stations and controlled delivery

PF-TRAIN-S3A-R0 · 17 October 2026 · Preliminary engineering definition — not for fabrication or construction.

## Direction and release boundary

Proceed with vehicle engineering now. North Pole location will be supplied later; no site alignment is selected here. Guests will disembark there, so both origin and North Pole need normal and accessible boarding, safe train holding and accessible routes beyond the vehicle. Ride experience and business projections are outside this work. The companion JSON contains the expanded survey specification, interface fields, purchase prerequisites, inspection records and responsibility matrix.

Adopt the owner's 0% longitudinal track grade as the design target. Survey and as-built measurements must verify the resulting local grades; acceptable deviations and maintenance limits remain for the track/vehicle engineers to set. Level rails do not mean flat drainage: formation crossfall, ditches, outlets and culverts need independent civil design. Retain 36-inch gauge for evaluation, four coaches, 400-inch coach frame envelopes and 30-inch inter-coach gaps as the shared study basis. Rail section, wheel profile, allowable radius, turnout geometry and tolerance limits are unreleased. A gauge label alone cannot match a locomotive, bogie, turnout and track. ASTM's public F2960 scope expressly recognizes the need to coordinate subsystem interfaces [TD04].

## Responsible authorities and standards

Clark County's current 2026 ARPM code applies to installations of 30 days or longer unless exempt; operating only 20 evenings does not establish an exemption. The Building Official determines classification. It calls for Nevada design-professional responsibility, reviewed documents, manufacturing quality assurance, inspections, commissioning and an approved on-site Qualified Individual [TD01]. Obtain a project-specific classification and standards/edition matrix before safety-critical procurement. County building-code adoption is a separate facility-design consideration [TD06].

The FRA policy's exceptions include operations below 24-inch gauge and off-system, insular tourist operations. An in-use public road crossing, in-use at-grade rail crossing, certain bridges, or another railroad within 30 feet defeats the stated insularity test. A 36-inch train is not automatically exempt [TD02]. NRS 455B separately addresses permanent public amusement facilities and operator safety duties [TD03].

Disembarking at a separately visited North Pole makes the service-description question more consequential; it does not itself determine classification. Under 49 CFR 37.37, primarily recreational conveyances and private transportation services follow different accessibility paths [TD07]. Finalize the applicable vehicle requirements with a qualified specialist. Both stations still require an accessible boarding interface; off-station rescue remains a separate system.

Also coordinate Comprehensive Planning on existing SUP/parcels and use changes; County Fire Prevention and Moapa Valley Fire District on plan-review/response roles, fuel and rescue; and Public Works/civil reviewers on drainage, crossings and off-site interfaces [TD11–14]. Existing farm approvals have not been established as covering this railway.

Current public ASTM scope pages were reviewed, not licensed full standards. F2960-23 addresses permanent amusement track; F3054-26 addresses railway operations. Their exclusions include FRA jurisdiction in whole or part [TD04–05]. These are proposed references pending agreed applicability, not a claim that every clause or edition is County-adopted. No construction tolerance has been copied from an unseen standard. Nevada responsible-charge/seal requirements also apply to professional documents [TD08].

## Survey specification to issue when the owner marks candidate areas

Ask a Nevada land surveyor for a boundary/control/topographic scope covering candidate corridors, station areas, storage/shop and drainage catchments. A screenshot or consumer GPS trail is useful for briefing, not construction setting-out. Deliver:

1. Parcel/APN and title/easement reference schedule; resolved boundary and right-of-way geometry; control monument descriptions and photographs.
2. Explicit horizontal reference frame/epoch, projection, vertical datum, units and ground-to-grid method. Distinguish international feet from legacy U.S. survey feet. Deliver point CSV, coded feature list, breaklines/TIN in LandXML or agreed equivalent, editable DWG/DXF, and signed PDF survey.
3. Ground shots and breaklines sufficient to model ditches, channel banks/beds, embankments, slopes, irrigation, walls, roads, crossings and abrupt changes. Include overhead obstructions, structures, fences, trees, culvert ends/inverts/sizes and visible utilities with confidence/source labels. Underground service locations require separate investigation before excavation.
4. A documented horizontal/vertical accuracy and closure report. Surveyor and track/civil engineer must agree accuracy, point density, corridor extents and supplemental checks before fieldwork; do not substitute an arbitrary grid for actual breaklines. Final track geometry needs a separate precision setting-out and as-built plan.
5. Civil/geotechnical follow-up: bearing/settlement, fill, expansive/collapsible soils, erosion, irrigation saturation, drainage/flood exposure, compaction criteria and material testing. Scope investigation to the selected corridors; no assumed ballast section or culvert capacity.

## Track–vehicle interface control

Issue a signed interface drawing/table connecting the vehicle engineer, track designer and suppliers. It must specify rail profile/material/hardness and cant; wheel diameter/profile, back-to-back and flange geometry; gauge measurement plane and limits; turnout check gauge/flangeways; actual wheel and axle loads; speed, twist and crosslevel limits; suspension travel and wear states; curves, transitions and vertical curvature; coupler yaw/pitch/roll and swept stairs/body/utility envelope. Include the maintenance rejection limits as well as new-build limits.

Use 0% longitudinal grade for the main traction and braking calculation; retain 1/2/3% only as off-design sensitivity. Continue 30/50/75 m curve-radius studies; none is released as permissible track. Require clothoid/other transition treatment, reverse-curve separation and any local crest/sag geometry to be engineered with the actual bogie/coupler system. A short tangent between opposing curves is not automatically sufficient. Local grade, settlement and construction variation must close traction, braking, parking and recovery checks together. Zero nominal grade does not eliminate parking brakes or rollback protection. New and worn wheels, empty/asymmetric/full load and adverse track geometry belong in the clearance/dynamics analysis.

Route selection can later compare a continuous loop, terminal loops and reversing operation against surveyed constraints. Vehicle work now must preserve reversing/recovery requirements. Do not select a push operation until locomotive visibility, braking, coupler buff loads and train-control procedures are supported.

## Station envelope without a location

Four study coach envelopes and three gaps occupy:

**L_coaches = 4 × 400 + 3 × 30 = 1,690 in = 140 ft 10 in (42.926 m).**

This excludes the locomotive, locomotive-to-coach gap, outer coupling projections and end stopping margins. A full train berth is `L_coaches + L_locomotive + G_locomotive + E_front + E_rear + any other projections not already included`. Freeze each endpoint definition before using it on a plan. A coach-only boarding platform follows actual door/step/lift positions plus stopping and circulation margins; it need not equal the whole train berth. Neither length is yet released.

Develop the same station-interface schedule for both stops: rail datum; empty/full floor and suspension levels; boarding side; door/step/lift deployment; permissible gaps; swept clearance; stop-position tolerance; drainage; route gradient/crossfall; guarding/gates; lighting; emergency access; departure interlock; brake holding and rollback prevention. Level or near-level boarding is the preferred study; final height depends on the vehicle. If amusement-ride criteria apply, Access Board section 1002 addresses loading gaps and alternatives, but it does not establish this project's classification [TD09]. A locomotive berth, passenger platform and accessible rescue area are different envelopes.

## Farm-crew work packages and pilot

Maximize trained crew participation after reviewed plans and inspection gates. Crew can manage traceability, receiving, approved earthwork, drainage placement, tie/ballast handling, instructed fastening, finish work and records. The responsible designer sets the geometry, materials, procedures and acceptance limits. Qualified crew may perform specialist work only when the required qualifications, equipment and inspection arrangement are actually demonstrated.

Start with a specialist-led, isolated pilot using the selected rail/tie/fastening system: surveyed tangent, transition/curve segment, representative joint and controlled ballast/drainage section. Include a turnout or crossing only if it is part of the released pilot purpose. Length and curve geometry follow the test objective and stopping/runout analysis; no default pilot dimensions are asserted. Keep it isolated from guests and other equipment. Measure geometry before loading, under the defined test load where required, and after loading/settlement. Record corrective work and repeat measurements before expanding production.

Rail bending requires the approved section-specific tool and procedure; measure curvature rather than forcing rail against spikes. JENNMAR lists a #3H-25 bender for 25–60-pound rail, but the page has inconsistent general descriptions; obtain model instructions and written profile compatibility before selection [TD10]. Confirm units, rail grade and minimum bend radius. Driver, tamper, rail drill/cutter, lifting equipment and a calibrated 36-inch gauge/crosslevel tool remain procurement items, not approved products. A laser/total station establishes line/elevation; a track gauge checks gauge/crosslevel; a chord/offset method checks curve shape. None replaces the others.

## Sequence and evidence for release

1. **Definition:** appoint responsible engineers/inspection agency; agree jurisdiction, standards, interface ownership and document control. Prepare information requests; do not send or order without owner instruction.
2. **Prototype release:** close wheel/rail, running gear, coupler, brake and structural drawings; approve calculations, materials, fabrication procedures, inspection/test plan and controlled deviations.
3. **First article:** mock up boarding/end platforms; manufacture one chassis/coach with traveler records. Verify materials, weld qualifications/NDT, dimensions, wheel loads, retention and accessible equipment. Release repeat fabrication only after its relevant results pass.
4. **Track release:** accepted survey, geotechnical/drainage design, permitted alignment and signed interface precede bulk materials and earthworks. Procure a matched rail/joint/fastening/tie/turnout package; used rail requires condition and provenance acceptance.
5. **Integration:** geometry/as-built inspection, static load and clearance checks, instrumented speed/brake/holding tests, curves/twist, control faults, breakaway and no-power recovery. Use secured ballast/manikins before passengers. Engineers set loads, limits, instruments and safe fault-injection method.
6. **Commissioning:** closed defects, approved manuals, trained staff, demonstrated accessible boarding/evacuation at both stops and worst rescue location, authority/insurer acceptance and required permits/certificates. A supplier's shop test does not release the completed railway.

The JSON matrix identifies each test's evidence and release owner. Final forces, welds, pin sizes, ballast/tie dimensions, rail-joint details, temperatures, tolerances and test acceptance thresholds remain explicitly held for the responsible professionals and OEMs.

Sources TD01–TD14: see `track_delivery.json`, all accessed 17 October 2026. No outreach, orders or permit submissions performed.
