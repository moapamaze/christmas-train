# Phase 3A — Frame, bogie and wheelset engineering definition

PF-TRAIN-S3A-R0 • 17 October 2026 • Preliminary; not for fabrication or construction.

## 1. Recommended architecture and dimensional conflict

Retain two two-axle bogies per coach as the development arrangement. Prefer an engineered, supplier-supported running-gear package with wheelsets, bearings, suspension, brakes and body attachment interfaces specified together. Farm fabrication of unproven wheelsets or bogies is not the starting recommendation. Matching 36-inch gauge establishes only one interface.

Use a welded steel underframe with two continuous longitudinal load paths, transverse bolsters at x=45 and 261 inches, end crossmembers, and framed coupling attachment boxes connected into both longitudinal members. Member sections, spacing, steel grade, plate thickness, fasteners and welds are **held**, not selected. Crossmembers carry the floor, seat anchors and outboard wall supports. End-platform, stair and lift reactions enter reinforced frame nodes. Cladding and decorative trim carry no credited primary loads. A stressed-skin body could reduce underframe mass, but only after analysis includes door/window openings, fatigue, joint stiffness and corrosion; do not quietly credit it in the present chassis calculation.

The 400-inch frame extends from x=-47 to 353; the 312-inch cabin from -3 to 309. Each cabin end overhangs its adjacent bogie centre by 48 inches, and each frame tip by 92 inches. The 44-inch platforms therefore create substantial cantilevers. Coupler loads act through the end-frame structure rather than floor sheet or platform trim.

**The previous 3-inch frame-depth graphic is unengineered.** A 216-inch bogie spacing gives span/depth=72 before accounting for openings and connection details. This ratio is a warning, not proof of failure. Expect to redesign the depth/load path; preserve the 28-inch floor height only if the complete wheel, suspension travel, bolster, frame and floor stack fits. Raising the floor changes stairs, accessible boarding, CG and roof clearances. The CAD envelope must remain adjustable until that stack is resolved.

## 2. Static load ledger and cantilever coefficients

Mass allocations come from the shared design basis, not measured vehicles. A local crew allowance of one person per coach is retained for structural screening; it is not an operating staffing decision. Accessible totals include two wheelchair occupants within the 13 guests, one crew member, and 300 kg total mobility devices.

| Coach / person mass | Gross kg | Weight kN | Balanced bogie kg-equivalent | Balanced axle kg-equivalent |
|---|---:|---:|---:|---:|
| Regular / 100 kg | 10,340 | 101.40 | 5,170 | 2,585 |
| Regular / 145 kg | 11,825 | 115.96 | 5,912.5 | 2,956.25 |
| Accessible / 100 kg | 9,235 | 90.56 | 4,617.5 | 2,308.75 |
| Accessible / 145 kg | 9,865 | 96.74 | 4,932.5 | 2,466.25 |

These are equilibrium averages with symmetric tare and payload, **not ratings**. No dynamic factor has been assigned. Equipment, roof HVAC, lift, wheelchair bays, tanks and end-platform loads require individual coordinates. Bogie self-mass is included in the tare allocations: subtract actual bogie mass before distributing body loads onto the frame; add it back when checking rail loads.

For items of mass m at x inches, total front-bogie reaction is Σm(261−x)/216 kg-equivalent; rear reaction is total mass minus front. Multiply kg-equivalent by 9.80665 for newtons. As an adverse disembarking sensitivity, moving the regular coach's 33 people to a front-half centroid x=76.5 gives front/rear reactions of **6,338.75/4,001.25 kg** nominal, or **7,607.19/4,217.81 kg** at 145 kg/person. This is redistribution of the same passenger load, not added occupancy. It is not a permitted riding arrangement. Even equal sharing between that front bogie's axles would be 3,803.59 kg/axle in the stress case; actual sharing also depends on braking torque, suspension and twist. A catalogue selection using only gross/4 is inadequate.

Useful linear coefficients for the frame engineer:

- A 1 kN downward load at frame tip x=-47 produces +1.426 kN front reaction, −0.426 kN rear reaction and 2.337 kNm hogging at the front bogie. Rear-tip results mirror these.
- A 1 kN load at cabin edge x=-3 produces 1.219 kNm cantilever moment at the front bogie.
- A 1 kN/m uniform line load over the complete 312-inch cabin produces 3.019 kNm midspan sagging and 0.743 kNm support hogging in the ideal symmetric beam model.

Apply the approved platform crowd, stair, handrail and deployed lift reactions to the correct locations. These coefficients do not establish their required design loads. Deflection, local deck strength, lateral torsional buckling, crossmember twist and bracket prying require separate checks.

## 3. Required combined load cases

The vehicle engineer must issue a load-case schedule and numerical factors before member design. Candidate standards are design-method references, not a declaration that European mainline standards govern this Nevada attraction. NEN's published scopes identify EN 12663-1 body structural analysis/testing and EN 13749 bogie verification/manufacturing quality; full texts and project applicability remain to be reviewed [FR07–08].

| Case | Loads and combinations to resolve | Principal checks |
|---|---|---|
| V1/V2 | Tare, full nominal/stress payload, equipment at actual locations | Global bending, seat/floor anchors, individual wheel loads |
| V3 | Partial seating, passengers concentrated at one end/side, wheelchair/lift positions | Unequal reactions, lateral CG, loading stability |
| L1/L2 | Traction and braking with vertical load; both coupling tension and compression | Sill and draft-box stress, bolster/pivot force, local buckling |
| L3 | Reversing, slack run-in/run-out and emergency brake imbalance | Transient longitudinal forces; compression stability |
| C1 | Curve lateral acceleration, cant/crosslevel, wind, offset occupancy | Roll, wheel unloading, lateral rail force and retention |
| T1 | Diagonal track twist combined with vertical and lateral load | Suspension equalization, frame torsion, lowest wheel load |
| P1 | Stationary stairs/platform crowd, lift deployed and eccentric | Cantilever bending, local torsion, vehicle restraint |
| M1 | Jacking, lifting, rerailing and towing with designated points | Local reinforcement, restraint, permissible support sequence |
| F1 | Repeated joint impacts, braking, curves, loading and corrosion allowances | Fatigue hot spots and inspection access |

Do not add the entire train's coupling force to every axle, or omit it from the body frame. Coupling forces pass through longitudinal members; wheel braking reactions enter through brake mounts and bogie-to-body connections. Use the braking/coupling analysis to determine the force at each connection. A 65-ton train screen does not define each coach's design mass.

## 4. Gauge, CG and curve compatibility

The 110-inch exterior width is 3.06 times the 36-inch gauge. Width alone does not establish stability. A complete model must resolve sprung/unsprung mass, suspension roll centre and stiffness, damping, side-bearing geometry, wheel/rail forces, wind and track crosslevel. Do not claim a rigid tipping calculation proves derailment safety.

For a transparent sensitivity, place 16 stress-mass passengers on the eight benches on one side, with one centred crew member and symmetric 7,040 kg tare. Total mass is 9,505 kg; seat centres y=32 inches give transverse CG offset e=0.1984 m. At 7.5 mph on a 30 m radius, v²/(Rg)=0.03821. With assumed CG height h=1.5 m and 0.9144 m support-spacing proxy, rigid inner-side weight fraction is 0.5−(e+h·a/g)/s=**0.2204**, versus 0.5 for centred stationary loading. At h=1.2/1.8 m it is 0.2329/0.2078. These are side totals, not individual-wheel predictions. Actual contact spacing differs from gauge; suspension, adverse cant, wind and twist are omitted. No acceptance threshold or safe speed is inferred. This demonstrates why partial loads and one-sided boarding deserve explicit assessment.

Using the 216-inch bogie centres, rigid body centre-chord offsets are 126, 75 and 50 mm for 30, 50 and 75 m radii. A 400×110-inch rectangular envelope then reaches approximately **1.681/1.572/1.516 m outside track centre** and **1.523/1.472/1.447 m inside**, respectively. These are preliminary geometric envelopes excluding stairs, deflection, tolerances, reverse curves and transition effects. Wheelbase, yaw stops and bogie sweep remain unknown; therefore no minimum curve radius is approved. Severn Lamb's identified Jupiter publishes 914 mm gauge and 50 m radius, but those figures describe its train, not this chassis [FR02].

## 5. Materials and real supply routes

The preferred steel underframe with light aluminium body/framing is an engineering development choice for repairability and separation of heavy train forces from the cabin. It is not a claim that steel is always lighter or cheaper. An all-aluminium underframe is a valid competing engineered proposal. Compare completed structure mass, stiffness, fatigue life, joints, corrosion protection and fabrication capability, not density alone.

Hydro documents 6005A extrusions for rail components, density 0.098 lb/in³, and temper/thickness-dependent properties; direct dissimilar-metal contact can cause galvanic corrosion [FR05]. These are supplier material data, not welded-member allowable stresses. Aluminium Association guidance explicitly treats weld-affected strengths and quality control [FR06]. Isolate aluminium/steel interfaces, retain engineered bonding paths for electrical safety, drain trapped water and provide replaceable exterior panels. Material grade, temper, weld procedure and heat-affected-zone design remain unresolved.

| Candidate | Verified primary-source evidence | Procurement limitation |
|---|---|---|
| Alan Keef | Current manufacturer describes passenger carriages, proprietary bogies and bespoke narrow-gauge work; 2024 weather-protected coach project included accessible provision [FR01] | No public rating/outline for this 914.4 mm, roughly 12 t coach; obtain a specific integrated proposal |
| Severn Lamb Jupiter | Manufacturer lists 914 mm gauge, 50 m minimum radius, 1% maximum gradient, enclosed option [FR02] | Whole-train reference; standalone truck availability and our weight/CG compatibility unverified |
| GHH-BONATRANS | Manufacturer designs wheelsets for customer bogie, brake and drive interfaces; provides calculation/test-backed development [FR03] | Exact gauge, wheel/axle design, order quantity, lead time and price unknown |
| Schaeffler FAG | Railway axleboxes and factory-sealed/greased TAROL/cylindrical units; application-specific housing and bearing validation [FR04] | No selected bearing part number or C/C0 rating; supplier must select for actual radial/axial duty, seals and temperature |

Public pages checked 17 October 2026 establish capabilities, not stock availability, a quotation or approval. Buying engineered running gear reduces integration risk but does not transfer responsibility for the coach/frame/track system. Fabricating bogies requires the same design evidence plus qualified manufacture and prototype verification; apparent simplicity is not an exemption.

## 6. Supplier qualification, assembly and release gates

A running-gear proposal must return a dimensioned interface drawing and load schedule covering: exact gauge and tolerances; wheel diameter/new-worn profile; wheelset back-to-back; flange thickness/height and root radius; rail-head match, cant and turnout/check-rail interfaces; axle fatigue calculations and material traceability; bearing selection/life, axial retention and seals; allowable static/dynamic vertical, lateral, longitudinal and roll loads; suspension load/deflection, bump/rebound travel, equalization and damping; bogie wheelbase and full yaw/pitch/roll envelope; brake mounting/thermal limits; bolster/centre-bearing/side-bearing interfaces; positive body retention, jacking/rerailing, inspection and replacement limits. Require unloaded and loaded wheel-load predictions and a permitted CG envelope. Obtain separate static, fatigue and exceptional-load definitions rather than a single ambiguous “ton” capacity.

The track and vehicle engineers jointly own the wheel/rail interface. Freeze neither profile nor turnout geometry until both sign the same controlled drawing. Route grade, radius, reverse-curve spacing, vertical transitions, crosslevel/twist tolerances and operating speed are required before final running-gear acceptance, even though the North Pole location can be supplied later.

Proposed execution sequence, subject to reviewed drawings:

1. Agree design basis, responsibility split and verification plan; approve load cases and choose the running-gear route.
2. Receive supplier CAD and mass/CG data; solve floor-height and suspension packaging; complete frame stress, fatigue, deflection and connection calculations.
3. Release fabrication drawings, material schedule, welding procedures, tolerances and inspection plan. Fabricate a frame on a surveyed fixture with accessible reference datums.
4. Inspect materials and fit-up before closing boxes; control weld sequence and distortion; perform specified weld examination; measure bolster coplanarity and diagonals before coating.
5. Install complete supplier wheelsets/bearings/brakes without unapproved machining or welding. Record assembly torque/retention, profile and back-to-back measurements; fit body and equipment.
6. Weigh every wheel empty and with controlled test loads; establish CG, clearances, suspension travel and loading reactions. Conduct engineer-approved static proof, twist, curve, brake and retention tests before passenger commissioning.

Farm crew can prepare fixtures, handle approved finishing and install noncritical trim under the issued work instructions. Specialist responsibility includes frame engineering, primary structural welding/examination, wheelset press fits, axle/bearing assembly, brake integration and acceptance testing. No pin diameters, member sizes, weld sizes or numerical fabrication tolerances are released by this report.

## Primary-source register

All links accessed 17 October 2026; verification limits are recorded in frames.json. Public standards scopes are not a substitute for full standards review.

- **FR01** [Alan Keef — Leisure, Park & Farm; Lappa Valley / Pairi Daiza case studies](https://www.alankeef.co.uk/services/leisure-park-farm).
- **FR02** [Severn Lamb — Jupiter manufacturer technical table](https://www.severn-lamb.com/people-movers/tracked-trains/rail-trains/jupiter-2).
- **FR03** [GHH-BONATRANS — Wheelsets and Design of new products](https://bonatrans.com/en/research-and-development/design-of-new-products/).
- **FR04** [Schaeffler FAG — Axlebox Bearings for Passenger Cars & Locomotives](https://www.schaeffler.us/us/products-and-solutions/industrial/industry_solutions/rail/axlebox_bearings_passenger_cars_locomotives/).
- **FR05** [Hydro — Alloy6005A data sheet, revision2019/02](https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6005a_revise_1.pdf).
- **FR06** [Aluminum Association — Aluminum Design Manual2020 and Welding Aluminum](https://www.aluminum.org/news/aluminum-association-releases-2020-edition-aluminum-design-manual).
- **FR07** [NEN-EN12663-1:2010+A2:2023 — Railway vehicle body structural requirements](https://www.nen.nl/en/nen-en-12663-1-2010-a2-2023-en-318525).
- **FR08** [NEN-EN13749:2021+A1:2023 — Bogie frame structural requirements](https://www.nen.nl/en/nen-en-13749-2021-a1-2023-en-318518).
- **FR09** [EVS-EN14363:2016+A2:2022 — Running behaviour and stationary tests](https://www.evs.ee/en/evs-en-14363-2016-a2-2022-consolidated).
