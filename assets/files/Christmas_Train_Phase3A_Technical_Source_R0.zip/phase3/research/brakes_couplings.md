# Phase 3A — Brakes and inter-car connections

Revision PF-TRAIN-S3A-R0 • 17 October 2026 • Preliminary engineering definition. **Not for fabrication, construction, passenger operation or procurement release.**

**Owner update:** track is to be laid at **0% longitudinal grade**. This is the governing project basis. The retained 1/2/3% cases are off-design sensitivities only; they are not route requirements. Final as-built profile and acceptance tolerance remain an engineering hold.

## 1. Recommendation and evidence

Retain the owner's hydraulic service-brake preference. Develop a distributed railway hydraulic system with brakes on every vehicle, a separately justified emergency function, and mechanically sustained parking on each coach. Advance it alongside a conventional automatic-air alternative until an experienced rail-brake integrator accepts responsibility for the complete system. A spring-applied caliper is a component; its presence does not establish a fail-safe train.

Hydraulic rail equipment is real, rather than an automotive improvisation. Knorr-Bremse lists HydroAct HC1P50 spring-actuated calipers with two hydraulic release circuits, force up to 100 kN per disc, 100 mm maximum disc width and approximately 60 kg without bracket. Its smaller HSC1P10N listing gives 20 kN, 45 mm disc width and 15 kg. These are manufacturer-listed examples, not selected components; the exact meaning of force, torque conversion, release pressure, friction pairing and operating duty require a controlled application drawing. [BC01]

Knorr-Bremse HydroControl Smart type u3HU is a railway hydraulic supply/control family for pressure- or spring-actuated calipers, listed at 0–100 bar; its accumulator configuration can support wheel-slide protection. HydroControl Basic HGK is a different variant without an accumulator. Neither establishes the complete architecture needed here. [BC02]

An industrial comparison shows why a rating alone is insufficient. Twiflex DS2610 lists GMXSH/XSH 7.5 at 11.2 kN **tangential disc force**, 65 bar minimum full-retraction pressure and 120 bar maximum pressure; its 13.62 kg caliper/thruster listing and force assume conditioned pads at nominal friction 0.4. The associated GMX family requires at least a 610 mm disc diameter. Packaging, mounting and rail-vehicle qualification remain unproved; do not order it for these coaches. The manufacturer-hosted sheet is dated 11/11, so a current controlled drawing is needed. [BC03, BC04]

Prefer an engineered railway drawbar between seldom-separated coaches, with a compatible detachable locomotive interface. Dellner's People Mover semi-permanent assembly uses a central double-acting damper, pivot anchor and cable support; its public page does not supply a rating or dimensions. Its brochure illustrates socket joints, draft gear and central connections. Voith's 430/530 railway coupling family is advertised up to 300 kN in tension and compression, while semi-permanent configurations can incorporate energy absorption. These establish actual railway principles, not small-train fit, price, lead time or attachment adequacy. [BC05–BC07]

## 2. Architecture for engineering development

**H1, preferred investigation:** each coach receives local hydraulic power/control equipment, separately isolated service zones for front and rear bogies, and a separately validated spring-applied/hydraulically released emergency/parking path. Local brake energy and control must permit a detached coach to brake and hold without the locomotive. The final design may use integrated railway actuators, but shared discs, brackets, fluid, electronics and release circuits are common-cause items that must be accounted for. No specific valve manifold is selected.

Driver service demand is distributed to local regulators; local pressure and actuator-state feedback return to a train brake controller. Brake-force balance must address empty, full, asymmetric and mobility-device loading, not merely equal pressure on every car. A monitored hardwired emergency continuity function is separate from the routine command/data bus. Driver/crew emergency controls, breakaway detection and defined power faults demand a local emergency response. Stored springs supply application energy only if release pressure can escape and the mechanism remains operable. Trapped pressure, a blocked return or a stuck valve can defeat that intention.

Traction permission requires the defined doors/gates and boarding equipment secured, emergency circuit healthy, parking/emergency release confirmed, and valid brake-system status. A stop indication alone does not prove brake holding. Releasing an emergency demand requires a deliberate reset and checks; restoration of power must not cause automatic movement. Manual auxiliary release requires positive vehicle securing, a recorded isolation state and traction lockout until reinstatement. Interlocks must not prevent required emergency egress.

**A1, comparison:** automatic railway air service/emergency with a continuous brake pipe, local reservoirs/distributors, suitable actuators, and independent mechanical/spring parking. Wabtec's emergency valve vents the brake pipe to initiate quick action; its 26C controls brake-pipe pressure, and rail distributors translate this into local brake action. [BC08] This alternative has an established separation-response principle and may integrate more readily with a purchased locomotive. It adds compressor/dryer/reservoir installation and demands demonstrated propagation, recharge and leakage performance. Air pressure alone cannot be credited indefinitely for parking.

**Reject as the sole system:** one automotive-style master cylinder and long interconnected hydraulic line, locomotive-only brakes, an ordinary trailer surge brake, or emergency braking dependent solely on a consumer wireless link. These do not provide the documented car-level fault containment needed for this design. This is a project engineering decision, not a claim that a particular statute bans every such device.

## 3. Fault matrix and proof obligations

| Event | Required response to develop | Verification before acceptance |
|---|---|---|
| Normal service request | Coordinated proportional braking on all cars; monitor response and traction removal | Empty/full/in-between loads; application and release times at each bogie |
| Driver emergency or crew emergency | Traction removed; validated emergency application throughout train | Every initiating control, worst voltage/temperature and maximum load |
| Loss of locomotive or hotel power | Local emergency response and sustained parking remain available | Cut each source separately; show no shared-power single failure defeats braking |
| Loss of local controller power | Defined local application and train fault indication | De-energize one car; verify resulting stop and coupler loads |
| Service hose rupture | Contain loss to defined zone; remaining service/emergency path responds | Controlled fault injection, fluid-loss and pressure-decay measurements |
| Release hose rupture/low release pressure | Spring force may apply; prevent uncontrolled lock-up or unequal braking | Measured torque buildup and wheel-slide behavior; cold/hot/worn parts |
| Blocked return or trapped release pressure | Detect failure to apply; alternate validated path must stop train | Stuck-valve/blockage analysis and representative bench fault tests |
| Routine bus loss/stale command | Time-bounded safe response; independent emergency function remains | Broken wires, frozen outputs and invalid messages |
| Emergency loop open, short or cross-feed | Detect intended fault set; absence of an open circuit alone is insufficient | Open/short/cross-feed tests; common-cause review |
| Coupling separation | Detached portion brakes and holds locally; locomotive also reacts | Controlled separation simulation, no passengers; prove connector sequence |
| One car or bogie unbraked | Detect; meet approved degraded stopping condition or prohibit operation | Residual stopping, adhesion and longitudinal-load analysis |
| Brake seized on/pressure sensor misleading | Detect drag/overheat or inconsistent feedback; controlled stop | Fault tests independent of one pressure indication |
| Manual release left active | Departure inhibited and conspicuous isolation indication | Recovery/towing procedure and restoration check |
| Parking and securing | Each detached vehicle holds under approved load, actual profile and environment | Independent hold test, endurance/leakage observations, securing procedure |

The table states requirements to prove, not demonstrated responses. Per-car independence must include connectors, power protection, fluid isolation, valve states and software/common wiring failures. A brake integrator must assign failure rates, diagnostic coverage, redundancy and acceptance criteria using the agreed governing standard. Farm crew should not prototype safety control logic.

## 4. Level-track stopping, adhesion and heat screening

The governing longitudinal grade is **0%**, per the owner's latest direction. The saved model retains 96 combinations across 55/60/65 tonnes, 5/7.5 mph, 1.5/3 s equivalent delay and service/emergency specific brake forces **0.50/0.80 m/s²**. Its 24 zero-grade cases are project-basis screens; the other 72 at 1/2/3% are off-design sensitivities. Delays and specific forces are analyst inputs, not standards, demonstrated performance or approved passenger decelerations.

Brake force B = M b. On level track, v1 = v, delay travel = vt, braking travel = v²/(2b), and total stop is their sum. In the retained nonzero-grade model, v1 = v + gst, delay travel = vt + gst²/2 and braking travel = v1²/[2(b − gs)], with g = 9.80665 m/s². This preserves gravity acceleration during delay. Here b means force per mass **before grade**, differing from the previous Stage 2 net-deceleration target. At the new zero-grade basis those values coincide. Off-design downhill comparisons require normalized assumptions.

No rolling-resistance or engine-braking credit is taken. Rotating inertia, jerk, brake buildup shape, fade, wheel-slide cycles and curves remain to be added. These translational results are **not a conservative upper bound**. The as-built longitudinal profile must be surveyed; the responsible engineer must set acceptable deviations and their treatment. No numerical grade tolerance is invented.

| Speed | Downgrade | Service stop, 3 s delay | Emergency stop, 3 s delay |
|---|---:|---:|---:|
| 5 mph | 0% | 11.7 m / 38.4 ft | 9.8 m / 32.2 ft |
| 7.5 mph | 0% | 21.3 m / 69.9 ft | 17.1 m / 56.1 ft |

Distances are mass-independent only because the assumed brake force scales directly with mass. At 55/60/65 tonnes, assumed service forces are 27.5/30.0/32.5 kN; emergency forces are 44/48/52 kN. Fixed hardware torque does not behave this way.

At **65 tonnes, 7.5 mph and 0% grade**, both ideal stops dissipate **0.365 MJ** of initial translational kinetic energy. The gravity-related continuous heat component is **zero**. Repeated-stop frequency, rotor/pad limits, hot starts, cooling and any dragging brake still govern thermal design. Manufacturer guidance distinguishes holding, dynamic and continuous duty. [BC09] The retained 3% cases previously produced 1.416/0.922 MJ per service/emergency stop and 64.1 kW continuous descent heat; these are explicitly **off-design examples, not project equipment loads**.

The following level-track emergency-command screens retain 65 t, 7.5 mph and 3 s delay. Failed-unit torque is not redistributed; unaffected brakes retain b = 0.80 for their own allocated mass. Adequate adhesion is assumed except the locomotive-only row, which explicitly limits force by assumed μ = 0.15. These are fault-study outputs, not permission to operate with a defect.

| Level-track case | Total stopping distance |
|---|---:|
| All vehicles braking | 17.08 m / 56.1 ft |
| Accessible coach unbraked | 18.51 m / 60.7 ft |
| One regular coach unbraked | 18.87 m / 61.9 ft |
| One regular bogie unbraked, equal bogie allocation | 17.88 m / 58.6 ft |
| Locomotive unbraked | 19.10 m / 62.7 ft |
| Only locomotive braking at assumed adhesion0.15 | 27.19 m / 89.2 ft |

Wheel/rail adhesion bounds B by μgM_braked. Fully braked weight requires ideal μ of 0.0510 for b = 0.50 and 0.0816 for b = 0.80. The 60-case adhesion matrix uses assumed μ = 0.03/0.05/0.08/0.10/0.15 and braked-weight fraction = 1/0.75/0.25, with nonzero grades marked off-design. None is a measured site value. At level grade and all weight braked, assumed μ = 0.03 increases the emergency-command stop to about 29.2 m. It is an adhesion upper-bound screen assuming sufficient surviving hardware torque, distinct from the no-redistribution fault table. More clamp force cannot cure insufficient adhesion. Establish contamination controls, slide protection/sanding suitability and operating restrictions from tests.

At exactly zero nominal grade the gravity holding term is zero; **parking is still required on every detached vehicle**. Wind, inadvertent movement, actual residual grade, uneven wheel loads and securing margins remain to be evaluated. The retained 3% static figures (19.12 kN train, 3.87 kN regular coach, 3.23 kN accessible coach) are off-design sensitivities only. For brake sizing, convert wheel force to axle torque using actual loaded wheel radius and then disc torque using the caliper's friction definition; do not confuse clamp force with tangential force. Include equivalent rotational mass ΣI/r² in dynamic deceleration.

## 5. Connection loads and articulation

For the 65 t upper screen, assume 14.5 t locomotive and 50.5 t coaches distributed proportionally to existing stress coach allocations. These are calculation allocations, not a weighed consist. The governing **level-track** coupling launch screen uses 0.15 m/s² acceleration and analyst resistance coefficient 0.005. This differs deliberately from the propulsion launch study's 0.10 m/s² and 0.010 coefficient: they are distinct preliminary load cases, **not a unified design envelope**. The responsible engineer must reconcile the full resistance, acceleration and transient load combinations. Curve resistance is absent here.

| Joint | Trailing mass | Level start tension / reverse push compression | Loco-only braking compression* | Rear car unbraked compression** |
|---|---:|---:|---:|---:|
| Loco-R1 | 50.50 t | 10.05 kN | 16.57 kN | 1.96 kN |
| R1-R2 | 37.33 t | 7.43 kN | 12.25 kN | 3.74 kN |
| R2-R3 | 24.16 t | 4.81 kN | 7.93 kN | 5.52 kN |
| R3-Accessible | 10.99 t | 2.19 kN | 3.61 kN | 7.30 kN |

The reverse-push figures assume the same quasi-static acceleration and resistance magnitudes while the locomotive pushes the consist; they are not dynamic buff ratings. *Locomotive braking is limited by assumed μ = 0.15 on 14.5 t; this is a failure study. **Other vehicles apply b = 0.80; rear coach contributes zero. On uniform grade, joint tension C = B_trailing − M_trailing B_total/M_total; negative C is compression. This ideal brake-imbalance force is grade-independent because common gravity acceleration cancels. It excludes differential grades, curve resistance and buildup. Perfectly mass-proportional braking gives zero quasi-static joint force, not zero transient force. Coaches braking with an unbraked locomotive give 9.01 kN head-joint tension. Nonzero-grade launch cases remain in a separately labeled off-design array.

These forces **must not become coupler design ratings**. Engineer separately sets buff/impact, reversing, collision, fatigue, rescue towing, vertical/lateral and proof loads; integrates draft-gear stroke; and evaluates compressive-force derailment on curves. A generic multiplication factor cannot replace that assessment.

Retain 30 in end-platform gap, 14 in pin setbacks and 58 in pin-center spacing only as sensitivity geometry. A 430 in equal-car center spacing gives approximate adjacent yaw 20.86°/12.52°/8.34° on 30/50/75 m same-radius curves; equal joint articulation is roughly half. This arc-spacing approximation does not cover reverse curves, turnout transitions, different locomotive geometry, vertical curves, suspension travel or twist. Perform an exact multibody swept-volume check with stops, wear, pin clearances, hoses, cables, stairs, guards and removable inspection covers. A single vertical pin alone does not supply all required pitch/roll freedom.

## 6. Detail release and inspection

The conceptual connection consists of a load-spreading frame anchor/draft gear, replaceable articulated bearing, retained pin/joint assembly, rail drawbar and the mirrored adjacent-car assembly. Provide positive primary retention and an independently reviewed secondary-retention concept; do not assume an ordinary safety chain will restrain a train or prevent derailment. No passenger passage across the coupler is approved.

For eventual pin engineering, average shear is F/(nπd²/4), projected bearing is F/(dt), and bending stress is 32M_pin/(πd³). Double shear requires verified load sharing; pin bending comes from actual contact widths and gaps. Check clevis net section, tear-out, prying, bearing fit, fretting, lubrication, retaining-device loads and corrosion. Drawbar checks include axial stress, eccentric bending, local/global buckling and approved fatigue assessment. Weld sizes, material grades, heat treatment, tolerances, pin diameter and plate thickness remain **HELD** pending calculations and controlled supplier data.

Release sequence: approve requirements and load cases; obtain interface/control drawings and duty ratings; complete failure analysis and independent review; build instrumented bench assemblies; test articulation and hydraulic faults; inspect traceable fabrication; conduct secured empty-vehicle trials, staged ballast tests and approved maximum-load stopping/holding tests. Record wheel loads, pressures, speeds, deceleration, coupler force, rotor temperatures and fault indications. Passenger service follows documented acceptance by the responsible professionals and authorities. Farm crew may maintain approved access/cleanliness and record inspections after training; safety-critical fabrication, hydraulic commissioning and acceptance require specialists.

## Primary-source register

All accessed 2026-10-17. Published web listings do not confirm availability, compatibility or a quote.

- BC01 — Knorr-Bremse, [Rail vehicle actuators / HydroAct](https://rail.knorr-bremse.com/en/us/portfolio/products-and-systems/braking-systems/actuation/). Product page, undated.
- BC02 — Knorr-Bremse, [HydroControl](https://rail.knorr-bremse.com/en/hk/portfolio/products-and-systems/braking-systems/control/hydraulic-control/). Product page, undated.
- BC03 — Twiflex, [GMXSH DS2610](https://www.twiflex.com/-/media/project/altramotion/shared/files/literature/brand/twiflex-limited/related/product-sheets/gmx-series/ds2610.pdf?rev=939e126f1f99407e92ae8f3d35e7ab0b). Manufacturer-hosted sheet, dated 11/11.
- BC04 — Twiflex, [GMX series](https://www.twiflex.com/products/disc-braking-systems/direct-acting-calipers/gmx-series). Product page, undated.
- BC05 — Dellner, [People Mover semi-permanent coupler](https://www.dellner.com/products/semi-permanent-couplers/semi-permanent-coupler-people-mover). Product page, undated.
- BC06 — Dellner, [2022 product brochure](https://dellner.com/wp-content/uploads/2022/08/DellnerBrochure2022_ENG_v1-1.pdf), PDF p.19, printed pp.38–39.
- BC07 — Voith, [Railway couplers and connections](https://www.voith.com/corp-en/connection-components-couplings/railway-couplers.html). Product page, undated.
- BC08 — Wabtec, [Emergency Brake Valve](https://www.wabteccorp.com/locomotive/braking-systems/pneumatic-controls/emergency-brake-valve). Product page, undated.
- BC09 — Twiflex, [Braking calculations](https://www.twiflex.com/braking-calculations). Manufacturer engineering guidance, undated.
