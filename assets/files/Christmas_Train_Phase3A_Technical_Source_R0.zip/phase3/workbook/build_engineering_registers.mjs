import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const base=fileURLToPath(new URL('..',import.meta.url));
const out=path.join(base,'output');
const audit=path.join(base,'workbook');
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const groups=['frames','brakes_couplings','body_boarding','propulsion_utilities','track_delivery'];
const docs=await Promise.all(groups.map(n=>read(path.join(base,'research',n+'.json'))));
const interfaces=await read(path.join(base,'source/interface_register.json'));
const text=v=>v==null?'Not documented':typeof v==='string'?v:Array.isArray(v)?v.map(text).join('; '):Object.entries(v).map(([k,x])=>k.replaceAll('_',' ')+': '+text(x)).join('; ');
const wb=Workbook.create();
const sheets=Object.fromEntries(['Calculations','Components','Interfaces','Sources'].map(n=>[n,wb.worksheets.add(n)]));
const palette={ink:'#182B3A',head:'#34495E',light:'#EDF2F5',input:'#FFF0BC',line:'#B8C5CD',muted:'#566875'};
function baseStyle(s,rows,cols){s.showGridLines=false;s.getRangeByIndexes(0,0,rows,cols).format.font={name:'Arial',size:10,color:palette.ink};s.getRangeByIndexes(0,0,rows,cols).format.verticalAlignment='center';s.getRangeByIndexes(0,0,rows,cols).format.rowHeight=23;s.tabColor=palette.head;}
function title(s,label,last){s.getRange('A2').values=[[label]];s.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:palette.ink};s.getRange(`A3:${last}3`).format.borders={bottom:{style:'thin',color:palette.line}};s.getRange('A4').values=[['PF-TRAIN-S3A-R0 · 17 October 2026 · Preliminary. Not for fabrication or construction.']];}
function header(s,r,last,labels){s.getRange(`A${r}:${last}${r}`).values=[labels];s.getRange(`A${r}:${last}${r}`).format={fill:palette.head,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:30,wrapText:true,horizontalAlignment:'center'};}
function longTable(s,labels,rows,widths,name){const end=String.fromCharCode(64+labels.length);baseStyle(s,rows.length+8,labels.length);header(s,6,end,labels);s.getRange(`A7:${end}${rows.length+6}`).values=rows;rows.forEach((row,i)=>{const h=Math.min(220,Math.max(44,...row.map((v,j)=>Math.ceil(text(v).length/(widths[j]*.95))*13+12)));s.getRange(`A${i+7}:${end}${i+7}`).format.rowHeight=h;if(i%2===1)s.getRange(`A${i+7}:${end}${i+7}`).format.fill='#F4F7F9';});s.getRange(`A7:${end}${rows.length+6}`).format.wrapText=true;s.getRange(`A7:${end}${rows.length+6}`).format.verticalAlignment='top';widths.forEach((w,i)=>s.getRangeByIndexes(0,i,rows.length+8,1).format.columnWidth=w);s.tables.add(`A6:${end}${rows.length+6}`,true,name);s.freezePanes.freezeRows(6);s.freezePanes.freezeColumns(2);return end;}

const c=sheets.Calculations;baseStyle(c,52,9);title(c,'Engineering calculations','I');
for(const [col,w] of Object.entries({A:39,B:17,C:12,D:58,E:3,F:42,G:18,H:12,I:62}))c.getRange(`${col}1:${col}52`).format.columnWidth=w;
header(c,6,'D',['Result','Value','Units','Interpretation']);
const summary=[['Nominal loaded mass',null,'kg','100 kg per person plus 300 kg mobility devices'],['Stress loaded mass',null,'kg','145 kg per person plus mobility devices'],['Active mass for performance',null,'kg','Editable sensitivity; not a demonstrated vehicle rating'],['Service stop including delay',null,'m','0% design grade; no credited rolling resistance'],['Emergency stop including delay',null,'m','Illustrative brake target before grade deduction'],['Required adhesion mass at start',null,'kg','Includes study acceleration; curves/wind excluded']];
c.getRange('A7:D12').values=summary;
c.getRange('B7:B12').formulas=[['=G17'],['=G18'],['=B26'],['=G34'],['=G35'],['=G24']];
c.getRange('A7:D12').format.rowHeight=36;c.getRange('D7:D12').format.wrapText=true;c.getRange('B7:B12').setNumberFormat('#,##0.0');
c.getRange('A14').values=[['Required input validity']];
c.getRange('B14').formulas=[['=IF(COUNT(B17:B41)<>25,"Missing input",IF(OR(MIN(B17:B27)<=0,B28<0,B29<=0,B30<0,B31<0,B32<=0,B33<=0,B33>1,B34<0,B35<=0,B36<=0,B37<=0,B38<0,B39<=0,B40<=0,B41<0),"Invalid input","Valid inputs"))']];
c.getRange('D14').values=[['Amber cells are editable assumptions. Engineering acceptance remains open.']];
header(c,16,'D',['Editable assumption','Value','Units','Basis / limitation']);
const inputs=[
['Regular coach count',3,'coaches','Project study basis'],['Regular coach tare',7040,'kg each','Mass allocation; not measured'],['Accessible coach tare',7535,'kg','Mass allocation; not measured'],['Locomotive and hotel allocation',14500,'kg','Mass allocation; not a selected locomotive'],['Guest places',109,'people','3 regular coaches plus accessible coach'],['Total crew mass allowance',4,'people','Includes driver; not approved staffing'],['Nominal person mass',100,'kg/person','Engineering screening assumption'],['Stress person mass',145,'kg/person','Engineering screening assumption'],['Mobility devices total',300,'kg','Two-device mass allowance'],['Active performance mass',65000,'kg','Upper sensitivity input'],['Initial speed',7.5,'mph','Study speed; not operating approval'],['Longitudinal grade magnitude',0,'fraction','Owner target 0%; survey verification pending. 1–3% off-design only.'],['Standard gravity',9.80665,'m/s²','Standard gravity; aligned with propulsion study'],['Running resistance coefficient',.005,'fraction','Assumption; curves/wind excluded'],['Starting resistance coefficient',.01,'fraction','Assumption; curves/wind excluded'],['Wheel/rail adhesion coefficient',.15,'fraction','Assumption; must assess degraded adhesion'],['Drive efficiency',.75,'fraction','Assumed overall traction efficiency'],['Brake response delay',3,'s','Assumption; gravity acceleration added for positive off-design grade'],['Service brake deceleration before grade',.5,'m/s²','Brake force/mass target BEFORE grade deduction'],['Emergency brake deceleration before grade',.8,'m/s²','Brake force/mass target BEFORE grade deduction'],['Powered adhesive mass',14500,'kg','Optimistic if all locomotive/hotel allocation were driven; actual axle mass required'],['Starting acceleration target',.1,'m/s²','Sensitivity, not guaranteed acceleration'],['Speed conversion',.44704,'m/s per mph','Exact unit conversion'],['Distance conversion',3.280839895013123,'ft per m','International feet'],['Traction auxiliary allowance',10,'kW','Assumption for propulsion-study comparison; hotel power excluded']];
c.getRange('A17:D41').values=inputs;c.getRange('B17:B41').format.fill=palette.input;c.getRange('B17:B41').setNumberFormat('#,##0.000');c.getRange('A17:D41').format.rowHeight=36;c.getRange('A17:D41').format.wrapText=true;c.getRange('B28:B28').setNumberFormat('0.0%');c.getRange('B30:B33').setNumberFormat('0.0%');
c.getRange('F16:I16').values=[['Calculation step','Value','Units','Method / limitation']];c.getRange('F16:I16').format={fill:palette.head,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:30,wrapText:true,horizontalAlignment:'center'};
const calculations=[
['Nominal total mass','B17*B18+B19+B20+(B21+B22)*B23+B25','kg','3 coach tares + accessible + locomotive/hotel + 113 people + devices'],
['Stress total mass','B17*B18+B19+B20+(B21+B22)*B24+B25','kg','Same tare; stress mass per person'],
['Initial speed','B27*B39','m/s','mph conversion'],
['Downhill gravity acceleration','B29*B28','m/s²','Small-grade approximation g × grade; no rolling resistance credited in stopping'],
['Running traction force','B26*B29*(B28+B30)','N','Uphill grade + rolling resistance; curves/wind excluded'],
['Starting traction force','B26*B29*(B28+B31)+B26*B38','N','Uphill grade + starting resistance + acceleration'],
['Available adhesion force','B32*B37*B29','N','Uses assumed powered adhesive mass; not total train mass'],
['Required powered mass at start','G22/(B32*B29)','kg','Required starting force / (adhesion × g)'],
['Wheel power at speed','G21*G19/1000','kW','Running resistance × speed'],
['Input traction power','G25/B33','kW','Traction input only; traction auxiliaries and hotel load excluded'],
['Speed when brakes apply','G19+G20*B34','m/s','Initial speed plus downhill gravity acceleration during response delay'],
['Distance during delay','G19*B34+0.5*G20*B34^2','m','Unbraked gravity-accelerated delay'],
['Net service deceleration','B35-G20','m/s²','Brake target BEFORE grade minus downhill gravity'],
['Net emergency deceleration','B36-G20','m/s²','Emergency target BEFORE grade minus downhill gravity'],
['Service brake distance','IF(G29<=0,"NO FINITE STOP",G27^2/(2*G29))','m','Constant effective braking after full application'],
['Emergency brake distance','IF(G30<=0,"NO FINITE STOP",G27^2/(2*G30))','m','Constant effective braking after full application'],
['Initial kinetic energy','0.5*B26*G19^2/1000000','MJ','At initial speed'],
['Total service stopping distance','IF(G29<=0,"NO FINITE STOP",G28+G31)','m','Delay travel plus brake distance'],
['Total emergency stopping distance','IF(G30<=0,"NO FINITE STOP",G28+G32)','m','Delay travel plus brake distance'],
['Service brake energy','IF(G29<=0,"NO FINITE STOP",G33+B26*B29*B28*G34/1000000)','MJ','Kinetic energy plus gravitational work over total stopping distance'],
['Emergency brake energy','IF(G30<=0,"NO FINITE STOP",G33+B26*B29*B28*G35/1000000)','MJ','Must be allocated to actual brakes; not thermal qualification'],
['Grade holding force','B26*B29*B28','N','Unfactored gravity load; parking rating/margins unresolved'],
['Service total brake force','B26*B35','N','Before grade deduction'],
['Emergency total brake force','B26*B36','N','Before grade deduction'],
['Service total stop in feet','IF(G29<=0,"NO FINITE STOP",G34*B40)','ft','Includes gravity-accelerated delay'],
['Emergency total stop in feet','IF(G30<=0,"NO FINITE STOP",G35*B40)','ft','Includes gravity-accelerated delay'],
['Traction input plus auxiliaries','G26+B41','kW','Includes assumed 10 kW traction auxiliaries; hotel power excluded']];
for(let i=0;i<calculations.length;i++){const [name,f,u,note]=calculations[i],r=17+i;c.getRange(`F${r}:I${r}`).values=[[name,null,u,note]];c.getRange(`G${r}`).formulas=[[`=IF($B$14<>"Valid inputs","INPUT REQUIRED",${f})`]];}
c.getRange('F17:I43').format.rowHeight=36;c.getRange('F17:I43').format.wrapText=true;c.getRange('G17:G43').setNumberFormat('#,##0.000');
c.getRange('A44').values=[['Limitations']];c.getRange('A44').format.font={bold:true};
c.getRange('A45').values=[['No thermal, fatigue, wheel-slide, adhesion distribution, brake timing, curvature or supplier-rating approval follows from these calculations.']];
c.getRange('A46').values=[['Stopping assumes constant brake force after delay and no propulsion. Conservative gravity-only delay; real timing and buildup need test data.']];
c.getRange('A47').values=[['Sources: owner/project design basis dated 2026-10-17; PU and BC technical studies in the Sources register. All operating inputs above are assumptions.']];
c.getRange('A49').values=[['Owner direction: 0% longitudinal grade. Local grades, construction tolerances and drainage require survey/engineer verification.']];
c.getRange('A48').values=[['14500 kg adhesive mass is a sensitivity assumption. The hotel-power allocation may not be carried by driven axles.']];
c.freezePanes.freezeRows(6);

const allSources=docs.flatMap(d=>d.sources||[]);
const sourceMap=Object.fromEntries(allSources.map(s=>[s.id,s]));
const comp=[];
for(let gi=0;gi<docs.length;gi++)for(const x of docs[gi].components||[]){const ids=x.sources||x.source_ids||[];const rating=x.documented_ratings??x.documented_rating;const srcRating=ids.map(id=>{const s=sourceMap[id];return s?`${id}: ${text(s.verified||s.verified_facts)}`:''}).filter(Boolean).join('\n');comp.push([x.id,x.item||x.system||x.function||groups[gi],x.candidate||[x.manufacturer,x.model].filter(Boolean).join(' — '),rating==null?(srcRating||'No application rating documented'):text(rating),x.status||x.selection||'Candidate only',text(x.required_interfaces||x.interface_holds||x.holds||x.release),ids.join(', '),'','Awaiting supplier response','']);}

const ce=longTable(sheets.Components,['ID','System / function','Research candidate','Documented data (not acceptance)','Research status','Required evidence before release','Source IDs','Supplier / model response','Review status (editable)','Supplier evidence / reply'],comp,[14,30,50,75,45,75,20,38,30,65],'ComponentsRegister');title(sheets.Components,'Component and supplier register',ce);sheets.Components.getRange(`H7:J${comp.length+6}`).format.fill=palette.input;sheets.Components.getRange(`I7:I${comp.length+6}`).dataValidation={rule:{type:'list',values:['Awaiting supplier response','Response received','Engineering review','Rejected','Accepted by responsible engineer']}};
const ir=interfaces.map(x=>[x.id,x.interface,x.current_basis,x.definition_required,x.responsible_party,x.drawing_reference,x.release_gate,'Open','']);const ie=longTable(sheets.Interfaces,['ID','Interface','Current study basis','Definition required','Responsible party','Drawing','Release gate','Status (editable)','Resolution / evidence'],ir,[12,28,52,75,45,18,48,25,65],'InterfacesRegister');title(sheets.Interfaces,'Engineering interface register',ie);sheets.Interfaces.getRange(`H7:I${ir.length+6}`).format.fill=palette.input;sheets.Interfaces.getRange(`H7:H${ir.length+6}`).dataValidation={rule:{type:'list',values:['Open','Evidence received','Under review','Released by responsible party']}};
const sr=allSources.map(x=>[x.id,x.title,new Date((x.accessed||'2026-10-17')+'T00:00:00Z'),x.url,text(x.verified||x.verified_facts),text(x.limitation||x.availability||x.limitations),'Primary source; see stated scope']);const se=longTable(sheets.Sources,['ID','Source title','Accessed','URL','Verified source information','Limitations / availability','Source type'],sr,[12,50,15,70,85,85,30],'SourcesRegister');title(sheets.Sources,'Source register',se);sheets.Sources.getRange(`C7:C${sr.length+6}`).setNumberFormat('mm/dd/yy');

wb.recalculate();
const val=addr=>c.getRange(addr).values[0][0];
const m=65000,grade=0,v=7.5*.44704,ag=9.80665*grade,t=3,va=v+ag*t,sd=v*t+.5*ag*t*t;
const expected={G17:54755,G18:59840,G19:v,G20:ag,G21:m*9.80665*(grade+.005),G22:m*9.80665*(grade+.01)+m*.1,G23:.15*14500*9.80665,G24:(m*9.80665*(grade+.01)+m*.1)/(.15*9.80665),G25:m*9.80665*(grade+.005)*v/1000,G26:m*9.80665*(grade+.005)*v/1000/.75,G27:va,G28:sd,G29:.5-ag,G30:.8-ag,G34:sd+va*va/(2*(.5-ag)),G35:sd+va*va/(2*(.8-ag))};
expected.G43=expected.G26+10;
expected.G36=.5*m*v*v/1e6+m*9.80665*grade*expected.G34/1e6;expected.G37=.5*m*v*v/1e6+m*9.80665*grade*expected.G35/1e6;
const checked=Object.entries(expected).map(([cell,exp])=>({cell,expected:exp,actual:val(cell),pass:Math.abs(val(cell)-exp)<1e-6}));if(checked.some(x=>!x.pass))throw Error('Independent calculation mismatch: '+JSON.stringify(checked.filter(x=>!x.pass)));
c.getRange('B27').values=[[5]];wb.recalculate();const changed=val('G34');if(!(changed<expected.G34))throw Error('Speed input did not recalculate');c.getRange('B27').values=[[7.5]];
c.getRange('B28').values=[[.06]];wb.recalculate();const impossible=val('G34');if(impossible!=='NO FINITE STOP')throw Error('Nonpositive net deceleration guard failed');c.getRange('B28').values=[[0]];
c.getRange('B34').values=[[null]];wb.recalculate();const blank=val('G34');if(blank!=='INPUT REQUIRED')throw Error('Blank input guard failed');c.getRange('B34').values=[[3]];
wb.recalculate();if(Math.abs(val('G34')-expected.G34)>1e-6)throw Error('Failed restore');
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'Final formula error scan'});
const check=await wb.inspect({kind:'table',range:'Calculations!F17:I43',include:'values,formulas',tableMaxRows:27,tableMaxCols:4,maxChars:20000});
await fs.writeFile(path.join(audit,'calculation_checks.json'),JSON.stringify({checked,input_tests:{changed_speed_service_stop_m:changed,nonpositive_deceleration:impossible,blank_delay:blank,restored_service_stop_m:val('G34')},grade_basis:{default_fraction:0,off_design_only:[.01,.02,.03]},counts:{components:comp.length,interfaces:ir.length,sources:sr.length},formula_scan:errors.ndjson,native_excel_test:'Not executed; artifact-tool recalculation tested'},null,2));
await fs.writeFile(path.join(audit,'calculation_inspect.ndjson'),check.ndjson);
for(const [name,range] of [['Calculations','A2:I12'],['CalculationsBuild','F16:I43'],['Components','A2:G9'],['ComponentsResponses','H6:J10'],['Interfaces','A2:I9'],['Sources','A2:G9']]){const sheetName=name.startsWith('Calculations')?'Calculations':name.startsWith('Components')?'Components':name;const png=await wb.render({sheetName,range,scale:1,format:'png'});await fs.writeFile(path.join(audit,name+'.png'),new Uint8Array(await png.arrayBuffer()));}
await fs.mkdir(out,{recursive:true});const exported=await SpreadsheetFile.exportXlsx(wb);const filename=path.join(out,'Christmas_Train_Phase3A_Engineering_Registers_R0.xlsx');await exported.save(filename);console.log(JSON.stringify({filename,components:comp.length,interfaces:ir.length,sources:sr.length,serviceStop:val('G34'),emergencyStop:val('G35'),formulaScan:errors.ndjson}));
