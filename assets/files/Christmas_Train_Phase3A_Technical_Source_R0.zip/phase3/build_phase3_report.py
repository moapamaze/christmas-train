from pathlib import Path
import json,re,html,hashlib,csv
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
P=Path(__file__).resolve().parent; O=P/'output'; O.mkdir(exist_ok=True)
for n,f in [('DV','DejaVuSans.ttf'),('DVB','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DVB',italic='DV',boldItalic='DVB')
INK=colors.HexColor('#17364a');GREEN=colors.HexColor('#285e50');MUTED=colors.HexColor('#526770');PALE=colors.HexColor('#edf3ef')
s=getSampleStyleSheet()
for name,font,size,leading,col in [('TitleX','DVB',25,31,INK),('H1X','DVB',18,23,INK),('H2X','DVB',11,15,GREEN),('BodyX','DV',9,13,INK),('SmallX','DV',7.7,10.8,MUTED),('CellX','DV',7.7,10.5,INK),('HeadX','DVB',7.7,10.5,colors.white)]:
 s.add(ParagraphStyle(name=name,fontName=font,fontSize=size,leading=leading,textColor=col,spaceAfter=7,spaceBefore=8 if name=='H2X' else 0,keepWithNext=name in ('H1X','H2X'),splitLongWords=True))
story=[];section_titles=[]
def clean(t):
 return str(t).replace('—',' - ').replace('–','-').replace('‑','-').replace('\u202f',' ').replace('\u00a0',' ')
def inline(t):
 t=escape(clean(t));t=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',t);t=re.sub(r'`([^`]+)`',r'<font color="#285e50">\1</font>',t)
 t=re.sub(r'\[([^\]]+)\]\((https?://[^ )]+)\)',r'<a href="\2" color="#285e50">\1</a>',t)
 return t

def para(t,sty='BodyX'):story.append(Paragraph(inline(t),s[sty]))
def new(t):
 if story:story.append(PageBreak())
 section_titles.append(t);para(t,'H1X')
def tab(headers,rows,widths=None):
 if widths is None:widths=[504/len(headers)]*len(headers)
 data=[[Paragraph(inline(c),s['HeadX']) for c in headers]]+[[Paragraph(inline(c),s['CellX']) for c in row] for row in rows]
 table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
 table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),GREEN),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#d3ded8'))]))
 story.append(table);story.append(Spacer(1,9))
def markdown(text):
 lines=text.splitlines();i=0;buf=[]
 def flush():
  if buf:para(' '.join(buf));buf.clear()
 while i<len(lines):
  line=lines[i].strip()
  if line.startswith('# '):flush();i+=1;continue
  if line.startswith('##'):
   flush();para(line.lstrip('# ').strip(),'H2X');i+=1;continue
  if line.startswith('|') and i+1<len(lines) and re.match(r'^\s*\|?\s*:?-{3}',lines[i+1]):
   flush();rows=[];headers=[x.strip() for x in line.strip('|').split('|')];i+=2
   while i<len(lines) and lines[i].strip().startswith('|'):
    row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
    if len(row)==len(headers):rows.append(row)
    i+=1
   weights=[max(8,min(36,len(c))) for c in headers]
   tab(headers,rows,[504*w/sum(weights) for w in weights]);continue
  if line.startswith('```'):
   flush();i+=1;code=[]
   while i<len(lines) and not lines[i].strip().startswith('```'):code.append(lines[i]);i+=1
   for c in code:para(c,'SmallX')
   i+=1;continue
  if not line:flush()
  elif re.match(r'^([-*]|\d+\.)\s+',line):flush();para(line)
  else:buf.append(line)
  i+=1
 flush()

basis=json.loads((P/'source/design_basis.json').read_text())
new('Phase 3A | Engineering definition')
para('PULSIPHER FARMS / MOAPA VALLEY CORN MAZE','SmallX')
para('Christmas Passenger Train\nTechnical Development Package','TitleX')
para('PF-TRAIN-S3A-R0 | 17 October 2026')
para('**Issue purpose:** component evaluation, engineering coordination, prototype planning and supplier review. **Not for fabrication, construction, procurement release or passenger operation.**')
tab(['This release develops','This release leaves held'],[
('Actual loads, component evidence, frame load paths and functional system architecture.','Final structural sections, weld sizes, wheel profiles, component selection and approved safety circuits.'),
('Coach, coupling, stair, brake, electrical and track/station interface drawings.','Surveyed route and North Pole station position; site-specific civil and platform construction details.'),
('Fabrication/inspection sequence, supplier response requirements and editable calculation/source records.','Authority classification, signed engineering, supplier commitments and commissioning acceptance.')],[252,252])
para('**Owner direction:** Track design target is 0% longitudinal grade; finished elevations and engineer-set tolerances must be verified independently of drainage. North Pole location will be supplied later. Passengers will disembark there. Vehicle development therefore includes safe boarding and accessible boarding at both stops. Ride experience, trip scheduling and business projections are outside this technical issue.')
para('The Stage 2 coach geometry is retained as the working arrangement. The rotating 3D models remain Stage 2 space models; new Phase 3 functional diagrams do not convert them into manufactured assemblies. Original H/I/J and Stage 1/2 records are preserved.','SmallX')

new('01 | Recommended development direction')
tab(['Decision','Phase 3A recommendation and evidence still needed'],[
('Frame and bogies','Develop an engineered steel underframe with purchased engineered bogies as the lead comparison; evaluate lighter body systems. Do not preserve the old 3 in floor/frame slab as a structural depth. Close load paths, fatigue, torsion, body mounts and actual component masses.'),
('Propulsion','Evaluate complete engineered locomotives against the entire consist. For custom work, compare diesel mechanical, hydraulic and electric as integrated systems. Separate hotel power from tractive demand and driven mass.'),
('Brakes','Retain hydraulic service actuation. Develop per-car stored-energy emergency/parking with supervised continuity as one architecture, and compare automatic railway air braking. No architecture has yet earned a fail-safe designation.'),
('Connections','Develop a rated rail coupling or engineered articulated drawbar with positive retention and a frame load path. An ordinary road-trailer connection is not a qualified substitute.'),
('Accessible boarding','Develop level/near-level bridge boarding at both stops. Evaluate an onboard lift/rescue option separately; the documented large-lift candidate conflicts with the current 42 in side doorway.'),
('Track and site','Continue route-independent vehicle and track interface engineering now. Freeze site-specific alignment, drainage and stations after survey and actual equipment limits are available.')],[104,400])
para('These are preliminary development choices. Supplier dimensions, ratings, tolerances, lead times and project compatibility must be confirmed in writing before selection. A published product is not a quote or proof of stock.')

new('02 | Findings that change the next drawings')
tab(['Finding','Required response'],[
('Thin floor/frame envelope','The old display slab is only 3 in deep over a 216 in bogie-center span. Member arrangement/depth, body participation, equipment clearances and fatigue must be solved before the 28 in floor height is fixed.'),
('Uneven passenger loading','Regular stress gross mass is 11,825 kg. Gross/4 gives 2,956 kg per axle only with equal sharing. A longitudinal crowd-shift screen raises one bogie reaction; qualify bogies and axles from actual worst load cases, not the average.'),
('Level-track traction','At 65 t and 0% grade, assumed 1% starting resistance requires 6.37 kN before acceleration/curves. Adding 0.10 m/s2 acceleration raises this to 12.87 kN. At assumed adhesion 0.15, the latter requires about 8.75 t driven mass. Actual curves, resistance and driven weight still govern selection.'),
('Braking convention','This issue fixes specific brake force B/M, then subtracts downhill gravity to get net deceleration. Stage 2 instead used a chosen net deceleration target. Do not compare the stopping distances without reconciling that definition and the delay inputs.'),
('Lift doorway conflict','The documented BraunAbility large-platform candidate needs more than the current 42 in clear opening. A 48 in alternate opening is an unintegrated study, not a revision to the retained 3D CAD.'),
('Station length','The four coach envelopes plus three study gaps occupy 140 ft 10 in. This excludes the locomotive, its connection and end margins, and is not a released platform or full-train berth length.')],[118,386])
para('Calculations are transparent screens using stated assumptions. They identify where more engineering is required; they do not establish operating limits or permit the purchase of safety-critical components.')

new('03 | Shared basis and calculation control')
g=basis['geometry'];c=basis['configuration']
tab(['Item','Working value','Status'],[
('Train','1 locomotive + 3 regular + 1 accessible coach','User configuration / study layout'),
('Gauge','36 in (914.4 mm)','Evaluation basis; wheel/rail system not selected'),
('Regular / accessible occupancy','32 guests / 11 fixed + 2 wheelchair places','Layout study; occupied mockup and approval pending'),
('People / devices','109 guests + 4 total crew; 100 / 145 kg per person; 300 kg devices','Nominal / stress inputs, not passenger weight limits'),
('Car tare allocations','Regular 7,040 kg; accessible 7,535 kg','Mass budgets, not measured takeoff'),
('Train mass','54,755 kg nominal; 59,840 kg stress; 55/60/65 t sensitivities','Calculated from allocations'),
('Cabin / exterior','306 x 104 in clear; 312 x 110 in outside','Stage 2 dimensions, subject to body build-up'),
('Coach / bogie spacing','400 in envelope; 216 in bogie centers','Study geometry'),
('Floor / platforms','28 in above rail; 44 in platform at each end','Provisional packaging'),
('Longitudinal grade','0% level-track target','Owner direction; survey and engineer-set acceptance tolerances pending'),
('Speed / curves','5 and 7.5 mph; 30/50/75 m radius','Sensitivity only, not permissible limits')],[122,217,165])
para('Crew mass is conservatively allocated one per coach for local screens, while the four-person total includes the driver. Final crew positions, fueled locomotive mass, luggage, devices, equipment masses and centers of gravity must replace these assumptions. Do not count occupants or growth allowance twice.')
para('The 65 t performance sensitivity is not the structural mass rating of the retained coach. The brake analysis distributes that upper mass into approximately 13.171 t per regular coach. Adopting that mass would require revised frame, bogie, axle, brake and body load cases; the 11.825 t regular stress case alone would no longer cover it.')
para('Formulas and case inputs are preserved in the calculation source files. Each discipline distinguishes verified publications, calculated results, analyst assumptions, development choices and held engineering decisions. The source register records the access date and limitation of each publication.','SmallX')

chapters=[('04 | Frames, bogies, wheels and stability','frames'),('05 | Brakes and inter-car connections','brakes_couplings'),('06 | Propulsion, HVAC and electrical power','propulsion_utilities'),('07 | Bodies, interior, stairs and accessible boarding','body_boarding'),('08 | Track, stations, fabrication and acceptance','track_delivery')]
for title,name in chapters:
 new(title)
 text=(P/'research'/f'{name}.md').read_text()
 text=re.split(r'\n## Primary-source register\b',text,maxsplit=1)[0]
 text=re.sub(r'\nSources TD01[^\n]*(?:\n|$)', '\n', text)
 markdown(text)

new('09 | Coordinated interface register')
para('The editable register accompanies the report. Close the interface with the responsible disciplines before releasing the connected fabrication or procurement package. A resolved dimension in one subsystem does not automatically release its neighbor.')
interfaces=json.loads((P/'source/interface_register.json').read_text())
tab(['ID / interface','Definition and current basis','Owner / gate'],[(x['id']+' '+x['interface'],x['definition_required']+'. '+x['current_basis'],x['responsible_party']+'. '+x['release_gate']) for x in interfaces],[100,255,149])

new('10 | Work packages and next release')
tab(['Work package','Useful work now','Release needed for permanent work'],[
('Full-size occupied mockup','Tape the actual floor outline and door/seat/route envelopes on level ground. Use stable rated chairs/fixtures for six-adult and mobility-device trials. Record changes to pitch, width and access before altering CAD.','Vehicle/accessibility review of the occupied mockup; do not assume the taped plan establishes evacuation or rated occupancy.'),
('Supplier definition','Use the component schedule to obtain certified drawings, exact model/options, loads, duty/temperature ratings, mass/CG, failure behavior, installation requirements and test evidence.','Owner authorization before outreach/orders; engineer acceptance of compatibility and responsibilities.'),
('First chassis/coach','Prepare fabrication travelers, material traceability, jig/datum strategy, fit-up sequence, corrosion plan and inspectable weld access.','Issued structural drawings, accepted materials, WPS/PQR, qualifications, inspection plan and critical tolerances.'),
('Pilot track','Plan material handling, a demonstrated rail-bending/fastening method, survey control and inspection records. Inventory farm equipment without assuming suitability.','Approved rail/wheel interface, survey/civil design, permitted crew scope, specialist method and independent inspection.'),
('Repeated fabrication','Capture first-article dimensions, actual tare/axle loads, assembly time, defects and service access before building repeated cars.','Engineering acceptance of first-article results and controlled revisions.'),
('Commissioning','Prepare instrument lists, ballast plan, defect register, no-power recovery and accessible rescue demonstrations.','Engineer-set acceptance criteria; static/dynamic/fault tests, authority and insurer requirements, completed manuals and trained staff.')],[100,202,202])
para('The next issue should close selected OEM interfaces and measured mockup results, then develop member sizes, connections, detailed manufacturing drawings, wiring/hydraulic schematics, materials/parts schedules and test limits. Final site documents remain sequenced after the owner supplies the North Pole location and a survey is available.')
para('No supplier has been contacted, no order placed and no project-specific engineering approval obtained by this issue. The authorized supplier site contains the technical release only.','SmallX')

sources=[];components=[]
for _,name in chapters:
 d=json.loads((P/'research'/f'{name}.json').read_text());sources.extend(d.get('sources',[]));components.extend(d.get('components',[]))
new('11 | Primary source register')
para('Access date: 17 October 2026 unless a record states otherwise. Product publications support only their stated product and conditions. Availability, current quotation, project suitability and signed engineering remain unconfirmed unless explicitly recorded.')
for r in sources:
 ident=r.get('id','');title=r.get('title',r.get('name','Source'));url=r.get('url','')
 para(ident+' | '+title,'H2X')
 verified=r.get('verified',r.get('verified_facts',r.get('verified_claim',r.get('claims',''))))
 limitation=r.get('limitation',r.get('limitations',r.get('availability','')))
 if isinstance(verified,(list,dict)):verified=json.dumps(verified,ensure_ascii=False)
 if isinstance(limitation,(list,dict)):limitation=json.dumps(limitation,ensure_ascii=False)
 para(verified,'SmallX')
 if limitation:para('Limit: '+limitation,'SmallX')
 if url:story.append(Paragraph('<a href="'+escape(url,{'"':'&quot;'})+'" color="#285e50">'+escape(url)+'</a>',s['SmallX']))

footerline='PRELIMINARY ENGINEERING DEFINITION - NOT FOR FABRICATION OR CONSTRUCTION'
def footer(can,doc):
 can.saveState();can.setStrokeColor(colors.HexColor('#d6e1da'));can.line(54,49,558,49)
 can.setFont('DVB',6.5);can.setFillColor(GREEN);can.drawString(54,36,footerline)
 can.setFont('DV',7);can.setFillColor(MUTED);can.drawString(54,23,'Pulsipher Farms | PF-TRAIN-S3A-R0 | 17 October 2026');can.drawRightString(558,23,str(doc.page))
 can.setFont('DV',7);can.drawString(54,766,'PULSIPHER FARMS  /  CHRISTMAS PASSENGER TRAIN');can.restoreState()
path=O/'Christmas_Train_Phase3A_Engineering_Definition_R0.pdf'
doc=SimpleDocTemplate(str(path),pagesize=(612,792),rightMargin=54,leftMargin=54,topMargin=48,bottomMargin=61,title='Pulsipher Farms Christmas Train Phase3A Engineering Definition R0',author='Pulsipher Farms project development')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
(O/'Phase3A_Source_Register_R0.json').write_text(json.dumps(sources,indent=2,ensure_ascii=False))
(O/'Phase3A_Component_Schedule_R0.json').write_text(json.dumps(components,indent=2,ensure_ascii=False))
(O/'report_sections.json').write_text(json.dumps(section_titles,indent=2))
print(json.dumps({'file':str(path),'pages':len(PdfReader(path).pages),'sources':len(sources),'components':len(components)}))
