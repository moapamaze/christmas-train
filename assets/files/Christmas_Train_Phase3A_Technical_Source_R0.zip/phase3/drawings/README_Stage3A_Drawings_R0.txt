PHASE 3A ENGINEERING-DEFINITION DRAWINGS / R0 / 2026-10-17

NOT FOR FABRICATION OR CONSTRUCTION. No engineer approval is claimed.
Nine coordinated sheets: L01 locomotive, F01 frames, R01 body, A01 accessible,
C01 coupling functions, S01 platforms/stairs, B01 brakes, E01 utilities, T01 track/stations.

Combined and individual 17 x 11 in PDFs are readable review outputs.
Each sheet has editable SVG and DXF. Sheet DXFs use PAPER INCHES (17 x 11),
not full-scale component geometry. They retain editable linework and text.
Stage3A_Coach_Interface_Envelopes_Inches_R0.dxf is MODEL SPACE in INCHES,
containing only retained coach frame/body/support envelopes, not structural members.
Do not scale schematic details to infer fabricated sizes.

Generator: build_Stage3A_Drawings_R0.py; inputs: phase3/source/design_basis.json
and phase3/source/Stage2_Geometry_Frozen_R0.json. It intentionally does not select
held sections, pins, welds, wheel profiles or other safety-critical hardware.
No new 3D solids are released: actual frame depth, bogies and connection geometry
must be selected before a manufacturing model can be authored. Stage2 3D models
remain envelope visualizations.

Source labels FR, BB, BC, PU and TD refer to their matching Phase3 source registers.
Owner update: 0% longitudinal track grade is the design basis. Survey acceptance, allowable deviation and vertical alignment remain the track engineer's responsibility; drainage is still required.
These sheets must be read with the Phase3 report, interface register and release holds.
