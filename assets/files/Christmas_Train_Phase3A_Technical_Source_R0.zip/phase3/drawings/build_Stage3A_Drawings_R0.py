"""Pulsipher Farms Phase 3A engineering-definition sheets.
Authoring units: PDF points. DXF sheets use inches (1/72 paper-scale).
All geometry is schematic unless explicitly dimensioned STUDY.
This generator consumes the frozen Stage 3 design basis and Stage 2 CAD geometry.
"""
from pathlib import Path
import json, math, html, textwrap, hashlib
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
import ezdxf
from pypdf import PdfReader, PdfWriter
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
B=json.loads((ROOT/'phase3/source/design_basis.json').read_text())
G=json.loads((ROOT/'phase3/source/Stage2_Geometry_Frozen_R0.json').read_text())
W,H=1224,792
INK='#193a48'; TEAL='#16767a'; GRAY='#63737c'; PALE='#ecf3f4'; GOLD='#a76913'; RED='#9b362f'; WHITE='#ffffff'
class Sheet:
 def __init__(self,code,title,sub):
  self.code,self.title,self.items=code,title,[]
  self.rect(22,20,W-44,H-40,stroke=INK)
  self.text(38,47,'PULSIPHER FARMS  /  CHRISTMAS RAILWAY',11,TEAL,True)
  self.text(38,76,title,22,INK,True)
  self.text(38,97,sub,10,GRAY)
  self.line(38,109,1186,109,INK,1)
  self.rect(22,722,1180,50,stroke=INK,fill=PALE)
  self.text(36,742,'PRELIMINARY ENGINEERING DEFINITION - NOT FOR FABRICATION OR CONSTRUCTION',11,RED,True)
  self.text(36,760,'PF-TRAIN-S3A-R0  |  2026-10-17  |  Retained Stage 2 geometry is a STUDY envelope. No engineer approval implied.',9,INK)
  self.line(1050,722,1050,772,INK)
  self.text(1065,745,code,20,INK,True)
  self.text(1065,761,'17 x 11 in / R0',9,GRAY)
 def line(self,x1,y1,x2,y2,stroke=INK,sw=1,dash=False):self.items.append(('line',(x1,y1,x2,y2,stroke,sw,dash)))
 def rect(self,x,y,w,h,stroke=INK,fill=None,sw=1,dash=False):self.items.append(('rect',(x,y,w,h,stroke,fill,sw,dash)))
 def circle(self,x,y,r,stroke=INK,fill=None,sw=1,dash=False):self.items.append(('circle',(x,y,r,stroke,fill,sw,dash)))
 def poly(self,pts,stroke=INK,fill=None,sw=1,dash=False):self.items.append(('poly',(pts,stroke,fill,sw,dash)))
 def text(self,x,y,s,size=10,color=INK,bold=False):self.items.append(('text',(x,y,str(s),size,color,bold)))
 def para(self,x,y,s,width,size=10,color=INK,leading=None):
  yy=y; leading=leading or size*1.45
  for para in s.split('\n'):
   words=para.split(); line=''
   for word in words:
    test=(line+' '+word).strip()
    if stringWidth(test,'Helvetica',size)>width and line:
     self.text(x,yy,line,size,color);yy+=leading;line=word
    else:line=test
   if line:self.text(x,yy,line,size,color);yy+=leading
   yy+=2
  return yy
 def head(self,x,y,s):self.text(x,y,s,12,TEAL,True)
 def arrow(self,x1,y1,x2,y2,color=TEAL,sw=1.5):
  self.line(x1,y1,x2,y2,color,sw);a=math.atan2(y2-y1,x2-x1)
  self.poly([(x2,y2),(x2-7*math.cos(a-.4),y2-7*math.sin(a-.4)),(x2-7*math.cos(a+.4),y2-7*math.sin(a+.4)),(x2,y2)],color,color)
 def dh(self,x1,x2,y,ext1,ext2,label,color=GOLD):
  self.line(x1,ext1,x1,y+5,color,.6);self.line(x2,ext2,x2,y+5,color,.6);self.line(x1,y,x2,y,color,.7)
  for x in(x1,x2):self.line(x-3,y+4,x+3,y-4,color,.9)
  tw=stringWidth(label,'Helvetica',9);self.rect((x1+x2-tw)/2-3,y-13,tw+6,12,WHITE,WHITE)
  self.text((x1+x2-tw)/2,y-3,label,9,color)
 def dv(self,y1,y2,x,ext1,ext2,label,color=GOLD):
  self.line(ext1,y1,x+5,y1,color,.6);self.line(ext2,y2,x+5,y2,color,.6);self.line(x,y1,x,y2,color,.7)
  for y in(y1,y2):self.line(x-4,y+3,x+4,y-3,color,.9)
  self.text(x+7,(y1+y2)/2,label,9,color)
 def note(self,x,y,w,title,txt):
  self.head(x,y,title);return self.para(x,y+19,txt,w,9.5,INK,14)
 def legend(self,y=696):
  self.text(38,y,'VERIFIED = cited source fact   |   CALCULATED = stated-input arithmetic   |   STUDY = layout / design basis   |   HELD = evidence or engineering required',9,GRAY)
 def block(self,x,y,w,h,title,sub='',fill=PALE):
  self.rect(x,y,w,h,TEAL,fill,1.2);self.text(x+10,y+20,title,10,INK,True)
  if sub:self.para(x+10,y+36,sub,w-20,9,GRAY,12)
 def save(self):
  path=OUT/f'Stage3A_{self.code}_R0'
  c=canvas.Canvas(str(path.with_suffix('.pdf')),pagesize=(W,H));c.setTitle(self.title+' | '+self.code+' | Preliminary R0');c.setAuthor('Pulsipher Farms - preliminary engineering study')
  svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="17in" height="11in" viewBox="0 0 {W} {H}"><title>{html.escape(self.title)}</title><rect width="1224" height="792" fill="white"/>']
  d=ezdxf.new('R2010');d.units=1;m=d.modelspace()
  d.layers.new('STUDY',dxfattribs={'color':3});d.layers.new('NOTES',dxfattribs={'color':7});d.layers.new('HELD',dxfattribs={'color':1})
  for typ,a in self.items:
   if typ=='text':
    x,y,s,sz,col,bo=a;c.setFillColor(HexColor(col));c.setFont('Helvetica-Bold' if bo else 'Helvetica',sz);c.drawString(x,H-y,s)
    svg.append(f'<text x="{x}" y="{y}" font-family="Arial,sans-serif" font-size="{sz}" font-weight="{700 if bo else 400}" fill="{col}">{html.escape(s)}</text>')
    m.add_text(s,dxfattribs={'insert':(x/72,(H-y)/72),'height':sz/72,'layer':'NOTES'})
    continue
   if typ=='line':x1,y1,x2,y2,col,sw,da=a;fill=None
   elif typ=='rect':x,y,w,h,col,fill,sw,da=a
   elif typ=='circle':x,y,r,col,fill,sw,da=a
   else:pts,col,fill,sw,da=a
   c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(fill or WHITE));c.setLineWidth(sw);c.setDash([5,3] if da else [])
   style=f' stroke="{col}" stroke-width="{sw}" fill="{fill or "none"}"'+(' stroke-dasharray="5 3"' if da else '')
   layer='HELD' if col==RED else 'STUDY';at={'layer':layer}
   if typ=='line':
    c.line(x1,H-y1,x2,H-y2);svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"{style}/>');m.add_line((x1/72,(H-y1)/72),(x2/72,(H-y2)/72),dxfattribs=at)
   elif typ=='rect':
    c.rect(x,H-y-h,w,h,fill=bool(fill),stroke=1);svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}"{style}/>');m.add_lwpolyline([(x/72,(H-y)/72),((x+w)/72,(H-y)/72),((x+w)/72,(H-y-h)/72),(x/72,(H-y-h)/72)],close=True,dxfattribs=at)
   elif typ=='circle':
    c.circle(x,H-y,r,fill=bool(fill),stroke=1);svg.append(f'<circle cx="{x}" cy="{y}" r="{r}"{style}/>');m.add_circle((x/72,(H-y)/72),r/72,dxfattribs=at)
   else:
    p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
    for xx,yy in pts[1:]:p.lineTo(xx,H-yy)
    c.drawPath(p,fill=bool(fill),stroke=1);svg.append(f'<polyline points="'+ ' '.join(f'{xx},{yy}' for xx,yy in pts)+f'"{style}/>');m.add_lwpolyline([(xx/72,(H-yy)/72) for xx,yy in pts],dxfattribs=at)
  c.save();svg.append('</svg>');path.with_suffix('.svg').write_text('\n'.join(svg));d.saveas(path.with_suffix('.dxf'))
  return str(path.with_suffix('.pdf'))
S=[]
# L01
s=Sheet('L01','Locomotive and train interface architecture','Selection basis: integrator-supplied diesel-hydrostatic power chassis; steam-era shell is cosmetic. Arrangement is functional, not a measured locomotive.')
s.head(40,136,'L1 / PROPULSION, HOTEL POWER AND SAFETY INTERFACES')
s.block(50,165,170,74,'Diesel engine','Cooling / fuel / aftertreatment; power and duty rating HELD')
s.block(270,165,170,74,'Hydrostatic drive','Pump + motors + reduction; filtration / heat rejection HELD')
s.block(490,165,170,74,'Railway wheelsets','Driven axle count, axle load, wheel profile and bearings HELD')
s.arrow(220,201,270,201);s.arrow(440,201,490,201)
s.block(50,278,170,80,'Hotel generation','Separated enclosure; exhaust and combustion air clear of occupants')
s.block(270,278,170,80,'Protected trainline','E01: source interlock, local isolation, bonds and cable articulation')
s.block(490,278,170,80,'Four enclosed coaches','Three regular + one accessible; all vehicle brakes coordinated')
s.arrow(220,316,270,316);s.arrow(440,316,490,316)
s.block(50,394,170,76,'Cab and controls','Forward / reverse sightlines; inhibit traction on brake faults')
s.block(270,394,170,76,'Train brake controller','Service + independent emergency / parking functions; see B01')
s.block(490,394,170,76,'Coupling load path','Engineered rail connection to frame; see C01')
s.arrow(220,430,270,430);s.arrow(440,430,490,430)
s.note(710,138,450,'L2 / DIMENSIONS AND RATINGS TO OBTAIN','HELD: engine model and rated continuous net power; hydrostatic duty / reduction; adhesion by driven wheel load; chassis mass and axle distribution; coupler height; wheel profile; curve and grade limits.\nHELD: complete cooling balance at Southern Nevada ambient, service clearance, fuel capacity, exhaust backpressure and hottest-surface segregation.\nObtain the integrator GA before drawing cosmetic boiler, smokebox, cab or tender around working machinery. Do not scale a Jupiter photograph.')
s.note(710,326,450,'L3 / VERIFIED INTERFACES BEFORE PURCHASE','Rated drawbar pull across speed, starting resistance and rail conditions; braking demonstration at gross train mass; continuous thermal capacity at slow speed; towing and rescue method; documented emergency stop and interlocks.\nEngine power alone does not prove usable rail tractive effort. The 14,500 kg locomotive + hotel allocation is not all assumed driven mass.')
s.note(40,523,348,'MASS BASIS / STUDY','Nominal 54,755 kg; stress 59,840 kg; upper screen 65,000 kg. The 65 t performance case can exceed current coach frame load cases; if adopted, revise every vehicle / bogie case. These are allocations, not supplier ratings.')
s.note(430,523,348,'OPERATING INPUTS / STUDY','Owner basis: 0% longitudinal track grade. Engineer sets survey acceptance and allowable deviation. 5 / 7.5 mph and 30 / 50 / 75 m radii remain study inputs; these are not operating approvals.')
s.note(820,523,348,'RELEASE GATE / HELD','Railway integrator confirms drive, brake, chassis and shell interfaces; system engineer closes mass / power / thermal budget. Refer to PU source register and interface schedule.')
s.legend();S.append(s)
# F01
s=Sheet('F01','Coach frame load paths and support interfaces','All shown members are symbols. Member sections, depth, spacing, grades, welds, bolts and connection stresses remain HELD.')
s.head(40,137,'F1 / FRAME PLAN - DIMENSIONED STUDY ENVELOPE')
x0,y0,sc=82,192,1.28
X=lambda x:x0+(x+47)*sc
s.rect(x0,y0,400*sc,110*sc,INK,None,1.5)
s.rect(X(-3),y0+4,312*sc,102*sc,GRAY,None,.8,True)
for yy in (y0+30,y0+110*sc-30):s.line(x0,yy,x0+400*sc,yy,TEAL,5)
for x in (45,261):
 s.rect(X(x)-7,y0,14,110*sc,TEAL,PALE,1.3);s.line(X(x),y0-15,X(x),y0+110*sc+15,GRAY,.7,True)
 s.text(X(x)-33,y0+110*sc+30,f'Bogie x={x}',9,GRAY)
for x in(-47,353):
 s.rect(X(x)-1 if x==-47 else X(x)-14,y0+43,15,55,RED,None,1.4)
s.dh(X(-47),X(353),174,y0,y0,'400 in frame envelope')
s.dh(X(45),X(261),382,y0+110*sc,y0+110*sc,'216 in bogie centres')
s.dv(y0,y0+110*sc,616,594,594,'110 in envelope')
s.arrow(43,262,82,262,RED);s.arrow(633,262,594,262,RED)
s.text(75,406,'End load boxes tie couplings into both girders; attachment geometry HELD.',9,RED)
s.head(720,137,'F2 / TRANSVERSE SECTION - SYMBOLIC')
s.line(730,238,1135,238,GRAY,2);s.text(740,223,'Floor / wall loads to crossmembers',10,GRAY)
s.rect(795,253,35,40,TEAL,None,2);s.rect(1030,253,35,40,TEAL,None,2)
s.line(747,258,1120,258,TEAL,2);s.arrow(812,186,812,231);s.arrow(1046,186,1046,231)
s.dh(812,1047,319,295,295,'Y_G girder spacing = HELD')
s.dv(238,293,1123,1105,1065,'D_F = HELD',RED)
s.text(734,351,'Section shapes are not actual profiles.',10,RED)
s.para(734,371,'No structural credit assigned to cabin walls or roof. Outboard floor, wall, stair and lift loads require designed transfer into both girders.',415,10)
s.head(40,424,'F3 / LONGITUDINAL SUPPORT AND CANTILEVER INTERFACES')
s.line(82,488,594,488,TEAL,5)
for x in(45,261):
 sx=X(x);s.poly([(sx,488),(sx-15,514),(sx+15,514),(sx,488)],GRAY,PALE);s.arrow(sx,547,sx,518)
for x in(-3,309):s.line(X(x),451,X(x),493,GRAY,.8,True)
s.dh(X(-47),X(45),457,488,488,'92 in tip overhang')
s.dh(X(261),X(353),457,488,488,'92 in tip overhang')
s.text(80,567,'Body edge to support: 48 in; platform extension: 44 in each end.',10,GRAY)
s.note(720,427,450,'LOAD CASES TO RESOLVE / FR REGISTER','Static balanced reactions are not axle ratings. Regular coach stress total 11,825 kg => 5,912.5 kg per bogie only when symmetric. Front-half crowd screening gives about 7,607 / 4,218 kg before dynamic factors.\nA 1 kN tip load produces +1.426 / -0.426 kN support reactions and 2.337 kN-m cantilever moment. Include coupling tension / compression, brake torque, jacking, derailment recovery, lift and stair point loads.')
s.note(40,611,1120,'FABRICATION RELEASE HOLD','Complete frame torsion, fatigue, buckling and attachment analysis; define weld procedure, qualifications and inspection. Rendered 3 in depth is not a structural selection; 28 in floor height remains provisional. A 65 t train performance case can require a 13.171 t regular-coach allocation, exceeding the current 11.825 t frame case; revise before adoption.')
s.legend();S.append(s)
# R01
s=Sheet('R01','Regular coach: body interfaces and assembly sequence','Retained envelope: 306 x 104 in clear cabin; 312 x 110 in exterior body; eight rows of four adults. Circulation and emergency egress remain under review.')
s.head(40,136,'R1 / FLOOR PLAN - SEATING AND BODY INTERFACES')
x,y,k=70,187,1.55
s.rect(x-3*k,y-3*k,312*k,110*k,INK,None,1.5);s.rect(x,y,306*k,104*k,GRAY,None,.7)
for seat in G['regular_seats']:
 s.rect(x+seat['x']*k,y+(seat['y']+52)*k,seat['l']*k,seat['w']*k,TEAL,PALE,.8)
s.line(x-3*k,y+52*k,x+309*k,y+52*k,GRAY,.7,True)
for xx in(-3,306):s.rect(x+xx*k,y+36*k,3*k,32*k,TEAL,WHITE,1)
s.dh(x,x+306*k,167,y,y,'306 in clear')
s.dv(y,y+104*k,570,x+306*k,x+306*k,'104 in clear')
s.dh(x+31*k,x+63*k,390,y+104*k,y+104*k,'32 in row pitch')
s.text(79,420,'20 in seat depth envelope; 40 in two-adult bench; 24 in aisle.',10,INK)
s.text(79,439,'32 in clear end doors are study values, not an egress approval.',10,RED)
s.head(675,136,'R2 / WALL - FLOOR - ROOF INTERFACE SECTION')
s.poly([(725,380),(725,205),(790,165),(1040,165),(1105,205),(1105,380)],INK,None,2)
s.line(725,378,1105,378,TEAL,3);s.line(736,365,1094,365,GRAY,1)
s.rect(726,235,11,78,TEAL,PALE);s.rect(1093,235,11,78,TEAL,PALE)
s.arrow(785,200,754,219);s.text(790,197,'Roof skin + insulation + liner: HELD',9,GRAY)
s.arrow(835,285,739,279);s.text(841,283,'Glazing safety / retention: HELD',9,GRAY)
s.arrow(850,337,746,359);s.text(858,334,'Floor finish + structural deck: HELD',9,GRAY)
s.text(745,406,'Walls attach to frame perimeter; openings need local reinforcement.',9,GRAY)
s.text(745,423,'No thickness depicted here is a build dimension.',9,RED)
s.note(40,487,350,'R3 / JOINT DEVELOPMENT','Floor: drained outer edge, sealed penetrations, removable service access away from walking paths.\nWall base: mechanical attachment + corrosion isolation; water path outside floor assembly.\nRoof: drained seams, HVAC curb loads to reinforced structure, condensate routed below occupied area.')
s.note(429,487,350,'R4 / BODY ASSEMBLY ORDER','1. Frame acceptance and dimensional survey.\n2. Dry-fit deck, walls, end doors and roof.\n3. Install protected wiring / HVAC pathways.\n4. Water test before insulation and liner.\n5. Secure seats to engineered load path.\n6. Finish, inspect and weigh each completed car.')
s.note(818,487,350,'R5 / MOCKUP AND RELEASE HOLDS','Full-width mockup with six adults: seat pitch, aisle passing, door operation, window reach and emergency exit route.\nEngineer defines seat anchor loads, floor panels, glazing, fire properties, insulation and door hardware. No ordinary building detail automatically governs the vehicle.')
s.legend();S.append(s)
# A01
s=Sheet('A01','Accessible coach: circulation, boarding and rescue','Layout reserves are study dimensions. Applicable accessibility basis, securement, lift rating, maneuvering and evacuation require specialist confirmation.')
s.head(40,135,'A1 / CLEAR FLOOR PLAN - 11 FIXED SEATS + 2 WHEELCHAIR PLACES')
x,y,k=70,192,2.25
s.rect(x-3*k,y-3*k,312*k,110*k,INK,None,1.5);s.rect(x,y,306*k,104*k,GRAY,None,.7)
for seat in G['accessible_seats']:s.rect(x+seat['x']*k,y+(seat['y']+52)*k,seat['l']*k,seat['w']*k,TEAL,PALE,.8)
for i,bay in enumerate(G['wheelchair_reserved_bays']):
 s.rect(x+bay['x']*k,y+(bay['y']+52)*k,bay['l']*k,bay['w']*k,GOLD,'#fbf2e3',1,True);s.text(x+bay['x']*k+16,y+40,f'WC {i+1}: 60 x 36 in',10,GOLD)
s.rect(x+60*k,y+40*k,246*k,36*k,TEAL,None,.7,True)
s.circle(x+30*k,y+58*k,30*k,TEAL,None,.9,True)
for yy in(-3,104):s.rect(x+9*k,y+yy*k,42*k,3*k,TEAL,WHITE,1)
for xx in(-3,306):s.rect(x+xx*k,y+40*k,3*k,36*k,TEAL,WHITE,1)
s.dh(x,x+306*k,168,y,y,'306 in clear cabin')
s.dv(y,y+104*k,790,x+306*k,x+306*k,'104 in')
s.text(x+9,y+104*k+24,'Turning reserve: 60 in diameter / continuous route reserve: 36 in',10,INK)
s.arrow(x+28*k,y+104*k+68,x+28*k,y+104*k+2)
s.text(x+5,y+104*k+85,'42 in front side-door study opening',10,TEAL)
s.note(852,137,310,'A2 / NORMAL BOARDING','Provide accessible boarding at BOTH stations; North Pole coordinates may follow later. Prefer matched platform + engineered bridge plate at the retained 42 in side door.\nLift alternative is UNINTEGRATED: researched Braun 1,000 lb unit needs 45.85 in minimum clear width / 50.96 in overall width; existing 42 in door does not fit. A 48 in opening study still needs full packaging.\nHELD: height, gap / step, device rating, gates, approach and rescue method.')
s.note(852,367,310,'A3 / DISABLED-TRAIN RESCUE','Normal lift failure cannot be the sole evacuation strategy. Establish rescue location, all-weather access, independent lowering / bridging means and staff-assist procedures.\nNo routine carry-down of occupied wheelchairs. Confirm how each expected mobility device transfers safely at a stalled vehicle.')
s.note(40,573,355,'ANCHORAGE / HELD','Wheelchair location, orientation, securement and occupant restraint depend on the verified regulatory basis and chosen system. Anchor loads transfer into engineered frame nodes, not floor skin alone.')
s.note(430,573,355,'DOOR AND INTERIOR REVIEW','36 in end-door reserve; front side openings 42 in. Verify clear width with hardware, thresholds, trim and handles installed. Protect circulation from seat backs, bags, hinges and equipment.')
s.note(820,573,355,'FULL-SCALE ACCEPTANCE','Mockup with real occupied mobility devices + companion seats; demonstrate entry, turn, park, exit and emergency retrieval. Resolve BB register before frame / body release.')
s.legend();S.append(s)
# C01
s=Sheet('C01','Rail connection: articulated drawbar concept and holds','FUNCTIONAL CONCEPT ONLY - not a copy of any supplier assembly. Choose a documented railway coupling / drawbar system before detailing pins, lugs or welds.')
s.head(40,136,'C1 / PLAN - TWO ARTICULATING JOINTS')
s.rect(50,188,155,95,INK,PALE);s.rect(445,188,155,95,INK,PALE)
s.text(61,209,'Coach A frame',10,INK,True);s.text(456,209,'Coach B frame',10,INK,True)
s.rect(56,221,75,30,TEAL,None,2);s.rect(519,221,75,30,TEAL,None,2)
s.line(93,236,557,236,TEAL,9)
for xx in(93,557):s.circle(xx,236,12,INK,WHITE,2);s.line(xx,193,xx,279,GRAY,.7,True)
s.line(205,169,205,293,GRAY,.6,True);s.line(445,169,445,293,GRAY,.6,True)
s.dh(205,445,166,188,188,'30 in gap: sensitivity only')
s.dh(93,557,318,249,249,'58 in pivot distance: sensitivity only')
s.text(58,348,'14 in pin setback each end is retained CAD sensitivity, not hardware selection.',9,RED)
s.text(58,367,'Real rail references: Dellner People Mover semi-permanent / Voith 430-530; fit unproven.',9,GRAY)
s.arrow(112,268,180,268,RED);s.arrow(537,268,470,268,RED)
s.head(695,136,'C2 / SIDE - VERTICAL ARTICULATION AND HOSE ROUTE')
s.rect(706,190,160,30,INK,PALE);s.rect(1016,190,160,30,INK,PALE)
s.circle(840,255,11,INK,WHITE,1.5);s.circle(1040,255,11,INK,WHITE,1.5);s.line(840,255,1040,255,TEAL,8)
s.line(840,219,840,244,INK,3);s.line(1040,219,1040,244,INK,3)
s.poly([(822,182),(860,147),(1019,147),(1061,182)],GRAY,None,1,True)
s.text(737,303,'Flexible services routed above / beside protected connection.',9,GRAY)
s.text(737,322,'Pitch / roll joint arrangement, Z_C height and travel = HELD.',9,RED)
s.head(40,398,'C3 / PIN JOINT SECTION - LOAD-BEARING AND RETENTION FUNCTIONS')
s.rect(70,441,165,20,TEAL,PALE,1.5);s.rect(70,503,165,20,TEAL,PALE,1.5)
s.rect(94,469,116,25,TEAL,None,1.5);s.rect(143,451,19,61,GOLD,None,2)
s.rect(146,425,13,118,INK,WHITE,1.3);s.rect(136,421,33,8,INK,PALE)
s.line(136,537,169,537,RED,3)
s.text(256,452,'Lugs t_L / frame socket: HELD',10,TEAL);s.arrow(254,455,232,455)
s.text(256,485,'Replaceable bushing: HELD',10,GOLD);s.arrow(251,482,166,482,GOLD)
s.text(256,520,'Pin d_P / material / bearing: HELD',10,INK);s.arrow(252,517,160,517,INK)
s.text(256,548,'Positive retention; no load credit',10,RED);s.arrow(252,543,172,538,RED)
s.head(695,398,'C4 / EXPLODED FUNCTIONAL STACK')
s.line(700,470,1160,470,GRAY,.7,True)
s.rect(705,433,30,8,INK,PALE);s.rect(716,441,8,65,INK,PALE);s.circle(720,496,2.5,INK,WHITE)
s.rect(800,442,40,15,TEAL,PALE);s.rect(800,487,40,15,TEAL,PALE);s.rect(795,442,5,60,TEAL,PALE)
for yy in(451,490):s.circle(920,yy,14,GOLD,PALE,1.5);s.circle(920,yy,8,GOLD,WHITE,1)
s.rect(1035,460,45,20,TEAL,PALE);s.circle(1020,470,20,TEAL,PALE,1.5);s.circle(1020,470,9,TEAL,WHITE,1)
s.circle(1120,470,14,RED,PALE,1.5);s.circle(1120,470,8,RED,WHITE,1);s.line(1111,490,1129,490,RED,2)
for xx,lab in [(696,'Headed pin'),(784,'Frame clevis'),(896,'Bushings'),(990,'Drawbar eye'),(1097,'Retainer')]:s.text(xx,532,lab,9,GRAY)
s.text(708,555,'Functional exploded parts; actual articulation and bearing type HELD.',9,RED)
s.note(40,599,540,'CALCULATION / RATING HOLD','Resolve tension, braking compression, slack impact, reverse operation, combined yaw / pitch / roll, wear and fatigue. Validate full train reverse-curve kinematics; compare matched railway coupler or engineered captive drawbar. No trailer tongue or generic hitch substitution.')
s.note(650,599,520,'FRAME AND SERVICE INTERFACE HOLD','Socket ties into both longitudinal girders through designed diaphragms. Define inspection access, fail-safe retention, wear limits and replaceable parts. Any secondary retention, inter-car guarding, hose loops and disconnect behavior must be coordinated. Refer BC register.')
s.legend();S.append(s)
# S01
s=Sheet('S01','End platforms, stairs and vehicle-to-station interfaces','Develop passenger protection around rail connections. The 44 in platform and 28 in floor height are retained packaging studies, not approved boarding geometry.')
s.head(40,136,'S1 / END PLATFORM PLAN - MOVING CONNECTION GUARDED')
x,y,k=118,190,2.9
s.rect(x,y,44*k,110*k,INK,PALE,1.5);s.line(x+44*k,y,x+44*k,y+110*k,INK,4)
s.text(x+44*k+15,y+32,'Cabin end wall',10,GRAY)
s.rect(x+44*k-5,y+39*k,10,32*k,TEAL,WHITE,1.3)
s.text(x+44*k+15,y+56*k,'32 in regular end door',9,TEAL)
s.rect(x-76,y+37*k,76,36*k,RED,None,1.2,True)
s.text(40,550,'Coupling / pinch envelope below platform: keep enclosed and inaccessible.',9,RED)
s.dh(x,x+44*k,171,y,y,'44 in study platform')
s.text(131,295,'Clear area',10,INK);s.text(131,312,'to verify by',10,INK);s.text(131,329,'mockup',10,INK)
s.arrow(x+22*k,y+8,x+22*k,y-35,TEAL);s.arrow(x+22*k,y+110*k-8,x+22*k,y+110*k+25,TEAL)
s.text(252,432,'Side boarding gate / stair module',10,TEAL)
s.text(252,451,'Interface width and swing HELD',9,RED)
s.head(670,136,'S2 / STAIR DEPLOYED AND STOWED - SYMBOLIC SIDE VIEW')
s.line(690,250,1110,250,INK,3);s.text(699,230,'Car floor / landing',10,INK)
s.line(690,446,1130,446,GRAY,1.5);s.text(698,468,'Top of rail reference; ground / station surface not fixed',9,GRAY)
s.poly([(888,250),(888,300),(943,300),(943,350),(998,350),(998,400),(1053,400),(1053,446)],TEAL,None,3)
s.poly([(906,250),(906,320),(934,320),(934,250)],RED,None,2,True)
s.text(956,282,'Stowed module',10,RED);s.arrow(951,285,934,286,RED)
s.poly([(864,225),(864,176),(1085,377),(1085,427)],TEAL,None,1.5)
s.dv(250,446,1125,1110,1130,'28 in study',GOLD)
s.text(706,507,'Step count / rise / going shown symbolically; all final values HELD.',10,RED)
s.text(706,526,'Guard and handrail heights, grip, gate latch and interlocks HELD.',10,RED)
s.note(40,596,350,'S3 / PROTECTED BOARDING','Provide slip resistance, contrast, drainage, lighting and graspable handholds. No access to drawbars, wheel paths or energized services. Gates must stay secure under operation and allow the approved emergency egress method.')
s.note(429,596,350,'S4 / CLEARANCE VERIFICATION','3D swept envelope includes full load / rebound, curve cant, body roll, articulation, wheel wear, track tolerance and stair stowage. Interlock or positively secure stowage before movement; establish inspection method.')
s.note(818,596,350,'S5 / FULL-SCALE TRIAL','Build a non-passenger mockup first. Confirm adult foot placement, reach, door swing, staff position and boarding flow. Accessible boarding uses A01; stair module is not the wheelchair evacuation solution.')
s.legend();S.append(s)
# B01
s=Sheet('B01','Train brake functional architecture','Owner preference retained: hydraulic service actuation under evaluation. All devices and line styles are functional placeholders; circuit and ratings require brake-system engineering.')
s.head(40,136,'B1 / COMMAND, ENERGY AND FAIL-SAFE FUNCTIONS')
s.block(55,174,175,80,'Driver command','Service demand + independent emergency stop; traction inhibit')
s.block(285,174,175,80,'Train brake control','Routine service demand separate from hardwired emergency continuity')
s.block(515,174,175,80,'Local coach controller','Local pressure + applied/released feedback; traction inhibit')
s.block(745,174,175,80,'Hydraulic service unit','Isolated zone A: front bogie; zone B: rear bogie; valves HELD')
s.block(975,174,175,80,'Wheel friction brakes','Caliper / disc or supplier system; axle adhesion and thermal checks')
for a,b in[(230,285),(460,515),(690,745),(920,975)]:s.arrow(a,214,b,214)
s.block(285,333,200,85,'Hardwired emergency loop','Driver / crew stop, breakaway, power loss; monitored independently',fill='#fbf2e3')
s.block(550,333,250,85,'Separate SAHR emergency / parking','Spring-applied / hydraulically released; vent -> apply; trapped-pressure / stuck-valve risk HELD',fill='#fbf2e3')
s.block(870,333,280,85,'Positive standstill hold','Detached car holds locally; manual release locks out traction; 0% owner basis, tolerance / hold duty HELD',fill='#fbf2e3')
s.arrow(485,375,550,375,RED);s.arrow(800,375,870,375,RED)
s.line(675,333,675,309,RED,1.5);s.line(675,309,1062,309,RED,1.5);s.arrow(1062,309,1062,254,RED)
s.line(143,254,143,313,RED,1.2,True);s.line(143,313,384,313,RED,1.2,True);s.arrow(384,313,384,333,RED)
s.text(52,294,'FUNCTIONS ONLY: no final valve logic, redundancy or fail-safe claim. No automatic restart.',11,RED,True)
s.note(40,472,350,'SERVICE / BALANCE','Design blended response across locomotive and every coach; verify empty / loaded brake balance, wheel slide and low-adhesion effects. Pressure ratings, bore sizes, disc sizes, fluid, hoses and control protocol remain HELD.')
s.note(430,472,350,'FAILURE / SAFETY','Analyze ruptured hose, leaking actuator, loss of electrical power, lost command, separation and common-cause faults. Prove remaining braking / stopping capability under the required fault scenarios. Do not equate release pressure loss with a proven complete emergency function.')
s.note(820,472,350,'TEST AND RELEASE','Dynamometer / supplier thermal proof + loaded stopping tests on surveyed track. Owner basis: 0% longitudinal grade; hold duty includes accepted deviation and fault cases. Test parking, single faults, separation simulation and recovery. Specialist approves the circuit.')
s.note(40,619,1120,'ALTERNATIVE TO COMPARE BEFORE SELECTION','Compare automatic pneumatic train brakes with H1 hydraulic service + separate SAHR emergency / parking. Keep hydraulic preference pending specialist selection. Knorr HydroAct provides a real rail-hydraulic reference, not a selected installation. Required valve redundancy, common-cause separation and zero-energy hold remain HELD. Refer BC register.')
s.legend();S.append(s)
# E01
s=Sheet('E01','Hotel power one-line and protected distribution','Power topology only: cable, breaker, connector, voltage, frequency, short-circuit capacity, neutral and grounding arrangement are HELD pending equipment selection.')
s.head(40,136,'E1 / SOURCE TRANSFER AND TRAINLINE - SINGLE-LINE SCHEMATIC')
s.block(55,174,180,70,'Diesel hotel generator','40-70 kW delivered continuous investigation envelope')
s.block(55,292,180,70,'Shore connection','Supply capacity / disconnect / personnel protection HELD')
s.block(305,210,240,105,'Interlocked transfer + main protection','Break-before-make; no parallel sources; neutral switching / bond topology HELD')
s.arrow(235,209,305,238);s.arrow(235,326,305,287)
s.line(545,262,1148,262,INK,3)
for i,xx in enumerate([610,755,900,1045]):
 s.line(xx,262,xx,308,INK,2);s.block(xx-45,310,130,75,f'Coach {i+1}', 'Lockable isolator + protected local branches')
 s.line(xx,385,xx,426,INK,1.5);s.block(xx-45,428,130,65,'Local loads','HVAC / lights / outlets; ratings HELD')
s.line(550,288,1155,288,TEAL,2,True)
s.text(574,239,'Protected trainline; sectional isolation / connectors accessible only to staff',9,GRAY)
s.text(569,523,'Separate PE bonds through connectors and vehicle chassis; never use rail or coupler as sole PE.',9,TEAL)
s.block(55,420,230,85,'Each coach: emergency battery','24 V study architecture; emergency lights, communications and essential controls; autonomy HELD',fill='#fbf2e3')
s.block(335,420,210,85,'Essential loads only','Emergency lights / comms / essential controls; no HVAC or brake-actuator credit',fill='#fbf2e3')
s.arrow(285,460,335,460,GOLD)
s.text(58,526,'Local protected charger supplies each battery; repeat on all coaches.',9,GOLD)
s.note(40,573,350,'LOAD BASIS / STUDY','Dry-weather hotel running screen about 27.54 kW; humid / ventilation sensitivity about 35.56 kW at assumed cooling COP 2.5 + 3 kW other loads. These are calculations, not equipment ratings. Heating and starting duty still require selection.')
s.note(429,573,350,'HVAC / SAFETY INTERFACES','Include ambient derating, startup/inrush, heater coincidence, condensate drainage, vibration, intake / exhaust separation and maintenance access. Brake control power is separately coordinated; lighting batteries are not presumed to operate train brakes.')
s.note(818,573,350,'RELEASE HOLD / PU REGISTER','480 V three-phase, 60 Hz is only an option. Licensed electrical design / integrator must establish topology, protective coordination, fault current, cable flex life, bonding and test regime. No conductor size or breaker rating is selected here.')
s.legend();S.append(s)
# T01
s=Sheet('T01','Track section, survey inputs and station berth interfaces','Owner basis: 0% longitudinal grade. No site alignment is issued; North Pole coordinates remain deferred. Both stations require boarding and evacuation interfaces.')
s.head(40,136,'T1 / TRACK SECTION - 36 in GAUGE STUDY BASIS')
s.poly([(75,382),(185,321),(525,321),(635,382)],GRAY,'#eff0ee',1)
s.rect(175,303,360,18,INK,PALE)
for xx in(265,445):
 s.poly([(xx-18,303),(xx+18,303),(xx+8,297),(xx+5,272),(xx+12,270),(xx+12,260),(xx-12,260),(xx-12,270),(xx-5,272),(xx-8,297),(xx-18,303)],INK,PALE,1.5)
 s.line(xx-32,304,xx+32,304,TEAL,3)
s.dh(277,433,229,260,260,'36 in gauge at defined gauge points')
s.line(57,402,650,402,GRAY,1.5);s.text(73,421,'Prepared formation / subgrade; drainage and geotechnical criteria HELD',9,GRAY)
s.text(78,465,'Section diagram symbolic: rail profile, tie and ballast dimensions are not selected.',10,RED)
s.arrow(131,351,89,372,TEAL);s.arrow(579,351,622,372,TEAL)
s.note(705,136,455,'T2 / TRACK DESIGN INPUTS','OWNER BASIS: 0% longitudinal grade. Track engineer defines vertical alignment, survey precision, acceptance tolerance and allowable deviation. Provide drainage independently; level rail does not mean level site grading.\nSurvey centerline, stations, soils / settlement, crossings, irrigation / flood paths, storage and access. North Pole coordinates remain deferred.\nHELD: rail / joints, ties, fastening, spacing, ballast / subgrade, cant, gauge tolerance and wear. Coordinate wheel back-to-back / flange, rail head, check rails and turnouts. Gauge match alone is insufficient.')
s.note(705,367,455,'T3 / FARM CREW / SPECIALIST BOUNDARY','Crew can support survey staking, approved grading / drainage, material handling and supervised tangent assembly after instruction. Specialist establishes first article, curves, transitions, turnouts and inspection standards.\nDo not field-bend rail to a guessed radius or use consumer laser level accuracy as track acceptance. Final line / level / gauge acceptance needs the specified instruments and tolerances.')
s.head(40,507,'T4 / STATION BERTH ENVELOPE - SITE-NEUTRAL INTERFACE')
s.line(57,563,649,563,INK,2)
s.rect(60,529,55,25,INK,PALE,1);s.text(66,546,'LOCO',8,INK)
for i,xx in enumerate((130,258,386,514)):
 s.rect(xx,529,103,25,TEAL,PALE,1);s.text(xx+23,546,f'COACH {i+1}',8,INK)
s.rect(130,584,490,34,TEAL,PALE,1);s.text(146,606,'Continuous boarding interface, accessible zones and protected exits',9,INK)
s.dh(60,617,650,554,618,'Train berth L_B = integrated train length + stopping allowance (HELD)')
s.note(705,566,455,'T5 / VEHICLE CLEARANCE AND DISPATCH','Set platform edge only after dynamic swept-envelope analysis; coordinate provisional 28 in floor with real bogies / suspension. Stations need safe local isolation, clear dispatch sightlines, lighting and rescue access. Defer coordinates, not vehicle-to-station interface decisions. Refer TD register.')
s.legend();S.append(s)
files=[s.save() for s in S]
writer=PdfWriter()
for f in files:writer.append(f)
combined=OUT/'Stage3A_Engineering_Definition_Drawings_R0.pdf';writer.write(combined)
# Real model-coordinate frame / floor interface sketch, in inches, no members sized.
d=ezdxf.new('R2010');d.units=1;m=d.modelspace()
for name,col in [('ENVELOPES',7),('SUPPORTS',3),('HELD_INTERFACES',1),('ANNOTATIONS',2)]:d.layers.new(name,dxfattribs={'color':col})
for rect in[(-47,-55,400,110),(-3,-55,312,110),(0,-52,306,104)]:
 x,y,w,h=rect;m.add_lwpolyline([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],close=True,dxfattribs={'layer':'ENVELOPES'})
for x in(45,261):m.add_line((x,-65),(x,65),dxfattribs={'layer':'SUPPORTS'})
for x in(-33,339):m.add_point((x,0),dxfattribs={'layer':'HELD_INTERFACES'})
m.add_text('STUDY ENVELOPES ONLY / inches / x=front inside end wall; y=transverse centre',dxfattribs={'height':4,'insert':(-47,82),'layer':'ANNOTATIONS'})
m.add_text('All girder, bolster, coupling, stair and lift attachments HELD. NOT FOR FABRICATION.',dxfattribs={'height':4,'insert':(-47,72),'layer':'ANNOTATIONS'})
d.saveas(OUT/'Stage3A_Coach_Interface_Envelopes_Inches_R0.dxf')
readme='''PHASE 3A ENGINEERING-DEFINITION DRAWINGS / R0 / 2026-10-17

NOT FOR FABRICATION OR CONSTRUCTION. No engineer approval is claimed.
Nine coordinated sheets: L01 locomotive, F01 frames, R01 body, A01 accessible,
C01 coupling functions, S01 platforms/stairs, B01 brakes, E01 utilities, T01 track/stations.

Combined and individual 17 x 11 in PDFs are readable review outputs.
Each sheet has editable SVG and DXF. Sheet DXFs use PAPER INCHES (17 x 11),
not full-scale component geometry. They retain editable linework and text.
Stage3A_Coach_Interface_Envelopes_Inches_R0.dxf is MODEL SPACE in INCHES,
containing only retained coach frame/body/support envelopes, not structural members.
Do not scale schematic details to infer fabricated sizes.

Generator: build_Stage3A_Drawings_R0.py; inputs: phase3/source/design_basis.json
and phase3/source/Stage2_Geometry_Frozen_R0.json. It intentionally does not select
held sections, pins, welds, wheel profiles or other safety-critical hardware.
No new 3D solids are released: actual frame depth, bogies and connection geometry
must be selected before a manufacturing model can be authored. Stage2 3D models
remain envelope visualizations.

Source labels FR, BB, BC, PU and TD refer to their matching Phase3 source registers.
Owner update: 0% longitudinal track grade is the design basis. Survey acceptance, allowable deviation and vertical alignment remain the track engineer's responsibility; drainage is still required.\nThese sheets must be read with the Phase3 report, interface register and release holds.
'''
(OUT/'README_Stage3A_Drawings_R0.txt').write_text(readme)
validation={'revision':'PF-TRAIN-S3A-R0','page_count':len(PdfReader(combined).pages),'paper_inches':[17,11], 'status':'PRELIMINARY - NOT FOR FABRICATION OR CONSTRUCTION', 'basis_values_verified_against_stage2':{'frame_length_in':G['frame_length_in'],'clear_length_in':G['clear_length_in'],'clear_width_in':G['clear_width_in'],'bogie_centres_in':G['bogie_centres_in'],'bogie_x_in':G['bogie_centre_x_in']},'sheet_dxf_units':'paper inches','model_dxf_units':'inches','generated_outputs':[Path(f).name for f in files],'export_checks':{'pdf_pages_17x11':all(tuple(float(x) for x in p.mediabox[2:])==(W,H) for p in PdfReader(combined).pages),'dxf_audit_errors':{p.name:len(ezdxf.readfile(p).audit().errors) for p in OUT.glob('*.dxf')},'svg_count':len(list(OUT.glob('*.svg')))},'visual_review':'PENDING'}
(OUT/'Stage3A_Drawings_Export_Validation_R0.json').write_text(json.dumps(validation,indent=2))
print(f'Created {len(S)} coordinated sheets, combined PDF, vector sources and interface DXF.')
