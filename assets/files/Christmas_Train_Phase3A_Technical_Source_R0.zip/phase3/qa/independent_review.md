# Phase 3A independent document QA

17 October 2026 · PF-TRAIN-S3A-R0 · Document review only; no engineering approval.

The preliminary package separates calculations, manufacturer examples and unresolved design decisions appropriately. I found no released member, weld, pin, brake circuit or track detail masquerading as construction approval. The significant initial drawing conflict was a four-inch overlap between the accessible aisle overlay and rear benches; the drawing agent has corrected the source geometry. Remaining notes below govern issue completion and subsequent engineering.

## Checks completed

- Independently reproduced all 96 brake stopping distances and their brake-work/energy identity. The model correctly subtracts downgrade acceleration from the assumed specific brake force and includes acceleration during the equivalent zero-brake delay. It explicitly excludes rotational inertia and actual buildup, so it is not a proven worst-case stopping envelope.
- Checked 12 traction force/power cases, four coupling-force signs, both HVAC humidity increments, nominal/stress train mass reconciliation, and the 42.926 m four-coach station envelope. Arithmetic passed.
- Checked lift, stair and frame interfaces. The Braun lift's 45.85-inch minimum clear doorway conflicts with the retained 42-inch door and remains unintegrated. Ground eight inches below rail creates a 36-inch total stair rise, so the four-rise seven-inch mockup does not fit that landing. The three-inch frame graphic is explicitly unengineered.
- Reviewed the 18-interface register and all five research modules. Source capabilities and ratings are consistently distinguished from approved selections; final applicability of standards and numerical acceptance criteria remains held.
- Inspected the nine-sheet contact image and individual A01, B01 and S01 images. Layouts are readable; functional diagrams are marked schematic and not for fabrication. Updated A01 geometry and S01/F01 labels were checked in regenerated source/PDF text. Refreshed A01/S01 images confirm the route and mockup wording corrections.

## Corrections and coordination notes

| ID | Finding | Disposition |
|---|---|---|
| QA01 | Initial A01 route y=-16…20 crossed benches ending at y=-12. | Corrected to the actual clear strip y=-12…24, x=60…306, with the front turning area and offset doors coordinated. This does not demonstrate maneuvering with occupied chairs. |
| QA02 | S01 said the clear area was “verified by mockup,” although no mockup occurred. | Regenerated PDF now says “to verify by mockup.” |
| QA03 | Original propulsion/drawing scripts depended on Stage 2 files outside the Phase 3 package. | Closed: frozen drawing and systems inputs are packaged; frame, propulsion and all nine drawing generators reproduced in a clean temporary directory using only Phase 3 files. Preserve the documented directory structure. |
| QA04 | The 65 t brake sensitivity allocates 13,170.765 kg per regular car and 10,987.704 kg accessible, exceeding frame stress cases of 11,825/9,865 kg. | L01/F01 now warn that adopting the upper allocation requires revising frame/bogie cases. Establish common individual-car maximum masses before design release. |
| QA05 | Propulsion launch uses starting resistance 0.010 and acceleration 0.10 m/s²; coupling example uses rolling resistance 0.005 and acceleration 0.15 m/s². | Closed for preliminary issue: brake text and JSON now distinguish both sensitivities and require engineer reconciliation before final design. |
| QA06 | Frame calculator updated its calculations inside the consolidated research JSON. | Changed to separate `frames_calculations.json`; all seven calculations match and the nine-source consolidated register remains intact. |

No physical tests, FEA, dynamic simulation, supplier availability or professional acceptance were verified. Root is separately opening key primary sources. Do not describe this QA as confirmation that the train is safe to build or operate.

## Owner steering received during review

The owner has now directed **0% longitudinal grade**. Frame static mass, cantilever, transverse CG and curve calculations are unchanged by this direction. Final propulsion, brake and track headlines now reflect this direction; the completed numerical check is recorded below. Crosslevel, twist, wind and local settlement remain separate issues; a level longitudinal design does not eliminate them.

Level-track propulsion check passed: at 65 t, starting force is 6.3743 kN; adding 0.10 m/s² acceleration gives 12.8743 kN and 8.7521 t required driven mass at assumed adhesion 0.15. Steady wheel power at 7.5 mph is 10.6859 kW; rolling with that acceleration gives 32.4791 kW. These remain sensitivity calculations, excluding curve and wind resistance.

## Final level-track coordination check

The final brake model passes independent recomputation: 24 level-track cases and 72 separately labeled off-design cases; the 65 t, 7.5 mph, three-second-delay results are **21.29966784 m service / 17.0841924 m emergency**, with **0.3653412 MJ** translational energy per ideal stop. All six level-track fault-study distances were reproduced. Parking remains required despite a zero nominal gravity term. The head-coupler launch sensitivity is **10.051179125 kN**, using its explicitly different 0.15 m/s² acceleration and 0.005 resistance case. The brake generator and consolidated JSON also reproduce in a clean temporary directory.

Workbook exported calculation-check values agree. Its 14.2479 kW input traction power is wheel power divided by efficiency; the propulsion report adds 10 kW assumed traction auxiliaries to reach 24.2479 kW. The final workbook now explicitly labels those exclusions and adds a separate input-plus-auxiliaries result (G43 = 24.247885652 kW); its exported calculation check passes. Final document QA is complete for this preliminary issue, with professional design and construction release holds unchanged.
