from pathlib import Path
import re,html,json
esc=html.escape
def inline(text):
 s=esc(str(text));s=re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)',r'<a href="\2" target="_blank" rel="noopener">\1 ↗</a>',s);s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s);s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s);return s
def table(headers,rows):return '<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+inline(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def markdown(text):
 lines=text.splitlines();out=[];buf=[];i=0;listing=None
 def flush():
  if buf:out.append('<p>'+inline(' '.join(buf))+'</p>');buf.clear()
 def close():
  nonlocal listing
  if listing:out.append('</'+listing+'>');listing=None
 while i<len(lines):
  line=lines[i].strip()
  if not line:flush();close();i+=1;continue
  if line.startswith('|') and i+1<len(lines) and re.match(r'^\s*\|?\s*:?-{3}',lines[i+1]):
   flush();close();heads=[x.strip() for x in line.strip('|').split('|')];rows=[];i+=2
   while i<len(lines) and lines[i].strip().startswith('|'):
    row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
    if len(row)==len(heads):rows.append(row)
    i+=1
   out.append(table(heads,rows));continue
  m=re.match(r'^(#{1,4})\s+(.+)$',line)
  if m:
   flush();close();n=max(2,len(m[1]));out.append(f'<h{n}>'+inline(m[2])+f'</h{n}>');i+=1;continue
  m=re.match(r'^([-*]|\d+\.)\s+(.*)$',line)
  if m:
   flush();typ='ul' if m[1] in ('-','*') else 'ol'
   if listing!=typ:close();out.append('<'+typ+'>');listing=typ
   out.append('<li>'+inline(m[2])+'</li>');i+=1;continue
  close();buf.append(line);i+=1
 flush();close();return '\n'.join(out)
