PF-TRAIN 3L.1 initial fabrication-interface issue.
This source contains original wheelset/axle and carrier interface drawings, exact OEM mating-pattern factual redraw, calculation code and evidence records.
It is not a fabrication-release package. DXF is a 2D OEM hole-pair interface in inches; it is not a carrier cut profile. Wheelset SVG is a dimension-chain/assembly study; no finished solid wheel/axle CAD is claimed.
Imported OEM manuals/images are not rehosted; use the canonical links. Builders may require the predecessor3K source package and installed drawing/CAD dependencies.
All delivery is through the existing technical site. Continue custom detail engineering in3L.2.
