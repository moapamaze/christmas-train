# Custom wheels, axles and brake attachment — fabrication development

Revision **PF-TRAIN-S3L-WHEEL-R0** • Reviewed 19 October 2026 UTC / 18 October 2026 Nevada time. Preliminary engineering for a fabrication package; production dimensions are not released.

## What we will build

Develop a **matched rigid wheelset**: two custom-machined monobloc rail wheels on one engineered rotating axle, carried by bearings in the bogie. Start with a qualified railway wheel blank, with the flange formed as part of that wheel. The farm can build much of the surrounding vehicle; the wheel profile, wheel/axle fits, heat treatment and wheelset pressing belong with a rail wheel machine shop.

The brake connection is a designed part of this assembly. Develop either **H-01A, a bolted disc on a machined integral wheel-hub mounting face**, or **H-01B, a separate engineered disc carrier on an axle seat**. Do not weld a generic rotor carrier to an axle, drill an arbitrary bolt circle into a finished wheel, or assume a clamp collar can carry braking torque. The brake architecture team must choose one interface and close its torque, temperature, fatigue and service-access requirements before we finish the axle and wheel drawings.

This is a genuine custom manufacturing route: [ORX's wheel page](https://orxrail.com/products/wheelsandtires.html) specifically describes machining wheel hubs for bolted brake discs and specialized profiles, and its [wheelset page](https://orxrail.com/products/wheelsets.html) explicitly includes narrow gauge. [Penn Machine](https://pennmach.com/products-resilient-solid-wheels/) offers custom forged solid wheels and design analysis. No supplier has yet accepted our dimensions, order size, application or delivery date. [WF01, WF03, WF04]

## What carries forward

Phase 3G identified its wheel, axle and bearing shapes as **symbols**, not accepted hardware. Phase 3K used 0.25 and 0.30 m rolling radii only as calculations. Neither supplied a fabrication-ready wheel.

Retain the 36 in / 914.4 mm gauge evaluation, four-axle coach analysis and 32 in raised-floor study. Gauge alone determines neither wheel back-to-back nor axle length. The rail head, wheel contact profile, flange gauge point, turnout check gauge and flangeway all need a coordinated drawing. We must check new and worn geometry, tolerance extremes and lateral motion. Smaller wheels also change brake packaging, contact stress and rotational speed; a blank's availability does not establish suitability.

## Loads already available to put on the engineering drawings

These are balanced, level-track analytical cases, not an accepted wheel/axle rating. Gravity is 9.80665 m/s².

| Case | Coach mass | Static load per axle | Static load per wheel |
|---|---:|---:|---:|
| Regular, upper screen | 13,200 kg | 32.362 kN | 16.181 kN |
| Regular, allocated tare | 7,040 kg | 17.260 kN | 8.630 kN |
| Accessible, upper screen | 11,000 kg | 26.968 kN | 13.484 kN |

For a regular coach with four equally braked axles, `F_axle = m × a / 4` and `T_axle = F_axle × D / 2`:

| Rolling-diameter probe | Torque/axle at 0.5 m/s² | Torque/axle at 0.7 m/s² | Speed at 7.5 mph |
|---|---:|---:|---:|
| 500 mm | 412.5 N·m | 577.5 N·m | 128.1 rpm |
| 600 mm | 495.0 N·m | 693.0 N·m | 106.7 rpm |

These demands exclude rotational inertia and unequal brake distribution. With equal left/right contact, each wheel contributes half the axle torque; a single axle disc and its carrier still transmit the whole axle torque. The joint and mount also require the **maximum physically achievable brake torque**, including parking application and credible simultaneous service/parking faults. Designing them only for the table would miss an important load case.

Before sizing the axle add the bearing-to-contact-point offsets, actual sprung/unsprung mass, lateral flange forces, track twist, load transfer, braking forces, impact/load factors and lifetime cycle spectrum. Existing coach-frame acceleration studies do not automatically define the correct wheelset fatigue loading.

## The part drawings to finish

| Part | Fabrication content | Evidence that sets the dimensions |
|---|---|---|
| **W-01, wheel** | Tread and flange coordinate profile; new/minimum worn diameters; rim width; bore; hub length/OD; web and fillet sections; disc mounting features if selected. Bore axis and back rim face are the principal drawing datums. | Matched rail/turnout geometry, wheel contact and fatigue analysis, braking thermal case, qualified blank and material class. |
| **A-01, axle** | Bearing journals, wheel seats, optional disc seat, shoulders, transitions, reliefs, end retention, common axis, lengths, surface finishes and runout controls. | Bearing selection and full combined-load/fatigue analysis, fit calculation and manufacturing process. |
| **H-01, brake interface** | Machined pilot/face and bolt group, or engineered press-fit carrier; axial location, runout, removal/tool clearance and thermal growth. | Selected rotor/caliper and rated torque, joint calculations and wheel/axle fatigue assessment. |
| **WS-01, wheelset assembly** | Back-to-back, wheel gauge at the defined profile datum, matched rolling diameters, bearing/disc positions, runout and serialized assembly acceptance. | One vehicle/track interface drawing, release tolerances and qualified assembly procedure. |

The accompanying dimension matrix lists each held item explicitly. It does not disguise an unknown bore, fit or flange geometry as a shop dimension.

## Material and process route

**Preferred development route:** forged/wrought monobloc wheel with integral flange, and a one-piece forged, heat-treated axle. [ASTM A504/A504M-18(2023)](https://store.astm.org/a0504_a0504m-18r23.html) is an active wheel specification covering material classes, treatment, hardness and inspection. [ASTM A729/A729M-17(2022)](https://store.astm.org/a0729_a0729m-17r22.html) covers heat-treated rail axles, including material/mechanical testing and nondestructive examination. These are candidate technical specifications, not asserted local legal requirements. We reviewed their public scope/abstract; the engineer and shop must obtain and use the full adopted specification. [WF06, WF07]

Do not select a wheel class solely because the train is slow, or specify ordinary 4140 bar as equivalent to a qualified railway axle. The required class, cleanliness, mechanical properties, treatment, fatigue performance and inspection must travel together. ORX's ability to machine several alloy families is manufacturing capability, not our material approval. [WF05]

**Alternative:** a qualified cast-steel rail wheel from a wheel manufacturer, with its own design and quality route. Amsted's published standard one-wear sizes start at 28 in, larger than the present 500/600 mm probes; its catalog is not evidence of a fitting small wheel. [WF10] A flame-cut plate wheel with a welded flange is not an established alternative in this package.

## How the wheel shop makes and assembles it

1. **Freeze interfaces:** wheel/rail profile, diameter and worn limits, bearing arrangement, back-to-back, brake attachment and removal sequence.
2. **Release drawings and process requirements:** wheel/axle detail and assembly drawings, material/class, treatment, tolerances, NDT and acceptance records.
3. **Buy traceable blanks:** approved forging/casting source and stock allowance; heat/lot and material certificates.
4. **Rough-machine and treat:** follow the approved sequence; preserve final-machining stock; record treatment and test results.
5. **Finish-machine:** profile and fit surfaces, transitions, runout and finish; inspect and record each serialized part.
6. **Match and press:** measure each bore and seat, control their temperature, use approved tooling/lubricant and record force versus displacement. Reject/disposition an unacceptable fit; welding or set screws are not a remedy.
7. **Install bearings and discs:** follow the selected interface and OEM instructions; inspect retention, preload/locking, runout and free rotation.
8. **First-article acceptance:** dimensional record, instrumented brake torque and hot/cold interface checks, full movement clearance and engineer disposition before production.

This proposed traveler is supported by railway manufacturing practice. APTA's [wheelset assembly standard](https://www.apta.com/wp-content/uploads/Standards_Documents/APTA-PR-M-S-019-17.pdf) addresses measured fits, pressing records and assembly qualification. Its large-axle tabulations must not be scaled into a guessed fit for this train. Its [axle design practice, Rev. 2](https://www.apta.com/wp-content/uploads/2026/05/APTA-PR-M-RP-008-98_R2.pdf), provides a useful framework for seats, transitions, material/process control and fatigue. Responsible engineering must choose a coherent technical basis and confirm applicability. [WF08, WF09]

## Calculations that turn the held fields into machining dimensions

For a preliminary solid circular axle section, nominal bending stress is `32M/(πd³)` and nominal torsional stress is `16T/(πd³)`. These are starting equations only. Local transitions, press-fit fretting, surface condition, residual stress, corrosion and alternating loads determine fatigue suitability; a yield-strength check alone cannot release A-01.

For an ideal cylindrical friction fit, `T = μ p π d² L / 2` and `F_axial = μ p π d L`. Actual interference requires shaft/hub elastic compatibility, material properties, geometry and hot/cold fit conditions. Unknown friction, hub stiffness and contact pressure are not substituted with convenient values. A wheel web and a short carrier can produce nonuniform pressure requiring a more complete model. Press force is a measured assembly acceptance variable, not an interchangeable torque rating.

Farm-crew scope now: build non-load-bearing fit mockups and protective handling aids to reviewed drawings; assist with later installation and inspection records under qualified supervision. Rail specialist scope: blanks, thermal processing, precision wheel/axle machining, NDT, pressing and wheelset dimensional acceptance. The custom brake bracket and bogie weldments can become local fabrication work after their calculations, drawings, weld procedures and inspection plan are released.

**Next concrete decision:** select the complete foundation brake and wheelset interface together, then freeze W-01/A-01/H-01 machining geometry. Do not order unmachined blanks until the wheel supplier confirms a viable blank and material/process route for that geometry.
