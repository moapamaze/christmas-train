from pathlib import Path
import html
P=Path(__file__).parent
S=[]
def add(v):S.append(v)
def txt(x,y,text,size=17,fill='#183a46',weight='400',anchor='start'):
 add(f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(text)}</text>')
def line(x1,y1,x2,y2,color='#234f5c',w=2,dash=None):
 add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{w}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
def box(x,y,w,h,fill='#fff',stroke='#a0b1b7'):
 add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{fill}" stroke="{stroke}"/>')
def dim(x1,y1,x2,y2,label,tx,ty):
 line(x1,y1,x2,y2,'#395f6d',1.4)
 if y1==y2:
  for x in [x1,x2]:line(x-5,y1-5,x+5,y1+5,'#395f6d',1.5)
 else:
  for y in [y1,y2]:line(x1-5,y-5,x1+5,y+5,'#395f6d',1.5)
 txt(tx,ty,label,16,'#254f5e','600')
add('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1180" role="img" aria-labelledby="title desc">')
add('<title id="title">L-W01 — custom wheelset and brake-disc fabrication interfaces</title><desc id="desc">Front section and exploded sequence of two custom monobloc wheels pressed on a rotating axle, an axle-mounted brake-disc carrier, and outboard bearings. 500 millimetre wheel and 12 inch rotor are fit studies. Machining dimensions are held for engineering.</desc>')
add('<style>text{font-family:Arial,Helvetica,sans-serif} .hold{fill:#a15c11}</style>')
box(0,0,1600,1180,'#f5f7f4','#f5f7f4')
txt(28,35,'L-W01  |  CUSTOM WHEELSET + BRAKE INTERFACES',26,weight='700')
txt(28,63,'Fabrication development • PF-TRAIN-S3L-WHEEL-R0 • 18 October 2026 Nevada time',16)
box(28,81,1544,514,'#fff')
txt(48,110,'A  FRONT SECTION — LOCATIONS AND DATUMS',20,weight='700')
txt(48,136,'Axial spacing and hub shapes are diagrammatic. Wheel and rotor rolling-plane diameters are proportioned.',16)
# rail line and wheels (axis at 340, 500-mm tread diameter shown as 300px)
line(180,340,1425,340,'#738d99',1.5,'12 6 3 6')
txt(1310,329,'A: rotation axis',15)
# axle, schematic shoulders
add('<path d="M292 324 H390 V316 H485 V310 H555 V319 H1045 V310 H1115 V316 H1210 V324 H1308 V356 H1210 V364 H1115 V370 H1045 V361 H555 V370 H485 V364 H390 V356 H292 Z" fill="#b8c8cf" stroke="#315968" stroke-width="2"/>')
# wheels (slim profile, flange beyond tread indicated)
add('<path d="M465 190 H515 V178 H532 V502 H515 V490 H465 V415 H489 V265 H465 Z" fill="#5f7e8a" stroke="#244855" stroke-width="2"/>')
add('<path d="M1135 190 H1085 V178 H1068 V502 H1085 V490 H1135 V415 H1111 V265 H1135 Z" fill="#5f7e8a" stroke="#244855" stroke-width="2"/>')
# axleboxes
for x in [334,1196]:
 box(x,292,70,96,'#dfe7e3','#355f59')
 box(x+17,307,36,66,'#9ec0b3','#355f59')
# disc + carrier
box(794,248.56,12,182.88,'#df9454','#90521f')
box(760,316,80,48,'#e9c5a3','#90521f')
# rail symbols
for x in [477,1085]:
 add(f'<path d="M{x} 490 h38 v12 h-12 v39 h19 v9 h-52 v-9 h19 v-39 h-12 Z" fill="#7a8e94"/>')
# Exact retained gauge between defined gauge faces, schematic axial spacing
line(515,490,515,561,'#738d99',1)
line(1085,490,1085,561,'#738d99',1)
dim(515,557,1085,557,'914.4 mm / 36 in TRACK GAUGE — evaluation basis',570,582)
# wheel diameter dimension
line(465,190,232,190,'#a1aeb3',1);line(465,490,232,490,'#a1aeb3',1)
dim(242,190,242,490,'500 mm tread Ø',55,236)
txt(55,258,'fit probe only',16,'#a15c11','600')
txt(55,283,'Flange outer Ø:',15)
txt(55,304,'HOLD with profile',15,'#a15c11','600')
# rotor dim and clearance
line(806,248.56,918,248.56,'#a1aeb3',1);line(806,431.44,918,431.44,'#a1aeb3',1)
dim(908,248.56,908,431.44,'304.8 mm / 12 in',930,279)
txt(930,301,'rotor fit study',16,'#a15c11','600')
line(806,431.44,878,431.44,'#a1aeb3',1);line(800,490,878,490,'#a1aeb3',1)
dim(868,431.44,868,490,'97.6 mm*',885,469)
# callouts
line(500,178,575,159);txt(577,164,'W-01 • one-piece wheel + integral flange',16,weight='600')
line(792,316,724,224);txt(600,209,'H-01B • engineered disc carrier',16,weight='600')
line(1200,292,1283,234);txt(1280,216,'Bearing + axlebox',16,weight='600')
txt(1258,243,'journal fit, retention',15);txt(1258,266,'and housing held',15,'#a15c11')
line(650,361,612,433);txt(550,453,'A-01 • one-piece rotating axle',16,weight='600')
# second panel exploded
box(28,613,960,384,'#fff')
txt(48,644,'B  EXPLODED ASSEMBLY — PARTS TO MANUFACTURE / SOURCE',20,weight='700')
txt(48,671,'Parts lifted off the axle for identification; actual pressing occurs axially with qualified tooling.',15)
line(72,908,944,908,'#738d99',1.5,'12 6 3 6')
# stylized axle + components
box(100,892,802,32,'#b8c8cf','#315968')
for x in [185,762]:
 box(x,711,35,134,'#5f7e8a','#244855')
 box(x+7,701,16,154,'#5f7e8a','#244855')
 line(x+17,858,x+17,889,'#738d99',1.4,'4 4')
for x in [110,872]:
 box(x,746,40,64,'#9ec0b3','#355f59')
 line(x+20,814,x+20,889,'#738d99',1.4,'4 4')
box(478,756,10,110,'#df9454','#90521f');box(460,789,48,44,'#e9c5a3','#90521f')
line(483,868,483,889,'#738d99',1.4,'4 4')
for x,t in [(130,'Bearing'),(201,'W-01'),(483,'Disc + H-01B'),(780,'W-01'),(892,'Bearing')]:txt(x,953,t,15,weight='600',anchor='middle')
txt(305,714,'Rotor joint: OEM pattern / joint design',15)
txt(305,739,'Carrier seat: torque + axial fit engineering',15)
txt(350,977,'WS-01 = inspected, serialized complete wheelset',16,weight='600')
# machining list right
box(1006,613,566,384,'#edf2ed')
txt(1025,646,'C  DIMENSIONS THAT RELEASE MACHINING',20,weight='700')
texts=[('W-01','Profile, bore, hub/web/rim, fillets and worn limits.'),('A-01','Journals, seats, shoulders, radii and end retention.'),('H-01B','Seat fit, hub/rotor joint, offset and runout.'),('WS-01','Back-to-back, matched Ø, gauge and runout.')]
y=681
for a,b in texts:
 txt(1025,y,a,17,weight='700');txt(1025,y+23,b,15);y+=64
txt(1025,945,'All above values: HOLD for coordinated release.',16,'#a15c11','700')
txt(1025,974,'See the part dimension matrix and shop traveler.',15)
# notes
box(28,1015,1544,135,'#fff4e4','#d8b583')
txt(48,1044,'* 97.6 mm = 500/2 − 304.8/2. This is rotor-edge height above rail for a new wheel, not approved running clearance.',17,weight='600')
txt(48,1071,'The caliper extends beyond the disc. Check worn wheel diameter, flange, track hardware, suspension, axlebox movement and bogie yaw.',16)
txt(48,1097,'No bore fit, bolt pattern, flange profile, axle diameter, material class or NDT acceptance is released by this drawing.',16)
txt(48,1126,'GEOMETRY STUDY • NOT A CUT FILE • NO WELD-ON FLANGE / AXLE CARRIER • NOT FOR FABRICATION',17,'#925719','700')
txt(30,1173,'Sources: WF01–WF09 in the linked wheel fabrication source register. Drawing is our interface study, not an OEM wheelset drawing.',14)
add('</svg>')
(P/'L-W01_Wheelset_Fabrication_Interfaces_R0.svg').write_text('\n'.join(S))
print('SVG saved')
