# Phase 3L.1 brake fabrication interfaces — I0

Website assets only; no PDF was produced.

- BF-01_Tolomatic_ME220MEFI_Interface_R0.svg: OEM mounting pattern and conditional assembly datum drawing.
- BF-02_Custom_Carrier_Integration_R0.svg: axlebox-referenced carrier concept, plan and axial section.
- BF-03_Caliper_Mount_Free_Body_R0.svg: isolated-caliper load case, linked to the mount calculation results.
- BF-01_OEM_Interface_Inches_R0.dxf: editable CAD reference, inch units. The true pair datum is hole H1=(0,0); H2=(4.750,0). The rotor and OEM bracket outline are reference geometry with assumed centering. This is not a carrier cut file.
- BF-01_Interface_Parameters_R0.json: facts, assumptions and held production dimensions.
- verification.json: XML, DXF hole count/diameter/pitch/datum and units checks.

Three PNGs are QA renders. Original SVGs should be used for the website zoom viewer.

Source: https://www.tolomatic.com/products/product-details/me220-mechanical-disc-brake/ — manufacturer dimensional sheet retrieved 2026-10-19. Exact assembly 0745-0024 is ME220MEFI, cast iron, floating bracket for a fixed 0.500-inch disc. Evidence review confirmed 4.750-inch mounting pitch and 0.386-inch OEM bracket holes. Horizontal centering of the bracket hole pair relative to the axle/lever projection is not explicitly dimensioned and remains an assembly-study assumption pending controlled OEM CAD/physical inspection. A, B and C remain the catalog labels, not invented bracket offset dimensions.

BF-03 values are read from ../mount_calculations/carrier_results_R0.json. Loads are analytical demands, not hardware ratings. Carrier plate, bolt group, torque link, axlebox attachments, wheelset, rotor attachment, chamber linkage and force limits remain unreleased.

The earlier ../brake-mechanism.js generic explainer was superseded by the user’s direction to prioritize fabrication drawings; do not publish it as the current fabrication response.
