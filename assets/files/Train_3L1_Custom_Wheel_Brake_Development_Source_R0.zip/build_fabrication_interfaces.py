from pathlib import Path
import json, math, hashlib, xml.etree.ElementTree as ET
import ezdxf
from ezdxf.enums import TextEntityAlignment

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'fabrication_interfaces'
OUT.mkdir(exist_ok=True)
INK='#173547'; FIX='#315f70'; ROT='#b96c22'; RED='#b6423c'; MUT='#536b79'; HELD='#93631f'; PALE='#edf3f6'
parts=[]
def txt(x,y,t,size=19,fill=INK,weight='normal',anchor='start'):
    import html
    return f'<text x="{x}" y="{y}" font-family="Arial,Helvetica,sans-serif" font-size="{size}" fill="{fill}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(str(t))}</text>'
def path(d,c=INK,w=2,dash=''):
    return f'<path d="{d}" fill="none" stroke="{c}" stroke-width="{w}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def rect(x,y,w,h,fill='white',stroke=INK,sw=2,dash=''):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def circle(x,y,r,c=INK,fill='white',w=2):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{c}" stroke-width="{w}"/>'
def dh(x1,x2,y,label,ext=None,color=INK):
    out=path(f'M{x1} {y}H{x2}',color,1.5)
    for x in [x1,x2]:
        out+=path(f'M{x-5} {y+6}L{x+5} {y-6}',color,1.5)
        if ext is not None:out+=path(f'M{x} {ext}V{y-7}',color,1)
    return out+txt((x1+x2)/2,y-12,label,19,color,'bold','middle')
def dv(y1,y2,x,label,ext=None,color=INK):
    out=path(f'M{x} {y1}V{y2}',color,1.5)
    for y in [y1,y2]:
        out+=path(f'M{x-6} {y+5}L{x+6} {y-5}',color,1.5)
        if ext is not None:out+=path(f'M{ext} {y}H{x+7}',color,1)
    return out+txt(x-14,(y1+y2)/2,label,18,color,'bold','end')
def title(number,title,sub):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1080" viewBox="0 0 1600 1080" role="img" aria-label="{title}"><rect width="1600" height="1080" fill="white"/>'+rect(18,18,1564,1044,'white',INK)+txt(45,58,f'{number}  {title}',28,INK,'bold')+txt(45,90,sub,18,MUT)+path('M35 110H1565',INK,2)
def footer(num):
    return path('M35 1009H1565',INK,2)+txt(45,1040,'PF-TRAIN-S3L.1-I0  |  19 OCT 2026  |  PRELIMINARY INTERFACE STUDY — NOT RELEASED FOR FABRICATION',17,HELD,'bold')+txt(1545,1040,num,19,INK,'bold','end')+'</svg>'

S=45;cx=430;cy=645
def X(v):return cx+S*v
def Y(v):return cy-S*v

svg=title('BF-01','REAL CALIPER MOUNTING INTERFACE','Tolomatic ME220MEFI · assembly 0745-0024 · cast iron · floating bracket / fixed disc · dimensions in inches [mm]')
svg+=txt(55,150,'VIEW NORMAL TO DISC',22,INK,'bold')+txt(55,176,'OEM pitch / vertical offsets; centered alignment is assumed.',17,MUT)
svg+=circle(cx,cy,6*S,ROT,'#fcf3e9',3)+circle(cx,cy,1.05*S,ROT,'#f1dac0',2)
svg+=path(f'M{cx-335} {cy}H{cx+335}M{cx} 205V955',MUT,1.2,'12 6 3 6')
svg+=rect(X(-3.5),Y(7.62),7*S,2.92*S,'#e6eef2',FIX,2,'8 5')
svg+=path(f'M{X(-3.8)} {Y(7.17)}H{X(3.8)}',MUT,1.2,'12 6 3 6')
svg+=circle(X(-2.375),Y(7.17),.193*S,FIX,'white',2)+circle(X(2.375),Y(7.17),.193*S,FIX,'white',2)
for x in [-2.375,2.375]:svg+=path(f'M{X(x)-13} {Y(7.17)}H{X(x)+13}M{X(x)} {Y(7.17)-13}V{Y(7.17)+13}',FIX,1)
svg+=circle(cx,Y(5),.32*S,FIX,'white',2)+path(f'M{cx-55} {Y(5)}H{cx+55}',MUT,1,'10 5')
svg+=txt(cx+35,Y(5)+7,'L — lever/cam axis',18,FIX,'bold')+txt(cx+30,cy+30,'O — axle / disc axis',19,ROT,'bold')
svg+=dh(X(-2.375),X(2.375),237,'4.750 [120.65] OEM hole pitch',Y(7.17),FIX)
svg+=dv(Y(5),Y(7.17),205,'2.17 [55.1]',X(-2.375),FIX)
svg+=dv(cy,Y(5),125,'',cx,ROT)+txt(81,526,'D = 5.00',18,ROT,'bold','middle')+txt(81,551,'[127.0]',18,ROT,'bold','middle')
svg+=path(f'M{X(2.375)+8} {Y(7.17)}L715 300H790',FIX,1.5)+txt(675,276,'2 × Ø0.386 [9.80]',19,FIX,'bold')+txt(697,323,'OEM bracket holes',17,FIX)
svg+=path(f'M{X(3.5)} {Y(7.62)}L718 366H795',MUT,1.5)+txt(680,392,'OEM bracket',17,MUT)+txt(680,416,'envelope ONLY',17,MUT)+txt(680,440,'7.00 × 2.92',18,FIX,'bold')
svg+=dh(X(-6),X(6),949,'Ø12.00 [304.8] ROTOR FIT STUDY ONLY',cy,ROT)
svg+=txt(55,985,'No custom carrier perimeter, bolt size, plate thickness, or manufacturing tolerance is released.',17,HELD,'bold')
svg+=rect(850,138,687,356,'#f2f6f8','#c3d1d8',1)
svg+=txt(875,173,'COORDINATES FOR CAD / MACHINIST REVIEW',21,INK,'bold')
rows=[('True pair datum','H1 = (0, 0); H2 = (4.750, 0)'),('Lever Y','2.170 below hole line — OEM'),('Axle Y','7.170 below hole line — derived'),('Study X','±2.375 about axle — ASSUMED'),('Hole diameter','0.386 — hole in OEM bracket'),('Derivation','7.170 = D 5.000 + OEM 2.170')]
for i,(a,b) in enumerate(rows):svg+=txt(875,211+i*43,a,18,FIX,'bold')+txt(1045,211+i*43,b,18)
svg+=txt(875,475,'DXF origin = H1. Controlled OEM CAD must confirm centering.',16,MUT)
svg+=txt(875,538,'PART-SPECIFIC ENVELOPE',22,INK,'bold')
for i,t in enumerate(['ME220MEFI / 0745-0024: cast-iron, floating-bracket type.','Disc thickness = 0.500 in [12.7 mm].','OEM axial dimensions: A = 0.844, B = 3.80, C = 5.98 in.','Use the OEM sheet for the A/B/C datum definitions.','For the 12-inch rotor row: effective braking radius = 5.08 in.']):svg+=txt(875,575+i*31,t,18)
svg+=rect(850,760,687,218,'#fff6e3','#d4b16e',1)+txt(875,795,'WHAT THIS DRAWING ALLOWS',21,HELD,'bold')
for i,t in enumerate(['A fabricator can locate the real OEM mounting holes and','reserve the bracket interface. Full caliper / lever travel','clearance is still required. Rotor thermal, fatigue and','rail-service qualification remain open. Verify OEM revision','and physical part before drilling any production bracket.']):svg+=txt(875,831+i*28,t,18,HELD)
svg+=footer('BF-01')
(OUT/'BF-01_Tolomatic_ME220MEFI_Interface_R0.svg').write_text(svg)

svg=title('BF-02','AXLEBOX-REFERENCED BRAKE CARRIER','Custom wheelset / disc / caliper carrier integration · arrangement and connection study · not to scale')
svg+=txt(50,150,'PLAN — LOOKING DOWN ON ONE WHEELSET',22,INK,'bold')
# Plan wheels, axleboxes, shaft and rotor.
svg+=rect(160,428,1130,34,'#edcfb1',ROT,3)
for x in [320,1100]:svg+=rect(x,312,45,268,'#f4e0ca',ROT,3)
for x in [190,1240]:svg+=rect(x,382,78,126,'#e0e9ee',FIX,3)
svg+=rect(711,330,19,230,'#edcfb1',ROT,3)
svg+=path('M226 390V275H1277V390',FIX,23)
svg+=rect(669,277,105,80,'#d4e3e9',FIX,3)
svg+=path('M710 275V245L520 185',FIX,5,'10 6')
svg+=circle(710,245,10,FIX,'white',3)+circle(520,185,10,FIX,'white',3)
svg+=rect(430,168,195,25,'#d4e3e9',FIX,3)
svg+=txt(60,207,'Sprung bogie frame',18,FIX,'bold')+path('M266 201H420',MUT,1.5)
svg+=txt(795,190,'Articulated torque-reaction link — concept only',19,HELD,'bold')+txt(795,217,'Joint type, restraints and allowable travel HELD',18,HELD)+path('M795 225H730L680 236',MUT,1.5)
svg+=txt(330,247,'Carrier follows axlebox motion',18,FIX,'bold')
svg+=txt(812,335,'OEM caliper + floating bracket',19,FIX,'bold')+path('M805 342L775 330',MUT,1.5)
svg+=txt(810,382,'Custom carrier interface',18,HELD,'bold')+txt(810,406,'uses BF-01 hole locations',18,HELD)+path('M800 376L773 300',MUT,1.5)
svg+=txt(460,492,'Axle — rotates',18,ROT,'bold')+txt(750,533,'Fixed-to-axle rotor',18,ROT,'bold')+path('M747 525L730 510',MUT,1.5)
svg+=txt(50,555,'Nonrotating axlebox',18,FIX,'bold')+path('M205 536L229 507',MUT,1.5)
svg+=txt(1100,614,'Flanged wheel',18,ROT,'bold')+path('M1130 591V580',MUT,1.5)
svg+=path('M365 610H1100',MUT,1.2,'12 6')+txt(732,638,'Wheel back-to-back B — derived from selected wheel / rail profile, NOT 36 in',18,HELD,'bold','middle')
# Lower coordinated section.
svg+=path('M40 665H1560',MUT,1.5)+txt(50,703,'AXIAL SECTION THROUGH ROTOR / CALIPER',22,INK,'bold')
svg+=rect(140,845,525,26,'#edcfb1',ROT,2)+rect(376,733,20,200,'#edcfb1',ROT,2)
svg+=rect(344,748,18,69,'#f0d7d6',RED,2)+rect(410,748,18,69,'#f0d7d6',RED,2)
svg+=path('M327 808V717H445V808',FIX,15)+rect(270,710,46,113,'#d4e3e9',FIX,2)
svg+=path('M140 737H265',FIX,12,'10 6')
svg+=dh(376,396,971,'t = 0.500 in [12.7 mm] OEM-compatible disc thickness',933,ROT)
svg+=txt(66,901,'Carrier plate and offset',17,HELD,'bold')+txt(66,924,'t_c / z_c — HELD',17,HELD)+path('M229 899L282 825',MUT,1.5)
svg+=txt(475,749,'OEM float remains free',18,FIX,'bold')+txt(475,775,'Do not clamp the sliding function.',17,FIX)+path('M469 781L440 789',MUT,1.5)
svg+=rect(765,696,772,287,'#f2f6f8','#c3d1d8',1)+txt(788,731,'CONNECTIONS TO ENGINEER BEFORE CUTTING',21,INK,'bold')
for i,t in enumerate(['1. Rotor → hub / axle: torque, fatigue, fit and retention.','2. Caliper → carrier: BF-01 pattern; bolt group and plate bending.','3. Carrier → axleboxes: fasteners, local stress and bearing clearance.','4. Carrier → bogie reaction: link load and full primary-suspension motion.','5. Chamber → lever: force reduction, stroke, angularity and wear reserve.','6. Entire assembly: disc runout, float, radial overlap and service access.','The 36-inch track gauge is a rail datum; it does not specify wheel spacing.']):svg+=txt(788,769+i*29,t,18,INK if i<6 else HELD)
svg+=footer('BF-02')
(OUT/'BF-02_Custom_Carrier_Integration_R0.svg').write_text(svg)

calc_path=ROOT/'mount_calculations'/'carrier_results_R0.json'
calc=json.loads(calc_path.read_text())
cases=calc['ME220_actual_interface']['mount_free_body_cases']
dcase=next(c for c in cases if c['id']=='highest_demand_dynamic' and c['disc_force_sign']==-1 and c['lever_force_sign']==1)
ucase=next(c for c in cases if c['id']=='catalog_cast_iron_660lbf_dynamic_sensitivity' and c['disc_force_sign']==-1 and c['lever_force_sign']==1)
svg=title('BF-03','CALIPER MOUNT — FREE-BODY LOAD STUDY','BF-01 centered-layout assumption · isolated caliper reactions · analytical case, not a brake or bolt rating')
svg+='<defs><marker id="force-tip" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8Z" fill="'+RED+'"/></marker><marker id="reaction-tip" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8Z" fill="'+FIX+'"/></marker></defs>'
def arrow(x1,y1,x2,y2,c,marker):
    angle=math.atan2(y2-y1,x2-x1);bx=x2-15*math.cos(angle);by=y2-15*math.sin(angle);px=7*math.sin(angle);py=-7*math.cos(angle)
    return path(f'M{x1} {y1}L{x2} {y2}',c,4)+f'<polygon points="{x2},{y2} {bx+px},{by+py} {bx-px},{by-py}" fill="{c}"/>'
svg+=txt(50,150,'REACTIONS ON ISOLATED CALIPER',22,INK,'bold')+txt(50,177,'Arrows show direction only. Diagram is not a force-scale plot.',17,MUT)
cx3=410;cy3=800;s3=45
xx=lambda x:cx3+s3*x;yy=lambda y:cy3-s3*y
svg+=path(f'M{xx(-6)} {cy3}A{6*s3} {6*s3} 0 0 1 {xx(6)} {cy3}',ROT,2)
svg+=path(f'M{xx(-6.7)} {cy3}H{xx(6.7)}M{cx3} 285V900',MUT,1.1,'12 6 3 6')
svg+=rect(xx(-3.5),yy(7.62),7*s3,2.92*s3,'#eef3f6',FIX,1.5,'8 5')
for x in [-2.375,2.375]:svg+=circle(xx(x),yy(7.17),.193*s3,FIX,'white',2)
svg+=dh(xx(-2.375),xx(2.375),380,'4.750 in / 120.65 mm',yy(7.17),FIX)
svg+=circle(xx(-4),yy(5),5,RED,RED,1)+circle(xx(0),yy(5.08),5,RED,RED,1)
svg+=path(f'M{xx(-4)} {yy(5)}H{cx3}',MUT,1.3,'8 5')
svg+=arrow(xx(-4),yy(5),xx(-4),yy(5)-98,RED,'force-tip')
svg+=arrow(xx(0),yy(5.08),xx(0)-95,yy(5.08),RED,'force-tip')
svg+=arrow(xx(-2.375),yy(7.17),xx(-2.375)+57,yy(7.17)+71,FIX,'reaction-tip')
svg+=arrow(xx(2.375),yy(7.17),xx(2.375)+57,yy(7.17)-56,FIX,'reaction-tip')
svg+=txt(55,243,'R1 on caliper',20,FIX,'bold')+txt(55,271,'(+2.820, −3.497) kN',19,FIX)+path(f'M210 280L{xx(-2.375)+20} {yy(7.17)+28}',FIX,1.3)
svg+=txt(505,243,'R2 on caliper',20,FIX,'bold')+txt(505,271,'(+2.820, +2.740) kN',19,FIX)+path(f'M618 280L{xx(2.375)+34} {yy(7.17)-35}',FIX,1.3)
svg+=txt(55,647,'Lever input: +0.757 kN upward',19,RED,'bold')+txt(55,675,'Assumed point (−4.00, +5.00) in',18,HELD)+path(f'M250 626L{xx(-4)} {yy(5)+8}',RED,1.3)
svg+=txt(452,612,'Disc friction load:',18,RED,'bold')+txt(452,640,'−5.639 kN to left',19,RED,'bold')+txt(452,668,'Point (0, +5.08) in',18,RED)+path(f'M452 600L{cx3} {yy(5.08)+8}',RED,1.3)
svg+=txt(435,836,'O — axle / disc axis',19,ROT,'bold')+txt(55,920,'Forces ON THE CARRIER are opposite R1 and R2.',19,FIX,'bold')+txt(55,949,'The carrier must also account for out-of-plane offsets and its own supports.',17,HELD)
svg+=rect(850,139,687,398,'#f2f6f8','#c3d1d8',1)+txt(875,176,'EXAMPLE DESIGN-DEMAND CASE',22,INK,'bold')
for i,t in enumerate(['13,200 kg coach; 4 braked axles assumed.','a = 0.7 m/s²; wheel radius = 0.30 m (probe).','5% rotational-inertia allowance (assumed).',f'Axle brake torque = {dcase["resulting_axle_brake_torque_Nm"]:.2f} N·m.',f'Lever force = {abs(dcase["assumed_lever_input_force_N"])/1000:.3f} kN from OEM equation.',f'Applied moment at hole midpoint = {dcase["moment_at_bolt_midpoint_Nm"]:.2f} N·m.',f'Peak load transferred at one hole = {dcase["peak_in_plane_point_load_N"]/1000:.3f} kN.']):svg+=txt(875,215+i*39,t,18)
svg+=txt(875,509,'The chosen force directions maximize the moment in this case.',16,MUT)
svg+=rect(850,567,687,413,'#fff6e3','#d4b16e',1)+txt(875,605,'THIS DOES NOT SIZE THE BRACKET',22,HELD,'bold')
for i,t in enumerate([f'Catalog 660 lbf input sensitivity gives {ucase["peak_in_plane_point_load_N"]/1000:.3f} kN','at one hole in this in-plane model — much more than','the example demand. 660 lbf is the cast-iron catalog','value; 580 lbf covers aluminum. Confirm exact cast-iron','instructions and the assumed 4-inch input location.','','No out-of-plane offset, prying, preload, local bearing,','fatigue, heat, corrosion or jam qualification is included.','Carrier plate, fasteners and joints remain unselected.']):svg+=txt(875,644+i*33,t,18,HELD)
svg+=footer('BF-03')
(OUT/'BF-03_Caliper_Mount_Free_Body_R0.svg').write_text(svg)

doc=ezdxf.new('R2010');doc.units=1;doc.header['$INSUNITS']=1
for name,color in [('OEM_HOLES',5),('OEM_REFERENCE',4),('STUDY_ROTOR',30),('CENTERLINES',8),('DIMENSIONS',7),('NOTES',7)]:doc.layers.new(name,dxfattribs={'color':color})
m=doc.modelspace()
m.add_circle((-2.375,7.17),.386/2,dxfattribs={'layer':'OEM_HOLES'})
m.add_circle((2.375,7.17),.386/2,dxfattribs={'layer':'OEM_HOLES'})
m.add_lwpolyline([(-3.5,4.70),(3.5,4.70),(3.5,7.62),(-3.5,7.62)],close=True,dxfattribs={'layer':'OEM_REFERENCE'})
m.add_circle((0,0),6,dxfattribs={'layer':'STUDY_ROTOR'})
m.add_point((0,0),dxfattribs={'layer':'CENTERLINES'});m.add_point((0,5),dxfattribs={'layer':'CENTERLINES'})
for a,b in [((-7,0),(7,0)),((0,-7),(0,9)),((-4,7.17),(4,7.17)),((-.5,5),(.5,5))]:m.add_line(a,b,dxfattribs={'layer':'CENTERLINES'})
dimoverride={'dimtxt':.16,'dimasz':.12,'dimexo':.07,'dimexe':.09,'dimtad':1,'dimdec':3}
m.add_linear_dim(base=(0,8.5),p1=(-2.375,7.17),p2=(2.375,7.17),override=dimoverride,dxfattribs={'layer':'DIMENSIONS'}).render()
m.add_linear_dim(base=(-7.3,0),p1=(0,0),p2=(0,5),angle=90,override=dimoverride,dxfattribs={'layer':'DIMENSIONS'}).render()
m.add_linear_dim(base=(-6.0,5),p1=(0,5),p2=(-2.375,7.17),angle=90,override=dimoverride,dxfattribs={'layer':'DIMENSIONS'}).render()
notes=[(9,8.5,'BF-01 / ME220MEFI 0745-0024 OEM INTERFACE'),(9,8.0,'INCHES. REFERENCE ONLY - NOT A CARRIER CUT FILE.'),(9,7.5,'2 HOLES DIA 0.386. PITCH 4.750.'),(9,7.0,'TRUE PAIR DATUM: H1(0,0); H2(4.750,0).'),(9,6.5,'AXLE-CENTERED X LAYOUT IS ASSUMED, NOT OEM DATUM.'),(9,6.0,'7.170 = OEM D 5.000 + OEM OFFSET 2.170.'),(9,5.5,'RECTANGLE IS BRACKET ENVELOPE; CENTERING ASSUMED.'),(9,5.0,'DIA 12 ROTOR IS FIT STUDY; THICKNESS 0.500.'),(9,4.5,'NO CUSTOM PERIMETER, THICKNESS, BOLT OR TOLERANCE.'),(9,4.0,'VERIFY OEM REVISION AND PHYSICAL PART BEFORE PRODUCTION.')]
for x,y,t in notes:m.add_text(t,dxfattribs={'height':.20,'layer':'NOTES'}).set_placement((x,y))
# Shift all reference geometry so the left OEM hole is the true datum.
from ezdxf.math import Matrix44
for ent in list(m):
    if ent.dxf.layer!='NOTES':
        try:ent.transform(Matrix44.translate(2.375,-7.17,0))
        except (AttributeError,NotImplementedError):pass
dxfpath=OUT/'BF-01_OEM_Interface_Inches_R0.dxf';doc.saveas(dxfpath)
facts={'revision':'PF-TRAIN-S3L.1-I0','status':'Preliminary interface study, not released for fabrication','units':'in','part':'Tolomatic ME220MEFI','assembly':'0745-0024','candidate_only':True,'disc_diameter_fit_study':12,'disc_thickness_oem':.5,'hole_diameter_oem':.386,'hole_pitch_oem':4.75,'lever_axis_oem_for_12in_disc':[0,5],'true_hole_pair_datum':[[0,0],[4.75,0]],'assembly_holes_with_centering_assumption':[[-2.375,7.17],[2.375,7.17]],'assembly_x_status':'Assumes hole-pair midpoint aligned with axle/lever projection; not explicitly dimensioned by OEM; controlled CAD needed','hole_y_derivation':'5.000 + 2.170 = 7.170','oem_bracket_envelope':{'width':7,'height':2.92,'top_above_hole_line':.45},'A_oem':.844,'B_oem':3.80,'C_oem':5.98,'effective_braking_radius_oem_for_12in_disc':5.08,'source':'Tolomatic ME220 manufacturer dimensional sheet, retrieved 2026-10-19; see evidence register','held':['custom carrier outer profile','custom plate thickness','fastener grade, diameter, engagement, preload','wheel and axle geometry and fits','rotor hub attachment','disc material/thermal qualification','torque-link joints and primary suspension clearances','chamber/linkage/caliper compatibility']}
(OUT/'BF-01_Interface_Parameters_R0.json').write_text(json.dumps(facts,indent=2))
checks=[]
for p in OUT.glob('*.svg'):
    ET.parse(p);checks.append({'file':p.name,'check':'SVG XML parses','passed':True})
re=ezdxf.readfile(dxfpath);holes=list(re.modelspace().query('CIRCLE[layer=="OEM_HOLES"]'))
checks.append({'check':'Two exact OEM holes','passed':len(holes)==2 and all(abs(h.dxf.radius-.193)<1e-12 for h in holes)})
checks.append({'check':'OEM hole pitch 4.750 in','passed':abs(abs(holes[1].dxf.center.x-holes[0].dxf.center.x)-4.75)<1e-12})
checks.append({'check':'True hole-pair datum H1(0,0), H2(4.750,0)','passed':all(abs(h.dxf.center.y)<1e-12 for h in holes) and abs(holes[0].dxf.center.x)<1e-12 and abs(holes[1].dxf.center.x-4.75)<1e-12})
checks.append({'check':'DXF INSUNITS inches','passed':re.header['$INSUNITS']==1})
(OUT/'verification.json').write_text(json.dumps({'checks':checks,'passed':all(x['passed'] for x in checks)},indent=2))
print(json.dumps({'files':[p.name for p in OUT.iterdir()],'checks':checks},indent=2))
