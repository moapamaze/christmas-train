from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,xml.etree.ElementTree as ET,ezdxf
P=Path(__file__).resolve().parent;S=Path('/workspace/sites/pulsipher-train-review/dist');A=S/'assets/fabrication-l1'
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.rows=[]
 def handle_starttag(self,t,a):self.rows.append(dict(a))
p=Parser();p.feed((S/'index.html').read_text());ids=[r['id'] for r in p.rows if 'id' in r];assert len(ids)==len(set(ids))
for r in p.rows:
 for k in ['href','src']:
  u=r.get(k,'')
  if not u or ':' in u or u.startswith('//'):continue
  if u.startswith('#'):assert u[1:] in ids,u
  else:assert (S/u.split('#')[0]).exists(),u
for name in ['fabrication','wheelset','wheelset-drawings','wheelset-loads','wheelset-manufacturing','brake-page-drawing-reader']:assert name in ids
svg=list(A.rglob('*.svg'));assert len(svg)==4
for f in svg:ET.parse(f)
d=ezdxf.readfile(A/'fabrication_interfaces/BF-01_OEM_Interface_Inches_R0.dxf');assert d.units==1
holes=[x for x in d.modelspace().query('CIRCLE') if abs(2*x.dxf.radius-.386)<1e-6];assert len(holes)==2
coords=sorted((round(c.dxf.center.x,6),round(c.dxf.center.y,6)) for c in holes);assert coords==[(0,0),(4.75,0)],coords
for f in A.rglob('*'):
 if f.is_file() and f.suffix in ('.svg','.json','.md','.py','.dxf'):
  rel=f.relative_to(A);src=P/rel
  if src.exists():assert hashlib.sha256(f.read_bytes()).digest()==hashlib.sha256(src.read_bytes()).digest(),str(rel)
for doc in json.loads((S/'assets/documents.json').read_text())['documents']:
 assert (S/doc['pdf']).exists()
 for pg in doc['pages']:assert (S/pg['image']).exists()
state=json.loads((S/'assets/engineering-program-state.json').read_text());assert state['current_stage']=='3L';assert not [s for s in state['stage_map'] if s['id']=='3L'][0]['desktop_issue_complete']
assert not list(A.rglob('*.pdf'))
report={'result':'PASS bounded static/site coordination checks','unique_html_ids':len(ids),'new_original_drawings':len(svg),'dxf_units':'inches','dxf_hole_pair':coords,'user_destination':'Site only','browser_interaction_tested':False,'scope':'Link/asset integrity, drawing XML, exact DXF pattern, source copies, preserved old readers and open3L status; not hardware/fabrication approval.'}
(P/'site_validation.json').write_text(json.dumps(report,indent=2));(A/'site_validation.json').write_text(json.dumps(report,indent=2));print(report)
