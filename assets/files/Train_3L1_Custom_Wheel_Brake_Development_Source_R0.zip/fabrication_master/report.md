# Custom fabrication: the complete train

**The design target is a complete custom-built train, with drawings that show how each part is made and how the parts connect.** The next work must develop the wheelsets, bogies and mechanical brakes together. The existing brake diagrams explain control and forces, but do not yet define a manufacturable brake carrier, wheel, axle or bogie.

This direction applies to the locomotive, both coach types, running gear, couplings, platforms, stairs and installation interfaces. Engines, bearings, air chambers, valves and friction wear parts can be specified manufactured components within those custom assemblies. Their exact interfaces must appear in our drawings; a generic cylinder or an instruction to “fit suitable brakes” is not sufficient. A purchased complete bogie remains a benchmark or fallback, rather than the assumed solution.

**Current status:** Phases through 3K are desktop review packages. No assembly has a fabrication release, and no physical manufacturing or brake test is claimed. Earlier frame dimensions and CAD are useful development work; they do not establish that the complete train can already be fabricated from them.

## Immediate package: 3L.1 — wheelset and brake carrier

The immediate deliverable is a small, coordinated assembly that a rail engineer and machine/fabrication shop can work through together:

1. **Wheelset assembly:** section through both wheels, axle, bearings, housings and retention; declared datums; rail/profile interface; wheel and axle detail sheets; bearing stack; brake torque-transfer interface.
2. **Mechanical brake assembly:** assembled side, plan and section views; exploded view; chamber, carrier, reaction structure, linkage or caliper, friction surface, adjustment, retention and guards. Show the load path into the bogie and the torque path into the wheelset.
3. **Individual custom parts:** carrier, chamber bracket, levers/pivots as applicable, rotor/hub adapter or tread-shoe supports, fasteners and welded joints. Every part has its own identifier and a corresponding BOM entry.
4. **Fit and movement checks:** actuator stroke, worn/new friction conditions, pad/shoe clearance, wheel and bearing removal, chamber tool access, suspension travel, yaw and full tolerance stack.
5. **Manufacturing and inspection plan:** raw material and process requirements, machining sequence, fixtures, first-article measurements, weld/NDT requirements and instrumented brake tests with acceptance values set by the responsible engineer.

The first dependency is the mechanical brake architecture and its actual component interfaces. Disc and tread arrangements cannot share one generic bracket drawing. Final wheel profile/back-to-back depends on the selected rail and turnout interface; final axle seats depend on the wheel, bearing and torque-transfer fits. Final chamber bracket and linkage depend on documented service and spring force versus travel, including wear adjustment. These unresolved interfaces will be called out by name, rather than hidden behind a completed-looking model.

The sequence is **design basis → wheel/axle/bearing stack → brake carrier/linkage → controlled first article → complete bogie**. Preliminary dimensions can support packaging and calculations before release. Safety-critical production dimensions, material conditions and acceptance values cannot be supplied merely to fill a blank.

## What will be custom drawn

| Family | Parts and interfaces to develop | Existing coverage / main dependency |
|---|---|---|
| **LO — Locomotive** | Main frame, cab/body, engine/drive mounts, cooling/exhaust supports, guards, controls and maintenance panels | Propulsion alternatives exist; selected engine/drive geometry, loads and cooling interfaces remain open. Continue in 3N. |
| **RC — Regular coach** | Frame/bolsters, wall/roof framing, floor/panels, benches, doors/windows and local attachments | J1a has a 110-member coordination model and bounded frame analysis. Bogie supports, joints, fatigue and body connections still need release. Continue 3J coordination and 3O. |
| **AC — Accessible coach** | Separate frame/body variant, door reinforcement, wheelchair/companion and boarding-equipment attachment structures | A separate layout exists. Equipment, loads, applicable requirements and evacuation must determine the final variant. Continue 3O/3Q. |
| **BG — Bogie** | Side frames/crossmembers, spring seats, axlebox guides, center/side bearings, retention and brake reaction structure | Existing rotating bogies are functional illustrations. Wheelset, suspension and support interfaces must become engineering geometry in 3L. |
| **WS — Wheelset** | Wheel geometry, axle, bearing housings/retainers and brake torque-transfer interface | Gauge alone is not sufficient. Profile, materials, fatigue, fit, machining and NDT requirements remain open. Start 3L.1. |
| **BM — Mechanical brake** | Chamber bracket, carrier, reaction bracket, linkage/pivots if used, friction supports, adjustment and guards | 3K has demand calculations and chamber candidates. A selected foundation brake and manufacturable mounts are missing. Start 3L.1. |
| **PA — Pneumatic installation** | Reservoir/valve/compressor brackets, protected routing and inter-car supports | Functional 3K topology exists. Final valves, port connections, pressure/flow limits and full-train response require completion. |
| **CP — Couplings** | Custom coupling/drawbar, pins/bushes/retainers, frame attachments, guards and hose/cable supports | Gap and pivot-distance figures remain sensitivities. 3M must resolve actual loads, articulation, wear, retention and joint design. |
| **PS / AB — Boarding** | End platforms, stairs, rails/guards/gates, lift/ramp interfaces and emergency-equipment mounts | Floor/track/station movement and accessibility/evacuation determine the final dimensions. Continue 3Q. |
| **HE — HVAC/electrical** | Equipment supports, ducts, enclosures, cable routes, lighting and condensate protection | Selected equipment, demands, protection and installation limits determine details. Continue 3P. |
| **TK / SN — Track and stations** | Track assembly/curve/crossing interfaces, station edges, gates, maintenance and storage interfaces | Continue typical details in 3R. Final alignment awaits survey and the deferred North Pole location. Retain the 0% longitudinal target. |

## What makes a part drawing ready for fabrication

The part number will identify the family, assembly and part, for example **PF-WS-010-020** for an axle in the first wheelset assembly. Revision and actual manufactured serial number remain separate. Existing frame member identifiers will be retained and cross-referenced.

A released detail drawing must contain, or explicitly reference, the applicable items below. A justified “not applicable” is appropriate for processes the part does not need.

| Drawing content | Required definition |
|---|---|
| Identity and geometry | Part/revision/parent/quantity/handedness, units, datums, controlling dimensions, sections and matching assembly references. |
| Material and process | Exact specification, grade, condition and product form; material certification; cut/blank and machining allowance; forming/casting/forging route where applicable. |
| Precision surfaces | Mating fits, runout/alignment/concentricity, surface finishes, holes/threads, heat treatment and hardness where needed. |
| Joints | Weld joint preparation, size/extent, approved WPS and distortion sequence; exact fasteners and reviewed locking/installation requirements. |
| Assembly and service | BOM/exploded references, fixture/alignment or press procedure, wear adjustment, removal access, edge treatment, coating and marking. |
| Acceptance | Measurable dimensions and limits, instruments/datums, hold/witness points, NDT and actual record forms; linked calculation/interface documents and authorized release. |

Wheel/axle manufacturing drawings need a specialist manufacturing route and accepted material, fatigue, fit and inspection basis. The project should not silently convert a wheel model into a welded-plate wheel design. Similarly, a bracket outline becomes a fabrication detail only after its reaction forces, stiffness, fatigue, fasteners/welds, travel and inspection access have been resolved.

## Who closes each step

The responsible vehicle/brake engineer accepts the loads, geometry, material conditions, fatigue design, joints and measurable acceptance limits. The fabricator establishes the capable manufacturing process and supplies actual conformity records. Wheel/axle machining, heat treatment, interference assembly and specified NDT require suitably capable specialists. Farm-crew assignments follow the released scope and demonstrated skills/equipment; preparation, fit mockups, finishing, designated assembly and supervised track work can be separated into clear work orders.

The drawing status will progress from **development**, to **prototype released**, to **production released**, and finally **as-built accepted**. Operational release is a separate commissioning gate. A prototype release applies only to its defined first article and test plan; a completed desktop phase does not authorize passenger use.

The existing sequence remains: finish 3L running gear, then 3M couplings, 3N propulsion, 3O bodies, 3P HVAC/electrical, 3Q boarding/accessibility, 3R track/stations and 3S coordinated release. Procurement and fabrication planning start with these drawing packages; phases 4–7 control actual purchasing, production, installation and commissioning. Work on independent assemblies continues while an interface is awaiting evidence.

**Delivery:** the technical site will carry the assembly drawings, part details, BOM, calculations, held decisions and change history. No new PDF is being saved to the conversation. This map changes the emphasis to custom fabrication; it does not add invented hardware ratings or claim an engineering approval.
