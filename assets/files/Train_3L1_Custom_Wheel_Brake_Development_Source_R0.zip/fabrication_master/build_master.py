"""Build the custom-fabrication scope register; no fabrication ratings are created."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def family(code, name, stage, custom, bought, delivered, dependent, owner):
    return dict(id=code, name=name, development_stage=stage,
                custom_parts=custom, specified_purchased_items=bought,
                existing_review_coverage=delivered, release_dependencies=dependent,
                responsible_release_roles=owner, fabrication_release=False)

families = [
    family('LO','Locomotive structure and propulsion installation','3N',
      ['Main frame and crossmembers','Cab and historical outer body','Engine/transmission/pump or motor mounting structure','Cooling supports, exhaust supports and guards','Fuel-system mounting and protection','Operator station and removable maintenance panels'],
      ['Selected diesel engine','Selected transmission or hydrostatic/electric drive components','Approved flexible mounts, exhaust components, cooling equipment and fuel-system hardware'],
      'Propulsion alternatives and common train mass basis exist; a named engine and installation geometry are not frozen.',
      ['Accepted tractive effort, axle load and duty-cycle basis','Selected engine/drive installation drawings and dynamic reactions','Cooling, exhaust, visibility, fire and access integration','Frame fatigue and joint design'],
      ['Vehicle/mechanical engineer','Powertrain installation specialist','Qualified structural fabricator']),
    family('RC','Regular coach structure and body','3J / 3O',
      ['Floor frame, bolsters and seat supports','Wall and roof framing','Floor, wall and roof panel assemblies','Door and window framing','Benches, end platforms and maintenance panels'],
      ['Specified steel/aluminum sections and panels','Qualified glazing, seals, hardware and finishes'],
      'J1a has a 110-member coordination model, frame calculations and a prototype plan. Earlier seat/floor connections remain development studies.',
      ['3L bogie support footprint and stiffness','Accepted vertical/lateral/longitudinal/fatigue loads','Seat/floor and body joint verification','Qualified panel, glazing and exit arrangement','Signed first-frame and first-body release'],
      ['Vehicle structural engineer','Body/interior engineer','Qualified fabricator']),
    family('AC','Accessible coach structure and body','3O / 3Q',
      ['Accessible frame/body variant','Door opening reinforcement','Wheelchair-space and restraint anchor structure where required','Companion-seat supports','Boarding-equipment interface structure'],
      ['Approved boarding equipment if used','Applicable restraint hardware and occupant-interface components','Qualified glazing, door and emergency-exit hardware'],
      'Separate accessible coach and circulation study exist. It is not a regular coach with seats simply removed.',
      ['Applicable accessibility and vehicle requirements','Equipment interface loads and access clearances','Wheelchair/companion layout and evacuation trials','Variant frame and door-opening calculations'],
      ['Vehicle structural engineer','Accessibility specialist','Boarding-equipment manufacturer']),
    family('BG','Custom bogie frames and suspension supports','3L',
      ['Side frames, crossmembers and bolster arrangement','Axlebox guides and spring seats','Center-bearing and side-bearing structures','Retention, droop/rebound stops and brake attachment load paths'],
      ['Selected springs, dampers, bushes and wear pads where used','Specified bearing elements and fasteners'],
      'Pivoting bogie illustrations are functional geometry; no released bogie dimensions, materials or ratings exist.',
      ['Wheelset and brake envelope from 3L.1','Suspension travel/load law and axle load distribution','Curve/swept-envelope and roll assessment','Bogie fatigue, local connections and manufacturing distortion analysis'],
      ['Rail vehicle/running-gear engineer','Qualified bogie fabricator','Independent inspection specialist']),
    family('WS','Custom wheelsets, axles and bearing housings','3L.1 / 3L',
      ['Wheel manufacturing geometry','Axle with wheel, bearing and brake-interface seats','Bearing housing and retention parts','Any separate rotor/hub carrier and mechanical torque-transfer interface'],
      ['Material blanks/forgings/castings to approved manufacturing specification','Exact bearings, seals and retention hardware','Specified friction rotor if selected as a purchased wear part'],
      '36-inch gauge is only an evaluation basis. Wheel diameter, wheel/rail profile, back-to-back, axle seats and interference fits are not released.',
      ['Matched rail section, wheel profile and track/turnout interfaces','Accepted axle, braking, lateral and fatigue loads','Bearing selection and arrangement','Wheel/axle material, heat treatment, stress, fatigue and fit analysis','Manufacturer capability and inspection/pressing procedure'],
      ['Rail wheelset design engineer','Specialist wheel/axle manufacturer','Qualified machining and NDT provider']),
    family('BM','Custom mechanical brake assembly and mounts','3L.1 / 3K integration',
      ['Brake carrier and reaction bracket','Air-chamber mounting structure','Levers, pivots, clevis/rod interfaces and adjustment parts if used','Rotor/hub adapter or tread-shoe support structure as selected','Travel stops, retention and guards'],
      ['Exact combination air chamber','Qualified friction pads/shoes and matching rotor or specified wheel braking surface','Selected pivot bushes/bearings and rated retention hardware'],
      '3K documents candidate chamber geometry and conditional braking demand. It does not contain a selected mechanical brake or release-ready mount.',
      ['Selected disc or tread architecture','Exact service-force/stroke and spring-force/stroke curves','Required per-axle braking and parking torque with brake balance','Wear, running clearances and suspension-travel envelope','Joint, fatigue, heat and tolerance-stack verification','Instrumented first-article tests'],
      ['Brake/running-gear engineer','Chamber and friction-component manufacturers','Qualified machine/fabrication shop']),
    family('PA','Pneumatic control and installation','3K / 3L / 3S',
      ['Reservoir, compressor and valve mounting brackets','Protected pipe/hose routing supports','Inter-car connection supports','Labels and accessible isolation/inspection panels'],
      ['Compressor, dryer, reservoirs and relief devices','Exact distributor/control/relay valves','Hoses, fittings, connectors and chambers'],
      '3K has functional architecture, state analysis and component candidates. Port-level installation, ratings and timing remain unresolved.',
      ['Valve architecture and all pressure/flow/duty ratings','Validated service/spring interaction and failure response','Protected routing at full yaw and suspension travel','Bench and full-consist charge/application/release tests'],
      ['Brake controls engineer','Pneumatic component manufacturers','Qualified installer']),
    family('CP','Custom couplings, drawbars and frame attachments','3M',
      ['Drawbar/coupler arrangement if custom selected','Pivot pins, bushes and retainers','Frame attachment structures and draft load path','Pinch guards and inter-car hose/cable supports'],
      ['Documented coupler hardware if incorporated','Specified bearings, bushes and retainers'],
      'Inter-car gap and pivot-distance values are sensitivity geometry only; no pin, plate or weld is released.',
      ['Tension/compression/braking/reversing/fatigue loads','Unequal brake application and separation cases','Yaw/pitch/roll, slack and minimum curve articulation','Strength, wear, retention and inspection design'],
      ['Rail vehicle/mechanical engineer','Qualified coupling fabricator','Inspection specialist']),
    family('PS','Onboard platforms, stairs, guards and gates','3Q',
      ['Platform frames and floors','Stair stringers, treads and mountings','Handrails, guards, gates and boarding barriers','Coupling and wheel pinch-point guards'],
      ['Slip-resistant surfaces','Qualified hinges, latches and lighting'],
      'Platform/stair concepts and clearances are studies; photographs do not establish hidden structure.',
      ['Accepted boarding/egress and guard criteria','Actual vehicle floor and station heights','Suspension, curve and derailment clearance assessment','Connection loads and accessible evacuation integration'],
      ['Vehicle structural engineer','Accessibility/life-safety reviewers','Qualified fabricator']),
    family('AB','Accessible boarding and evacuation equipment interfaces','3Q',
      ['Vehicle/station interface brackets and reinforcements','Custom platform or bridge arrangement where selected','Stowage, guards and emergency-equipment mounts'],
      ['Rated lift/ramp/bridge system if selected','Specified safety interlocks and emergency lowering components'],
      'Normal boarding and off-station evacuation must both be developed; no equipment is selected.',
      ['Applicability determination and accepted user dimensions','Rated equipment interface forces and installation limits','Power-loss and off-station evacuation method','Full-size boarding/evacuation trials'],
      ['Accessibility specialist','Vehicle/station engineers','Equipment manufacturer']),
    family('HE','HVAC and electrical installation','3P',
      ['Equipment supports and vibration mounts','Duct/plenum and return-air assemblies','Cable trays, enclosures and harness routing','Emergency-lighting supports and condensate protection'],
      ['Selected HVAC and ventilation equipment','Generator/alternator/shore equipment','Protection, cable, connectors, controls and emergency lights'],
      'Body and power interfaces are pending; complete installation drawings are not released.',
      ['Coordinated occupancy/thermal/electrical demand','Equipment installation and startup data','Cable, protection, bonding and emergency-light design','Condensate/noise/vibration/exhaust interfaces'],
      ['Mechanical/HVAC engineer','Qualified electrical designer and installer']),
    family('TK','Track fabrication and installation interfaces','3R / 6',
      ['Surveyed alignment and track assembly','Approved curved-rail preparation','Crossing and turnout integration','Drainage, ballast/subgrade and maintenance details'],
      ['Matched rail, ties, fastenings and joint components','Engineered turnout/crossing components where selected'],
      'Level longitudinal target is retained. Final alignment awaits survey and North Pole location.',
      ['Wheel/rail and turnout compatibility from 3L','Accepted axle loads, curve radius and alignment tolerances','Boundary/topographic survey and subgrade/drainage information','Track engineer installation and acceptance documents'],
      ['Track/civil engineer','Surveyor','Specialist track installer with defined farm-crew work']),
    family('SN','Stations, maintenance and storage interfaces','3R / 6',
      ['Station platform structure and edge interfaces','Boarding gates and barriers','Maintenance access and vehicle support/jacking interfaces','Storage and emergency-access provisions'],
      ['Selected structural and electrical components','Rated maintenance lifting/support equipment'],
      'Typical interfaces can progress; station locations and final civil structures are not fixed.',
      ['Vehicle swept envelope and loaded/empty floor movement','Boarding/accessibility solution','Survey, geotechnical and authority requirements','Drainage, utilities and responder access'],
      ['Civil/structural engineer','Accessibility/life-safety reviewers','Qualified installer'])
]

required = [
  ('identity','Unique part number, drawing number, revision, parent assembly, quantity, handedness, units, release status and authorized sign-off.'),
  ('geometry','Manufacturable views and necessary sections; all controlling dimensions tied to stated datums; critical interfaces referenced to the same coordinate system as the assembly.'),
  ('material','Exact material specification, grade, condition and product form; traceability/certification requirements. “Steel” or “aluminum” alone is insufficient.'),
  ('blank_and_process','Cut/blank envelope, machining stock and sequence; formed radii and bend direction; casting/forging/machining route where applicable.'),
  ('heat_treatment','Heat treatment, hardness range, case depth or stress relief when required; otherwise a justified not-applicable designation.'),
  ('fits_and_surfaces','Mating parts, bearing/wheel fits, tolerances, surface finishes, runout/concentricity/alignment and retention requirements where applicable.'),
  ('holes_and_threads','Hole locations, diameters, fits, depth, threads and edge conditions, with mating interfaces checked; no scaled-from-rendering holes.'),
  ('welding','Joint preparation, weld symbols, size/extent, sequence, applicable approved WPS, access and distortion control. Specify inspection/NDT and acceptance criteria where required.'),
  ('fasteners','Exact fastener specification, grade, coating, washer/locking arrangement, engagement and approved installation method; torque/preload belongs to the reviewed joint design.'),
  ('finish','Edge breaks, corrosion protection, masked/mating surfaces, marking and protection during storage.'),
  ('assembly','Exploded/BOM references, assembly order, fixtures, press or alignment procedure, wear adjustment and service/removal access.'),
  ('inspection','Measurable first-article and production checks, instruments/datums, hold/witness points, NDT scope and acceptance values; record form tied to part/serial.'),
  ('loads_and_basis','Link to calculation and interface documents governing the part, including relevant load/fatigue/thermal cases; no unsupported rating printed on a part.'),
  ('change_control','Approved substitutions, deviations, rework limits and superseded revisions; unresolved critical items prohibit the fabrication-release stamp.')
]

sequence = [
 dict(id='3L.1-A', title='Freeze the local wheelset/brake design basis', inputs=['Existing upper coach masses and 3K torque cases','Rail/wheel profile candidates','Disc-versus-tread packaging comparison'], outputs=['One declared development architecture','Interface datum drawing','Load cases and evidence requests'], holds=['Final wheel/rail profile and accepted loads'], allows_next='Geometric studies and draft manufacturing drawings may continue with conspicuous held fields.'),
 dict(id='3L.1-B', title='Develop the wheel, axle and bearing stack', inputs=['3L.1-A interface basis','Bearing supplier geometry','Manufacturing capability'], outputs=['Wheel and axle section drawings','Bearing/retention stack','Fit, finish and NDT schedule draft'], holds=['Material/heat treatment, fatigue, fits and wheel/rail compatibility sign-off'], allows_next='Use candidate envelopes to position the mechanical brake; do not machine wheel/axle seats.'),
 dict(id='3L.1-C', title='Develop the brake carrier and actuator linkage', inputs=['3L.1-B wheelset envelope','Exact chamber force/stroke/spring data','Selected friction system geometry and properties'], outputs=['Assembled, section and exploded drawings','Carrier/bracket/lever/pin detail sheets','Stroke/clearance/tolerance calculation and attachment load path'], holds=['OEM interface data and engineer acceptance of forces, joints and wear travel'], allows_next='Build an explicitly released non-load-bearing fit mockup if separately defined; no passenger-service hardware release.'),
 dict(id='3L.1-D', title='Release and test one controlled first article', inputs=['Signed prototype drawing issue','Approved material and process specifications','Instrumented test plan with numerical acceptance criteria'], outputs=['Manufacturing traveler','Actual dimensional/NDT records','Actual torque/stroke/heat/parking and wear-adjustment results'], holds=['Prototype-build release; test equipment and witnessed results'], allows_next='Revise the drawing package from actual findings before production release.'),
 dict(id='3L.2', title='Complete the bogie around the verified interfaces', inputs=['3L.1 wheelset/brake findings','Suspension and body support basis'], outputs=['Custom bogie frame and support detail set','Bogie yaw/travel/clearance and stiffness model','Frame/bolster interface update'], holds=['Vehicle dynamics, fatigue and support interface acceptance'], allows_next='Coordinate 3J frame revision and 3M coupling loads without silently replacing the earlier studies.'),
 dict(id='3M–3R', title='Continue the existing subsystem order', inputs=['Accepted local interfaces as available'], outputs=['Custom coupling, locomotive, coach-body, HVAC/electrical, accessible-boarding, track and station drawing families'], holds=['Each family’s listed dependencies'], allows_next='Develop independent subsystems while one interface awaits external evidence.'),
 dict(id='3S / 4–7', title='Coordinate, procure, fabricate, install and commission', inputs=['Accepted subsystem interfaces and signed release packages'], outputs=['Controlled BOM and procurement specifications','Production records','As-built and commissioning evidence'], holds=['Actual professional releases, purchase authorization and test evidence'], allows_next='Production and passenger operation occur only after their distinct gates; a desktop phase completion does not pass them.')
]

sources=[]
for rel in ['phase3k/program/program_state.json','phase3k/source/Phase3K_Design_Basis_R0.json','phase3k/source/design_basis.json']:
    p=ROOT/rel
    sources.append(dict(path=rel, sha256=hashlib.sha256(p.read_bytes()).hexdigest(), use='Existing project scope and status; not external approval.'))

master = dict(
 schema_version=1, revision='PF-TRAIN-CUSTOM-FAB-MAP-R0', owner_local_date='2026-10-18', prepared_utc_date='2026-10-19',
 status='FABRICATION DEVELOPMENT SCOPE — NO FABRICATION RELEASE',
 owner_direction='Custom fabrication is the primary design route for the entire train; provide the parts and connections needed to make it, with the site as the delivery location.',
 publication='Existing technical review site only; no new PDF attachment or separate chat deliverable.',
 scope_interpretation='Design the complete custom vehicle and its installation. Specify exact purchased engines, bearings, air chambers, controls and wear components where incorporated; custom project scope does not imply farm fabrication of their internals.',
 primary_route='Custom-engineered assemblies; purchased complete running gear remains a comparison/fallback only and is not silently substituted for this directive.',
 current_status=dict(desktop_issues_completed_through='3K', approved_fabrication_assemblies=[], actual_manufacturing_tests=None, note='Completed review phases are not completed shop-drawing releases.'),
 part_id_rule=dict(format='PF-{family}-{assembly3}-{part3}', examples=['PF-WS-010-000 wheelset assembly','PF-WS-010-010 wheel','PF-WS-010-020 axle','PF-BM-020-000 brake assembly','PF-BM-020-010 brake carrier','PF-BM-020-020 chamber bracket'], assembly_suffix='000', revision='Separate field, never silently overwrite an issued revision.', serial='Separate field for actual manufactured units.', predecessor_ids='Retain existing J/I/H member IDs and cross-reference them; this hierarchy does not renumber or release prior parts.'),
 families=families,
 released_drawing_requirements=[dict(id=i, requirement=t) for i,t in required],
 release_states=[
   dict(id='DEVELOPMENT', meaning='Draft dimensions, candidate materials and calculated interfaces; held fields visible.'),
   dict(id='PROTOTYPE_RELEASED', meaning='Responsible designer signs a defined first-article scope and process/test plan. This is not permission for public operation.'),
   dict(id='PRODUCTION_RELEASED', meaning='First-article findings, critical interfaces, manufacturing processes and acceptance checks have been accepted by the responsible professionals.'),
   dict(id='AS_BUILT_ACCEPTED', meaning='Actual manufactured item conforms to its released revision, or approved deviations are recorded.'),
   dict(id='OPERATION_RELEASED', meaning='The integrated train/site passes the separately approved commissioning and required operational approvals.')
 ],
 work_sequence=sequence,
 responsibility=dict(
   engineering='Responsible discipline engineer accepts loads, materials, fatigue, geometry, tolerances, joints and acceptance limits; integrator owns cross-subsystem compatibility.',
   fabrication='Qualified shop owns capability, process plan, fixtures and actual conformity records; it does not close a design hold by choosing a convenient dimension.',
   specialist='Wheel/axle machining, heat treatment, interference assembly, brake validation and specified NDT go to suitably capable specialists under released procedures.',
   farm_crew='Farm crew can perform the released work matching its qualifications, training and equipment: fit mockups, preparation, finishing, designated assembly and supervised track work. Safety-critical work is assigned by demonstrated capability, not by who owns the shop.',
   inspection='Designated inspector records actual material certificates, dimensions, weld/NDT and test results; no acceptance result is prefilled.',
   owner='Owner approves business choices and separately authorizes purchases/outreach. Owner approval is not a substitute for engineering release.'),
 source_records=sources)

(HERE/'master.json').write_text(json.dumps(master,indent=2)+'\n')
print(json.dumps({'path':str(HERE/'master.json'),'families':len(families),'drawing_requirements':len(required),'sequence_steps':len(sequence)}))
