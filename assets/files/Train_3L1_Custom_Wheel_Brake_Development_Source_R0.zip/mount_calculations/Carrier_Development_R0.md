# Custom brake carrier: the dimensions and loads now established

Revision PF-TRAIN-BRAKE-MECHANISM-MOUNT-R0 — October 18, 2026, Pacific time.

This develops the custom mounting interface around the **Tolomatic ME220MEFI / 0745-0024** cast-iron mechanical caliper and a 12-inch fixed-disc packaging study. It preserves the requested air-service / spring-parking concept. The semi-type combination chamber, reduction mechanism, rotor, axle and finished carrier remain a coordinated selection; this is not a fabrication release.

## Real interface dimensions

The manufacturer's floating-bracket drawing provides two 0.386-inch nominal holes on 4.750-inch centers: the dimensioned relative pattern is **H1=(0,0), H2=(4.750,0) inches**. With a 12-inch disc, its table places the lever axis 5.000 inches above the axle. The hole line is another 2.170 inches above the lever axis. For this calculation only, the hole pair is assumed horizontally centered on the axle/cam axis, giving hole centers **(−2.375, 7.170) and (+2.375, 7.170) inches**, or **(−60.325, 182.118) and (+60.325, 182.118) mm**. The image does not explicitly dimension that horizontal centering; controlled OEM CAD or physical-part measurement must establish it. These are conditional layout coordinates, not a released hole diameter or drill schedule for the custom support. The candidate accepts a 0.500-inch disc. [FM-02]

The rotor's effective friction radius is **5.080 inches / 129.032 mm**. That is distinct from its 6-inch outside radius and from the lever-axis height. The caliper's 4-inch left lever arm is a possible linkage input location shown on the drawing; the manufacturer must confirm that the published input-force rating applies there and confirm permitted input direction. Do not attach a large chamber to the shorter arm by analogy.

## Loads that size this mount

For the upper regular-coach allocation of 13,200 kg, four equally braked axles, level track and 0.7 m/s² deceleration, each axle supplies 2,310 N at the rail. At 0.300 m wheel radius, the axle demand is 693 Nm; a separate assumed 5% rotational allowance raises it to **727.65 Nm**. The allowance is not a calculated wheelset inertia.

The OEM equations use dynamic torque = 7.45 × braking radius × lever force, and static torque = 3.725 × braking radius × lever force, with consistent inch/lbf units. The factor is a torque relationship, not a pad-clamping-force ratio. [FM-03]

| Analysis case | Lever force | Axle brake torque | Peak in-plane load at one mounting hole* |
|---|---:|---:|---:|
| Highest present stopping-demand probe | 170.17 lbf / 756.95 N | 727.65 Nm | 4.49 kN |
| 580 lbf aluminum-version comparison | 2,579.97 N | 2,480.09 Nm | 15.31 kN |
| 660 lbf cast-iron catalog input sensitivity | 2,935.83 N | 2,822.18 Nm | 17.42 kN |
| 660 lbf, static equation comparison | 2,935.83 N | 1,411.09 Nm | 10.32 kN |

*Calculated rigid, in-plane two-hole interface model, conditional on the horizontally centered pair, including the lever input at the assumed 4-inch arm and the equivalent disc tangential force; opposite disc rotation and both input-force signs are enveloped. This is not bolt capacity. The linked parts instructions identify the aluminum version and its 580-lbf limit; the cast-iron catalog lists 660 lbf. Exact cast-iron installation instructions, the horizontal mounting datum and the rated input location remain to be obtained. Neither force value is permission to apply that load to an arbitrary linkage point.

The key consequence is concrete: sizing a bracket for the normal stopping demand alone would miss much larger actuator-driven reactions. The two mounting holes can see a calculated 17.42 kN reaction each in the catalog-force probe even though only 4.49 kN appears in the stopping-demand probe. Full-pressure, spring-parking, compounded and jam loads still have to bound that envelope. Rail slip is not a dependable structural overload limiter.

## What connects to what

The caliper floating bracket bolts to a custom machined carrier. That carrier follows the wheelset through primary suspension travel, using an axlebox-referenced support or an engineered equivalent. A torque-reaction connection carries brake torque into the bogie while accommodating required movement. The wheel/axle/rotor turn inside that stationary support. The manufacturer’s axial floating bracket does not accommodate unrestricted vertical wheelset movement.

The two-hole calculation isolates the caliper. A complete carrier calculation also includes the chamber-anchor load and the reduction linkage pivots. If the chamber and caliper share one carrier, their opposed actuation reactions still load local brackets even when they partly cancel in the complete assembly. The ideal net pad-normal forces are not simply added to the mount as an external load; imbalance, misalignment and axial offsets need their own cases.

For example, a torque link with a hypothetical **200 mm perpendicular lever arm** carries 3.64 kN at the present 727.65 Nm demand and 14.11 kN in the 660-lbf catalog torque probe. The actual perpendicular arm changes with linkage geometry and suspension travel. Those figures do not size a pin or select a bearing.

A force-reducing linkage also increases output travel. Both the chamber's force curves and the caliper's new/worn-pad travel must close together. A service-pressure regulator does not limit the parking spring force. Required ratio, stops, pins and wear adjustment therefore belong on one released mechanism drawing, not on separate guessed brackets.

## Fabrication decisions and measurable records

| Item | Information that the fabrication drawing must contain | Evidence needed to release it |
|---|---|---|
| Carrier plate and stiffeners | Material specification, thicknesses, radii, edge distances, machined datum faces and cut geometry | Full load envelope; bending, shear, bearing, tear-out, prying, local-support stiffness and fatigue analysis |
| Caliper joint | Exact fastener, grip, thread engagement, hole/locating-fit system, washers, preload method and retention | OEM mounting requirements plus combined-load, separation, slip and fatigue assessment |
| Chamber / reduction linkage | Certified force–stroke envelope, lever arms through travel, pin fits, bushings, stops and retained joints | Maximum and minimum service and spring forces; no overtravel or caliper overload with worn pads or faults |
| Wheelset and rotor hub | Wheel profile, journals, interference or other approved attachment, disc center plane, axial stack and runout | Wheelset specialist's combined bending/torsion/fatigue and rotor thermal design |
| Torque link and axlebox support | Articulated-end details, effective lever arm through movement, retention and clearances | Suspension geometry; reversible torque and impact envelope; bearing and local-frame calculations |
| Welded carrier subassembly | Qualified process, filler, joint preparation, weld sizes, sequence and inspection criteria | Approved material / fatigue detail and shop welding procedure; not a generic fillet note |

Use the bearing journals to establish the axle axis, then control the disc center plane and carrier mounting face from that datum system. Record the complete axial stack rather than relying on a side-view envelope. Where finish-machined faces are part of a welded assembly, the engineer and shop must establish the weld/inspection/machining sequence and distortion allowance.

The manufacturing sequence is: verify actual OEM parts and drawings; resolve the chamber/caliper force and travel match; complete the wheelset and suspension interfaces; release the carrier and joint calculations; make a non-load-bearing fit fixture; fabricate and machine one prototype; inspect datums, fits and joints; cycle full suspension and pad-wear travel; perform instrumented static, reversible and fatigue/thermal testing to written criteria; release production after review. Farm-crew work can include the fit fixture, handling and controlled assembly after drawings are released. Wheelset manufacture, critical machining, qualified welding and final brake acceptance require the appropriate specialists.

## Calculation audit

`calculate_carrier_R0.py` reproduces the JSON results. It checks load and moment equilibrium for every modeled bolt pattern and verifies the force/torque conversions. There are **213 passing arithmetic checks**. These do not verify strength, fatigue life, stopping performance, suitability or approval. No plate thickness, bolt size or weld size has been inferred from the hole diameter.

NASA RP-1228 supplies the elastic bolt-group and combined-load framework; joint stiffness, preload, contact and fatigue remain explicit work items. AISC's HSS connection guidance identifies useful local support limit states, but it is not asserted to govern this vehicle or approve its mount. [MC01, MC04]
