#!/usr/bin/env python3
"""Auditable load development; never selects or approves brake mounting hardware."""
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'carrier_inputs_R0.json'
raw = INPUT.read_bytes()
p = json.loads(raw)
b = p['basis']
t = p['twiflex_benchmark']

def joint_pattern(force_N, pitch_u_mm, pitch_v_mm, e_u_mm, offset_mm):
    """Equal-stiffness elastic bolt-group reactions, local u/v, force in +v.

    Signed axial contributions are a linear distribution across a complete rigid
    interface. They are NOT actual bolt tension: preload, compression contact,
    prying, separation and plate flexibility must be resolved in final analysis.
    """
    points = [(u*pitch_u_mm/2, v*pitch_v_mm/2)
              for u,v in itertools.product([-1,1], repeat=2)]
    j = sum(u*u + v*v for u,v in points)
    iv = sum(v*v for u,v in points)
    mz = force_N * e_u_mm
    mu = -force_N * offset_mm
    loads = []
    for n,(u,v) in enumerate(points, 1):
        qu = -mz*v/j
        qv = force_N/len(points) + mz*u/j
        axial = mu*v/iv
        loads.append(dict(point=n,u_mm=u,v_mm=v,shear_u_N=qu,
                          shear_v_N=qv,shear_resultant_N=math.hypot(qu,qv),
                          signed_interface_axial_partition_N=axial))
    return dict(force_N=force_N, u_pitch_mm=pitch_u_mm,v_pitch_mm=pitch_v_mm,
                e_u_mm=e_u_mm,out_of_plane_offset_mm=offset_mm,
                moment_normal_to_plate_Nmm=mz, overturning_moment_Nmm=mu,
                peak_shear_N=max(q['shear_resultant_N'] for q in loads),
                peak_positive_axial_partition_N=max(q['signed_interface_axial_partition_N'] for q in loads),
                points=loads,
                equilibrium=dict(sum_shear_u_N=sum(q['shear_u_N'] for q in loads),
                                 sum_shear_v_N=sum(q['shear_v_N'] for q in loads),
                                 moment_z_Nmm=sum(q['u_mm']*q['shear_v_N']-q['v_mm']*q['shear_u_N'] for q in loads),
                                 axial_sum_N=sum(q['signed_interface_axial_partition_N'] for q in loads),
                                 axial_moment_u_Nmm=sum(q['v_mm']*q['signed_interface_axial_partition_N'] for q in loads)))

demand=[]
disc=[]
for a,r,k in itertools.product(b['decelerations_m_s2'], b['wheel_radii_m'],b['rotational_allowance_fractions']):
    rail=b['mass_kg']*a/b['braked_axles']
    torque=rail*r*(1+k)
    case=f"A{a:g}-R{r:g}-I{k:g}"
    demand.append(dict(id=case,deceleration_m_s2=a,wheel_radius_m=r,
                       rotational_allowance_fraction=k,rail_force_N_per_axle=rail,
                       brake_torque_Nm_per_axle=torque,
                       wheel_rail_mu_needed_uniform_load=a/b['gravity_m_s2']))
    for rd,mu in itertools.product(p['generic_disc_sensitivity']['effective_radii_m'],p['generic_disc_sensitivity']['lining_mu']):
        ft=torque/rd
        disc.append(dict(demand_id=case,effective_disc_radius_m=rd,lining_mu=mu,
                         tangential_force_N_per_caliper=ft,total_two_pad_normal_N=ft/mu,
                         one_pad_normal_N_if_symmetric=ft/(2*mu)))
max_demand=max(demand,key=lambda d:d['brake_torque_Nm_per_axle'])
benchmark=[]
for D,mu,n in itertools.product(t['disc_diameters_m'],t['lining_mu_sensitivity'],t['calipers_per_rotor_sensitivity']):
    re=D/2-t['effective_radius_offset_m']
    service=t['service_tangential_force_N_at_nominal_mu']*mu/t['nominal_mu']
    park=t['parking_full_rate_tangential_force_N_at_nominal_mu']*mu/t['nominal_mu']
    benchmark.append(dict(disc_diameter_m=D,effective_radius_m=re,
                          assumed_lining_mu=mu,service_calipers_per_rotor=n,
                          service_tangential_force_N_each=service,
                          service_torque_Nm_per_axle=service*n*re,
                          arithmetic_capacity_to_highest_demand_ratio=service*n*re/max_demand['brake_torque_Nm_per_axle'],
                          one_full_rate_parking_caliper_torque_Nm=park*re,
                          raw_rotor_bottom_above_top_rail_mm_at_R250=(0.25-D/2)*1000,
                          raw_rotor_bottom_above_top_rail_mm_at_R300=(0.30-D/2)*1000,
                          provenance='At mu=0.4 uses published force. Other mu values are conditional linear-friction sensitivities at unchanged normal force, NOT OEM guaranteed outputs.',
                          clearance_note='Geometric disc-edge height only; excludes wear, flange-depth/track hardware, guard, movement and required clearance.'))

joint=[]
force_cases=[('demand_727.65Nm_at_Re117mm',max_demand['brake_torque_Nm_per_axle']/0.117),
             ('MXA_published_nominal_mu0.4',6900),
             ('MXA_hypothetical_mu0.5',6900*0.5/0.4),
             ('MXK_published_nominal_mu0.4',6500)]
for (fid,f),pat,e,d in itertools.product(force_cases,p['generic_carrier_joint_sensitivity']['patterns_mm'],p['generic_carrier_joint_sensitivity']['in_plane_force_eccentricity_u_mm'],p['generic_carrier_joint_sensitivity']['out_of_plane_force_offset_mm']):
    case=joint_pattern(f,pat['u_pitch'],pat['v_pitch'],e,d)
    case.update(force_case=fid,pattern=pat['id'])
    joint.append(case)

link=[]
for name,T in [(max_demand['id'],max_demand['brake_torque_Nm_per_axle']),
               ('MXA_300mm_nominal',6900*0.117),
               ('MXA_300mm_hypothetical_mu0.5',6900*0.5/0.4*0.117),
               ('MXAplusMXK_300mm_nominal_simultaneous', (6900+6500)*0.117)]:
    for arm in p['torque_reaction_link_sensitivity']['effective_perpendicular_lever_arms_m']:
        link.append(dict(case=name,torque_Nm=T,effective_perpendicular_arm_m=arm,
                         link_axial_force_N=T/arm,
                         note='Static equilibrium only; applied in either direction. No dynamic, fatigue, joint-misalignment or fault factor.'))

result=dict(revision=p['revision'],input_sha256=hashlib.sha256(raw).hexdigest(),
            status=p['status'],demand=demand,disc_normal_loads=disc,
            benchmark=benchmark,joint_sensitivities=joint,torque_reaction_link=link,
            highest_demand=max_demand,
            released_fabrication_dimensions=False,
            required_release_data=p['governing_loads_still_required'],
            equations={
                'rail_force_per_axle':'Frail = mass * a / number_braked_axles',
                'torque_per_axle':'T = Frail * wheel_radius * (1 + rotational_allowance)',
                'caliper_tangent':'Ft = T / effective_disc_radius / equal_sharing_caliper_count',
                'total_normal_load':'Nsum = Ft / mu = Npad1 + Npad2',
                'link':'Flink = T / perpendicular_lever_arm',
                'bolt_direct_and_torsion':'q_i = F/n + (Mz/J)*[-v_i,u_i]; J=sum(u_i^2+v_i^2)',
                'axial_partition':'signed L_i = Mu*v_i / sum(v_i^2) for symmetric pattern; NOT actual bolt tension',
                'twiflex_radius':'Re = Ddisc/2 - 0.033m per DS2501/DS2507'})

# Actual two-hole candidate interface, independent from generic sensitivity above.
# Reference dimensions come from the OEM ME220 floating-bracket drawing.
# The location at which the published lever-force rating applies still needs OEM
# confirmation. The 4-inch left-hand lever point is a declared analysis assumption.
lbf_N=4.4482216152605
in_m=.0254
rb=5.08*in_m
hole_y=7.17*in_m
pitch=4.75*in_m
lever_x=-4.00*in_m
lever_y=5.00*in_m
lever_cases=[]
for d in demand:
    for kind,kme in [('dynamic',7.45),('static_same_torque_comparison',3.725)]:
        fl=d['brake_torque_Nm_per_axle']/(kme*rb)
        lever_cases.append(dict(demand_id=d['id'],rating_equation=kind,
                               torque_Nm=d['brake_torque_Nm_per_axle'],
                               calculated_lever_force_N=fl,calculated_lever_force_lbf=fl/lbf_N,
                               note='Static same-torque values are comparison only; they are not a defined parking criterion.'))
actual_interface_cases=[]
flhigh=max_demand['brake_torque_Nm_per_axle']/(7.45*rb)
for cid,fl,kme in [('highest_demand_dynamic',flhigh,7.45),
                   ('manual_580lbf_dynamic_sensitivity',580*lbf_N,7.45),
                   ('catalog_cast_iron_660lbf_dynamic_sensitivity',660*lbf_N,7.45),
                   ('catalog_cast_iron_660lbf_static_sensitivity',660*lbf_N,3.725)]:
    ft=kme*fl
    for sign_ft,sign_fl in itertools.product([-1,1],repeat=2):
        fx=sign_ft*ft
        fy=sign_fl*fl
        mz=-(rb-hole_y)*fx+lever_x*fy
        points=[]
        for u in [-pitch/2,pitch/2]:
            # Interface reaction contributions on the attached carrier. Physical
            # bolt reactions on the isolated caliper have the opposite signs.
            qx=fx/2
            qy=fy/2+mz*u/(pitch*pitch/2)
            points.append(dict(x_from_midpoint_mm=u*1000,y_from_axle_mm=hole_y*1000,
                               load_x_N=qx,load_y_N=qy,resultant_in_plane_N=math.hypot(qx,qy)))
        actual_interface_cases.append(dict(id=cid,disc_force_sign=sign_ft,lever_force_sign=sign_fl,
                                           equivalent_disc_tangential_force_N=fx,
                                           assumed_lever_input_force_N=fy,
                                           resulting_axle_brake_torque_Nm=abs(fx)*rb,
                                           moment_at_bolt_midpoint_Nm=mz,
                                           bolt_interface_loads=points,
                                           peak_in_plane_point_load_N=max(q['resultant_in_plane_N'] for q in points),
                                           limits='In-plane, rigid support only. No out-of-plane offset, preload, fatigue, prying, bearing, thermal or jam qualification.'))
result['ME220_actual_interface']={
    'candidate':'Tolomatic ME220MEFI / 0745-0024, not selected',
    'source_file':'../evidence/Tolomatic_ME220MEFI_Interface_R0.json',
    'OEM_bracket_hole_diameter_mm_printed':9.80,
    'OEM_hole_pitch_mm':pitch*1000,
    'OEM_dimensioned_relative_hole_coordinates_mm':[[0,0],[pitch*1000,0]],
    'axle_center_origin_mm':[0,0],
    'hole_centers_mm':[[-pitch*500,hole_y*1000],[pitch*500,hole_y*1000]],
    'hole_centers_evidence_status':p['ME220_horizontal_datum_assumption'],
    'effective_friction_point_mm':[0,rb*1000],
    'assumed_input_point_mm':[lever_x*1000,lever_y*1000],
    'input_point_status':'4-inch left lever arm shown by OEM drawing; manufacturer must confirm that this is the input point used in the published torque equation and permitted force direction.',
    'force_rating_status':'660lbf cast-iron catalog value; 580lbf also evaluated as an aluminum-version comparison because the linked parts instructions explicitly identify the die-cast-aluminum version. Exact cast-iron installation instructions and input-point correspondence remain required.',
    'custom_carrier_hole_diameter_mm':None,
    'fastener_and_carrier_sizes_released':False,
    'demand_to_lever_force':lever_cases,
    'mount_free_body_cases':actual_interface_cases,
    'equations':{
        'dynamic_T':'T_Nm = 7.45 * rb_m * lever_force_N',
        'static_T':'T_Nm = 3.725 * rb_m * lever_force_N',
        'equivalent_Ft':'Ft = T/rb. This is NOT a pad-normal-force multiplier.',
        'mount_moment':'Mz = -(rb - hole_y)*Fx_disc + x_lever*Fy_lever',
        'two_hole_forces':'Qx_i=Fx/2; Qy_i=Fy/2 + Mz*x_i / sum(x_i^2)'},
    'important':'Caliper two-hole reactions include its lever input. If the chamber is mounted on the same carrier, its anchor reaction must also be added to the complete carrier free body; the caliper-only model is not the full carrier or torque-link model.'}
result['ME220_actual_interface']['torque_link_sensitivities']=[
    dict(case=cid,axle_torque_Nm=T,effective_perpendicular_lever_arm_m=arm,
         link_axial_force_N=T/arm,
         status='Static equilibrium only. Actual lever arm throughout suspension travel, dynamic/fatigue factors and pins/joints remain unresolved.')
    for cid,T in [('highest_demand',max_demand['brake_torque_Nm_per_axle']),
                  ('catalog_660lbf_dynamic',7.45*rb*660*lbf_N)]
    for arm in p['torque_reaction_link_sensitivity']['effective_perpendicular_lever_arms_m']]
result['ME220_actual_interface']['actuator_matching_conditions']={
    'definition':'q = instantaneous output lever force / chamber force under ideal lossless geometry. Actual force additionally depends on linkage efficiency and geometry through stroke.',
    'overload_condition':'q_max * F_chamber_max * eta_max <= verified caliper input limit, checked for service, parking and compounded fault cases',
    'service_condition':'q_min * F_chamber_min_service * eta_min >= required dynamic lever force',
    'parking_condition':'q_min * F_spring_min * eta_min >= T_required_hold / (3.725 * rb), using validated static rating and wear/temperature conditions',
    'stroke_condition':'For constant ideal q, output displacement = chamber displacement / q. A force-reducing linkage increases output travel; travel and force cannot be matched independently.',
    'actual_ratio_selected':None,
    'overload_stop_or_limiter_selected':None,
    'notes':'A regulator alone does not bound spring force. Do not infer the spring force curve from chamber type number or service pA.'}

checks=[]
def check(name,actual,expected):
    checks.append(dict(name=name,passed=math.isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-8),actual=actual,expected=expected))
check('base 0.5m/s2 R0.3 torque',next(d['brake_torque_Nm_per_axle'] for d in demand if d['id']=='A0.5-R0.3-I0'),495)
check('high with 5 percent rotational',max_demand['brake_torque_Nm_per_axle'],727.65)
check('published MXA nominal 300mm torque',6900*.117,807.3)
check('published MXK nominal 300mm torque',6500*.117,760.5)
for i,x in enumerate(joint):
    eq=x['equilibrium']
    check(f'joint{i} sum_u',eq['sum_shear_u_N'],0)
    check(f'joint{i} sum_v',eq['sum_shear_v_N'],x['force_N'])
    check(f'joint{i} torsion',eq['moment_z_Nmm'],x['moment_normal_to_plate_Nmm'])
    check(f'joint{i} axial sum',eq['axial_sum_N'],0)
    check(f'joint{i} overturning',eq['axial_moment_u_Nmm'],x['overturning_moment_Nmm'])
check('generic pad sum',disc[0]['one_pad_normal_N_if_symmetric']*2,disc[0]['total_two_pad_normal_N'])
for i,x in enumerate(actual_interface_cases):
    q=x['bolt_interface_loads']
    check(f'ME220 {i} force x',sum(y['load_x_N'] for y in q),x['equivalent_disc_tangential_force_N'])
    check(f'ME220 {i} force y',sum(y['load_y_N'] for y in q),x['assumed_lever_input_force_N'])
    check(f'ME220 {i} moment',sum(y['x_from_midpoint_mm']/1000*y['load_y_N'] for y in q),x['moment_at_bolt_midpoint_Nm'])
assert all(c['passed'] for c in checks), 'Arithmetic validation failed'
(ROOT/'carrier_results_R0.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'ME220_Mount_Study_R0.json').write_text(json.dumps(dict(revision=p['revision'],status=p['status'],study=result['ME220_actual_interface']),indent=2)+'\n')
(ROOT/'carrier_validation_R0.json').write_text(json.dumps(dict(revision=p['revision'],checks=checks,all_passed=True,scope='Arithmetic and equilibrium only. Not hardware qualification or engineering approval.'),indent=2)+'\n')
print(json.dumps(dict(demand_cases=len(demand),joint_cases=len(joint),checks=len(checks),highest_demand=max_demand)))
