# Actual brake interface for the custom wheelset study

Checked 19 October 2026 UTC. These are manufacturer dimensions and a proposed fit study, not a released passenger-rail brake assembly.

**Primary fit-study candidate: Tolomatic ME220MEFI, part 0745-0024.** This is a cast-iron mechanical caliper with machined cam and floating bracket for a fixed 1/2-inch disc. It provides a physical component around which the custom carrier can be drawn while preserving the owner's preference for a commercial combination air/spring chamber. The chamber, force-reduction linkage and brake are not a documented matched assembly.

## Verified interface

The OEM floating bracket has **two Ø0.386-inch holes at 4.750-inch centers**. Draw those two OEM holes at datum coordinates H1=(0,0), H2=(4.750,0) inches. The new carrier's hole clearance, thickness, edge distance, threads, bolts and preload are separate design decisions. The OEM bracket is 7.00 inches wide and 2.92 inches high; its mounting-hole line is 2.17 inches above the lever-axis line. The dimension sheet lists the candidate's A/B/C dimensions as 0.844/3.80/5.98 inches. These are catalogue dimensions, not assigned machining tolerances.

For a **12-inch-diameter packaging study**, the OEM table gives D=5.00 inches from disc axis to lever axis and effective braking radius=5.08 inches. Thus the mounting-hole line is 7.17 inches from the axle axis in the depicted radial orientation. This does not define the axial mounting-face datum: use the exact manufacturer CAD or controlled drawing before fixing the carrier standoff. The caliper floating motion accommodates its brake mechanism, not unrestricted wheelset suspension travel.

Sources: [ME220 product](https://www.tolomatic.com/products/product-details/me220-mechanical-disc-brake/), [OEM dimensional sheet](https://www.tolomatic.com/wp-content/uploads/2022/06/ef27c269674345e6a6ce688607eb2f73-orig-scaled.jpg).

## Verified force/travel information and integration consequences

The OEM specifications distinguish 580 lbf maximum lever force for aluminum housings and 660 lbf for cast iron. They give dynamic torque in inch-pounds as `7.45 × braking radius in inches × lever force in pounds`; static torque uses coefficient 3.725. New total pad clearance is 0.048 inch; maximum axial movement without intermediate adjustment is 0.387 inch; wear before adjustment is 0.104 inch per side. The printed angular-stroke notation requires clarification before conversion.

The drawing shows 4.00-inch and 2.38-inch lever-hole radii. Confirm which input location the catalogue equation covers. Do not apply the rated equation unchanged after moving the pushrod to a different hole. The linked parts sheet explicitly covers die-cast aluminum and gives 580 lbf; this is not a conflict with the cast-iron catalogue rating. Obtain the exact cast-iron variant instructions before accepting 660 lbf in this assembly. It also confirms that wear adjustment is manual.

Sources: [OEM specifications](https://www.tolomatic.com/wp-content/uploads/2022/06/9900-4009_09_PTcat-62.png), [linked parts sheet](https://www.tolomatic.com/wp-content/uploads/2022/05/0701-0210_04_me220ps.pdf).

**Design implication:** a common 30/30 chamber must not be bolted directly to this lever on the assumption that its force is suitable. Match full pressure, maximum parking-spring force, travel, wear and simultaneous service/parking failure loads. A reduction linkage or different chamber may be necessary. Carrier loads include disc reactions and actuator-linkage loads, not only the demanded stopping torque.

Use an axlebox-referenced carrier concept, or another proven means of preserving disc/caliper alignment during primary suspension motion. A torque link may react braking into the bogie, but its pivots, geometry and joint forces remain to be engineered. A rigid chassis bracket with no suspension accommodation is not an acceptable continuation of the current sketch.

## A measured alternative, not a change in preference

Twiflex MX13/MX25 calipers accept documented proprietary air thrusters. MXA supplies air-applied service braking; MXK is spring-applied and air-released. DS2501 lists MXA maximum tangential braking force 6.9 kN at 7 bar, based on conditioned pads at nominal friction 0.4. With a 300 mm disc and the manufacturer's effective-radius formula, this implies 807.3 N·m. This is a published operating-condition estimate, not an ultimate carrier load or rail qualification. MXK legacy and current documents differ slightly on the spring force, requiring reconciliation. Neither is a verified substitute for an MGM canister.

Sources: [MXA DS2501](https://www.twiflex.com/-/media/project/altramotion/shared/files/literature/brand/twiflex-limited/related/product-sheets/mx-series/ds2501.pdf?rev=b9dde05a5786403c887602cf6a735044), [current MX mounting sheet](https://www.twiflex.com/-/media/project/altramotion/shared/files/literature/brand/twiflex-limited/data-sheets/mcm-ds2500-tf-en-a4-web.pdf?rev=3bac2d61e1964c8dbfb92d86377cb535).

The next fabrication development can now include a real mounting pattern, candidate axial envelope, removable carrier arrangement, inspection-access space, custom wheel/axle/rotor interface schedule and force-based carrier calculation. Rotor material, thermal capacity, hub attachment, bearings, axle and wheel fits, fatigue loads, tolerances and brake balance remain coordinated engineering decisions. No stock or application approval has been confirmed, and no supplier has been contacted.
