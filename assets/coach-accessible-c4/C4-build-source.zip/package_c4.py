"""Publish only compact final C4 assets into the existing repository asset tree."""
from pathlib import Path
import gzip,json,hashlib,shutil,zipfile
H=Path(__file__).parent;O=H/'issued';D=H.parent/'train-review-current/dist/assets/coach-accessible-c4';D.mkdir(parents=True,exist_ok=True)
V=json.loads((O/'verification.json').read_text())
assert V['failed_count']==0, V['failed_count']
assert (O/'drawing-visual-review.json').exists(), 'Final four-sheet visual QA record required'
for name in ['front-header-note.md','rear-bearing-analytical.json','rear-foot-relief-check.json','rear-header-freeze.json','door-mechanism-final-summary.json','door-mechanism-target-check.json','door-mechanism-sweep-check.json','edge-hinge-independent-review.json']:
 if (H/name).exists():shutil.copy(H/name,O/name)
shutil.copy(H/'edge-issued/edge-floor-cuts-and-checks.json',O/'edge-floor-cuts-and-checks.json')
for p in O.glob('C4-A*.svg'):(O/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),compresslevel=9,mtime=0))
record=json.loads((O/'design-record.json').read_text())
for sheet in record['drawing_sheets']:sheet['file']=sheet['id']+'.svg.gz'
(O/'design-record.json').write_text(json.dumps(record,indent=2))
for p in O.glob('*.step'):(O/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),compresslevel=9,mtime=0))
scriptnames=['build_c4.py','door_mechanisms.py','frame_connections.py','bridge_connections.py','bridge_retention.py','edge_hinge.py','edge_pockets.py','front_header.py','rear_header.py','station_pitch.py','storage_connections.py','verify_c4_paths.py','issue_c4.py','package_c4.py','BUILD-README.txt','header_loadscreen.py','layout-proposal.json','path-bay1.json','path-bay2.json','GN1024-NI-3-E.step','GN1024-NI-4-E.step','door-mechanism-final-summary.json','door-mechanism-target-check.json','door-mechanism-sweep-check.json','edge-issued/edge-floor-cuts-and-checks.json','rear-foot-relief-check.json','rear-header-freeze.json']
missing=[n for n in scriptnames if not (H/n).exists()]
assert not missing,missing
source_manifest={'coordinate_system':'Coach X front-to-rear, Y transverse, Z above rail; inches; proposed loaded floorZ32','build':'python build_c4.py; python verify_c4_paths.py; python issue_c4.py','runtime':'Python3, CadQuery2.7, numpy, matplotlib, shapely; STEP exports use millimeters','source_commit':'0f689682ddc40c6024e9d888625d22dcdf84170a','files':[{'file':n,'sha256':hashlib.sha256((H/n).read_bytes()).hexdigest()} for n in scriptnames]}
source_manifest['issued_drawing_files']=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'decompressed_svg_sha256':hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()} for p in sorted(O.glob('C4-A*.svg.gz'))]
(O/'source-manifest.json').write_text(json.dumps(source_manifest,indent=2))
with zipfile.ZipFile(O/'C4-build-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in scriptnames:z.write(H/n,n)
 z.writestr('source-manifest.json',json.dumps(source_manifest,indent=2))
# Raw tessellations, edge projection intermediates and uncompressed STEP stay in scratch.
selected=[]
for p in O.iterdir():
 if p.is_file() and not p.name.startswith('drawing-edges-') and not (p.name.startswith('model-') and p.suffix=='.json') and p.suffix!='.step' and not (p.name.startswith('C4-A') and p.suffix=='.svg'):
  shutil.copy(p,D/p.name);selected.append(p.name)
manifest={'release_status':'UNRATED PRELIMINARY DESIGN — FAILED STRENGTH SCREENS; NOT FOR CONSTRUCTION OR PASSENGER USE','files':[{'file':n,'bytes':(D/n).stat().st_size,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in sorted(selected)]}
(D/'asset-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'directory':str(D),'files':len(selected)+1,'size_MiB':sum(p.stat().st_size for p in D.iterdir() if p.is_file())/2**20},indent=2))
