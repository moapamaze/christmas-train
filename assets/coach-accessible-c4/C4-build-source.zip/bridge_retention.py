"""Positive bridge pin retention using actual manufacturer free-spring geometry.
Free spring-wire overlap with the shaft is reported separately, never a clearance pass.
No OEM axial retention capacity or vibration qualification is inferred.
"""
from pathlib import Path
import cadquery as cq
import math

def repair_retention(parts,add,box,cyl):
 H=Path(__file__).parent
 clips={k:cq.importers.importStep(str(H/f'GN1024-NI-{k}-E.step')).val().scale(1/25.4) for k in [3,4]}
 records=[]
 def get(i):return next(p for p in parts if p['id']==i)
 def replace(i,s,name=None):
  p=get(i);p['shape']=s
  if name:p['name']=name
 def bore(i,p,d,r,h):replace(i,get(i)['shape'].cut(cyl(r,h,p,d)))
 def cotter_at(k,x,y,z):
  # Crosshole runs alongY; loop points+Y, curved spring leg+Z.
  return clips[k].rotate((0,0,0),(1,0,0),90).translate((x,y+(29.75 if k==3 else 29.5)/25.4,z))
 def describe(i,k,pin,crossx,y,z,outside_face):
  g=get(i);g['name']=f'Actual JW Winco GN1024-NI-{k}-E spring cotter; installed deflection open';g['material']='JW Winco AISI301 spring wire'
  g.setdefault('definition',{}).update({'manufacturer_part':f'GN1024-NI-{k}-E','manufacturer_geometry':'actual unloaded STEP; curved leg elastically deflects on installation','recommended_crosshole_mm':3.5 if k==3 else 4.5,'crosshole_axis':'Y','crosshole_center_in':[crossx,y,z],'shaft_range_mm':[10,16] if k==3 else [16,20],'axial_retention_capacity':'not supplied by retrieved catalog; actual application/proof test required'})
  records.append({'pin':pin,'cotter':i,'part':f'GN1024-NI-{k}-E','full_crosshole_exposure_in':abs(crossx-outside_face)-(3.5 if k==3 else 4.5)/25.4/2,'free_spring_shaft_intersection_in3':get(pin)['shape'].intersect(g['shape']).Volume(),'classification':'unloaded spring-shape contact, not rigid-clearance pass'})
 # Coach pins: 3/4 shaft,4mm wire. Longer exposed tail gives usable hole edge distance.
 for x in [14,46]:
  pid=f'BR-PIN-{x}';cx=x+1.375;y=-58;z=30.25
  sh=cyl(.375,2.8,(x-1.2,y,z),(1,0,0)).cut(cyl(4.5/25.4/2,2,(cx,y-1,z),(0,1,0)))
  replace(pid,sh,'Coach clevis pin3/4; extended tail and4.5mm cotter crosshole')
  cid=f'PIN-COTTER-{x}--54';replace(cid,cotter_at(4,cx,y,z))
  describe(cid,4,pid,cx,y,z,x+1)
 # Station receiver pins: retainer placed outside bridge width so it clears endplate, shoe and channel.
 for x,sgn in [(14,-1),(46,1)]:
  pid=f'ST-KEEP-{x}';y=-87.625;z=29.25;cx=x+sgn*2.5
  sh=cyl(.25,4.35,(x-sgn*1.6,y,z),(sgn,0,0)).fuse(cyl(.4,.15,(x-sgn*1.75,y,z),(sgn,0,0)))
  av=(0,.5,math.sqrt(3)/2)
  sh=sh.cut(cyl(3.5/25.4/2,2,(cx,y-av[1],z-av[2]),av))
  replace(pid,sh,'Station keeper1/2; outboard tail for actual spring-cotter access')
  cid=f'PIN-COTTER-{x}--83.625';replace(cid,cotter_at(3,cx,y,z).rotate((cx,y,z),(cx+1,y,z),60));describe(cid,3,pid,cx,y,z,x+sgn*1.375)
  get(cid)['definition']['crosshole_axis']=[0,.5,math.sqrt(3)/2]
  get(cid)['definition']['orientation_note']='60deg aboutshaft fromhorizontalcrosshole, clearingfarhandrailoutrigger; nominal bboxYgap.0324in, tolerance-open'
 # Handrail locks increase to1/2-inch, with positive heads and outboard3E cotters.
 for x,sgn in [(10.25,-1),(49.75,1)]:
  for oldy in [-86,-55]:
   y=oldy-4;z=31;cx=x+sgn*1.5;pid=f'BR-HR-LOCK-{x}-{oldy}'
   for q in [f'BR-HR-SOCKET-{x}-{oldy}',f'BR-HR-POST-{x}-{oldy}']:
    bore(q,(x-1.5,y,z),(1,0,0),.265,3);get(q).setdefault('definition',{})['cross_bore_in']=.53
   sh=cyl(.25,3,(x-sgn*1.2,y,z),(sgn,0,0)).fuse(cyl(.375,.15,(x-sgn*1.35,y,z),(sgn,0,0)))
   sh=sh.cut(cyl(3.5/25.4/2,2,(cx,y-1,z),(0,1,0)))
   replace(pid,sh,'Removable handrail lock1/2 with head and3.5mm crosshole')
   get(pid).setdefault('definition',{}).update({'shaft_diameter_in':.5,'post_socket_bore_in':.53,'crosshole_mm':3.5})
   cid=f'BR-HR-COTTER-{x}-{oldy}';replace(cid,cotter_at(3,cx,y,z));describe(cid,3,pid,cx,y,z,x+sgn*.9375)
 # Transition hinge keeps its1/2 shaft and gains real3E spring cotters at both exposed ends.
 pid='ST-TRANSITION-PIN';y=-96.5;z=32
 sh=cyl(.25,37,(11.5,y,z),(1,0,0))
 for cx in [11.65,48.35]:sh=sh.cut(cyl(3.5/25.4/2,2,(cx,y-1,z),(0,1,0)))
 replace(pid,sh)
 for cx,face in [(11.65,12),(48.35,47.8)]:
  cid=f'ST-TRANSITION-COTTER-{cx}';replace(cid,cotter_at(3,cx,y,z));describe(cid,3,pid,cx,y,z,face)
 # Check every new cotter against all other rigid members; intended spring/own-pin contact is separate.
 def bb(s):
  b=s.BoundingBox();return[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax]
 def ov(a,b):return all(min(a[j+1],b[j+1])-max(a[j],b[j])>1e-7 for j in [0,2,4])
 collisions=[]
 for r in records:
  a=get(r['cotter']);ab=bb(a['shape'])
  for q in parts:
   if q['id'] in [r['cotter'],r['pin']] or q.get('kind')=='reservation':continue
   if ov(ab,bb(q['shape'])):
    v=a['shape'].intersect(q['shape']).Volume()
    if v>1e-7:collisions.append({'cotter':r['cotter'],'part':q['id'],'intersection_in3':v})
 return {'retainer_count':len(records),'records':records,'rigid_member_collisions':collisions,'scope':'Actual OEM free-spring shapes; shaft contact explicitly excluded from rigid collision claim; installed deflection and retention load tests open','sources':['https://www.jwwinco.com/en-us/products/product-family/Stainless-Steel/GN-1024-Stainless-Steel-Spring-Cotter-Pins','https://live-catalog.jwwinco.com/pdf/winco/US/1024.pdf?dispositiontype=attachment']}
