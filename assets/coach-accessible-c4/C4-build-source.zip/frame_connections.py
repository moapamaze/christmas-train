"""Proposed drilled retained-frame interface, original inch geometry.
Existing members are tagged reference so new-assembly mass does not count them twice.
"""
import math
import cadquery as cq
def connect_frame(parts,add,box,cyl,tube):
 checks=[];welds=[]
 def get(i):return next(p for p in parts if p['id']==i)
 def bore(i,x,y,z,h,r):get(i)['shape']=get(i)['shape'].cut(cyl(r,h,(x,y,z)))
 def check(a,b,kind):
  v=get(a)['shape'].intersect(get(b)['shape']).Volume();checks.append({'first':a,'second':b,'type':kind,'intersection_in3':v,'pass':v<1e-7})
 add('FRAME-P1','Retained negative-Y perimeter HSS4x2x1/8; proposed sleeved holes','c4-frame-interface',tube(-47,353,-55,-53,27.003937,31.003937,'x',.125),kind='reference')
 for tag,x in [('FRONT',-3),('REAR',309)]:add('FRAME-'+tag,'Retained end crossmember HSS6x2x3/16; proposed sleeved holes','c4-frame-interface',tube(x-1,x+1,-32,32,25.003937,31.003937,'y',.1875),kind='reference')
 for bay,x in [(1,78),(2,144)]:get(f'WC{bay}-SHOULDER-POST')['shape']=tube(x-1.5,x+1.5,-55,-53,31.378937,98,'z',.1875)
 feet=[]
 for x in [5.25,9.75,50.25,54.75]:feet.append((f'SD-FOOT-BOLT-{x}',f'SD-FOOT-SLEEVE-{x}','SD-F1' if x<30 else 'SD-F2','FRAME-P1',x,-54,26.5,31.253937))
 for x in [-35.25,-32.25]:feet.append((f'SD-HOLD-ANCHOR-{x}',f'SD-HOLD-SLEEVE-{x}','SD-HOLD-FOOT','FRAME-P1',x,-54,26.5,31.375))
 for bay,x in [(1,78),(2,144)]:
  for xx in [x-2,x+2]:feet.append((f'WC{bay}-SHOULDER-BOLT-{xx}',f'WC{bay}-SHOULDER-SLEEVE-{xx}',f'WC{bay}-SHOULDER-ROOT','FRAME-P1',xx,-54,26.5,31.378937))
 for tag,x in [('FRONT',-3),('REAR',309)]:
  for y in [-15.75,-11.25,23.25,27.75]:feet.append((tag+'-FOOT-BOLT-'+str(y),tag+'-FOOT-SLEEVE-'+str(y),tag+'-FOOT-'+str(-15 if y<0 else 24),'FRAME-'+tag,x,y,24.5,31.378937))
 for bid,sid,fid,rid,x,y,z0,ftop in feet:
  bore(rid,x,y,z0-.1,8,.390625);bore(fid,x,y,30.9,1,.28125)
  lower_fixed=not (bid.startswith('SD-FOOT-BOLT-') and x in [9.75,50.25])
  nut_z=z0+.003937 if lower_fixed else z0
  shaft_bottom=nut_z-.25 if lower_fixed else z0
  # Real bearing washer and hex-head geometry; nominal threads have cylindrical contact.
  washer=bid+'-WASHER';add(washer,'1/2 bolt washer OD1 ID.53 x1/16',get(bid)['group'],cyl(.5,.0625,(x,y,ftop)).cut(cyl(.265,.08,(x,y,ftop-.01))))
  cr=.75/math.sqrt(3);poly=[(cr*math.cos(math.radians(30+60*k)),cr*math.sin(math.radians(30+60*k))) for k in range(6)]
  head=cq.Workplane('XY').polyline(poly).close().extrude(.3125).val().translate((x,y,ftop+.0625))
  get(bid)['shape']=cyl(.25,ftop+.0625-shaft_bottom,(x,y,shaft_bottom)).fuse(head)
  nut=bid+'-NUT'
  # Drop old schematic side nuts, replaced by this consistent actual hex body.
  old='SD-FOOT-NUT-'+str(x)
  if any(p['id']==old for p in parts):parts[:]=[p for p in parts if p['id']!=old]
  ns=cq.Workplane('XY').polyline(poly).close().extrude(.4375).val().translate((x,y,nut_z)).cut(cyl(.25,.46,(x,y,nut_z-.01)))
  add(nut,'1/2-13 all-metal prevailing-torque nut, nominal thread bore',get(bid)['group'],ns)
  get(bid)['definition']={'shaft_in':.5,'thread':'1/2-13 UNC Grade8 candidate','frame_clearance_bore_in':.78125,'crush_sleeve_OD_ID_in':[.75,.5625],'foot_clearance_bore_in':.5625,'washer_OD_ID_thickness_in':[1,.53,.0625],'hex_head_AF_height_in':[.75,.3125],'thread_form_modeled':False,'release':'Local frame wall, bearing and edge distances require structural qualification'}
  lower=bid+'-LOWER-WASHER'
  if lower_fixed:
   add(lower,'Lower frame washer OD1 ID.53 x1/16, seated under HSS','c4-door-frame',cyl(.5,.0625,(x,y,nut_z+.4375)).cut(cyl(.265,.08,(x,y,nut_z+.4275))))
   get(bid)['definition'].update({'lower_nut_z_in':[nut_z,nut_z+.4375],'lower_washer_z_in':[nut_z+.4375,nut_z+.5],'thread_projection_in':.25,'shaft_bottom_z_in':shaft_bottom})
   check(bid,lower,'shaft/washer clearance')
  for q in [sid,fid,rid,washer,nut]:check(bid,q,'shaft/clearance or nominal thread bore')
  check(sid,rid,'crush sleeve/frame bored hole')
  welds.append({'members':[sid,rid],'contact':'Sleeve welded flush to both drilled HSS walls; weld sizing/local frame load qualification held'})
 # Locker is a dimensional storage candidate, not a falsely complete manufactured cabinet.
 for p in parts:
  if p['group']=='c4-securement-storage':p['kind']='reservation';p['name']='Storage cabinet reservation — '+p['name'];p['definition']={'outer_envelope_in':[16,20,26],'status':'Procure complete lockable cabinet with manufacturer hinge/latch/base fasteners; schematic cabinet hardware not fabrication geometry'}
 return {'scope':'Physical portal/shoulder/frame bolt interfaces and rack keeper bore pairs','check_count':len(checks),'passed_count':sum(q['pass'] for q in checks),'failed_count':sum(not q['pass'] for q in checks),'checks':checks,'intentional_contacts':welds,'exclusions':['Existing frame local strength and modification approval not established.','Storage cabinet is a purchased-system reservation; rack retention remains conditional.']}
