"""Original C4 bridge joints. Replaces schematic touching parts with bores,
threaded receivers, steel receiver extensions and positive pin retention.
Called after coarse member construction and before export. Dimensions in inches.
"""
import math,json
from pathlib import Path
import cadquery as cq
def repair(parts,add,box,cyl,tube):
 joints=[];welds=[]
 def get(i):return next(p for p in parts if p['id']==i)
 def remove(i):parts[:]=[p for p in parts if p['id']!=i]
 def put(i,s):get(i)['shape']=s
 def bore(i,p,d,r,h):put(i,get(i)['shape'].cut(cyl(r,h,p,d)))
 def meta(i,**kw):get(i).setdefault('definition',{}).update(kw)
 def joint(a,b,typ):joints.append({'first':a,'second':b,'type':typ})
 def pin_head(i,p,d,r=.5,h=.2):add(i,'Machined pin head','c4-coach-dock',cyl(r,h,p,d),'Steel, proof load held','#c6ccc3')
 def threadnut(i,x,y,z,th=.25,rad=.125,group='c4-bridge'):
  hw=.25 if rad==.125 else .3125
  s=box(x-hw,x+hw,y-hw,y+hw,z,z+th).cut(cyl(rad,th+.02,(x,y,z-.01)))
  add(i,'Captive square nut; thread form omitted',group,s,'Steel, isolated from aluminum','#b6bcae');meta(i,thread='1/4-20 UNC' if rad==.125 else '3/8-16 UNC',thread_form_modeled=False,body_in=[2*hw,2*hw,th])
 def verticalbolt(i,x,y,z0,z1,targets,head='socket',group='c4-bridge',rad=.125):
  r=rad;clear=rad+.015625
  for q in targets:bore(q,(x,y,z0-.5),(0,0,1),clear,z1-z0+1)
  if head=='flush_top':
   h=rad/math.tan(math.radians(41))
   for q in targets:put(q,get(q)['shape'].cut(cq.Solid.makeCone(r,2*r,h,cq.Vector(x,y,z1-h))))
   sh=cyl(r,z1-z0-h,(x,y,z0)).fuse(cq.Solid.makeCone(r,2*r,h,cq.Vector(x,y,z1-h)))
  elif head=='flush_bottom':
   h=rad/math.tan(math.radians(41))
   for q in targets:put(q,get(q)['shape'].cut(cq.Solid.makeCone(2*r,r,h,cq.Vector(x,y,z0))))
   sh=cyl(r,z1-z0-h,(x,y,z0+h)).fuse(cq.Solid.makeCone(2*r,r,h,cq.Vector(x,y,z0)))
  else:sh=cyl(r,z1-z0,(x,y,z0)).fuse(cyl(.21875,.1875,(x,y,z0-.1875)))
  add(i,'Joint screw; actual clear bores and receiver','c4-bridge',sh,'Grade8 steel candidate','#c6ccc3');meta(i,thread='1/4-20 UNC' if rad==.125 else '3/8-16 UNC',clear_hole_in=2*clear,shaft_diameter_in=2*rad,axis='Z',grip_z_in=[z0,z1],head=head,countersink_included_angle_deg=82 if head.startswith('flush') else None,thread_form_modeled=False)
  for q in targets:joint(i,q,'clearance bore')
 # Shift bridge attachment outside coach sill; maintain32-inch bearing pitch.
 shift_groups={'c4-bridge','c4-handrails','c4-station-dock','c4-station-reservations'}
 for p in parts:
  if p['group'] in shift_groups or (p['group']=='c4-coach-dock' and (p['id'].startswith('BR-') or p['id'].startswith('PIN-COTTER'))):p['shape']=p['shape'].translate((0,-4,0))
 #40-long deck with coach lip landing flush in a machined threshold pocket.
 put('BR-DECK',box(11.75,48.25,-92,-52,31.625,32));get('BR-DECK')['name']='Bridge deck36.5 x40 x3/8; machined edge-angle recesses; abrasive finish'
 put('SD-SILL',box(10.5,49.5,-55,-52,31.003937,31.625));get('SD-SILL')['name']='Solid steel threshold bearing packer; supports bridge lip on existing perimeter rail'
 meta('SD-SILL',construction='Machined steel packer, no duplicate HSS over existing perimeter',dimensions_in=[39,3,.621063],bearing_top_z_in=31.625)
 put('SD-THRESH',get('SD-THRESH')['shape'].cut(box(11.625,48.375,-55.01,-51.99,31.615,32.01)))
 meta('SD-THRESH',pocket_in={'x':[11.625,48.375],'y':[-55,-52],'z':[31.625,32]},clearance_each_side_in=.125,bridge_top_z_in=32)
 # Side edge angles, mechanically clamped by outer stringer deck screws.
 for x in [11.75,48]:
  pid='BR-CURB-'+str(x)
  flange=box(11.75,13.5,-92,-55,31.625,31.875) if x<30 else box(46.5,48.25,-92,-55,31.625,31.875)
  upright=box(x,x+.25,-92,-55,31.625,34)
  put(pid,upright.fuse(flange));put('BR-DECK',get('BR-DECK')['shape'].cut(upright.fuse(flange)))
  # Machine a 1/4-deep underside deck recess; full stringer section remains intact.
  meta(pid,section='Original bolted edge angle',barrier_height_in=2,flange_thickness_in=.25,deck_underside_recess_in=.25,stringer_notched=False,unwelded=True)
 # Receiver extensions are steel assemblies outside the existing threshold tube.
 for x in [14,46]:
  add('COACH-EXT-BASE-'+str(x),'Coach receiver extension4x4.75x3/4 plate','c4-coach-dock',box(x-2,x+2,-59.5,-54.75,28.125,28.875))
  add('COACH-EXT-HEEL-'+str(x),'Receiver heel plate4x3x1/4 to threshold tube','c4-coach-dock',box(x-2,x+2,-55.25,-55,28.625,31.625))
  for xx in [x-1.75,x+1.5]:
   # Triangular vertical gusset bridges the cantilever to heel, without pin obstruction.
   poly=[(-58.5,28.875),(-55.25,28.875),(-55.25,30.5)]
   s=cq.Workplane('YZ').polyline(poly).close().extrude(.25).val().translate((xx,0,0))
   add(f'COACH-EXT-GUSSET-{x}-{xx}','Receiver extension1/4 triangular gusset','c4-coach-dock',s)
  welds.append({'assembly':'COACH-EXT-'+str(x),'members':['COACH-EXT-BASE-'+str(x),'COACH-EXT-HEEL-'+str(x),'BR-COACH-LUG-'+str(x)+'-0','BR-COACH-LUG-'+str(x)+'-1'],'weld':'Proposed3/16 continuous E70 fillet; load transfer/local HSS wall qualification held','note':'Weld lands intentionally contact; no volume-overlap substituted for pin clearance.'})
 # Machine coach end bearing plate and its two tongues as one T6 component.
 front='BR-END--54'
 #Broad endmembers provide four-spaced handrail bracket bolts at each corner.
 for ep,y in [(front,-58),('BR-END--86',-90)]:put(ep,box(11.75,48.25,y-2.5,y+2.5,29.375,29.625))
 for x in [14,46]:
  tid='BR-TONGUE-'+str(x);put(front,get(front)['shape'].fuse(get(tid)['shape']));remove(tid)
 meta(front,construction='Single machined6061-T6 endmember with integral tongues; no weld in primary T6 path',pin_bore_in=.780)
 # Positive coach pin retention. Cross bores precede cotter insertion.
 for x in [14,46]:
  i='BR-PIN-'+str(x);bore(i,(x+1.1,-59,30.25),(0,1,0),.0703125,2)
  pin_head('BR-PIN-HEAD-'+str(x),(x-1.4,-58,30.25),(1,0,0));joint(i,front,'clearance bore')
  for n in [0,1]:joint(i,f'BR-COACH-LUG-{x}-{n}','clearance bore')
  joint(i,f'PIN-COTTER-{x}--54','cross-drilled retainer')
 # Deck bolts use removable captive square nuts on strips inside the open stringers.
 for x in [12.5,21.25,30,38.75,47.5]:
  rail='BR-RAIL-'+str(x);carrier=f'BR-NUTCARRIER-{x}'
  add(carrier,'Nut carrier0.8x28x0.04 inserted through stringer end','c4-bridge',box(x-.4,x+.4,-88,-60,31.21,31.25),'Steel, isolated from aluminum','#aab5ac')
  for oldy in [-83,-75,-67,-59]:
   y=oldy-4;remove(f'BR-DECK-BOLT-{x}-{oldy}')
   targets=['BR-DECK',rail,carrier]
   if x in [12.5,47.5]:targets+=['BR-CURB-'+str(11.75 if x==12.5 else 48)]
   nut=f'BR-DECK-NUT-{x}-{y}';threadnut(nut,x,y,31.25)
   verticalbolt(f'BR-DECK-SCREW-{x}-{y}',x,y,31.18,32,targets,head='flush_top');joint(f'BR-DECK-SCREW-{x}-{y}',nut,'nominal threaded contact; thread form omitted')
 # Steel socket/outrigger brackets sit below the endmember, not inside it.
 for x in [10.25,49.75]:
  for oldy in [-86,-55]:
   y=oldy-4;sid=f'BR-HR-SOCKET-{x}-{oldy}';fid=f'BR-HR-FOOT-{x}-{oldy}';pid=f'BR-HR-POST-{x}-{oldy}';lock=f'BR-HR-LOCK-{x}-{oldy}'
   put(fid,get(fid)['shape'].translate((0,0,-.25)))
   put(sid,get(sid)['shape'].fuse(get(fid)['shape']));remove(fid)
   put(pid,cyl(.75,37.5,(x,y,29.5)).cut(cyl(.63,37.52,(x,y,29.49))))
   # Socket bore cuts the added base so the removable rail can fully insert.
   bore(sid,(x,y,28.9),(0,0,1),.775,4.2)
   for q in [sid,pid]:bore(q,(x-1.3,y,31),(1,0,0),.203125,2.6)
   put(lock,cyl(.1875,2.4,(x-1.2,y,31),(1,0,0)).fuse(cyl(.3125,.15,(x-1.35,y,31),(1,0,0))))
   bore(lock,(x+1.05,y-.5,31),(0,1,0),.0703125,1)
   cid=f'BR-HR-COTTER-{x}-{oldy}';add(cid,'Handrail positive cross-pin retainer','c4-bridge',cyl(.0625,.8,(x+1.05,y-.4,31),(0,1,0)))
   for q in [sid,pid]:joint(lock,q,'cross bore')
   joint(lock,cid,'cross-drilled retainer');meta(pid,insertion_in=3.5,lock_axis_z_in=31,bottom_z_in=29.5,cross_bore_in=.40625)
  top='BR-HR-TOP-'+str(x)
  put(top,cyl(.75,39,(x,-92,67.25),(0,1,0)).cut(cyl(.63,39.02,(x,-92.01,67.25),(0,1,0))))
 #Four3/8 screws attach each socket bracket, with real holes, flush undersideheads and nuts.
 for sx in [10.25,49.75]:
  xs=[12.25,13.5] if sx<30 else [46.5,47.75]
  for oldy,ys,ep in [(-55,[-60,-58.5],front),(-86,[-91,-89],'BR-END--86')]:
   bracket=f'BR-HR-SOCKET-{sx}-{oldy}'
   for xx in xs:
    for yy in ys:
     rail='BR-RAIL-'+str(12.5 if sx<30 else 47.5);rb=get(rail)['shape'].BoundingBox();onrail=rb.xmin<xx<rb.xmax and rb.ymin<yy<rb.ymax
     nz=29.75 if onrail else 29.625
     targets=[bracket,ep]+([rail] if onrail else[])
     nut=f'BR-HR-BASE-NUT-{sx}-{xx}-{yy}';threadnut(nut,xx,yy,nz,.3125,.1875)
     bid=f'BR-HR-BASE-SCREW-{sx}-{xx}-{yy}';verticalbolt(bid,xx,yy,29.125,nz+.34,targets,head='flush_bottom',rad=.1875);joint(bid,nut,'nominal threaded contact')
 # Endplate attachments: nuts reached through open stringer ends before final closure.
 for y,oldy,ep in [(-90,-86,'BR-END--86'),(-58,-55,front)]:
  for x in [12.5,21.25,30,38.75,47.5]:
   yy=y+(.5 if y==-90 else -.5);rid='BR-RAIL-'+str(x);targets=[ep,rid]
   if x in [12.5,47.5]:targets.append(f'BR-HR-SOCKET-{10.25 if x==12.5 else 49.75}-{oldy}')
   nut=f'BR-END-NUT-{x}-{y}';threadnut(nut,x,yy,29.75)
   bid=f'BR-END-SCREW-{x}-{y}';verticalbolt(bid,x,yy,29.125,30.05,targets);joint(bid,nut,'nominal threaded contact')
 # Steel station shoes: countersunk underside screws leave the bearing face flush.
 for x in [14,46]:
  shoe='BR-SHOE-'+str(x)
  for y in [-90.5,-89.5]:
   nut=f'BR-SHOE-NUT-{x}-{y}';threadnut(nut,x,y,29.625)
   bid=f'BR-SHOE-SCREW-{x}-{y}';verticalbolt(bid,x,y,28.875,29.925,[shoe,'BR-END--86'],head='flush_bottom');joint(bid,nut,'nominal threaded contact')
  keeper='ST-KEEP-'+str(x);yc=-87.625
  for q in [p['id'] for p in parts if p['id'].startswith(('ST-ENDSTOP-'+str(x),'ST-LIP-'+str(x)))]:bore(q,(x-2,yc,29.25),(1,0,0),.28125,4);joint(keeper,q,'keeper bore')
  # Move retained pin fully through both channel walls and cross-drill its exposed tail.
  put(keeper,cyl(.25,3.2,(x-1.6,yc,29.25),(1,0,0)).fuse(cyl(.4,.15,(x-1.75,yc,29.25),(1,0,0))))
  bore(keeper,(x+1.5,yc-.6,29.25),(0,1,0),.0703125,1.2)
  cot=f'PIN-COTTER-{x}--83.625';put(cot,cyl(.0625,1,(x+1.5,yc-.5,29.25),(0,1,0)));joint(keeper,cot,'cross-drilled retainer')
 # A complete station transition hinge with interleaved barrels and leaf lands.
 remove('ST-TRANSITION-HINGE');plate='ST-TRANSITION';hingey=-96.5;hingez=32
 # Plate ends at-96; leaf tabs reach a hinge axis outside its rolling surface.
 add('ST-TRANSITION-FIX','Station transition hinge fixed mounting strip','c4-station-dock',box(11.75,48.25,-98,-97,31.75,32))
 for i in range(12):
  x=12+i*3;fixed=i%2==0;pid='ST-TR-HNG-'+str(i)
  sleeve=cyl(.375,2.8,(x,hingey,hingez),(1,0,0)).cut(cyl(.265,2.82,(x-.01,hingey,hingez),(1,0,0)))
  land=box(x,x+2.8,-97.25 if fixed else -96.5,-96.5 if fixed else -95.75,31.75,32)
  s=sleeve.fuse(land).cut(cyl(.265,2.82,(x-.01,hingey,hingez),(1,0,0)))
  add(pid,'Interleaved station transition hinge barrel and tab','c4-station-dock',s)
  welds.append({'assembly':pid,'members':[pid,'ST-TRANSITION-FIX' if fixed else plate],'weld':'Continuous1/8 fillet on steel mounting land; pin bore remains clear'})
 add('ST-TRANSITION-PIN','1/2-inch transition hinge pin','c4-station-dock',cyl(.25,37,(11.5,hingey,hingez),(1,0,0)))
 for i in range(12):joint('ST-TRANSITION-PIN','ST-TR-HNG-'+str(i),'hinge bore')
 for x in [11.65,48.35]:
  bore('ST-TRANSITION-PIN',(x,hingey-.5,hingez),(0,1,0),.0703125,1)
  pid='ST-TRANSITION-COTTER-'+str(x);add(pid,'Transition hinge positive retainer','c4-station-dock',cyl(.0625,.8,(x,hingey-.4,hingez),(0,1,0)));joint('ST-TRANSITION-PIN',pid,'cross-drilled retainer')
 # Affected assembly metadata appears in the part inspector.
 for p in parts:
  if p['group'].startswith('c4-') and not p.get('definition'):
   b=p['shape'].BoundingBox();p['definition']={'component':p['name'],'dimensions_xyz_in':[b.xlen,b.ylen,b.zlen],'nominal_geometry':True,'detail_status':'Original preliminary part; purchased geometry only where explicitly labeled reservation'}
 for x in [12.5,47.5]:
  for y in [-87,-79,-71,-63]:joint(f'BR-DECK-NUT-{x}-{y}','BR-CURB-'+str(11.75 if x==12.5 else 48),'nut-to-edge-angle separation')
 # Check declared joints in their assembled state. Contact with a thread form omitted is zero-volume.
 results=[]
 for q in joints:
  a=get(q['first'])['shape'];b=get(q['second'])['shape'];v=a.intersect(b).Volume()
  results.append({**q,'intersection_in3':v,'pass':v<1e-7})
 out={'scope':'Declared bridge pin, bolt, nut and bore pairs only; whole-assembly collision qualification not claimed','check_count':len(results),'passed_count':sum(r['pass'] for r in results),'failed_count':sum(not r['pass'] for r in results),'checks':results,'intentional_contacts':welds,'limits':['Countersunk threads are called out but not helical solids.','Station and coach local structural attachment strength still requires engineering review.','Handrail post/socket geometry and retention corrected; two-point bracket mounting and socket-load test not yet qualified.']}
 return out
