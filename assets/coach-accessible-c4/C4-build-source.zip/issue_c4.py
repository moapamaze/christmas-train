from pathlib import Path
import json,math,shutil,collections
import numpy as np
from station_pitch import bridge_angle
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon,Arc,Circle
from matplotlib.collections import LineCollection
H=Path(__file__).parent;O=H/'issued'
# Final release metadata is applied identically to both meshes; geometry is unchanged.
import gzip
for state in ['boarding','travel']:
 mp=O/f'model-{state}.json'; model=json.loads(mp.read_text())
 warning='UNRATED: concentrated bridge strength screens FAIL. Structural redesign required before passenger use.'
 if warning not in model['notes']:model['notes'].insert(0,warning)
 for part in model['parts']:
  part['metadata']['engineering_status']='UNRATED development geometry. Concentrated bridge strength screens FAIL; structural redesign and acceptance required before passenger use.'
  part['metadata']['release_status']='NOT FOR CONSTRUCTION OR PASSENGER USE'
 raw=json.dumps(model,separators=(',',':')).encode();mp.write_bytes(raw);(O/f'model-{state}.json.gz').write_bytes(gzip.compress(raw,mtime=0))
P=json.loads((O/'parts.json').read_text());M=json.loads((O/'model-boarding.json').read_text())
layout=json.loads((H/'layout-proposal.json').read_text());paths=json.loads((H/'maneuvering-verification.json').read_text())
def density(p):
 s=p['material'].lower()
 return .098 if 'alum' in s or '6061' in s else .283
mass=collections.defaultdict(float)
for p in P:
 if p['kind']=='physical':mass[p['group']]+=p['volume_in3']*density(p)
bridge=mass['c4-bridge'];rails=mass['c4-handrails']
moving=[p for p in P if p['kind']=='physical' and p['group'] in ['c4-bridge','c4-handrails']]
dead_coach=sum(p['volume_in3']*density(p)*(p.get('centroid_in',[0,sum(p['bounds_in']['y'])/2,0])[1]+90)/37.75 for p in moving)
dead_station=bridge+rails-dead_coach
# Conservative simple-beam screens; not a qualification model for the whole assembly.
E=10e6;L=37.75;I=(2*2**3-1.75*1.75**3)/12;S=I
rail600=600*L/4/S;rail_delta=600*L**3/(48*E*I)
deck300=6*(300*8.75/4)/(3*.375**2)
deck500=6*(500*8.75/4)/(3*.375**2)
pin_tau=600/(2*math.pi*.375**2)
hrI=math.pi*(1.5**4-1.26**4)/64;hrS=hrI/.75;hrstress=100*36/hrS
calc={'status':'UNRATED / NOT ACCEPTED. Concentrated near-end/interface structural screens fail; physical fit is a preliminary arrangement only. No complete WTORS acceptance.',
 'bridge':{'clear_width_in':36,'deck_length_in':39.875,'bearing_pitch_in':37.75,'deck_thickness_in':.375,'stringers':{'central_section_in':[2,2,.125],'central_count':3,'outer_section_in':[2,1.5,.125],'outer_count':2,'pitch_max_in':8.75,'I_in4':I},'bridge_mass_lb':bridge,'separate_handrails_mass_lb':rails,'assembled_bridge_plus_handrails_lb':bridge+rails,'mass_basis':'CAD physical volumes, aluminum0.098 and steel0.283lb/in3; coatings, anti-slip, final hardware and tolerance excluded','handling':'Use a station trolley/rack. Handrails detach as separate pieces. Two-person lift planning and measured handling assessment required; no one-person lift assertion.',
 'screen_loads':{'reference_design_load_lb':600,'reference_patch_in':[26,26],'reference_ultimate_safety_factor':3,'supplemental_wheel_load_lb':500,'supplemental_dynamic_factor':1.5},
 'central_stringer_all600lb_on_one_midspan':{'stress_psi':rail600,'elastic_deflection_in':rail_delta,'three_times_stress_psi':3*rail600,'extrusion_minimum_ultimate_psi':38000,'ratio_Fu_to_three_times_stress':38000/(3*rail600)},
 'deck300lb_on3in_strip_over8_75in':{'stress_psi':deck300,'three_times_stress_psi':3*deck300,'candidate_required_minimum_Fu_psi':38000},
 'supplemental500lb_wheel_on3in_strip':{'stress_at1_5load_psi':1.5*deck500,'candidate_minimum_yield_psi':35000},
 'one_coach_pin_takes600lb_double_shear':{'pin_diameter_in':.75,'shear_stress_psi':pin_tau,'note':'Bending, wear, lug prying, retention fatigue and material certification remain open.'},
 'handrail100lb_at36in_cantilever':{'section_OD_wall_in':[1.5,.12],'stress_psi':hrstress,'required_candidate_minimum_Fy_psi':46000,'note':'Single-post bound; socket, outrigger, fastening and deck torsion require separate qualification.'},
 'vertical_reactions':{'dead_load_coach_end_lb':dead_coach,'dead_load_station_end_lb':dead_station,'dead_load_basis':'Exact CAD centroid and material-density weight, simply supported atY−52.25/−90; additional station transition dead load excluded from moving bridge','600lb_centered_coach_end_lb':300+dead_coach,'600lb_centered_station_end_lb':300+dead_station,'600lb_at_one_end_envelope_lb':600+max(dead_coach,dead_station),'design_interface_screen_per_end_lb':850,'per_end_ultimate_screen_lb':2550,'coach_overhang_in':.125,'600lb_at_coach_lip_coach_reaction_lb':600*(1+.125/37.75),'600lb_at_coach_lip_station_uplift_lb':600*.125/37.75,'three_times_station_uplift_lb':1800*.125/37.75,'coach_receiver_cantilever_from_frame_inner_face_in':.75,'850lb_one_receiver_conservative_moment_lb_in':637.5,'three_times_receiver_moment_lb_in':1912.5,'additional_grasp_force_lb':100,'additional_grasp_moment_lb_in':3600},
 'deck_coach_end_wheel_screen':{'unsupported_length_in':3.125,'500lb_wheel_times1_5_stress_psi':6*(500*1.5*3.125)/(3*.375**2),'required_minimum_Fy_psi':35000,'note':'Conservative3inwide strip, full500lb at cantilever tip; nominal3/8plate, local fastener/edge and thickness tolerances still require qualification.'},'outer_stringer_reference_patch':{'maximum_tributary_load_lb':600*8.75/26,'ultimate_stress_psi':3*(600*8.75/26)*37.75/4/((1.5*2**3-1.25*1.75**3)/12),'note':'600lb26inwide reference patch distributes to adjacent rails; separate500lbwheel1.5dynamic screen remains.'},'height_condition':{'nominal_loaded_coach_floor_in':32,'illustrated_station_floor_in':32,'station_height_selected':False,'maximum_measured_floor_difference_in':2.5,'slope_at_limit':abs(math.tan(bridge_angle(2.5))),'ratio_run_to_rise':1/abs(math.tan(bridge_angle(2.5))),'pitch_angle_deg':abs(math.degrees(bridge_angle(2.5))),'pitch_basis':'Exact tangency tofixedR2stationcrown withfixed1/8shim; coachhingeZ31.625, shoesoleZ28.125, stationcrowncenterZ26.125+rise','cross_slope_limit':1/48,'station_shoe_float_in':{'level_fore_keeper_clearance':.625,'level_rear_stop_clearance':.75,'minimum_nominal_pitched_fore_clearance':.31633823521876536,'lateral_x':.125,'uplift_gap':.25},'station_shoe_float_scope':'Actual level forekeeperclearance0.625in/rearstopclearance0.75in; nominalpitchedforeminimum0.316338in. Theseareclearances, notqualifiedmovementallowances. Fullindependentfloat/pitch envelopeunqualified.','station_transition_hinge_axis_yz_in':[-96.5,31.8125],'station_hinge_barrel_step_in':.1875,'joint_gap_limit_in':.625,'station_overlap_nominal_in':2,'station_overlap_after_hypothetical_0_75in_shift_in':1.25,'overlap_scope':'Nominal2inoverlap shown; independentfloat/pitch extremes notqualified','transition_plate_step_in':.1875},
 'suspension_review':{'loaded_floor_in':32,'accessible_empty_floor_mm_old_budget':827.14085,'accessible_empty_floor_mm_reconciled_budget_candidate':822.79514,'tare_budget_measured':False,'normal_heave_review_mm':[777.8,842.8],'roll_pitch_review_deg':1,'door_station_xy_in':[30,-52.25],'coach_clevis_axes_xyz_in':[[10.5,-52.25,31.625],[49.5,-52.25,31.625]],'body_pitch_reference_x_in':153,'roll_height_allowance_in':52.25*math.sin(math.pi/180),'pitch_height_allowance_in':123*math.sin(math.pi/180),'conclusion':'Full assumed +/-1 degree roll/pitch plus travel cannot be accepted against this bridge condition. Measure/freeze actual station threshold ranges and operational level-track limits; bridge is usable only within its stated height, slope, retention and gap conditions.'}},
 'door_screen':{'side_structural_opening_in':[42,78],'side_clear_boarding_path_in':[36,78],'end_clear_in':[36,78],'side_leaf_width_in':43,'end_leaf_width_in':37.5,'latch_axes_above_rail_in':[68,80],'actual_grip_centers_above_floor_in':[34.25,46.25],'candidate_uniform_pressure_psf':25,'side_pressure_resultant_lb':25*43*77.5/144,'side_two_latch_share_lb_each':25*43*77.5/144/4,'note':'25psf is an illustrative load case, not accepted wind design pressure. Portal reactions, slam, abuse, rail collision loads and life testing remain open.'}}
calc['assembly_mass_by_group_lb']=dict(mass)
calc['on_coach_candidate_physical_mass_lb']=sum(v for k,v in mass.items() if k in ['c4-door-frame','c4-side-leaf','c4-end-leaves','c4-coach-dock','c4-securement-foundation','c4-edge-guards'])
calc['mass_budget_note']='Candidate physical component mass is not a net coach tare increment; replaced body/door allocations must be reconciled and reservations/procured parts remain excluded.'
(O/'calculations.json').write_text(json.dumps(calc,indent=2))
retention=json.loads((O/'retention-check.json').read_text())
retention['scope']='Base OEM retainer selection/free-spring geometry checks. Location records precede final edge/header/station changes; use final model and listed final placement reports.'
retention['final_placement_reports']={'coach_pins':'pitch-check.json + edge-hinge-independent-review.json','front_handrail_pins':'front-header-check.json','station_keepers_and_rear_hardware':'rear-header-check.json + station-pitch-check.json','station_transition_pin':'transition-hinge-check.json + station-pitch-check.json'}
(O/'retention-check.json').write_text(json.dumps(retention,indent=2))
# Separate spring-fit exclusions from removed/superseded old fastening pairs.
br=json.loads((O/'bridge-joint-check.json').read_text())
br['spring_contact_exclusions']=sum(q.get('pass') is None and 'classification' in q for q in br['checks'])
br['superseded_count']=sum(q.get('pass') is None and 'superseded' in q for q in br['checks'])
(O/'bridge-joint-check.json').write_text(json.dumps(br,indent=2))
sources=[
 {'id':'C4-S1','title':'Q’STRAINT QRT-360 OEM product information','url':'https://www.qstraint.com/qrt-360/','use':'Rail application; candidate4-point system. Product qualification does not qualify the coach installation.'},
 {'id':'C4-S2','title':'Q’STRAINT L-Track OEM product information','url':'https://www.qstraint.com/l-track/','use':'6061-T6;82-degree countersink;5/16 bolts at4-inch pitch; short lengths require supplier confirmation.'},
 {'id':'C4-S3','title':'Q’STRAINT Q5-1150-QRT360 RevF manufacturer manual, archived mirror','url':'https://www.manualslib.com/manual/3964011/Q-Straint-Qrt-360.html','use':'Manufacturer-authored primary document hosted by an archive. Pages7,8,14–16: overall retractor reservation, layout ranges and1.42x0.50 routed pocket. Current OEM issue must be obtained before release.'},
 {'id':'C4-S4','title':'36 CFR1192.83(c), primary regulatory comparison','url':'https://www.ecfr.gov/current/title-36/chapter-XI/part-1192/subpart-D/section-1192.83','use':'Bridge loading, edge protection, attachment, gaps and handrails; actual vehicle classification remains open.'},
 {'id':'C4-S5','title':'Access Board ADA Chapter10','url':'https://www.access-board.gov/ada/chapter/ch10/','use':'Side entry requires actual maneuverability; amusement ride gap exception references1192.83(c).'},
 {'id':'C4-S6','title':'Hydro6061 extrusion data sheet','url':'https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6061.pdf','use':'Unwelded T6 extrusion minimum38ksi ultimate,35ksi yield; welding reducesT6 strength.'},
 {'id':'C4-S7','title':'Kaiser6061 sheet/plate technical data','url':'https://online.kaiseraluminum.com/depot/PublicProductInformation/Document/1015/Kaiser_Aluminum_6061_Sheet_Coil_and_Plate.pdf','use':'0.098lb/in3 nominal density and10Msi modulus; typical strengths are not used as certified minimums.'},
 {'id':'C4-S8','title':'Adaptive Engineering Mobilift CX manufacturer information','url':'https://adaptivelifts.com/pdf/CX-infopack.pdf','use':'Conditional station-owned lift alternative:600lb,60in lift,34x56platform,standard32wide bridge. Standard bridge does not meet this project36-inch route target; OEM custom interface and train restraint approval needed.'},
 {'id':'C4-S9','title':'Portaramp rail ramp manufacturer brochure','url':'https://www.portaramp.ca/wp-content/uploads/2022/07/Portable-Wheelchair-Ramps-for-the-Rail-Industry-Rail-Ramp-Brochure-CANADA.pdf','use':'Rail-specific procurement alternative; brochure lists300kg SWL and760/850mm widths, both narrower than36-inch project target. Request custom36clear candidate, not assume stock fit.'}]
sources.append({'id':'C4-S10','title':'JW Winco GN1024 manufacturer catalog and supplied STEP','url':'https://www.jwwinco.com/en-us/products/product-family/Stainless-Steel/GN-1024-Stainless-Steel-Spring-Cotter-Pins','use':'Actual3E/4E free spring geometry and shaft/crosshole selection; installed spring deflection, retention capacity and vibration qualification remain open.'})
sources.extend({'id':'C4-S11','title':'JW Winco GN912.3 reduced-head screw catalog','url':v['url'],'use':v['use']} for v in json.loads((O/'edge-hardware-check.json').read_text()).get('sources',[]))
sources.append({'id':'C4-S12','title':'Portland Bolt SAEJ429 manufacturer technical reference','url':'https://www.portlandbolt.com/technical/specifications/sae-j429/','use':'ConditionalGrade8proof comparisons; modeledcustomfasteners are not certifiedprocureditems and comparisons do notqualifyjoints.'})
from header_loadscreen import screen
strength=screen(dead_coach,dead_station)
(O/'header-loadscreen.json').write_text(json.dumps(strength,indent=2))
station_report=json.loads((O/'station-pitch-check.json').read_text())
if 'transition_hinge' in station_report:(O/'transition-hinge-check.json').write_text(json.dumps(station_report['transition_hinge'],indent=2))
header_reports={n:json.loads((O/(n+'.json')).read_text()) for n in ['front-header-check','rear-header-check','station-pitch-check','transition-hinge-check'] if (O/(n+'.json')).exists()}
calc['bridge']['header_and_station_reports']=header_reports
calc['bridge']['failed_strength_screens']=strength
(O/'calculations.json').write_text(json.dumps(calc,indent=2))
sheetlist=[{'id':'C4-A04','file':'C4-A04.svg.gz','preview':'C4-A04.png','title':'Threshold-edge hinge, guards and floor pockets'},{'id':'C4-A01','file':'C4-A01.svg.gz','preview':'C4-A01.png','title':'Side-loading doorway and offset enddoors'}, {'id':'C4-A02','file':'C4-A02.svg.gz','preview':'C4-A02.png','title':'Conditional station bridge, docking and storage'}, {'id':'C4-A03','file':'C4-A03.svg.gz','preview':'C4-A03.png','title':'Wheelchair restraint interfaces and frame load path'}]
sheetlist.sort(key=lambda q:q['id'])
record={'revision':'C4-R0-PRELIMINARY','title':'Accessible coach: side-loading doors, boarding and restraint interfaces','units':'inches','source_commit':'0f689682ddc40c6024e9d888625d22dcdf84170a','normal_boarding':'Side-loading through42-inch structural side portal with36-inch actual clear guarded path. NegativeY illustrated; physical handing provisional until station coordination. Both stations use same normal boarding/unloading side. Enddoors are not the normal ADA boarding path.',
 'completed_scope':['Accessible side portal relocates C1 post25:42in structural opening,36in clear guarded boarding path,78in clear height.','Offset enddoor portal36 clear atY−12..24, actual steel leaves, interleaved hinges, retained pins and two independently operated captive shoot bolts.','Original36-clear station-owned bridge with boxed transverse headers, pinned coach clevises, captured station shoes, transition plate, edge curbs and removable handrails.','Station storage rack with removable bolted retaining bar and actual stored-bridge fit. Complete lockable retractor cabinet reserved outside enddoor route.','Split underfloor restraint support members fitted between main girder and existing seat rails; separate short-track pockets avoid girder through-bolts.','Both actual guarded bridge approaches swept with one reversal, fixed passengers, other wheelchair and other-bay retractor reservations. Full30x48proxy clears side guards before turning.'],
 'unfinished':['Bridge concentrated near-end/interface structural screens fail. Header, tongue/notch and connection load paths require redesign and qualification before passenger use.','Site height/gap, stopping tolerance, body roll/pitch and final suspension range.','Complete accessible shell framing/skin/glazing, weather seals, body structural analysis and manufacture.','Door slam/wind loads, latch/hinge endurance, egress and movement interlock architecture; enddoor sweep against actual endplatform/gangway and adjacent vehicles.','Station rack foundation anchors, handling trolley and separate detached-handrail storage bracket. Complete purchased storage cabinet and its mounting hardware.','Station transition hinge needs a compatible continuous tread cover over interknuckle gaps; cover selection and attachment remain open.','Bridge whole-assembly load test, joint/handrail socket qualification, wear and handling assessment; no rated capacity issued.','Securement current OEM installation drawing, approved short-track lengths and first-hole phase, exact retractor anchorage point within its housing, device attachment points, occupant shoulder/lap routing and load qualification.','Bolts crossing existing seat rails require resolved sleeves or a vendor-approved hole phase. Track fasteners remain reservations, not a released drill pattern.','Full WTORS installation approval and real mobility-device trials.'],
 'capacity':{'fixed_seats':11,'folding_seats':2,'wheelchair_bays':2,'zero_wheelchair_seats':13,'one_wheelchair_seats':12,'two_wheelchair_seats':11,'passengers_each_mode':13},
 'drawing_sheets':sheetlist,'viewer_models':{'boarding':'model-boarding.json.gz','travel':'model-travel.json.gz'},'sources':sources,'floor_cuts':json.loads((O/'edge-hardware-check.json').read_text())['floor_cuts'],'threshold_pitch_geometry':json.loads((O/'pitch-check.json').read_text()),'frame_replacement_mapping':{'FRAME-P1':'P-1','FRAME-FRONT':'T-3_1','FRAME-REAR':'T309_1'},'parked_wheelchair_proxies':[{'bay':r['bay'],'bounds_in':r['parked_body_bounds'],'heading_deg':0} for r in paths['reports']],'calculations_file':'calculations.json','maneuvering_file':'maneuvering-verification.json','release_status':'UNRATED DEVELOPMENT GEOMETRY — STRUCTURAL SCREENS FAIL — NOT FOR CONSTRUCTION'}
tieproposals=[]
for r in paths['reports']:
 b=r['bay'];dx=66*(b-1);bb=r['parked_body_bounds'];yc=sum(bb['y'])/2
 ties=[]
 for tag,xf,ys,xd in [('rear',72+dx,[-41,-27],bb['x'][0]+16),('front',122+dx,[-47.5,-20.5],bb['x'][0]+36)]:
  for j,yf in enumerate(ys):
   endpoint=[xd,yc+(-10 if j==0 else 10),47];origin=[xf,yf,32];run=math.hypot(endpoint[0]-xf,endpoint[1]-yf)
   ties.append({'position':tag,'floor_interface_origin_in':origin,'illustrative_device_point_in':endpoint,'elevation_deg':math.degrees(math.atan2(15,run)),'plan_splay_deg':math.degrees(math.atan2(abs(endpoint[1]-yf),abs(endpoint[0]-xf)))})
 tieproposals.append({'bay':b,'ties':ties,'status':'Illustrative device-frame points within actual parked30x48proxy. Device attachment points and exact web exit inside purchased retractor remain unknown; angles are not OEM acceptance.'})
record['conditional_tie_geometry']=tieproposals
(O/'frame-replacements.json').write_text(json.dumps(record['frame_replacement_mapping'],indent=2))
record['header_and_station_reports']=header_reports
record['structural_release']='FAILED CONCENTRATED PROBES: redesign and qualified structural acceptance required before passenger use'
record['strength_screen_file']='header-loadscreen.json'
record['coordinate_system']='Coach X front-to-rear, Y transverse, Z above rail; inches; proposed loaded floorZ32'
record['actual_joint_detail']='Nominal bores, mating fasteners, spacers, crush sleeves, hinge knuckles and positive retainers are included. Threads are nominal mating envelopes, not helical manufacture models. Named OEM reservations are not fabricated substitutes.'
(O/'design-record.json').write_text(json.dumps(record,indent=2))
(O/'sources.json').write_text(json.dumps(sources,indent=2))
checks=[]
def check(n,ok,detail):checks.append({'name':n,'pass':bool(ok),'detail':detail})
check('Side structural opening',51-9==42,'Portal jambs X6..9 and51..54; door held180 outside opening.')
check('End clear width',24-(-12)==36,'Offset openingY−12..24. Enddoors closed in normal side-boarding state; endplatform/gangway operating clearance remains unqualified.')
check('Bridge curb clear width',48-12==36,'Curbs inside facesX12/48; Rigid deck endsY−52.125; coach edgeY−52; hingeY−52.25.')
check('Handrail clear width',49-11>=36,'Inside handrail surfacesX11/49;38 clear. Curbs govern36.')
check('Retained seat count',sum(s['seats'] for s in layout['fixed_seats'])==11,'11fixed+2fold; eachWC replacesonefold place.')
for q in paths['reports']:
 check(f'Bay{q["bay"]} continuous sampled sweep',q['collision_count']==0 and q['conservative_continuous_clearance_lower_bound_in']>0,f'{q["sample_count"]}samples;lowerbound{q["conservative_continuous_clearance_lower_bound_in"]:.6f}in;one reversal.')
 check(f'Bay{q["bay"]} parked inside60x36',q['parked_inside_assigned60x36bay'],q['parked_body_bounds'])
 check(f'Bay{q["bay"]} other final parked pose',q['other_bay_at_actual_computed_parked_pose']['continuous_lower_bound_in']>0,q['other_bay_at_actual_computed_parked_pose'])
check('Bridge conditional slope',abs(math.tan(bridge_angle(2.5)))<1/12,'Measured floor difference limited2.5in across37.75in bearing pitch; station not selected.')
component_screen_references=[{'name':'Single stringer600lb screen at3x','stress_psi':3*rail600,'comparison_psi':38000,'passes_this_bound':3*rail600<38000,'scope':'Simple beam bound only; does not qualify connections or wholebridge.'},{'name':'Handrail post100lb screen','stress_psi':hrstress,'comparison_psi':46000,'passes_this_bound':hrstress<46000,'scope':'Socket/fasteners/bridge torsion remain unqualified.'}]
for p in M['parts']:
 if not p['display_only'] and p['group'] in ['c4-door-frame','c4-side-leaf','c4-end-leaves','c4-securement-foundation','c4-securement-storage']:
  b=p['bounds_in'];over= min(b['x'][1],306)>max(b['x'][0],0)+1e-6 and min(b['y'][1],24)>max(b['y'][0],-12)+1e-6 and b['z'][1]>32+1e-6 and b['z'][0]<110-1e-6
  if over:check('Route intrusion '+p['id'],False,b)
# Validate the reports actually issued, preserving intentionally superseded pairs.
report_names=['model-solid-check','bridge-joint-check','frame-joint-check','retention-check','storage-joint-check','pitch-check','edge-hardware-check','front-header-check','rear-header-check','station-pitch-check','transition-hinge-check']
reports={n:json.loads((O/(n+'.json')).read_text()) for n in report_names if (O/(n+'.json')).exists()}
for n,d in reports.items():
 if 'failed_count' in d:check(n+' declared joints',d['failed_count']==0,{k:d[k] for k in ['check_count','passed_count','failed_count','superseded_count','spring_contact_exclusions'] if k in d})
 if 'checks' in d and 'failed_count' not in d:check(n+' declared pairs',all(q.get('pass',True) is not False for q in d['checks']),{'count':len(d['checks'])})
 if 'contacts' in d:check(n+' nominal bearing contacts',all(q.get('distance_in',0)<1e-6 for q in d['contacts']),{'count':len(d['contacts']),'gaps':[q for q in d['contacts'] if q.get('distance_in',0)>=1e-6]})
 if 'joint_checks' in d:check(n+' declared mating pairs',all(q.get('pass',True) for q in d['joint_checks']),{'count':len(d['joint_checks'])})
 for k in ['invalid_solid_ids','duplicate_ids','rigid_collisions','rigid_member_collisions','stored_bridge_rack_collisions','unintended_collisions','collisions']:
  if k in d:check(n+' '+k,not d[k],d[k])
 for state in d.get('pitch_reports',[]):check(n+' pitch '+str(state['station_minus_coach_floor_in']),not state.get('rigid_collisions',[]),state)
door=json.loads((H/'door-mechanism-final-summary.json').read_text())
check('Door module solid validity',not door['invalid'],{'solid_count':door['parts']})
check('Door module declared connections',not door['target_unintended_penetrations'],door['target_unintended_penetrations'])
check('Side door sampled sweep',not door['sweep_collisions'],{'collisions':door['sweep_collisions'],'analytic_retainer_bound':door['analytical_cotter_exclusion']})
edgeind=json.loads((H/'edge-issued/edge-floor-cuts-and-checks.json').read_text())
check('Edge guard/foot independent three-pitch probe',not edgeind.get('targeted_guard_and_flushhead_penetrations',[]),{'penetrations':edgeind.get('targeted_guard_and_flushhead_penetrations',[])})
check('Guard straight-driver access',all(not q['unintended'] for q in edgeind.get('guard_driver_access',[])),{'probe_count':len(edgeind.get('guard_driver_access',[]))})
V={'status':'GEOMETRY CHECKS ONLY; STRUCTURAL SCREENS FAIL; UNRATED / NOT ACCEPTED','geometry_check_count':len(checks),'check_count':len(checks),'passed_count':sum(q['pass'] for q in checks),'failed_count':sum(not q['pass'] for q in checks),'checks':checks,'joint_reports':reports,'part_count':len(P),'physical_part_count':sum(p['kind']=='physical' for p in P),'path_reports':paths['reports'],'exclusions':record['unfinished'],'sources':sources}
V['component_screen_references']=component_screen_references
V['strength_screen_status']='FAIL — NOT RATED OR ACCEPTED'
V['strength_screens']=strength
V['failed_strength_screen_count']=strength.get('failed_strength_screen_count')
V['scope_of_passed_count']='Declared geometry/space/mating checks only. Excludes structural acceptance; failed strength screens are reported separately.'
(O/'verification.json').write_text(json.dumps(V,indent=2))
for n in ['maneuvering-verification.json','path-bay1.json','path-bay2.json','C4-path-study.svg','C4-path-study.png']:
 shutil.copy(H/n,O/n)
# Drafting views are directly projected CadQuery edge geometry.
edge={s:json.loads((O/f'drawing-edges-{s}.json').read_text()) for s in ['boarding','travel']}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':11,'axes.labelsize':9,'svg.fonttype':'none'})
def wire(ax,groups,proj,state='boarding',ids=None):
 for p in edge[state]:
  if p['group'] not in groups or (ids and not ids(p['id'])):continue
  lines=[np.array(q)[:,proj] for q in p['lines']]
  ax.add_collection(LineCollection(lines,colors='#ad8c44' if p['kind'] in ('reservation','reference') else '#284f52',linewidths=.35 if p['kind']=='physical' else .45,alpha=.75))
 ax.set_aspect('equal');ax.grid(alpha=.12);ax.tick_params(labelsize=8)
def wire_stored_bridge(ax):
 # Same rigid transform as storage_connections.py: translate(0,92,-32),
 # rotate X+90 degrees, then translate(59,-120.25,34.5). X/Z projection below.
 for p in edge['boarding']:
  if p['group']!='c4-bridge':continue
  lines=[np.array(q)[:,[0,1]]+np.array([59,126.5]) for q in p['lines']]
  ax.add_collection(LineCollection(lines,colors='#ad8c44',linewidths=.35,alpha=.75))
def dim(ax,p1,p2,label,offset=(0,0)):
 a=np.array(p1)+offset;b=np.array(p2)+offset
 ax.annotate('',xy=a,xytext=b,arrowprops={'arrowstyle':'<->','lw':.7,'color':'#675c4d'});ax.text(*(a+b)/2,label,ha='center',va='center',fontsize=8,color='#514a40',bbox={'facecolor':'white','edgecolor':'none','pad':1.5})
def title(fig,n,name):
 fig.text(.035,.96,'PULSIPHER RAILWAY  /  ACCESSIBLE COACH',fontsize=12,color='#35564d',weight='bold')
 fig.text(.035,.925,name,fontsize=20,color='#193f37',weight='bold');fig.text(.965,.955,n+'  ·  R0',ha='right',fontsize=16,color='#193f37')
 fig.text(.035,.025,'INCHES  |  GLOBAL COACH COORDINATES  |  PRELIMINARY — NOT FOR CONSTRUCTION',fontsize=9,color='#7e4e37');fig.text(.965,.025,'19 OCT 2026',ha='right',fontsize=9,color='#7e4e37')
def notes(ax,head,lines):
 ax.axis('off');ax.text(0,1,head,va='top',fontsize=12,weight='bold',color='#193f37');y=1-.28/(ax.figure.get_figheight()*ax.get_position().height)
 import textwrap,re
 for line in lines:
  line=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',line)
  line=re.sub(r'([,;])(?=\S)',r'\1 ',line)
  for old,new in [('abovefloor','above floor'),('perleaf','per leaf'),('endplatform','end platform'),('andtwo','and two'),('CandidateQRT','Candidate QRT'),('outsideY','outside Y'),('tiedowns','tie-downs')]:line=line.replace(old,new)
  ss=textwrap.fill(line,54);ax.text(0,y,ss,va='top',fontsize=9,linespacing=1.4,color='#344b47');y-=(9*1.4/72/(ax.figure.get_figheight()*ax.get_position().height))*(ss.count('\n')+1)+.04
def save(fig,n):
 fig.savefig(O/(n+'.svg'),facecolor='white');fig.savefig(O/(n+'.png'),dpi=160,facecolor='white');plt.close(fig)
fig=plt.figure(figsize=(17,11));title(fig,'C4-A01','Side-loading doorway and offset enddoors')
ax=fig.add_axes([.04,.39,.31,.49]);wire(ax,['c4-door-frame','c4-side-leaf','c4-coach-dock','c4-edge-guards'],[0,2],'travel',lambda s:s.startswith(('SD','EDGE'))) 
ax.set(xlim=(-1,60),ylim=(23,119),xlabel='Coach X',ylabel='Z above rail');ax.set_title('SIDE ELEVATION · CLOSED LEAF',loc='left');dim(ax,(9,114),(51,114),'42 STRUCTURAL OPENING');dim(ax,(12,27),(48,27),'36 CLEAR PATH');dim(ax,(57,32),(57,110),'78 CLEAR');ax.axhline(32,color='#967c56',lw=.7)
ax=fig.add_axes([.38,.39,.28,.49]);wire(ax,['c4-door-frame','c4-end-leaves'],[1,2],'travel',lambda s:s.startswith('FRONT'));ax.set(xlim=(-25,35),ylim=(23,119),xlabel='Coach Y',ylabel='Z');ax.set_title('FRONT END · OFFSET ROUTE',loc='left');dim(ax,(-12,114),(24,114),'36 CLEAR');ax.axhline(32,color='#967c56',lw=.7)
ax=fig.add_axes([.68,.39,.28,.49]);wire(ax,['c4-door-frame','c4-side-leaf','c4-end-leaves','c4-bridge','c4-handrails','c4-edge-guards'],[0,1],ids=lambda s:not s.startswith('REAR'));ax.set(xlim=(-48,66),ylim=(-100,58),xlabel='Coach X',ylabel='Coach Y');ax.set_title('BOARDING · SIDE OPEN / ENDDOORS CLOSED',loc='left');ax.add_patch(Arc((8.5,-57.5),86,86,theta1=180,theta2=360,color='#b58a4f',linestyle='--',lw=.8));ax.add_patch(Rectangle((0,-12),60,36,fill=False,edgecolor='#62a190',ls=':'));ax.annotate('SIDE LOADING',xy=(30,-53),xytext=(30,-88),ha='center',arrowprops={'arrowstyle':'->','lw':1.2},fontsize=8)
notes(fig.add_axes([.04,.075,.29,.25]),'Portal and leaf construction',['Replace the regular-body X25 post at this side. Jambs define a 42-inch structural opening; bridge curbs and threshold-edge guards govern the 36-inch clear boarding path. Header underside Z110.','Side leaf43wide; end leaf37.5wide. Three1/2-inch retained hinge pins, bored knuckles and1/4-inch tabs perleaf. Frame feet connect to steel through crush sleeves.'])
notes(fig.add_axes([.36,.075,.29,.25]),'Latches and operating sequence',['Two independent1/2-inch shoot bolts: lift/rotate key, retract2in, then swing. Actual grips34.25/46.25abovefloor. Positive180-degree side hold-open pin precedes boarding.','Side loading is the ADA boarding basis. Enddoors serve endplatform circulation; they are not the normal wheelchair boarding path.'])
notes(fig.add_axes([.68,.075,.28,.25]),'Remaining release work',['Confirm body skin/roof junction, seals, closing gaps, hinge and latch endurance, wind/slam loads and emergency release. Movement interlock remains to be engineered.','Open leaf sweep occupies the platform approach during opening. Keep the sweep vacant, lock leaf open, then place the bridge.'])
save(fig,'C4-A01')
fig=plt.figure(figsize=(17,11));title(fig,'C4-A02','Conditional station bridge, docking and storage')
ax=fig.add_axes([.04,.43,.32,.44]);wire(ax,['c4-bridge','c4-handrails','c4-coach-dock','c4-station-dock','c4-edge-guards'],[0,1]);ax.set(xlim=(3,57),ylim=(-102,-45),xlabel='Coach X',ylabel='Coach Y');ax.set_title('PLAN · 36-INCH CLEAR BOARDING PATH',loc='left');dim(ax,(12,-94),(48,-94),'36 CLEAR');dim(ax,(54,-90),(54,-52.25),'37.75 BEARING PITCH')
ax=fig.add_axes([.39,.43,.28,.44]);wire(ax,['c4-bridge','c4-handrails','c4-coach-dock','c4-station-dock','c4-edge-guards'],[1,2]);ax.set(xlim=(-103,-45),ylim=(23,74),xlabel='Coach Y',ylabel='Z');ax.set_title('SIDE ELEVATION · NOMINAL LEVEL DATUM',loc='left');ax.axhline(32,color='#997344',lw=.7);dim(ax,(-96,32),(-96,68),'36 HANDRAIL');ax.text(-82,35,'3/16 transition\n2 in overlap',fontsize=8)
ax=fig.add_axes([.70,.43,.26,.44]);wire(ax,['c4-station-storage'],[0,2]);wire_stored_bridge(ax);ax.set(xlim=(60,116),ylim=(25,82),xlabel='Station X',ylabel='Z');ax.set_title('STATION STORAGE RACK',loc='left');ax.text(64,27,'Stored bridge: handrails removed\nRack beyond 60-inch clear landing',fontsize=8);dim(ax,(68,79),(110,79),'42 RACK')
notes(fig.add_axes([.04,.075,.29,.29]),'Construction and handling',[f'Bolted6061 deck3/8; three2x2x1/8 central andtwo2x1.5x1/8 edge stringers. Continuous abrasive surface,2-inch edge curbs. CAD bridge mass{bridge:.1f}lb; removable handrails{rails:.1f}lb total.','Use station trolley and restrained rack. No bridge mass stored in the coach turning space. A removable bolted crossbar captures the upright bridge; actual stored fit checked. Rack station anchors and handrail storage remain held.'])
notes(fig.add_axes([.36,.075,.29,.29]),'Attachment and movement',['Two3/4-inch coach clevis pins with actual spring cotters;39.875-inch deck and37.75-inch bearings. Station shoes: level clearance0.625in fore/0.75in rear; pitched fore minimum0.316in. Lateral float+/-0.125in; uplift gap0.25in. Full movement envelope unqualified.','Station nose overlaps2in nominal;3/16 hinged transition covers the moving joint. Train movement prevented before deployment. Threshold-edge pivot leaves1/8-inch nominal joint;600lb tip load creates1.99lb station uplift. Interface screen2550lb ultimate plus handrail moment; local joints still require qualification.'])
notes(fig.add_axes([.68,.075,.28,.29]),'UNRATED / structural redesign',['Concentrated near-end/interface strength screens FAIL. Structural redesign is required before passenger use. See the engineering record for failed header and tongue probes.','Station height and gap remain unselected. The 2.5-inch floor difference limit gives at most 3.81 degrees, approximately 1:15.03, with fixed-crown contact.','The 600-pound reference load and 3x ultimate criterion do not rate this assembly. Site, suspension, joint and whole-assembly qualification remain open.'])
save(fig,'C4-A02')
fig=plt.figure(figsize=(17,11));title(fig,'C4-A03','Wheelchair restraint interfaces and frame load path')
ax=fig.add_axes([.04,.43,.62,.44]);wire(ax,['c4-securement-foundation','c4-oem-reservations'],[0,1]);ax.set(xlim=(54,199),ylim=(-60,-6),xlabel='Coach X',ylabel='Coach Y');ax.set_title('TWO 60 × 36 BAYS · STRAPS REMOVED DURING ENTRY',loc='left')
for b,r in zip(layout['wheelchair_bays'],paths['reports']):
 ax.add_patch(Rectangle((b['x'][0],-52),60,36,fill=False,edgecolor='#468999',lw=1.2));v=r['parked_body_bounds'];ax.add_patch(Rectangle((v['x'][0],v['y'][0]),48,30,facecolor='#83a5ae',alpha=.15,edgecolor='#4b7c85'));ax.text(sum(b['x'])/2,-12,b['id']+' / OPTIONAL FOLD STOWED',ha='center',fontsize=8);dim(ax,(b['x'][0],-57),(b['x'][1],-57),'60 CLEAR')
for prop in tieproposals:
 for tie in prop['ties']:
  a=tie['floor_interface_origin_in'];b=tie['illustrative_device_point_in'];ax.plot([a[0],b[0]],[a[1],b[1]],'--',color='#a36a37',linewidth=.9)
ax.text(120,-8,'Dashed straps use illustrative device points; actual attachments unresolved',ha='center',fontsize=7)
ax=fig.add_axes([.70,.43,.26,.44]);wire(ax,['c4-securement-foundation','c4-oem-reservations'],[1,2],ids=lambda s:s.startswith('WC1-REAR'))
ax.set(xlim=(-57,-12),ylim=(24,38),xlabel='Coach Y',ylabel='Z');ax.set_title('REAR ANCHOR SUPPORT SECTION',loc='left')
for y0,y1,dep in [(-55,-53,4),(-45,-43,3),(-36,-32,12),(-21,-19,3)]:ax.add_patch(Rectangle((y0,31.003937-dep),y1-y0,dep,facecolor='#b9c8cd',edgecolor='#52757e',alpha=.6))
ax.axhline(32,color='#967c56',lw=.7);ax.text(-53,35.4,'Existing rails shaded\nNo main-girder through-bolt',fontsize=8)
notes(fig.add_axes([.04,.075,.29,.29]),'OEM system / exact limits',['CandidateQRT-360 four-point retractors plus separate occupant lap/shoulder belt. Overall5.4x4.5x2.5 reservations are manufacturer manual dimensions, not replicas.','OEM track:1.42wide x0.50deep routed pocket;5/16 bolts at4-inch pitch. Short-track length, first-hole offset and anchorage location within housing require current OEM approval.'])
notes(fig.add_axes([.36,.075,.29,.29]),'Original frame interface',['Rear anchor stationsX72/138; front122/188. Rear spread14; front27. Separate short tracks avoid the main girder. Custom4x7x1/4 saddles and split3x2x3/16 members connect to existing steel.','Post X78/144 supports shoulder-anchor zone outsideY−52. Its foot uses1/2-inch bolts and perimeter crush sleeves. OEM belt guide and device frame attachments are unresolved.'])
notes(fig.add_axes([.68,.075,.28,.29]),'Use and acceptance',['Before access, remove all four retractors from the active bay and fit flush track covers; optional fold is locked upright. Other occupied bay retains its four retractors.','Fold-only mode: no wheelchair tiedowns deployed in that bay. The complete vehicle WTORS load path, belt angles and actual device fit are not yet approved. See independent bridge-path study.'])
save(fig,'C4-A03')
print(json.dumps({'parts':len(P),'checks':len(checks),'failed':sum(not q['pass'] for q in checks),'bridge_lb':bridge,'handrails_lb':rails,'rail_stress3_psi':3*rail600,'handrail_stress_psi':hrstress},indent=2))

# Actual threshold-edge hardware: final exported edges, including guards and replacement feet.
fig=plt.figure(figsize=(17,11));title(fig,'C4-A04','Threshold-edge hinges, guards and floor transition')
edgegroups=['c4-door-frame','c4-coach-dock','c4-bridge','c4-edge-guards']
def threshold_ids(s):
 return s.startswith(('SD-J','SD-F','SD-THRESH','COACH-THRESH','COACH-EDGE','BR-COACH-LUG','BR-PIN','PIN-COTTER-14--54','PIN-COTTER-46--54','EDGE-')) or s in ['BR-DECK','BR-END--54','BR-CURB-11.75','BR-CURB-48']
ax=fig.add_axes([.04,.59,.92,.27]);wire(ax,edgegroups,[0,1],ids=threshold_ids)
ax.set(xlim=(4,56),ylim=(-59.5,-47.5),xlabel='Coach X',ylabel='Coach Y');ax.set_title('THRESHOLD PLAN · ATTACHED GUARDS AND EDGE RECEIVERS',loc='left')
dim(ax,(9,-48.5),(51,-48.5),'42 STRUCTURAL OPENING');dim(ax,(12,-50),(48,-50),'36 CLEAR PATH')
for x in [10.5,49.5]:ax.plot(x,-52.25,'+',color='#a66f3b',markersize=7)
ax.annotate('Pivot axes Y −52.25',xy=(10.5,-52.25),xytext=(20,-57.7),ha='left',fontsize=8,arrowprops={'arrowstyle':'->','lw':.7,'color':'#a66f3b'})
ax.text(32,-57.7,'Deck edge Y −52.125 / coach edge Y −52',fontsize=8,color='#514a40')
leftids=lambda s:threshold_ids(s) and not s.startswith(('EDGE-R','COACH-EDGE-BASE-49.5','COACH-EDGE-HEEL-49.5','COACH-EDGE-GUSSET-49.5','BR-COACH-LUG-46','BR-PIN-46','BR-PIN-HEAD-46','PIN-COTTER-46'))
ax=fig.add_axes([.04,.285,.27,.245]);wire(ax,edgegroups,[0,2],ids=leftids)
ax.set(xlim=(7,14),ylim=(27.5,35),xlabel='Coach X',ylabel='Z above rail');ax.set_title('LEFT POCKET · FRONT PROJECTION',loc='left');ax.axhline(32,color='#997344',lw=.7)
ax.plot(10.5,31.625,'+',color='#a66f3b',markersize=8);ax.annotate('Pin Ø3/4',xy=(10.5,31.625),xytext=(11.3,28.4),fontsize=8,arrowprops={'arrowstyle':'->','lw':.7})
ax=fig.add_axes([.37,.285,.27,.245]);wire(ax,edgegroups,[1,2],ids=leftids)
ax.set(xlim=(-59,-49),ylim=(27.5,35),xlabel='Coach Y',ylabel='Z');ax.set_title('LEFT HINGE · SIDE PROJECTION',loc='left');ax.axhline(32,color='#997344',lw=.7)
ax.plot(-52.25,31.625,'+',color='#a66f3b',markersize=8);ax.annotate('Axis Z31.625',xy=(-52.25,31.625),xytext=(-58.6,34.3),fontsize=8,arrowprops={'arrowstyle':'->','lw':.7})
notes(fig.add_axes([.70,.285,.26,.245]),'Threshold section / nominal datums',['One-piece machined steel threshold bar is flush at Z32. The 3/8-inch deck ends 1/8 inch from the coach edge in the level state. Bearing pitch is 37.75 inches.','Receiver guards, spacers and screws are actual exported parts. Guards are removed for pin/cotter servicing with the boarding area vacant.'])
notes(fig.add_axes([.04,.075,.29,.155]),'Floor and steel load path',['Full-depth edge pockets and central threshold cutout replace the floor locally. The one-piece threshold bar and backing angle transfer load to the perimeter frame, with nominal 1/8-inch fillets. No wood-panel support credit.'])
notes(fig.add_axes([.36,.075,.29,.155]),'Positive pin retention',['Two Ø3/4 coach pins use actual OEM spring cotters. The source shape is the free spring form; installed deflection, pullout capacity and vibration retention require qualification.'])
notes(fig.add_axes([.68,.075,.28,.155]),'UNRATED / failed strength probes',['Near-end connection strength probes FAIL. Structural redesign is required before passenger use; see the engineering record. Continuous movement, elastic clearance, tolerance and hand/glove checks also remain open.'])
save(fig,'C4-A04')
