"""C4 preliminary accessible doorway, docking bridge and restraint interfaces.
All construction geometry is original preliminary design. Purchased restraint
parts are explicitly reservations: no OEM internal geometry/hole offsets inferred.
Run with CadQuery 2.7; inch coordinate system retained in JSON, STEP uses mm.
"""
from pathlib import Path
import json,gzip,math,copy
import cadquery as cq
import numpy as np
H=Path(__file__).parent
OUT=H/'issued';OUT.mkdir(exist_ok=True)
parts=[]
def box(x0,x1,y0,y1,z0,z1):
 return cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,cq.Vector(x0,y0,z0))
def cyl(r,h,p,d=(0,0,1)):
 return cq.Solid.makeCylinder(r,h,cq.Vector(*p),cq.Vector(*d))
def tube(x0,x1,y0,y1,z0,z1,axis,t):
 b=[x0,x1,y0,y1,z0,z1];i='xyz'.index(axis)
 q=b.copy()
 for j in range(3):
  if j==i:q[2*j]-=.01;q[2*j+1]+=.01
  else:q[2*j]+=t;q[2*j+1]-=t
 return box(*b).cut(box(*q))
def add(pid,name,group,s,material='A500 steel, preliminary',color='#61767b',kind='physical',move=None):
 parts.append(dict(id=pid,name=name,group=group,shape=s,material=material,color=color,kind=kind,move=move))
def bolt(pid,p,d,h=.75,r=.25,group='c4-door-frame'):
 add(pid,'Proposed captive pin / fastener '+pid,group,cyl(r,h,p,d),'Steel, grade / proof load to be selected','#c5c9c5')
def cut_holes(s,centers,r,axis='z'):
 for p in centers:
  d={'x':(1,0,0),'y':(0,1,0),'z':(0,0,1)}[axis]
  pp=list(p);pp['xyz'.index(axis)]-=10
  s=s.cut(cyl(r,20,pp,d))
 return s
# Side portal: entirely outside the 42-inch opening and interior Y=-52 boundary.
for i,x in enumerate([6,51]):
 add(f'SD-J{i+1}','Side doorway jamb HSS 3 x 2 x 1/8','c4-door-frame',tube(x,x+3,-55,-53,31.253937,110,'z',.125))
 foot=cut_holes(box(x-1.5,x+4.5,-56,-52,31.003937,31.253937),[(x-.75,-54,32),(x+3.75,-54,32)],.28125)
 add(f'SD-F{i+1}','Jamb foot 6 x 4 x 1/4; two 9/16 holes','c4-door-frame',foot)
 for xx in [x-.75,x+3.75]:
  bolt(f'SD-FOOT-BOLT-{xx}',(xx,-54,26.5),(0,0,1),5,.25)
  add(f'SD-FOOT-SLEEVE-{xx}','Perimeter rail crush sleeve OD3/4 ID9/16','c4-door-frame',cyl(.375,4,(xx,-54,27.003937)).cut(cyl(.28125,4.02,(xx,-54,26.993937))))
  add(f'SD-FOOT-NUT-{xx}','1/2 inch nut body; thread not modeled','c4-door-frame',cyl(.4375,.4375,(xx,-54,26.5)).cut(cyl(.25,.45,(xx,-54,26.49))))
add('SD-H','Side portal header HSS 2 x 2 x 1/8','c4-door-frame',tube(6,54,-55,-53,110,112,'x',.125))
add('SD-SILL','Threshold transfer tube 3 x 3 x 3/16','c4-coach-dock',tube(6,54,-55,-52,28.625,31.625,'x',.1875))
add('SD-THRESH','Flush threshold plate, 42 x 3 x 3/8','c4-coach-dock',box(9,51,-55,-52,31.625,32))
# Closed side leaf has overlapping seals; hinge outside body skin, opens clockwise 180deg.
sideaxis=(8.5,-57.5,0)
for pid,b,a in [('L',(8.5,10,-57,-55.5,32.25,109.75),'z'),('R',(50,51.5,-57,-55.5,32.25,109.75),'z'),('B',(10,50,-57,-55.5,32.25,33.75),'x'),('T',(10,50,-57,-55.5,108.25,109.75),'x'),('M',(10,50,-57,-55.5,63,64.5),'x')]:
 add('SD-LF-'+pid,'Side leaf HSS 1.5 x 1.5 x 0.083','c4-side-leaf',tube(*b,a,.083),'6061-T6 aluminum; welded HAZ check required','#9d805b',move=('side',))
add('SD-PANEL','Lower leaf skin 0.063 in','c4-side-leaf',box(10,50,-57.063,-57,33.75,63),'Aluminum','#967c59',move=('side',))
add('SD-GLASS','Laminated safety glazing reservation','c4-side-leaf',box(10,50,-56.45,-56.2,64.5,108.25),'Glazing specification unresolved','#8db7bf',kind='reservation',move=('side',))
for z in [42,70,100]:
 for j,(zz,h) in enumerate([(z,1.5),(z+1.625,1.5),(z+3.25,1.5)]):
  s=cyl(.5,h,(8.5,-57.5,zz)).cut(cyl(.265,h+.02,(8.5,-57.5,zz-.01)))
  add(f'SD-HNG-{z}-{j}','Hinge sleeve OD1 / ID0.530','c4-side-leaf' if j==1 else 'c4-door-frame',s,move=('side',) if j==1 else None)
 bolt(f'SD-PIN-{z}',(8.5,-57.5,z-.25),(0,0,1),5.3,.25)
 add(f'SD-HNG-FIX-{z}','Hinge frame tab 1/4 plate','c4-door-frame',box(6.5,9,-57.5,-54, z,z+.25))
 add(f'SD-HNG-LEAF-{z}','Hinge leaf tab 1/4 plate','c4-side-leaf',box(8.5,11,-57.5,-55.8,z+1.625,z+1.875),move=('side',))
# Dual shoot bolts and guarded operating handle; load/supplier specification not released.
for z in [34,106]:
 add('SD-BOLT-'+str(z),'Slide bolt 1/2 diameter, 1-inch engagement','c4-side-leaf',cyl(.25,3,(49,-54.75,z),(1,0,0)),move=('side',))
 add('SD-STRIKE-'+str(z),'Steel strike keeper 1/4 plate with 9/16 bore','c4-door-frame',cut_holes(box(51,52,-55.5,-54, z-.75,z+.75),[(51,-54.75,z)],.28125,'x'))
add('SD-HANDLE','Guarded two-bolt release handle','c4-side-leaf',cyl(.375,6,(48,-53.4,66)),move=('side',))
add('SD-ROD','Protected vertical latch linkage','c4-side-leaf',cyl(.1875,72,(49,-54.75,34)),move=('side',))
add('SD-HOLD','180-degree hold-open bracket; captive retaining pin','c4-door-frame',box(-32,-29,-59.75,-57.75,65,68))
# End portals: offset 36-inch aperture, Y=-12..24. Leaves fold to the -Y endwall.
for e,x,sign in [('FRONT',-3,-1),('REAR',309,1)]:
 for y in [-15,24]:
  add(e+'-J'+str(y),'End portal HSS 3 x 2 x 1/8','c4-door-frame',tube(x-1,x+1,y,y+3,31.378937,110,'z',.125))
  foot=cut_holes(box(x-2,x+2,y-1.5,y+4.5,31.003937,31.378937),[(x,y-.75,31),(x,y+3.75,31)],.28125)
  add(e+'-FOOT-'+str(y),'End jamb foot 4 x 6 x 3/8','c4-door-frame',foot)
  for yy in [y-.75,y+3.75]:
   bolt(e+'-FOOT-BOLT-'+str(yy),(x,yy,24.5),(0,0,1),7,.25)
   add(e+'-FOOT-SLEEVE-'+str(yy),'End crossmember crush sleeve OD3/4 ID9/16','c4-door-frame',cyl(.375,6,(x,yy,25.003937)).cut(cyl(.28125,6.02,(x,yy,24.993937))))
 add(e+'-HEAD','End portal header, 36-inch clear width','c4-door-frame',tube(x-1,x+1,-15,27,110,112,'y',.125))
 xx=x+sign*2.5; y0=-13; y1=25
 move=('end',xx,-13,sign)
 for pid,b,a in [('L',(xx-.75,xx+.75,y0,y0+1.5,32.25,109.75),'z'),('R',(xx-.75,xx+.75,y1-1.5,y1,32.25,109.75),'z'),('B',(xx-.75,xx+.75,y0+1.5,y1-1.5,32.25,33.75),'y'),('T',(xx-.75,xx+.75,y0+1.5,y1-1.5,108.25,109.75),'y'),('M',(xx-.75,xx+.75,y0+1.5,y1-1.5,63,64.5),'y')]:
  add(e+'-LF-'+pid,'End leaf HSS 1.5 x 1.5 x 0.083','c4-end-leaves',tube(*b,a,.083),'6061-T6 aluminum; HAZ check required','#9d805b',move=move)
 add(e+'-PANEL','End leaf lower panel','c4-end-leaves',box(xx-.063,xx,y0+1.5,y1-1.5,33.75,63),'Aluminum','#967c59',move=move)
 add(e+'-GLASS','End leaf safety glazing reservation','c4-end-leaves',box(xx,xx+.25,y0+1.5,y1-1.5,64.5,108.25),'Glazing unresolved','#8db7bf',kind='reservation',move=move)
 for z in [42,70,100]:
  add(e+'-HINGE-'+str(z),'End hinge sleeve and pin envelope','c4-door-frame',cyl(.5,4.5,(xx,-13,z)).cut(cyl(.265,4.52,(xx,-13,z-.01))))
  bolt(e+'-PIN-'+str(z),(xx,-13,z-.25),(0,0,1),5,.25)
 for z in [42,70,100]:
  add(e+'-HINGE-FRAME-TAB-'+str(z),'End hinge frame tab 1/4 plate','c4-door-frame',box(min(x,xx),max(x,xx),-14,-12,z,z+.25))
  add(e+'-HINGE-LEAF-TAB-'+str(z),'End hinge leaf tab 1/4 plate','c4-end-leaves',box(xx-.75,xx+.75,-13,-10.5,z+1.625,z+1.875),move=move)
 for z in [34,106]:
  add(e+'-BOLT-'+str(z),'Enddoor slide bolt 1/2, 1-inch keeper engagement','c4-end-leaves',cyl(.25,3,(xx,22,z),(0,1,0)),move=move)
  add(e+'-STRIKE-'+str(z),'Enddoor 1/4 keeper, 9/16 bore','c4-door-frame',cut_holes(box(xx-.75,xx+.75,24,25,z-.75,z+.75),[(xx,24,z)],.28125,'y'))
 add(e+'-HANDLE','Enddoor guarded release handle','c4-end-leaves',cyl(.375,6,(xx-sign*1.3,22,66)),move=move)
 add(e+'-LINK','Two-point linkage rod, 3/8 diameter','c4-end-leaves',cyl(.1875,72,(xx,22,34)),move=move)
 for z in [35,65,105]:
  add(e+'-LINK-GUIDE-'+str(z),'Linkage guide 1/4 bracket, 7/16 bore','c4-end-leaves',box(xx-.5,xx+.5,21.5,22.5,z,z+.25).cut(cyl(.22,.27,(xx,22,z-.01))),move=move)
 add(e+'-HOLD-OPEN','Enddoor 180-degree hold-open keeper','c4-door-frame',box(xx-1,xx+1,-49,-46,65,68))
# Detachable station-owned bridge: 36 clear, 36 long, 32-inch bearing pitch.
# Unwelded 6061 structural members; deck bolted to stringers to preserve T6 properties.
add('BR-DECK','Bridge deck 36.5 x 36 x 3/8; bonded abrasive finish','c4-bridge',box(11.75,48.25,-88,-52,31.625,32),'6061-T6 aluminum, bolted','#bac0b9')
for x in [12.5,21.25,30,38.75,47.5]:
 add('BR-RAIL-'+str(x),'Bridge stringer 2 x 1.5 x 1/8, 32 long','c4-bridge',tube(x-.75,x+.75,-86,-54,29.625,31.625,'y',.125),'6061-T6 unwelded','#7d8e93')
for x in [11.75,48]:
 add('BR-CURB-'+str(x),'Bridge edge curb 2 high x 1/4','c4-bridge',box(x,x+.25,-88,-55,32,34),'6061-T6 aluminum','#d5a64d')
for y in [-86,-54]:
 add('BR-END-'+str(y),'Bridge transverse bearing angle, 1/4 plate','c4-bridge',box(11.75,48.25,y-.75,y+.75,29.375,29.625),'6061-T6 aluminum','#8b9a9c')
for x in [14,46]:
 for i,xx in enumerate([x-1,x+.5]):
  lug=box(xx,xx+.5,-55.25,-52.75,28.875,31.625).cut(cyl(.39,.52,(xx-.01,-54,30.25),(1,0,0)))
  add(f'BR-COACH-LUG-{x}-{i}','Coach clevis cheek 1/2 plate, 0.780 bore','c4-coach-dock',lug)
 mid=box(x-.45,x+.45,-55,-53,29.25,31.25).cut(cyl(.39,.92,(x-.46,-54,30.25),(1,0,0)))
 add('BR-TONGUE-'+str(x),'Bridge clevis tongue and 3/4 captive pin','c4-bridge',mid,'6061-T6 aluminum','#8b9a9c')
 bolt('BR-PIN-'+str(x),(x-1.2,-54,30.25),(1,0,0),2.5,.375,'c4-coach-dock')
 # Far end captured shoe is retained in a slotted station channel; free pitch via rocker face.
 add('BR-SHOE-'+str(x),'Station-end sliding shoe 2 x 3, captured under channel lips','c4-bridge',box(x-1,x+1,-87.5,-84.5,28.875,29.375),'Steel, isolated from aluminum','#7d8e93')
 add('ST-BEAR-'+str(x),'Station shoe bearing pad, 1/4 plate','c4-station-dock',box(x-2,x+2,-89,-83,28.625,28.875))
 for xx in [x-1.375,x+1.125]:
  add(f'ST-LIP-{x}-{xx}','Capturing channel upstand; removable entry keeper','c4-station-dock',box(xx,xx+.25,-89,-83,28.625,30))
  add(f'ST-TOP-{x}-{xx}','Uplift retaining lip; 0.25 vertical service gap','c4-station-dock',box(xx if xx<x else xx-.75,xx+1 if xx<x else xx+.25,-89,-83,29.625,29.875))
 for yy in [-88.5,-83.75]:add(f'ST-ENDSTOP-{x}-{yy}','Station channel travel stop; +/-0.75 longitudinal float','c4-station-dock',box(x-1.375,x+1.375,yy,yy+.25,28.625,29.625))
 bolt('ST-KEEP-'+str(x),(x-1.6,-83.625,29.25),(1,0,0),3.2,.25,'c4-station-dock')
add('ST-DOCK','Illustrative station dock transfer beam, HSS 4 x 4 x 1/4','c4-station-dock',tube(8,52,-90,-86,24.625,28.625,'x',.25))
add('ST-TRANSITION','Hinged 3/16 transition plate;2-inch nominal overlap, no exposed joint gap','c4-station-dock',box(12.25,47.75,-92,-86,32,32.1875),'Steel, hinge/edge finish detail held','#899e91')
add('ST-TRANSITION-HINGE','Station transition hinge 1/2 pin','c4-station-dock',cyl(.25,35.5,(12.25,-92,32),(1,0,0)))
# Removable handrails: 1.5-inch OD steel, 36 inches above the bridge, outside 36 clear.
for x in [10.25,49.75]:
 for y in [-86,-55]:
  add(f'BR-HR-POST-{x}-{y}','Removable handrail post, round 1.5 x 0.120','c4-handrails',cyl(.75,35,(x,y,32)).cut(cyl(.63,35.02,(x,y,31.99))),'A500 round steel, grade to be confirmed','#60756f')
  add(f'BR-HR-SOCKET-{x}-{y}','Handrail socket OD1.875 / ID1.55','c4-bridge',cyl(.9375,4,(x,y,29)).cut(cyl(.775,4.02,(x,y,28.99))),'Steel, isolated from aluminum','#768782')
  add(f'BR-HR-FOOT-{x}-{y}','Socket outrigger 5 x 3 x 1/4 plate','c4-bridge',box(x-1.25,x+3.75,y-1.5,y+1.5,29.375,29.625) if x<30 else box(x-3.75,x+1.25,y-1.5,y+1.5,29.375,29.625),'Steel, bolted to bridge end angles','#768782')
  bolt(f'BR-HR-LOCK-{x}-{y}',(x-1.1,y,32),(1,0,0),2.2,.1875,'c4-bridge')
 add('BR-HR-TOP-'+str(x),'Bridge handrail, 1.5 diameter grasp, top36 above deck','c4-handrails',cyl(.75,35,(x,-88,67.25),(0,1,0)).cut(cyl(.63,35.02,(x,-88.01,67.25),(0,1,0))),'A500 round steel, 100lb point-load check','#60756f')
# Pin positive retention and physical deck fasteners. Pins remain tethered to receiver.
for x in [14,46]:
 for y,z in [(-54,30.25),(-83.625,29.25)]:
  add(f'PIN-COTTER-{x}-{y}','Positive pin retaining cross-pin, 1/8 diameter','c4-coach-dock' if y==-54 else 'c4-station-dock',cyl(.0625,1,(x+1.1,y-.5,z),(0,1,0)))
for x in [12.5,21.25,30,38.75,47.5]:
 for y in [-83,-75,-67,-59]:
  bolt(f'BR-DECK-BOLT-{x}-{y}',(x,y,31.05),(0,0,1),.95,.125,'c4-bridge')
# Station storage rack is outside the reserved 60-inch landing and never travels on coach.
for x in [68,108]:
 add('RACK-UP-'+str(x),'Station rack HSS 2 x 2 x 1/8','c4-station-storage',tube(x,x+2,-115,-113,32,76,'z',.125))
 add('RACK-FOOT-'+str(x),'Station rack 8 x 8 x 3/8 anchor plate','c4-station-storage',box(x-3,x+5,-118,-110,31.625,32))
 bolt('RACK-KEEP-'+str(x),(x+1,-118,62),(0,1,0),7,.25,'c4-station-storage')
for z in [34,70]:add('RACK-CROSS-'+str(z),'Bridge storage rack crossmember','c4-station-storage',tube(68,110,-115,-113,z,z+2,'x',.125))
add('RACK-TRAY','Station storage rack bridge lower tray','c4-station-storage',box(68,110,-120,-110,33.5,34))
# Landing represents reserved clear space only. It is a separate optional group.
add('ST-LAND','60 x 60 station landing reservation; height not selected','c4-station-reservations',box(0,60,-146,-86,31.95,32),'Space reservation','#b5ceb8',kind='reservation')
# Secured retractor locker on front platform, outside the offset enddoor route.
for pid,b in [('BOTTOM',(-40,-24,30,50,32,32.063)),('TOP',(-40,-24,30,50,57.937,58)),('LEFT',(-40,-39.937,30,50,32,58)),('RIGHT',(-24.063,-24,30,50,32,58)),('BACK',(-40,-24,49.937,50,32,58)),('DOOR',(-40,-24,29.937,30,32,58))]:
 add('RET-LOCKER-'+pid,'Closed retractor storage locker; endplatform route remains clear','c4-securement-storage',box(*b),'6061 aluminum,0.063 sheet','#8e9f91')
add('RET-LOCKER-HINGE','Locker hinge pin','c4-securement-storage',cyl(.1875,24,(-40,30,33)))
add('RET-LOCKER-LATCH','Positive closed locker latch','c4-securement-storage',box(-26,-24,29.5,30,43,47))
# Four transverse OEM track routing reservations and original underfloor support beams.
# Front track30; rear track24. Manufacturer pitch known; first-hole offset held for OEM drawing.
for bay,dx in [(1,0),(2,66)]:
 for label,x,L in [('REAR',72+dx,24),('FRONT',122+dx,30)]:
  # Separate short OEM mounting zones avoid drilling the main girder.
  ys=[-41,-27] if label=='REAR' else [-47.5,-20.5]
  for n,y in enumerate(ys):
   add(f'WC{bay}-{label}-ROUTE{n}','OEM short track pocket 1.42 x 6 x 0.50; factory first-hole offset HELD','c4-oem-reservations',box(x-.71,x+.71,y-3,y+3,31.5,32),'Purchased Q’STRAINT flange track; short length approval required','#d0b055',kind='reservation')
   back=box(x-2,x+2,y-3.5,y+3.5,31.003937,31.253937)
   add(f'WC{bay}-{label}-BACK{n}','Custom steel saddle 4 x 7 x 1/4; no OEM holes released','c4-securement-foundation',back)
   # Candidate4-inch pitch is known; bolt station phase is an explicit coordination assumption.
   for yy in [y-2,y+2]:
    add(f'WC{bay}-{label}-BOLT{n}-{yy}','5/16 track bolt at4-inch pitch; first-hole phase provisional','c4-oem-reservations',cyl(.15625,3,(x,yy,29)), 'OEM Grade8 hardware, phase/length held','#d0b055',kind='reservation')
   add(f'WC{bay}-{label}-RET{n}','QRT-360 5.4 x 4.5 x 2.5 overall reservation; remove during access','c4-oem-reservations',box(x-2.7,x+2.7,y-2.25,y+2.25,32,34.5),'Purchased QRT-360, not fabricated geometry','#b18d48',kind='reservation')
  for side,ya,yb in [('OUTER',-53,-45),('MID',-43,-36),('INNER',-32,-21)]:
   add(f'WC{bay}-{label}-BEAM-{side}','Split transverse HSS 3 x 2 x 3/16, fitted between existing rails','c4-securement-foundation',tube(x-1,x+1,ya,yb,28.003937,31.003937,'y',.1875))
   for yy in [ya,yb]:
    for xx in [x-1.1875,x+1]:
     add(f'WC{bay}-{label}-WELD-{side}-{yy}-{xx}','Proposed 3/16 fillet weld run, geometry symbol only','c4-securement-foundation',box(xx,xx+.1875,yy-.09375,yy+.09375,28.25,30.75),'Weld E70 candidate; develop to local HSS wall','#acb3a8')
 # Wall load path sits fully outside the WC clear boundary.
 x=78+dx
 add(f'WC{bay}-SHOULDER-POST','Proposed shoulder-anchor post HSS 3 x 2 x 3/16','c4-securement-foundation',tube(x-1.5,x+1.5,-55,-53,31,98,'z',.1875))
 add(f'WC{bay}-SHOULDER-PLATE','External wall reinforcement 6 x 24 x 1/4, anchor holes held','c4-securement-foundation',box(x-3,x+3,-53,-52.75,62,86))
 add(f'WC{bay}-SHOULDER-ZONE','Shoulder belt guide zone; vendor/occupant positioning required','c4-oem-reservations',box(x-2,x+2,-52.75,-52,66,82),'OEM adjustable guide not modeled','#d0b055',kind='reservation')
 add(f'WC{bay}-SHOULDER-ROOT','Shoulder-post foot 6 x 4 x 3/8, fitted to perimeter steel','c4-securement-foundation',box(x-3,x+3,-56,-52,31.003937,31.378937))
 for xx in [x-2,x+2]:
  bolt(f'WC{bay}-SHOULDER-BOLT-{xx}',(xx,-54,26.5),(0,0,1),5.25,.25,'c4-securement-foundation')
  add(f'WC{bay}-SHOULDER-SLEEVE-{xx}','Perimeter rail crush sleeve OD3/4 ID9/16','c4-securement-foundation',cyl(.375,4,(xx,-54,27.003937)).cut(cyl(.28125,4.02,(xx,-54,26.993937))))
GROUPS=[('c4-door-frame','Accessible portal frames / fixed hardware',True),('c4-side-leaf','Side boarding leaf',True),('c4-end-leaves','Offset enddoor leaves',True),('c4-bridge','Station-owned detachable bridge',True),('c4-handrails','Removable bridge handrails',True),('c4-coach-dock','Coach threshold / pinned dock',True),('c4-station-dock','Conditional station captured dock',True),('c4-securement-foundation','Proposed restraint load path',True),('c4-securement-storage','Restrained retractor storage on endplatform',True),('c4-oem-reservations','OEM component / routing reservations — not fabrication',False),('c4-station-reservations','Conditional 60-inch landing reservation',False),('c4-station-storage','Station storage rack — outside clear landing',False)]
from door_mechanisms import build_doors,transform_door_shape
# Replace the earlier envelope development geometry with connected door mechanisms.
keep_side={'SD-J1','SD-J2','SD-F1','SD-F2','SD-H','SD-SILL','SD-THRESH'}
parts[:]=[p for p in parts if not p['id'].startswith('SD-') or p['id'] in keep_side or p['id'].startswith('SD-FOOT-')]
for prefix in ['FRONT','REAR']:
 keep={prefix+'-J-15',prefix+'-J24',prefix+'-HEAD'}
 parts[:]=[p for p in parts if not p['id'].startswith(prefix+'-') or p['id'] in keep or p['id'].startswith(prefix+'-FOOT-')]
for pid,cutter in build_doors(add,box,tube,cyl,bolt,cut_holes):
 p=next(q for q in parts if q['id']==pid);p['shape']=p['shape'].cut(cutter)
def transformed(p,state):return transform_door_shape(p,state)
def export(state):
 out=[];solids=[];edges=[]
 for p in parts:
  if p['group']=='c4-storage-fit' and state!='storage':continue
  if state=='travel' and p['group'] in ['c4-bridge','c4-handrails','c4-station-dock','c4-station-reservations','c4-station-storage']:continue
  s=transformed(p,state);bb=s.BoundingBox();vs,ts=s.tessellate(.12,.15)
  b={a:[getattr(bb,a+'min'),getattr(bb,a+'max')] for a in 'xyz'}
  out.append({'id':p['id'],'name':p['name'],'group':p['group'],'positions':[v for q in vs for v in q.toTuple()],'indices':[v for q in ts for v in q],'color':p['color'],'opacity':.3 if p['kind']=='reservation' else 1,'bounds_in':b,'centre_in':[(v[0]+v[1])/2 for v in b.values()],'dimensions_xyz_in':[v[1]-v[0] for v in b.values()],'display_only':p['kind']=='reservation','metadata':{'kind':p['kind'],'definition':p.get('definition',{'component':p['name']}),'material':{'candidate':p['material']},'engineering_status':'UNRATED development geometry. Concentrated bridge strength screens FAIL; structural redesign and acceptance required before passenger use.','release_status':'NOT FOR CONSTRUCTION OR PASSENGER USE'}})
  if p['kind']=='physical' or p['group']=='c4-frame-interface':solids.append(s.scale(25.4))
  lines=[]
  for e in s.Edges():
   try:lines.append([v.toTuple() for v in e.sample(12)[0]])
   except Exception:lines.append([e.startPoint().toTuple(),e.endPoint().toTuple()])
  edges.append({'id':p['id'],'group':p['group'],'kind':p['kind'],'lines':lines,'color':p['color']})
 model={'schemaVersion':3,'units':'inches','title':'C4 accessible boarding / restraint interface — '+state,'coordinate_system':'Coach X front-to-rear, Y transverse, Z above rail; inches; proposed loaded floor Z32','groups':[{'id':i,'label':n,'default_visible':v,'explosion_vector_in':[0,0,0]} for i,n,v in GROUPS],'parts':out,'notes':['UNRATED: concentrated bridge strength screens FAIL. Structural redesign required before passenger use.','Global coach coordinates: X front-to-rear, Y right, Z above rail; loaded floor32.','Side negative-Y portal42structural; bridge and edge hardware govern36clear. Only side leaf opens for boarding; enddoors remain closed.','Bridge station geometry conditional; receiver must be engineered after station survey and final suspension range.','OEM parts are named reservations only. No complete WTORS approval or fabricated OEM component definition.']}
 raw=json.dumps(model,separators=(',',':')).encode();(OUT/f'model-{state}.json').write_bytes(raw);(OUT/f'model-{state}.json.gz').write_bytes(gzip.compress(raw,mtime=0))
 cq.exporters.export(cq.Compound.makeCompound(solids),str(OUT/f'C4-{state}-preliminary.step'))
 (OUT/f'drawing-edges-{state}.json').write_text(json.dumps(edges,separators=(',',':')))
 return model
from frame_connections import connect_frame
print('Door geometry complete',flush=True)
frame_report=connect_frame(parts,add,box,cyl,tube)
(OUT/'frame-joint-check.json').write_text(json.dumps(frame_report,indent=2))
GROUPS.append(('c4-frame-interface','Existing frame segments with proposed interface holes',False))
from bridge_connections import repair
print('Frame checks complete',flush=True)
bridge_joint_report=repair(parts,add,box,cyl,tube)
from bridge_retention import repair_retention
print('Bridge joints complete',flush=True)
retention_report=repair_retention(parts,add,box,cyl)
from edge_hinge import reposition,validate_pitch
print('Retention complete; edge hinge construction',flush=True)
edge_report=reposition(parts,add,box,cyl,tube)
from edge_pockets import finish_edges
edge_hardware_report=finish_edges(parts,add,box,cyl)
edge_hardware_report['floor_cuts'].append({'id':'threshold-weld-toes','bounds_in':{'x':[12,48],'y':[-52.125,-51.125],'z':[31.003937,31.128937]},'depth':'1/8 underside relief for actual threshold fillet toes'})
(OUT/'edge-hardware-check.json').write_text(json.dumps(edge_hardware_report,indent=2))
from front_header import reinforce_headers
print('Front header correction',flush=True)
front_report=reinforce_headers(parts,add,box,cyl,tube)
(OUT/'front-header-check.json').write_text(json.dumps(front_report,indent=2))
from rear_header import reinforce_rear
print('Rear header and station bearing correction',flush=True)
rear_report=reinforce_rear(parts,add,box,cyl,tube)
(OUT/'rear-header-check.json').write_text(json.dumps(rear_report,indent=2))
print('Final coach and station pitch checks',flush=True)
edge_report=validate_pitch(parts,box,front_report.get('pitch_critical_ids',[])+rear_report.get('pitch_critical_ids',[]))
from station_pitch import verify_station,repair_transition
transition_report=repair_transition(parts,box,cyl)
(OUT/'transition-hinge-check.json').write_text(json.dumps(transition_report,indent=2))
station_report=verify_station(parts,rear_report.get('pitch_critical_ids',[]))
(OUT/'station-pitch-check.json').write_text(json.dumps(station_report,indent=2))
(OUT/'pitch-check.json').write_text(json.dumps(edge_report,indent=2))
# Recheck frame pairs after the two inner jamb screws become flush heads.
for q in frame_report['checks']:
 a=next((p for p in parts if p['id']==q['first']),None);b=next((p for p in parts if p['id']==q['second']),None)
 if a is None or b is None:q['pass']=None;q['superseded']='Part removed by edge hardware correction';continue
 v=a['shape'].intersect(b['shape']).Volume();q['intersection_in3']=v;q['pass']=v<1e-7
frame_report['passed_count']=sum(q['pass'] is True for q in frame_report['checks']);frame_report['failed_count']=sum(q['pass'] is False for q in frame_report['checks'])
frame_report['superseded_count']=sum(q['pass'] is None for q in frame_report['checks'])
(OUT/'frame-joint-check.json').write_text(json.dumps(frame_report,indent=2))
retention_report['superseded_coach_pin_locations']='Threshold-edge pin coordinates and actual shapes replace earlierY−58 coach records; see pitch-check and final model.'
(OUT/'retention-check.json').write_text(json.dumps(retention_report,indent=2))
# Recheck final shaft shapes after enlarged crossholes and positive retainers.
for q in bridge_joint_report['checks']:
 a=next((p for p in parts if p['id']==q['first']),None);b=next((p for p in parts if p['id']==q['second']),None)
 if a is None or b is None:q['pass']=None;q['superseded']='Original connection replaced by final header/edge hardware';continue
 v=a['shape'].intersect(b['shape']).Volume();q['intersection_in3']=v;q['pass']=v<1e-7
 if 'cross-drilled retainer'==q['type']:q['classification']='Actual free spring geometry: own-shaft contact is intentional, not a rigid clearance check';q['pass']=None
bridge_joint_report['passed_count']=sum(q['pass'] is True for q in bridge_joint_report['checks'])
bridge_joint_report['failed_count']=sum(q['pass'] is False for q in bridge_joint_report['checks'])
bridge_joint_report['spring_contact_exclusions']=sum(q['pass'] is None and 'classification' in q for q in bridge_joint_report['checks'])
bridge_joint_report['superseded_count']=sum(q['pass'] is None and 'superseded' in q for q in bridge_joint_report['checks'])
(OUT/'bridge-joint-check.json').write_text(json.dumps(bridge_joint_report,indent=2))
print('Joint reports complete',flush=True)
from storage_connections import repair_storage
storage_report=repair_storage(parts,add,box,cyl,tube)
(OUT/'storage-joint-check.json').write_text(json.dumps(storage_report,indent=2))
GROUPS.append(('c4-edge-guards','Removable side hinge guards and fasteners',True))
GROUPS.append(('c4-storage-fit','Actual bridge in station storage rack; alternate state',False))
solidcheck={'part_count':len(parts),'invalid_solid_ids':[p['id'] for p in parts if not p['shape'].isValid()],'duplicate_ids':sorted({p['id'] for p in parts if sum(q['id']==p['id'] for q in parts)>1})}
(OUT/'model-solid-check.json').write_text(json.dumps(solidcheck,indent=2))
assert not solidcheck['invalid_solid_ids'] and not solidcheck['duplicate_ids'],solidcheck
print('Storage check complete; exporting',flush=True)
models={s:export(s) for s in ['boarding','travel']}
schedule=[]
for p in parts:
 b=p['shape'].BoundingBox();schedule.append({'id':p['id'],'name':p['name'],'group':p['group'],'kind':p['kind'],'volume_in3':p['shape'].Volume(),'centroid_in':list(p['shape'].Center().toTuple()),'material':p['material'],'definition':p.get('definition',{}),'bounds_in':{a:[getattr(b,a+'min'),getattr(b,a+'max')] for a in 'xyz'}})
(OUT/'parts.json').write_text(json.dumps(schedule,indent=2))
print('Exported',len(parts),'parts; physical',sum(p['kind']=='physical' for p in parts))
