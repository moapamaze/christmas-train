"""C4 edge hinge floor pockets, removable partial covers and flush inner foot screws.
Original inch geometry. This supplemental postprocessor modifies real mating parts.
Run standalone to export schema3 replacement/new parts and an exact composition map.
"""
from pathlib import Path
import math,json,gzip,hashlib
import cadquery as cq
D=Path(__file__).parent
MM=25.4
SOURCE='https://www.jwwinco.com/en-us/products/3.2-Mounting-Positioning-Leveling-with-Retaining-Cables-Screws-Clamping-and-Supporting-Elements/Swing-bolts-Shoulder-screws-Thrust-bolts/GN-912.3-Stainless-Steel-Socket-Cap-Screws-with-Reduced-Head-Diameter-with-Internal-Hex'
def finish_edges(parts,add,box,cyl):
 def get(pid):return next(p for p in parts if p['id']==pid)
 changed=[];new=[];deleted=[];checks=[]
 def extra(pid,name,group,shape,definition,material='5052-H32 aluminum candidate'):
  add(pid,name,group,shape,material=material);get(pid)['definition']=definition;new.append(pid)
 def check(a,b,role):
  v=get(a)['shape'].intersect(get(b)['shape']).Volume();checks.append({'a':a,'b':b,'role':role,'overlap_in3':v,'pass':v<1e-7})
 # Two original custom flush heads; supplier/load qualification required.
 for x,fid in [(9.75,'SD-F1'),(50.25,'SD-F2')]:
  y=-54;z=31.253937;bid=f'SD-FOOT-BOLT-{x}';wid=bid+'-WASHER'
  if any(p['id']==wid for p in parts):parts[:]=[p for p in parts if p['id']!=wid]
  deleted.append(wid)
  cone=cq.Solid.makeCone(.25,.4375,.1875,cq.Vector(x,y,z-.1875),cq.Vector(0,0,1))
  tip=z-5.;shaft=cyl(.25,z-.1875-tip,(x,y,tip));head=shaft.fuse(cone)
  # 1/4in internal hex, .125in deep; positive drive geometry is real, not a decal.
  rad=.25/math.sqrt(3);xy=[(x+rad*math.cos(math.pi/6+k*math.pi/3),y+rad*math.sin(math.pi/6+k*math.pi/3)) for k in range(6)]
  drive=cq.Workplane('XY').polyline(xy).close().extrude(.14).val().translate((0,0,z-.125));head=head.cut(drive)
  get(bid)['shape']=head;get(bid)['name']='Custom flush90-degree1/2-13 inner jamb-foot screw'
  get(bid)['definition']={'shaft_diameter_in':.5,'head_diameter_in':.875,'included_angle_deg':90,'head_height_in':.1875,'head_top_z_in':z,'hex_AF_in':.25,'hex_depth_in':.125,'bottom_z_in':z-5,'overall_length_in':5,'thread_projection_below_nut_in':.25,'procurement':'Original custom dimensional candidate; alloy, heat treatment, head proof and thread certification not selected','thread':'1/2-13 nominal cylindrical thread envelope; existing lower nut retained','structural_limit':'Countersunk head bearing, reduced foot net section, fatigue and preload require qualification; no Grade8 claim for this unselected custom screw'};get(bid)['material']='Custom alloy-steel candidate; certification unresolved'
  foot=get(fid);foot['shape']=foot['shape'].cut(cone);foot.setdefault('definition',{})['inner_screw_countersink']={'axis_xyz_in':[x,y,z],'major_diameter_in':.875,'included_angle_deg':90,'cone_depth_in':.1875,'foot_thickness_in':.25,'pilot_diameter_in':.5625,'minimum_unconed_foot_depth_in':.0625}
  relief_x=[9.9875,10.5] if x<30 else [49.5,50.0125]
  foot['shape']=foot['shape'].cut(box(relief_x[0],relief_x[1],-56,-55,30.9,31.4)).cut(box(relief_x[0],relief_x[1],-52.95,-52,30.9,31.4))
  foot['definition']['outboard_tongue_relief']={'x_in':relief_x,'y_intervals_in':[[-56,-55],[-52.95,-52]],'depth':'through1/4in foot','nominal_tongue_side_clearance_in':.0625,'counterbore_separation':'Countersink centerY−54 retained between two edge-corner reliefs; its full nominal conical bearing remains','qualification':'Revised foot net section, corner finish and local fatigue remain unresolved'}
  nutid=bid+'-NUT';nut=get(nutid);nb=nut['shape'].BoundingBox();desired_top=27.003937-.0625
  nut['shape']=nut['shape'].translate((0,0,desired_top-nb.zmax));nut.setdefault('definition',{})['seated_stack']={'nut_top_z_in':desired_top,'nut_height_in':.4375,'bolt_projection_in':.25,'lower_washer_thickness_in':.0625}
  lower=bid+'-LOWER-WASHER';extra(lower,'Lower foot bearing washer OD1 ID.53 x1/16','c4-door-frame',cyl(.5,.0625,(x,y,desired_top)).cut(cyl(.265,.08,(x,y,desired_top-.01))),{'OD_in':1,'ID_in':.53,'thickness_in':.0625,'upper_z_in':27.003937,'bearing':'Lower perimeter wall and flush crush sleeve; selection/hardness and preload qualification open'},'Hardened steel washer candidate')
  changed.extend([bid,fid,nutid]);check(bid,fid,'Flush head/countersink nominal matching contact');check(bid,nutid,'Nominal mating thread envelope');check(bid,lower,'Bolt/lower bearing washer clearance');check(nutid,lower,'Seated nut/washer face')
 # Partial guards: roof and three sides; no inner wall that could obstruct the pin head.
 for oldx,x,side in [(14,10.5,'L'),(46,49.5,'R')]:
  xr=[9.0625,12] if side=='L' else [48,50.9375];t=.0625;z0=33.125;z1=z0+t
  cover=box(xr[0],xr[1],-53.625,-50.0625,z0,z1)
  outer=(xr[0],xr[0]+t) if side=='L' else (xr[1]-t,xr[1])
  cover=cover.fuse(box(*outer,-53.625,-50.0625,32,z0))
  cover=cover.fuse(box(xr[0],xr[1],-53.625,-53.5625,32,z0)).fuse(box(xr[0],xr[1],-50.125,-50.0625,32,z0))
  cover=cover.cut(box(x-.55,x+.55,-53.7,-53.5,31.9,32.75))
  coverid=f'EDGE-{side}-COVER';fittings=[]
  for j,xx in enumerate([x-.75,x+.75]):
   ear=f'BR-COACH-LUG-{oldx}-{j}';esh=get(ear)['shape']
   for k,yy in enumerate([-52.75,-51.5]):
    code=f'EDGE-{side}-{j+1}{k+1}';sid=code+'-SCREW';spid=code+'-SPACER'
    cover=cover.cut(cyl(4.5/MM/2,.2,(xx,yy,33.05)))
    # Blind M4 threaded envelope; 6mm depth leaves the hinge bore untouched.
    esh=esh.cut(cyl(2/MM,6/MM,(xx,yy,33-6/MM)))
    spacer=cyl(.15625,.125,(xx,yy,33)).cut(cyl(4.5/MM/2,.15,(xx,yy,32.99)))
    extra(spid,'Guard standoff OD5/16 ID4.5mm x1/8','c4-edge-guards',spacer,{'OD_in':.3125,'ID_mm':4.5,'height_in':.125},'Steel spacer candidate')
    # GN912.3 M4x10-NI nominal body with its published 5.5mm reduced head and3mm socket.
    screw=cyl(2/MM,10/MM,(xx,yy,z1-10/MM)).fuse(cyl(2.75/MM,4/MM,(xx,yy,z1)))
    rr=3/MM/math.sqrt(3);poly=[(xx+rr*math.cos(math.pi/6+n*math.pi/3),yy+rr*math.sin(math.pi/6+n*math.pi/3)) for n in range(6)]
    socket=cq.Workplane('XY').polyline(poly).close().extrude(2.2/MM).val().translate((0,0,z1+2/MM));screw=screw.cut(socket)
    extra(sid,'JW Winco GN912.3-M4-10-NI guard screw candidate','c4-edge-guards',screw,{'designation':'GN912.3-M4-10-NI','nominal_thread':'M4x0.7 major-envelope model','length_under_head_mm':10,'head_diameter_mm':5.5,'head_height_mm':4,'socket_AF_mm':3,'modeled_socket_depth_mm':2,'thread_engagement_mm':10-(.125+.0625)*MM,'blind_hole_depth_mm':6,'source':SOURCE,'retention':'Supplier-compatible threadlocker and torque/witness process to qualify; no certified vibration retention'},'Stainless steel candidate per GN912.3')
    fittings.append({'screw':sid,'spacer':spid,'ear':ear,'axis_xyz_in':[xx,yy,33]})
   get(ear)['shape']=esh;get(ear).setdefault('definition',{})['guard_attachment']={'two_top_blind_holes':'M4x0.7,6mm depth; modeled major diameter','x_in':xx,'y_in':[-52.75,-51.5]};changed.append(ear)
  extra(coverid,'Removable partial edge hinge cover,1/16 sheet','c4-edge-guards',cover,{'outer_bounds_in':{'x':xr,'y':[-53.625,-50.0625],'z':[32,z1]},'inner_side':'Open toward36in route for pinhead clearance; no full finger-exclusion claim','rear_tongue_notch_in':{'width_x':1.1,'top_z':32.75,'running_side_gap':.1},'attachment':fittings,'operation':'Remove four screws and lift cover before extracting coach pin/cotter; reinstall before passenger movement','limits':'Partial hardware cover outsideX12..48, not a step or a rated walking surface; rounded edges, formed corners and material/fire/weather durability to qualify'})
  for f in fittings:
   for obj in [f['spacer'],f['ear'],coverid]:check(f['screw'],obj,'Nominal screw through clearance / mating threaded envelope')
  for ear in [f'BR-COACH-LUG-{oldx}-{j}' for j in (0,1)]:check(coverid,ear,'Fixed guard to modified receiver ear')
 pockets=[{'id':'edge-left','bounds_in':{'x':[9.0625,12],'y':[-52,-50.125],'z':[31.003937,32]},'depth':'full proposed floor thickness','covers':'EDGE-L-COVER'},{'id':'edge-right','bounds_in':{'x':[48,50.9375],'y':[-52,-50.125],'z':[31.003937,32]},'depth':'full proposed floor thickness','covers':'EDGE-R-COVER'},{'id':'central-threshold','bounds_in':{'x':[12,48],'y':[-52,-51.25],'z':[31.003937,32]},'depth':'full floor thickness for steel riser and threshold','counterpart':'SD-THRESH and independently specified welded steel angle/riser'}]
 return {'revision':'C4-edge-detail-01','source_units':'inches','replacement_ids':list(dict.fromkeys(changed)),'new_ids':new,'delete_ids':deleted,'composition':'Replace existing parts by exact ID, remove delete_ids, append new IDs; never overlay duplicate undrilled ears or old bolt heads. Floor cuts must be applied to full coach floor reference separately.','floor_cuts':pockets,'floor_pocket_margin_basis':{'left_cotter_bounds_in':{'x':[9.17125974,9.32874026],'y':[-53.43110236,-50.51771644],'z':[31.54625984,32.68799223]},'front_floor_edge_to_cotter_in':.39271644,'inner_pinhead_to_route_boundary_in':.1,'guard_to_jamb_nominal_x_gap_in':.0625,'cotter_free_shape_to_outer_guard_wall_nominal_x_gap_in':.04625974,'tool_operation':'Vertical3mm Allen driver reserved withinØ.375x3in above each guard screw; remove guards then extract pin/cotter with boarding area empty. Full hand/glove/service path requires mockup.'},'joint_checks':checks,'limits':['Dimensional prototype proposal, not fabrication release or proof of pinch exclusion.','Partial covers stand above floor outside the central36in corridor; actual mobility-device paths must include them.','M4 blind holes reduce receiver-ear local section; main3/4in hinge bore remains separate.','Floor edge sealing, finished corner radius and debris control require detail.','Custom countersunk foot screws require supplier/structural qualification; old Grade8 assertion is superseded for these two screws.'],'sources':[{'url':SOURCE,'use':'Published M4x10 reduced-head screw dimensions:5.5mm head,4mm height,3mm socket. Modeled socket depth is a development assumption.'}]}

def standalone():
 OUT=D/'edge-issued';OUT.mkdir(exist_ok=True);parts=[]
 def box(x0,x1,y0,y1,z0,z1):return cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,cq.Vector(x0,y0,z0))
 def cyl(r,h,p,d=(0,0,1)):return cq.Solid.makeCylinder(r,h,cq.Vector(*p),cq.Vector(*d))
 def add(pid,name,group,s,material='Steel candidate',**kw):parts.append({'id':pid,'name':name,'group':group,'shape':s,'material':material,'kind':'physical','color':'#bdbea7' if 'guard' in group else '#66818c',**kw})
 for oldx,x in [(14,10.5),(46,49.5)]:
  for n,xx in enumerate([x-1,x+.5]):add(f'BR-COACH-LUG-{oldx}-{n}','Modified coach receiver ear','c4-coach-dock',box(xx,xx+.5,-53,-51.25,30.25,33).cut(cyl(.39,.52,(xx-.01,-52.25,31.625),(1,0,0))))
 for x,fid,bx,holes in [(9.75,'SD-F1',4.5,[5.25,9.75]),(50.25,'SD-F2',49.5,[50.25,54.75])]:
  f=box(bx,bx+6,-56,-52,31.003937,31.253937)
  for hx in holes:f=f.cut(cyl(.28125,.3,(hx,-54,30.99)))
  add(fid,'Side jamb foot with modified inner countersink','c4-door-frame',f)
  add(f'SD-FOOT-BOLT-{x}','Placeholder replaced in postprocessor','c4-door-frame',cyl(.25,4.753937,(x,-54,26.5)))
  cr=.75/math.sqrt(3);poly=[(cr*math.cos(math.radians(30+60*k)),cr*math.sin(math.radians(30+60*k))) for k in range(6)]
  nut=cq.Workplane('XY').polyline(poly).close().extrude(.4375).val().translate((x,-54,26.5)).cut(cyl(.25,.46,(x,-54,26.49)))
  add(f'SD-FOOT-BOLT-{x}-NUT','Existing1/2-13 nut reseated under washer','c4-door-frame',nut)
 report=finish_edges(parts,add,box,cyl);report['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 # Verify partial guards against exact new hinge, OEM cotter, head and pitched tongue.
 checks=[];clip0=cq.importers.importStep(str(D/'GN1024-NI-4-E.step')).val().scale(1/MM).rotate((0,0,0),(1,0,0),90)
 for oldx,x,sgn,side in [(14,10.5,-1,'L'),(46,49.5,1,'R')]:
  fixed=[p for p in parts if p['id'].startswith('EDGE-'+side)]+[p for p in parts if p['id'].startswith(f'BR-COACH-LUG-{oldx}')]+[p for p in parts if p['id']==('SD-F1' if side=='L' else 'SD-F2')]
  tongue=box(x-.45,x+.45,-58.5,-51.25,29.375,32.25).cut(box(x-.5,x+.5,-55.3,-52.75,28,31.5)).cut(cyl(.39,1,(x-.5,-52.25,31.625),(1,0,0)))
  cotter=clip0.translate((x+sgn*1.25,-52.25+29.5/MM,31.625));head=cyl(.5,.2,(x-sgn*1.2,-52.25,31.625),(-sgn,0,0))
  for name,s in [('cotter',cotter),('head',head)]+[(f'tongue-rise-{rise}',tongue.rotate((0,-52.25,31.625),(1,-52.25,31.625),-math.degrees(math.atan2(rise,37.75)))) for rise in [-2.5,0,2.5]]:
   for p in fixed:
    if name in ('cotter','head') and not p['id'].startswith('EDGE'):continue
    v=s.intersect(p['shape']).Volume()
    if v>1e-7:checks.append({'moving':name,'fixed':p['id'],'overlap_in3':v})
  # Corrected flush head and washer removal against the same pitch extremes.
  screw=next(p['shape'] for p in parts if p['id']==f'SD-FOOT-BOLT-{9.75 if side=="L" else 50.25}')
  for rise in [-2.5,0,2.5]:
   s=tongue.rotate((0,-52.25,31.625),(1,-52.25,31.625),-math.degrees(math.atan2(rise,37.75)));v=s.intersect(screw).Volume()
   if v>1e-7:checks.append({'moving':'tongue','rise':rise,'fixed':'flushfoot'+side,'overlap_in3':v})
 report['targeted_guard_and_flushhead_penetrations']=checks
 tools=[]
 jboxes=[box(6,9,-55,-53,31.253937,110),box(51,54,-55,-53,31.253937,110)]
 for p in parts:
  if not p['id'].endswith('-SCREW') or not p['id'].startswith('EDGE-'):continue
  bb=p['shape'].BoundingBox();xx=(bb.xmin+bb.xmax)/2;yy=(bb.ymin+bb.ymax)/2;z=bb.zmax
  tool=cyl(.375/2,3,(xx,yy,z));hits=[]
  for q in parts:
   if q['id']==p['id']:continue
   v=tool.intersect(q['shape']).Volume()
   if v>1e-7:hits.append({'part':q['id'],'overlap_in3':v})
  for j,b in enumerate(jboxes):
   v=tool.intersect(b).Volume()
   if v>1e-7:hits.append({'part':'jamb'+str(j+1),'overlap_in3':v})
  tools.append({'screw':p['id'],'driver_OD_in':.375,'length_in':3,'unintended':hits,'minimum_jamb_clearance_in':min(tool.distance(b) for b in jboxes)})
 report['guard_driver_access']=tools
 pp=[]
 for p in parts:
  s=p['shape'];b=s.BoundingBox();vv,ff=s.tessellate(.02,.12);bounds={a:[getattr(b,a+'min'),getattr(b,a+'max')] for a in 'xyz'}
  pp.append({'id':p['id'],'name':p['name'],'group':p['group'],'positions':[v for q in vv for v in q.toTuple()],'indices':[v for q in ff for v in q],'color':p['color'],'opacity':1,'bounds_in':bounds,'centre_in':[(v[0]+v[1])/2 for v in bounds.values()],'dimensions_xyz_in':[v[1]-v[0] for v in bounds.values()],'metadata':{'kind':'physical','definition':p.get('definition',{}),'material':{'candidate':p['material']},'release_status':'NOT FOR CONSTRUCTION'}})
 model={'schemaVersion':3,'units':'inches','title':'C4 edge hinge guards and drilled replacement interfaces','groups':[{'id':g,'label':g,'default_visible':True,'explosion_vector_in':[0,0,0]} for g in ['c4-edge-guards','c4-door-frame','c4-coach-dock']],'parts':pp,'composition':{k:report[k] for k in ['replacement_ids','new_ids','delete_ids','composition']}}
 (OUT/'model-edge-guards.json.gz').write_bytes(gzip.compress(json.dumps(model,separators=(',',':')).encode(),mtime=0))
 (OUT/'edge-floor-cuts-and-checks.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'parts-edge-guards.json').write_text(json.dumps([{k:v for k,v in p.items() if k not in ['positions','indices']} for p in pp],indent=2)+'\n')
 step=OUT/'C4-edge-guards-and-replacements.step';cq.exporters.export(cq.Compound.makeCompound([p['shape'].scale(MM) for p in parts]),str(step));(OUT/(step.name+'.gz')).write_bytes(gzip.compress(step.read_bytes(),mtime=0));step.unlink()
 print(json.dumps({'parts':len(pp),'joint_checks':len(report['joint_checks']),'joint_failures':[q for q in report['joint_checks'] if not q['pass']],'targeted_penetrations':checks,'source_sha256':report['source_sha256']},indent=2))
if __name__=='__main__':standalone()
