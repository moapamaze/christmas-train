"""C4 front transverse header correction; inch geometry, unwelded aluminum.
Isolated postprocessor after edge_hinge.reposition and edge_pockets.finish_edges.
"""
import math
import cadquery as cq

def reinforce_headers(parts,add,box,cyl,tube):
 def get(i):return next(p for p in parts if p['id']==i)
 def put(i,s):get(i)['shape']=s
 def rem(i):parts[:]=[p for p in parts if p['id']!=i]
 def meta(i,**d):get(i).setdefault('definition',{}).update(d)
 def mass():
  return sum(p['shape'].Volume()*(.098 if '6061' in p.get('material','') else .283) for p in parts if p.get('kind','physical')=='physical' and p['group'] in ['c4-bridge','c4-handrails'])
 initialmass=mass();new=[];checks=[];contacts=[]
 def make(i,n,s,mat='6061-T6 unwelded; certified 35ksi yield minimum',**d):
  add(i,n,'c4-bridge',s,mat,'#b0b7ad' if 'steel' in mat.lower() else '#799ca7');new.append(i);meta(i,**d)
 def hole(i,x,y,z0,z1,r):put(i,get(i)['shape'].cut(cyl(r,z1-z0,(x,y,z0))))
 def pair(a,b,kind):
  v=get(a)['shape'].intersect(get(b)['shape']).Volume();checks.append({'first':a,'second':b,'type':kind,'intersection_in3':v,'pass':v<1e-7})
 def touch(a,b,kind):contacts.append({'first':a,'second':b,'type':kind,'distance_in':get(a)['shape'].distance(get(b)['shape'])})
 def hexbody(x,y,z,h,af):return cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(h).val().translate((x,y,z))
 def washer(i,x,y,z,r,od):make(i,'Custom steel flat washer; actual annular bearing',cyl(od/2,.125,(x,y,z)).cut(cyl(r+.015625,.145,(x,y,z-.01))),'Hardened steel candidate',thickness_in=.125,outside_diameter_in=od,inside_diameter_in=2*r+.03125)
 def stack(tag,x,y,r,underhead,length,nutbase,af,nh,sleeveod,targets):
  sid=tag+'-SLEEVE';make(sid,'Unwelded internal crush sleeve; fit between header inner faces',cyl(sleeveod/2,1.75,(x,y,27.5)).cut(cyl(r+.03125,1.77,(x,y,27.49))),'4140 quenched-and-tempered steel, certified100ksi yield candidate; isolated from aluminum',length_in=1.75,OD_in=sleeveod,ID_in=2*r+.0625,assembly='Insert through open crossbox end before mating endmember; jig in position; no sleeve weld or preload crushing across unsupported walls')
  for target in targets:hole(target,x,y,27,34,r+(.03125 if r==.25 else .015625))
  washer(tag+'-LOW-WASHER',x,y,27.25,r,1 if r==.25 else .875)
  washer(tag+'-TOP-WASHER',x,y,nutbase-.125,r,.875)
  bid=tag+'-BOLT';make(bid,'SAE J429 Grade8 candidate hex bolt; thread form omitted',cyl(r,length,(x,y,underhead)).fuse(hexbody(x,y,underhead-.34375 if r==.25 else underhead-.25,.34375 if r==.25 else .25,af)),'SAE J429 Grade8 steel candidate',diameter_in=2*r,underhead_length_in=length,thread='1/2-13 UNC' if r==.25 else '3/8-16 UNC',locking='All-metal prevailing torque nut, actual torque/washer/isolation stack to be qualified',thread_form_modeled=False)
  nid=tag+'-NUT';make(nid,'All-metal prevailing torque hex nut candidate',hexbody(x,y,nutbase,nh,af).cut(cyl(r,nh+.02,(x,y,nutbase-.01))),'Grade8 compatible steel nut candidate',thread_form_modeled=False,accessible='Top for tongue bolts; open forward stringer end before deck closure for rail bolts',minimum_nominal_thread_projection_in=underhead+length-nutbase-nh)
  for t in targets+[sid,tag+'-LOW-WASHER',tag+'-TOP-WASHER',nid]:pair(bid,t,'actual clear bore / nominal omitted thread contact')
  pair(sid,'BR-FRONT-HEADER','internal sleeve fits hollow box');touch(sid,'BR-FRONT-HEADER','sleeve end lands against header inner faces')
 # Front handrail, pin and actual spring retainer move as one assembly.
 for x in [10.25,49.75]:
  for prefix in ['BR-HR-SOCKET-','BR-HR-POST-','BR-HR-LOCK-','BR-HR-COTTER-']:
   i=f'{prefix}{x}--55';put(i,get(i)['shape'].translate((0,-2,0)));meta(i,final_center_y_in=-61,relocation='Front assembly moved rearward2in to clear integral pin tongue; retain same insertion/pin geometry')
  # Recreate bracket foot with new well-separated bolts; no abandoned through holes credited.
  foot=box(9,14,-62.5,-59.5,29.125,29.375) if x<30 else box(46,51,-62.5,-59.5,29.125,29.375)
  sock=cyl(.9375,4,(x,-61,29)).fuse(foot).cut(cyl(.775,4.2,(x,-61,28.9))).cut(cyl(.265,3,(x-1.5,-61,31),(1,0,0)))
  put(f'BR-HR-SOCKET-{x}--55',sock)
 # Saddle-fit front posts to the retained top tube; no solid penetration at welded T joint.
 for x in [10.25,49.75]:
  pid=f'BR-HR-POST-{x}--55';put(pid,get(pid)['shape'].cut(cyl(.75,40,(x,-92.5,67.25),(0,1,0))));meta(pid,top_joint='Fishmouth saddle to existing top tube; proposed continuous1/8 E70 fillet around steel post saddle; handrail weld qualification held')
 # Old front screws are fully superseded; rear screw stacks belong to rear module.
 for p in list(parts):
  i=p['id']
  if (i.startswith(('BR-END-SCREW-','BR-END-NUT-')) and i.endswith('--58')) or (i.startswith('BR-END-HEAD-SPACER-') and i.endswith('--58.5')):rem(i)
  elif i.startswith(('BR-HR-BASE-SCREW-','BR-HR-BASE-NUT-')):
   bb=p['shape'].BoundingBox()
   if (bb.ymin+bb.ymax)/2>-65:rem(i)
 # Widened solid endmember is still one machined part. Tongue roots extend across both header bolt rows.
 fp=box(9.25,50.75,-62.5,-55.5,29.375,29.625)
 for x in [10.5,49.5]:
  tongue=box(x-.45,x+.45,-59.25,-51.25,29.375,32.25).cut(box(x-.5,x+.5,-55.3,-52.75,28,31.5)).cut(cyl(.39,1,(x-.5,-52.25,31.625),(1,0,0)))
  fp=fp.fuse(tongue)
 for xx in [10.25,49.75]:fp=fp.cut(cyl(.96875,1,(xx,-61,29)))
 put('BR-END--54',fp);meta('BR-END--54',construction='Single machined6061-T6 endmember; integral tongues extend back toY−59.25; two vertical1/2bolts each transfer root moment directly to box',flat_bounds_in=[9.25,50.75,-62.5,-55.5,29.375,29.625],no_weld_in_t6_path=True)
 make('BR-FRONT-HEADER','Front unwelded2×2×1/8 transverse box',tube(9.25,50.75,-59.25,-57.25,27.375,29.375,'x',.125),section_in=[2,2,.125],run_x_in=[9.25,50.75],load_path='Longitudinal rails bear on endmember, then box; box transfers acrossX to sleeved tongue bolt pairs; integral tongues transfer to existing coach pins')
 for x in [10.5,49.5]:
  for y in [-58.75,-57.75]:stack(f'BR-FH-TONGUE-{x}-{y}',x,y,.25,27.25,6,32.375,.75,.4375,.75,['BR-FRONT-HEADER','BR-END--54'])
 for x in [12.5,21.25,30,38.75,47.5]:
  stack(f'BR-FH-RAIL-{x}',x,-58.25,.1875,27.25,3.25,29.875,.5625,.328125,.75,['BR-FRONT-HEADER','BR-END--54','BR-RAIL-'+str(x)])
  touch('BR-RAIL-'+str(x),'BR-END--54','rail bottom wall bears directly on endmember')
 # Relocated handrail bracket bolts; one column clamps rail bottom wall, one is inboard clear of it.
 for sx in [10.25,49.75]:
  xs=[12.5,13.625] if sx<30 else [46.375,47.5]
  for x in xs:
   onrail=x in [12.5,47.5];rail='BR-RAIL-'+str(12.5 if sx<30 else 47.5)
   for y in [-62,-60.5]:
    targets=[f'BR-HR-SOCKET-{sx}--55','BR-END--54']+([rail] if onrail else[])
    tag=f'BR-FH-HR-{sx}-{x}-{y}';r=.1875;nz=29.75 if onrail else 29.625;h=r/math.tan(math.radians(41))
    for t in targets:
     hole(t,x,y,29,31,r+.015625)
     put(t,get(t)['shape'].cut(cq.Solid.makeCone(2*r,r,h,cq.Vector(x,y,29.125))))
    make(tag+'-BOLT','Relocated3/8 flush underside socket-bracket screw',cq.Solid.makeCone(2*r,r,h,cq.Vector(x,y,29.125)).fuse(cyl(r,nz+.4-29.125-h,(x,y,29.125+h))),'Grade8 steel screw candidate',diameter_in=.375,countersink_angle_deg=82,thread_form_modeled=False)
    make(tag+'-NUT','Relocated wrench-held prevailing torque hex nut',hexbody(x,y,nz,.328125,.5625).cut(cyl(r,.35,(x,y,nz-.01))),'Compatible all-metal prevailing torque steel nut candidate',counterhold='Long-reach9/16 open-end wrench through open forward stringer end before deck/coach-pin closure; outer nut centered in1.25in inner rail width. Inboard nut accessible from above.',thread_form_modeled=False)
    for t in targets+[tag+'-NUT']:pair(tag+'-BOLT',t,'actual bore / omitted thread')
 # Positive-clearance front scope includes new box/hardware and actual shifted socket/post/pins.
 checked=[];coll=[]
 near=[p for p in parts if p.get('kind','physical')=='physical' and p['shape'].BoundingBox().ymax>-64 and p['shape'].BoundingBox().ymin<-55.25 and p['group'] in ['c4-bridge','c4-handrails']]
 selected=set(new+['BR-END--54']+[f'BR-HR-{k}-{x}--55' for x in [10.25,49.75] for k in ['SOCKET','POST','LOCK','COTTER']])
 for i,a in enumerate(near):
  aa=a['shape'].BoundingBox()
  for b in near[i+1:]:
   if a['id'] not in selected and b['id'] not in selected:continue
   if 'COTTER' in a['id'] and 'LOCK' in b['id'] or 'LOCK' in a['id'] and 'COTTER' in b['id']:continue
   bb=b['shape'].BoundingBox()
   if all(min(getattr(aa,d+'max'),getattr(bb,d+'max'))-max(getattr(aa,d+'min'),getattr(bb,d+'min'))>1e-6 for d in 'xyz'):
    v=a['shape'].intersect(b['shape']).Volume();checked.append([a['id'],b['id']])
    if v>1e-6:coll.append({'first':a['id'],'second':b['id'],'intersection_in3':v})
 touch('BR-FRONT-HEADER','BR-END--54','full header top skins bear on endmember underside')
 results=screen_header()
 return {'module':'front_header.py','revision':'C4-front-header-R1','checks':checks,'contacts':contacts,'scoped_overlap_pair_count':len(checked),'rigid_collisions':coll,'new_part_ids':new,'pitch_critical_ids':new+['BR-END--54']+[f'BR-HR-{k}-{x}--55' for x in [10.25,49.75] for k in ['SOCKET','POST','LOCK','COTTER']],'mass_change_lb':mass()-initialmass,'loadscreen':results,'sources':['https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6061.pdf','https://www.portlandbolt.com/technical/specifications/sae-j429/'],'assembly':['Preposition internal sleeves through open box ends; no welded aluminum joint.','Mate machined endmember and stringers; insert lower bolts and access central nuts through open forward stringer ends before deck closure.','Tongue nuts remain above outboard tongue roots, accessible from above; no travel-route fastener projections.','Fit relocated front handrail sockets/pins/cotters as a unit; top rail retains original overhang geometry.','Use dissimilar-metal isolation/coating and qualified prevailing torque installation; no friction-only force credit.'],'holds':['Designer load probes only, not a bridge rating or accepted load spectrum.','Gross/net elastic beam screen does not qualify local tube-wall bearing, washer prying, notch fatigue, extrusion corner properties, bolt preload retention or handrail bracket combined loading.','Full grillage/deck connection distribution and moving dead-load center of gravity remain unqualified; 600lbf patch and500lbf wheel screens remain separate.','Header end tube-hole sections and combined bending/torsion require final local analysis/test; no strength is credited to thin endplate as an isolated transverse beam.','Fabricate to certified unwelded6061-T6 minimum35ksi yield; steel fastener proof comparison is conditional on actual Grade8 procurement.']}


def screen_header():
 I=(2**4-1.75**4)/12
 # A vertical sleeve bore removes only the two tube skins; sleeve strength not credited.
 In=I-2*.40625*(.125**3/12+.125*.9375**2)
 results={'gross_I_in4':I,'central_single_hole_net_I_in4':In,'support_pitch_in':39,'central_reaction_lbf':300,'midspan_moment_inlb':300*39/4,'gross_service_stress_psi':300*39/4/I,'net_service_stress_psi':300*39/4/In,'net_3x_stress_psi':900*39/4/In,'T6_min_yield_comparison_psi':35000,'tongue_one_side_reaction_lbf':300,'tongue_pin_to_boltgroup_y_lever_in':6,'tongue_bolt_row_pitch_in':1,'tongue_ideal_max_bolt_tension_lbf':300/2+300*6,'tongue_ideal_3x_bolt_tension_lbf':3*(300/2+300*6),'half_inch_Grade8_proof_comparison_lbf':.1419*120000,'tongue_ideal_3x_bearing_psi_at_bolt':3*(300/2+300*6)/(.5*2.875),'central_rail_3x_direct_axial_probe_lbf':900,'central_rail_pitch_transfer_lever_in':1,'central_rail_ideal_service_bolt_tension_lbf':300+300*6/1,'central_rail_ideal_3x_bolt_tension_lbf':3*(300+300*6/1),'three_eighth_Grade8_proof_comparison_lbf':.0775*120000,'central_rail_pitch_transfer_note':'Conservatively assign the entire front-end300lbf reaction and6in pin offset to one rail joint; central throughbolt plus compression contact at1in box edge transfers pitch moment. Local rail bottom wall, prying and actual contact stiffness remain open.','header_max_3x_torsion_probe_inlb':900*6,'header_Bredt_3x_shear_psi':900*6/(2*1.875**2*.125),'tongue_notch_gross_section_modulus_in3':.9*.75**2/6,'tongue_notch_3x_gross_stress_psi':900*3.05/(.9*.75**2/6),'tongue_notch_note':'Only gross section at notch root; local corner stress and fatigue remain open, no notch-strength approval'}
 # Independently vary a single300lbf rail reaction across all five stringers;
 # no equal transverse load sharing is assumed. End tongue reaction is bounded by300.
 cases=[]
 for xp in [12.5,21.25,30,38.75,47.5]:
  ra=300*(49.5-xp)/39;rb=300-ra;rows=[]
  for xx in [12.5,21.25,30,38.75,47.5]:
   mm=ra*(xx-10.5)-300*max(0,xx-xp);rows.append({'section_x_in':xx,'moment_inlb':mm,'net_service_stress_psi':abs(mm)/In,'net_3x_stress_psi':3*abs(mm)/In})
  cases.append({'loaded_stringer_x_in':xp,'reaction_left_lbf':ra,'reaction_right_lbf':rb,'force_residual_lbf':ra+rb-300,'moment_residual_inlb':rb*39-300*(xp-10.5),'sections':rows})
 results['asymmetric_single_stringer_cases']=cases
 results['conservative_net_bending_plus_gross_torsion_3x_von_mises_psi']=math.sqrt(results['net_3x_stress_psi']**2+3*results['header_Bredt_3x_shear_psi']**2)
 results['combined_probe_limit']='Combines maximum net bending and maximum gross closed-cell torsion conservatively; holes and local tube-wall force introduction remain separate qualification holds.'
 return results
