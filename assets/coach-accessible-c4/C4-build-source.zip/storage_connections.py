"""Bolted station storage restraint and explicit bridge storage fit; inch geometry."""
import math
import cadquery as cq
def repair_storage(parts,add,box,cyl,tube):
 def get(i):return next(p for p in parts if p['id']==i)
 parts[:]=[p for p in parts if not p['id'].startswith('RACK-KEEP-')]
 tray=box(68,110,-124,-110,33.5,34)
 # Rear header bolt tips need real drain/tool-clear slots, not support on fasteners.
 for x in [71.5,80.25,89,97.75,106.5]:tray=tray.cut(box(x-.625,x+.625,-119.75,-118,33.4,34.1))
 get('RACK-TRAY')['shape']=tray
 get('RACK-TRAY')['definition']={'thickness_in':.5,'bolt_tip_clear_slots':'Five1.25x1.75throughslots centeredX71.5/80.25/89/97.75/106.5,Y−118.875','load_path':'Two welded cradle pads support rear deck/header edge, never the protruding cleat bolts','station_foundation':'Site-dependent anchor pattern and rack strength remain held'}
 for x in [74.5,103.5]:
  add('RACK-CRADLE-'+str(x),'Welded1/2-high steel cradle pad beneath rear deck/header edge','c4-station-storage',box(x-1.5,x+1.5,-120.25,-118,34,34.5))
  parts[-1]['definition']={'dimensions_xyz_in':[3,2.25,.5],'attachment':'Continuous1/8fillet totray alongaccessiblepadedges; localrack strength held','contact':'Rear deck/header edge atstoredZ34.5'}
 add('RACK-RETAINER','Removable storage crossbar HSS2x1x1/8; two1/2 bolted spacers','c4-station-storage',tube(67,111,-123.5,-122.5,61.5,63.5,'x',.125))
 checks=[]
 for x in [69,109]:
  rid='RACK-UP-'+str(x-1);sid='RACK-SPACER-'+str(x);bid='RACK-RETAINER-BOLT-'+str(x)
  # Bored sleeves prevent crushing of both hollow members under clamp load.
  for pid,ya,yb in [(rid,-115,-113),('RACK-RETAINER',-123.5,-122.5)]:
   get(pid)['shape']=get(pid)['shape'].cut(cyl(.390625,12,(x,-125,62.5),(0,1,0)))
   add(f'RACK-CRUSH-{x}-{ya}','Storage restraint crush sleeve OD3/4 ID9/16','c4-station-storage',cyl(.375,yb-ya,(x,ya,62.5),(0,1,0)).cut(cyl(.28125,yb-ya+.02,(x,ya-.01,62.5),(0,1,0))))
  add(sid,'Storage bar spacer OD1 ID9/16,7.5long','c4-station-storage',cyl(.5,7.5,(x,-122.5,62.5),(0,1,0)).cut(cyl(.28125,7.52,(x,-122.51,62.5),(0,1,0))))
  sh=cyl(.25,11.25,(x,-123.5,62.5),(0,1,0)).fuse(cyl(.4375,.3125,(x,-123.8125,62.5),(0,1,0)))
  add(bid,'Storage bar1/2-13 bolt with headed bearing face','c4-station-storage',sh)
  nid='RACK-RETAINER-NUT-'+str(x);add(nid,'Storage bar all-metal prevailing-torque nut; nominal1/2-13 bore','c4-station-storage',cyl(.4375,.4375,(x,-113,62.5),(0,1,0)).cut(cyl(.25,.46,(x,-113.01,62.5),(0,1,0))))
  for q in [rid,'RACK-RETAINER',sid,nid]+[p['id'] for p in parts if p['id'].startswith(f'RACK-CRUSH-{x}-')]:
   v=sh.intersect(get(q)['shape']).Volume();checks.append({'first':bid,'second':q,'intersection_in3':v,'pass':v<1e-7})
  get(bid)['definition']={'diameter_in':.5,'thread':'1/2-13 UNC','overall_shaft_length_in':11.25,'retention':'All-metal prevailing-torque nut; remove crossbar only with empty controlled storage area','crush_sleeve_OD_ID_in':[.75,.5625],'spacer_length_in':7.5}
 # Separate optional group shows the actual bridge resting on the tray, handrails removed.
 originals=[p for p in parts if p['group']=='c4-bridge']
 stored=[]
 for p in originals:
  s=p['shape'].translate((0,92,-32)).rotate((0,0,0),(1,0,0),90).translate((59,-120.25,34.5))
  add('STORED-'+p['id'],'Stored pose: '+p['name'],'c4-storage-fit',s,p['material'],p['color'],'reference')
  stored.append(parts[-1])
 collisions=[]
 for a in stored:
  ab=a['shape'].BoundingBox()
  for b in [q for q in parts if q['group']=='c4-station-storage']:
   bb=b['shape'].BoundingBox()
   if all(min(getattr(ab,d+'max'),getattr(bb,d+'max'))-max(getattr(ab,d+'min'),getattr(bb,d+'min'))>1e-7 for d in 'xyz'):
    v=a['shape'].intersect(b['shape']).Volume()
    if v>1e-7:collisions.append({'stored_part':a['id'],'rack_part':b['id'],'intersection_in3':v})
 return {'scope':'Bolted storage bar and actual bridge-to-rack fit; no storage load rating','check_count':len(checks),'passed_count':sum(q['pass'] for q in checks),'failed_count':sum(not q['pass'] for q in checks),'checks':checks,'stored_bridge_rack_collisions':collisions,'storage_pose_transform':'Translate(0,92,-32), rotateX+90deg, translate(59,-120.25,34.5)','limits':['Handrails are removed and require a separate storage bracket.','Rack foundation anchor design depends on station structure and is not released.','Restraint load, handling/trolley and wind/abuse tests remain open.']}
