"""Three-state station-side interface and articulated transition-flap probe.
Nominal inch geometry; explicit tested states, not continuous/tolerance acceptance.
"""
import math
import cadquery as cq

def bridge_angle(rise):
 # Fixed R2 crown + fixed 1/8 shim, flat shoe plane Z28.125 at level.
 # Exact tangency: 37.75sin(beta)+(rise-5.5)cos(beta)+5.5=0.
 beta=-math.atan2(rise,37.75)
 for _ in range(12):
  beta-=(37.75*math.sin(beta)+(rise-5.5)*math.cos(beta)+5.5)/(37.75*math.cos(beta)-(rise-5.5)*math.sin(beta))
 return beta

def flap_pose(rise):
 beta=bridge_angle(rise);yh=-96.5;zh=31.8125+rise
 dy=-92+52.25;dz=.375
 ey=-52.25+dy*math.cos(beta)-dz*math.sin(beta)
 ez=31.625+dy*math.sin(beta)+dz*math.cos(beta)
 edge=math.atan2(ez-zh,ey-yh)-math.asin(.1875/math.hypot(ez-zh,ey-yh))
 lo,hi=-.2,.2
 for _ in range(60):
  a=(lo+hi)/2;y=yh+6.5*math.cos(a)-.1875*math.sin(a);z=zh+6.5*math.sin(a)+.1875*math.cos(a)
  distance=-math.sin(beta)*(y+52.25)+math.cos(beta)*(z-31.625)-.375
  if distance>0:hi=a
  else:lo=a
 tip=(lo+hi)/2;alpha=max(edge,tip)
 return beta,alpha,{'flap_angle_deg':math.degrees(alpha),'support':'bridge far top edge atY≈−92' if edge>tip else 'flap inboard nose atlocalY6.5','bridge_far_edge_yz_in':[ey,ez],'flap_hinge_yz_in':[yh,zh],'basis':'Choose the larger rotation required to clear the deck at each overlap endpoint. Straight plane/line geometry guarantees nonpenetration between endpoints; physical hinge and BRep checked separately.'}

def repair_transition(parts,box,cyl):
 def get(i):return next(p for p in parts if p['id']==i)
 checks=[]
 for i in range(12):
  x=12+i*3;fixed=i%2==0;pid='ST-TR-HNG-'+str(i)
  sleeve=cyl(.375,2.8,(x,-96.5,31.8125),(1,0,0))
  # Lands underlap their attached sheet; no overlapping solids at the weld interface.
  land=box(x,x+2.8,-97.25 if fixed else -96.5,-96.5 if fixed else -95.75,31.5625,31.75 if fixed else 32)
  get(pid)['shape']=sleeve.fuse(land).cut(cyl(.265,2.82,(x-.01,-96.5,31.8125),(1,0,0)))
  get(pid)['definition']={'hinge_axis_yz_in':[-96.5,31.8125],'OD_ID_in':[.75,.53],'upper_barrel_above_landing_in':.1875,'land_underlap_in':.25,'attachment':'Continuous1/8fillet onaccessiblelandedge; actual land contact tofixedstrip ortransitionplate, no intersecting parts','kind':'fixed' if fixed else 'moving withplate'}
 for p in parts:
  if p['id']=='ST-TRANSITION-PIN' or p['id'].startswith('ST-TRANSITION-COTTER-'):
   if not p.get('definition',{}).get('recessed_transition_axis',False):p['shape']=p['shape'].translate((0,0,-.1875))
   p.setdefault('definition',{}).update({'final_hinge_axis_yz_in':[-96.5,31.8125],'recessed_transition_axis':True})
 for i in range(12):
  pid='ST-TR-HNG-'+str(i);member='ST-TRANSITION-FIX' if i%2==0 else 'ST-TRANSITION'
  for a,b in [('ST-TRANSITION-PIN',pid),(pid,member)]:
   v=get(a)['shape'].intersect(get(b)['shape']).Volume();checks.append({'first':a,'second':b,'intersection_in3':v,'pass':v<1e-7})
 return {'checks':checks,'hinge_axis_yz_in':[-96.5,31.8125],'barrel_top_z_in':32.1875,'maximum_nominal_barrel_step_in':.1875,'limits':['Interknuckle gaps and tread transition require a continuous compatible walking-surface cover and real-device/hand checks before passenger use. Cover is not yet selected or represented as completed.','Fixed stationstrip attachment tosurveyedplatform remains site-specific.']}

def verify_station(parts,extra_ids=()):
 box=lambda x0,x1,y0,y1,z0,z1:cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,cq.Vector(x0,y0,z0))
 cyl=lambda r,h,p,d=(0,0,1):cq.Solid.makeCylinder(r,h,cq.Vector(*p),cq.Vector(*d))
 transition=repair_transition(parts,box,cyl)
 def overlap(aa,bb):
  return all(min(getattr(aa,d+'max'),getattr(bb,d+'max'))-max(getattr(aa,d+'min'),getattr(bb,d+'min'))>1e-6 for d in 'xyz')
 ids=['BR-DECK','BR-END--86']+[f'BR-RAIL-{x}' for x in [12.5,21.25,30,38.75,47.5]]+list(extra_ids)
 bridge=[p for p in parts if p['id'] in ids or p['id'].startswith(('BR-SHOE-','BR-HR-SOCKET-'))]
 station=[p for p in parts if p['group']=='c4-station-dock']
 flap_ids=['ST-TRANSITION']+[f'ST-TR-HNG-{i}' for i in range(12) if i%2]
 reports=[]
 for rise in [-2.5,0,2.5]:
  beta,alpha,flap=flap_pose(rise);fixed={}
  for p in station:
   sh=p['shape']
   if p['id'] in flap_ids:sh=sh.rotate((0,-96.5,31.8125),(1,-96.5,31.8125),math.degrees(alpha))
   fixed[p['id']]=sh.translate((0,0,rise))
  fixed_bounds={i:s.BoundingBox() for i,s in fixed.items()}
  collisions=[];npairs=0
  for p in bridge:
   sh=p['shape'].rotate((0,-52.25,31.625),(1,-52.25,31.625),math.degrees(beta));sh_bounds=sh.BoundingBox()
   for q in station:
    bs=fixed[q['id']]
    if overlap(sh_bounds,fixed_bounds[q['id']]):
     npairs+=1;v=sh.intersect(bs).Volume()
     if v>1e-6:collisions.append({'moving':p['id'],'fixed':q['id'],'intersection_in3':v})
  # Moving interleaved knuckles retain the common axis while the flap articulates.
  for pid in flap_ids:
   for q in station:
    if q['id'] in flap_ids:continue
    if overlap(fixed_bounds[pid],fixed_bounds[q['id']]):
     npairs+=1;v=fixed[pid].intersect(fixed[q['id']]).Volume()
     if v>1e-6:collisions.append({'moving':pid,'fixed':q['id'],'intersection_in3':v})
  reports.append({'station_minus_coach_floor_in':rise,'bridge_pitch_deg':math.degrees(beta),'transition_flap':flap,'boolean_pair_count':npairs,'rigid_collisions':collisions})
 return {'transition_hinge':transition,'scope':'Three conditional station-height states, dock shifted to station datum, actual transitionplate/oddknuckles articulated to first supporting deck contact. Selected bridge/end/header/shoe/socket members against all stationdock parts.','pitch_reports':reports,'limits':['No rated support/contact pressure, elastic deformation, manufacturing tolerance or continuous varying-height proof.','Train movement must be prevented during deployment. Station docking foundation and station surface connections require site-specific design.','Transitionflap carries nominal geometric contact only; skin bending and wear qualification remain open.']}
