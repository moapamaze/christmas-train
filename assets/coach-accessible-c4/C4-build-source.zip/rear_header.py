"""C4 rear unwelded header, real cleats, lowered captured rocking shoes.
All dimensions inches. Original dimensional hardware candidates; strength release held.
"""
import math
import cadquery as cq

def reinforce_rear(parts,add,box,cyl,tube,audit_only_ids=None):
 def get(i):return next(p for p in parts if p['id']==i)
 def put(i,s):get(i)['shape']=s
 def rem(i):parts[:]=[p for p in parts if p['id']!=i]
 def meta(i,**d):get(i).setdefault('definition',{}).update(d)
 def mass(groups):return sum(p['shape'].Volume()*(.098 if '6061' in p.get('material','') else .283) for p in parts if p.get('kind','physical')=='physical' and p['group'] in groups)
 m0=mass(['c4-bridge','c4-handrails']);s0=mass(['c4-station-dock']);new=[];changed=[];deleted=[];checks=[];contacts=[]
 def make(i,n,s,mat='6061-T6 unwelded candidate',group='c4-bridge',**d):
  add(i,n,group,s,mat,'#95a7ad');new.append(i);meta(i,**d)
 def cut(i,s):put(i,get(i)['shape'].cut(s));changed.append(i)
 def pair(a,b,kind):
  v=get(a)['shape'].intersect(get(b)['shape']).Volume();checks.append({'first':a,'second':b,'type':kind,'intersection_in3':v,'pass':v<1e-7})
 def touch(a,b,kind):contacts.append({'first':a,'second':b,'type':kind,'distance_in':get(a)['shape'].distance(get(b)['shape'])})
 def hx(x,y,z,h,af):return cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(h).val().translate((x,y,z))
 def hy(x,y,z,h,af):return hx(0,0,0,h,af).rotate((0,0,0),(1,0,0),-90).translate((x,y,z))
 def flush(i,x,y,z0,z1,r,targets):
  h=r/math.tan(math.radians(41));cone=cq.Solid.makeCone(2*r,r,h,cq.Vector(x,y,z0));s=cone.fuse(cyl(r,z1-z0-h,(x,y,z0+h)))
  for t in targets:cut(t,cyl(r+.015625,z1-z0+1,(x,y,z0-.5)));cut(t,cone)
  put(i,s);changed.append(i);meta(i,diameter_in=2*r,head_diameter_in=4*r,countersink_deg=82,overall_length_in=z1-z0,thread_form_modeled=False,procurement='Original nominal dimensional candidate; certified screw selection and proof qualification unresolved')
 # Remove superseded thin-endplate-to-rail fasteners.
 for p in list(parts):
  i=p['id']
  if (i.startswith(('BR-END-SCREW-','BR-END-NUT-')) and i.endswith('--90')) or (i.startswith('BR-END-HEAD-SPACER-') and i.endswith('--89.5')):rem(i);deleted.append(i)
 header='BR-REAR-HEADER';make(header,'Rear2x2x1/8 unwelded transverse header',tube(11.75,48.25,-92,-90,29.625,31.625,'x',.125),section_in=[2,2,.125],load_path='Five rail-end cleats transfer to rear header; bottom wall bears on endplate over captured shoe spacers; actual bolted shoe/socket connections tie stack')
 for x in [12.5,21.25,30,38.75,47.5]:
  outer=x in [12.5,47.5];w=1.1875 if outer else 1.5
  ci=f'BR-RH-CLEAT-{x}';cleat=box(x-w/2,x+w/2,-90,-89.5,29.75,31.25).fuse(box(x-w/2,x+w/2,-90,-87.75,29.75,30.125))
  cleat=cleat.cut(cyl(.203125,.7,(x,-90.1,30.75),(0,1,0))).cut(hy(x,-89.625,30.75,.14,.578125))
  make(ci,'Machined rail-end L-cleat with captured horizontal hex head',cleat,width_in=w,vertical_leg_thickness_in=.5,flange_thickness_in=.375,head_pocket_AF_in=.578125,head_pocket_depth_in=.125,assembly='Insert bolt head into shallow machined antirotation pocket before sliding cleat into open rail end; no weld')
  cut(header,cyl(.328125,2.2,(x,-92.1,30.75),(0,1,0)))
  sl=f'BR-RH-SLEEVE-{x}';make(sl,'Rear header through crush sleeve',cyl(.3125,2,(x,-92,30.75),(0,1,0)).cut(cyl(.203125,2.02,(x,-92.01,30.75),(0,1,0))),'Steel isolated from aluminum',OD_in=.625,ID_in=.40625,length_in=2)
  bi=f'BR-RH-BOLT-{x}';make(bi,'Captured-head3/8 rear cleat bolt',cyl(.1875,3,(x,-92.625,30.75),(0,1,0)).fuse(hy(x,-89.625,30.75,.25,.5625)),'Grade8 steel dimensional candidate',diameter_in=.375,under_head_length_in=3,head_AF_in=.5625,thread='3/8-16 nominal envelope',thread_form_modeled=False)
  wi=f'BR-RH-WASHER-{x}';make(wi,'Rear cleat washer',cyl(.4375,.0625,(x,-92.0625,30.75),(0,1,0)).cut(cyl(.203125,.08,(x,-92.07,30.75),(0,1,0))),'Steel washer candidate')
  ni=f'BR-RH-NUT-{x}';make(ni,'Rear cleat prevailing torque nut candidate',hy(x,-92.390625,30.75,.328125,.5625).cut(cyl(.1875,.35,(x,-92.4,30.75),(0,1,0))),'Compatible steel nut candidate',nominal_tip_projection_in=.234375,thread_form_modeled=False)
  rail=f'BR-RAIL-{x}'
  for t in [ci,header,sl,wi,ni]:pair(bi,t,'Nominal actual bore / omitted thread')
  pair(sl,header,'Through sleeve clearance');pair(ci,rail,'Cleat fits hollow rail');touch(ci,rail,'Cleat flange bears on rail lower inner face');touch(sl,wi,'Sleeve end face under washer');touch(ci,header,'Cleat vertical face contacts header front wall')
  if outer:
   sx=10.25 if x<30 else 49.75;xx=12.25 if x<30 else 47.75;yy=-89
   ni=f'BR-HR-BASE-NUT-{sx}-{xx}-{yy}';bi=f'BR-HR-BASE-SCREW-{sx}-{xx}-{yy}'
   pocket=box(xx-.3203125,xx+.3203125,yy-.3203125,yy+.3203125,30.0625,30.14);cut(ci,pocket)
   put(ni,box(xx-.3125,xx+.3125,yy-.3125,yy+.3125,30.0625,30.375).cut(cyl(.1875,.34,(xx,yy,30.05))));changed.append(ni)
   flush(bi,xx,yy,29.125,30.625,.1875,[f'BR-HR-SOCKET-{sx}--86','BR-END--86',rail,ci]);meta(ni,pocket='Shallow1/16 square antirotation pocket in cleat; nominal minimum side land.0234in is only locating, not a credited tensile section',tip_projection_in=.25)
   pair(bi,ni,'Raised captured square nut');pair(bi,ci,'Extended socket screw also fixes outer rail cleat');pair(ni,ci,'Square nut seated in shallow pocket')
  else:
   y=-88.25;cut(ci,hx(x,y,30,.14,.578125))
   for t in [ci,rail,'BR-END--86']:cut(t,cyl(.203125,1.6,(x,y,28.7)))
   bi=f'BR-RH-VBOLT-{x}';make(bi,'Captured downward3/8 cleat bolt',cyl(.1875,1.25,(x,y,28.75)).fuse(hx(x,y,30,.25,.5625)),'Grade8 steel dimensional candidate',under_head_length_in=1.25,diameter_in=.375,head_AF_in=.5625,thread_form_modeled=False)
   wi=f'BR-RH-VWASHER-{x}';make(wi,'Cleat lower washer',cyl(.4375,.0625,(x,y,29.3125)).cut(cyl(.203125,.08,(x,y,29.3))),'Steel washer candidate')
   ni=f'BR-RH-VNUT-{x}';make(ni,'Cleat lower prevailing torque nut',hx(x,y,28.984375,.328125,.5625).cut(cyl(.1875,.35,(x,y,28.975))),'Compatible steel nut candidate',nominal_tip_projection_in=.234375,thread_form_modeled=False)
   for t in [ci,rail,'BR-END--86',wi,ni]:pair(bi,t,'Actual bore / nominal mating thread')
 # Rear socket row passes through box bottom wall; raised nuts and extended screws.
 for sx,xs in [(10.25,[12.25,13.5]),(49.75,[46.5,47.75])]:
  for x in xs:
   y=-91;ni=f'BR-HR-BASE-NUT-{sx}-{x}-{y}';bi=f'BR-HR-BASE-SCREW-{sx}-{x}-{y}'
   put(ni,box(x-.3125,x+.3125,y-.3125,y+.3125,29.75,30.0625).cut(cyl(.1875,.34,(x,y,29.74))));changed.append(ni)
   flush(bi,x,y,29.125,30.3125,.1875,[f'BR-HR-SOCKET-{sx}--86','BR-END--86',header]);pair(bi,ni,'Rear socket nut seated on header bottom inner face');pair(ni,header,'Raised socket nut/box floor contact')
 # Re-machine two inboard-front socket fastener axes in fresh bracket/endplate blanks; old holes are not slotted.
 for sx,xold,xnew in [(10.25,13.5,13.625),(49.75,46.5,46.375)]:
  y=-89;sid=f'BR-HR-SOCKET-{sx}--86'
  for target,z0,z1 in [(sid,29.125,29.375),('BR-END--86',29.375,29.625)]:put(target,get(target)['shape'].fuse(box(xold-.4,xold+.4,y-.45,y+.45,z0,z1)))
  ni=f'BR-HR-BASE-NUT-{sx}-{xold}-{y}';bi=f'BR-HR-BASE-SCREW-{sx}-{xold}-{y}'
  put(ni,hx(xnew,y,29.625,.328125,.5625).cut(cyl(.1875,.35,(xnew,y,29.615))));changed.append(ni);meta(ni,shape='9/16AF hex nut clears adjacent shoe nut',height_in=.328125,thread_form_modeled=False,nominal_tip_projection_in=.234375)
  flush(bi,xnew,y,29.125,30.1875,.1875,[sid,'BR-END--86']);meta(bi,actual_axis_xy_in=[xnew,y],blank_requirement='Machine new bracket/endplate blanks with revised axis; shape union restores original blank before drilling, not a proposed weld-filled repair');pair(bi,ni,'Repositioned inboard nut clears outer rail wall')
 # Lower all station bearing/capture parts, preserving their bores and actual cotters.
 for p in parts:
  i=p['id']
  if i.startswith(('ST-BEAR-','ST-LIP-','ST-TOP-','ST-ENDSTOP-','ST-KEEP-')) or i=='ST-DOCK' or i in ['PIN-COTTER-14--83.625','PIN-COTTER-46--83.625']:
   p['shape']=p['shape'].translate((0,0,-.75));changed.append(i);meta(i,station_stack_lowering_in=.75)
   if i.startswith('ST-LIP-'):p['shape']=p['shape'].cut(box(0,60,-100,-80,28.875,31));meta(i,connection='Upstand rests on dock top skin with proposed qualified1/8 fillet along3in rear bearing land; lip rests on upstand top with continuous1/8 fillet to qualify; no overlapping plates credited')
   if i.startswith('ST-ENDSTOP-'):
    sx=int(i.split('-')[2]);p['shape']=p['shape'].intersect(box(sx-1.125,sx+1.125,-100,-80,20,32));meta(i,construction='Endstop fitted between channel upstands with proposed welded butt/fillet connection; no overlapping plate volumes')
   if i.startswith('ST-TOP-'):
    sx=int(i.split('-')[2]);p['shape']=p['shape'].cut(box(sx-.75,sx+.75,-100,-80,28,30));meta(i,clear_slot_width_in=1.5,nominal_shoe_capture_overlap_each_side_in=.25)
 for x in [14,46]:
  shoe=f'BR-SHOE-{x}';put(shoe,get(shoe)['shape'].translate((0,0,-.75)));changed.append(shoe)
  spacer=f'BR-SHOE-SPACER-{x}';make(spacer,'Solid structural shoe spacer1.125x3x3/4',box(x-.5625,x+.5625,-91.5,-88.5,28.625,29.375),'Steel isolated from aluminum',thickness_in=.75,load_path='Direct compression from endplate to shoe; actual two extended shoe screws retain stack')
  # Upper spacer step fits below the actual socket bracket foot, with face-bearing contact.
  sx=10.25 if x<30 else 49.75; sid=f'BR-HR-SOCKET-{sx}--86'
  xr=(x-.5625,x) if x<30 else (x,x+.5625)
  cut(spacer,box(xr[0],xr[1],-91.5,-88.5,29.125,29.375));meta(spacer,upper_step_depth_in=.25,upper_step='Half-width step under socket foot; remaining half bears directly on endplate; load path through bracket/endplate locally unqualified')
  for y in [-90.5,-89.5]:
   ni=f'BR-SHOE-NUT-{x}-{y}';bi=f'BR-SHOE-SCREW-{x}-{y}';nz=29.75 if y==-90.5 else 29.625
   put(ni,box(x-.25,x+.25,y-.25,y+.25,nz,nz+.25).rotate((x,y,0),(x,y,1),45).cut(cyl(.125,.27,(x,y,nz-.01))));changed.append(ni)
   targets=[shoe,spacer,sid,'BR-END--86']+([header] if y==-90.5 else[])
   flush(bi,x,y,28.125,nz+.5,.125,targets);pair(bi,ni,'Extended shoe screw / seated nut');pair(ni,header,'Shoe nut to rear header');touch(shoe,spacer,'Shoe upperface bears on spacer');touch(spacer,'BR-END--86','Solid spacer to endplate')
  # Fixed cylindrical crown; pad/base is one machined steel component, never a free floating surface.
  pad=f'ST-BEAR-{x}';crown=cyl(2,2,(x-1,-90,26.125),(1,0,0)).intersect(box(x-1,x+1,-92,-88,28,28.125));base=box(x-1.125,x+1.125,-92,-88,27.875,28)
  put(pad,base.fuse(crown));get(pad)['name']='Machined station bearing with R2 cylindrical crown and integral1/8 base';meta(pad,crown_radius_in=2,crown_axis_yz_in=[-90,26.125],crown_top_z_in=28.125,base_bottom_z_in=27.875,base_top_z_in=28,nominal_line_contact='2in X bearing width; Hertz contact/wear and local bearing strength unresolved',contact_equation='37.75sin(beta)+(rise-5.5)cos(beta)+5.5=0')
  # Two actual countersunk fasteners attach each bearing block to dock box.
  for xx in [x-.5,x+.5]:
   y=-91.75;tag=f'ST-BEAR-FIX-{xx}';r=.125;h=r/math.tan(math.radians(41));cone=cq.Solid.makeCone(r,2*r,h,cq.Vector(xx,y,28-h))
   for t in [pad,'ST-DOCK']:cut(t,cyl(.140625,5,(xx,y,23.5)));cut(t,cone)
   # Flush sleeve across full4in box; bearing base shares cap load.
   sl=tag+'-SLEEVE';make(sl,'Dock bearing bolt crush sleeve',cyl(.25,4,(xx,y,23.875)).cut(cyl(.140625,4.02,(xx,y,23.865))).cut(cone),'Steel candidate',group='c4-station-dock',length_in=4,OD_in=.5,ID_in=.28125)
   cut('ST-DOCK',cyl(.265625,4.2,(xx,y,23.775)))
   bi=tag+'-BOLT';make(bi,'1/4 flush top bearing-block bolt',cyl(r,4.75-h,(xx,y,23.25)).fuse(cone),'Custom steel dimensional candidate',group='c4-station-dock',overall_length_in=4.75,countersink_deg=82,thread_form_modeled=False)
   wi=tag+'-WASHER';make(wi,'Dock bearing lower washer',cyl(.3125,.0625,(xx,y,23.8125)).cut(cyl(.140625,.08,(xx,y,23.8))),'Steel candidate',group='c4-station-dock')
   ni=tag+'-NUT';make(ni,'Dock bearing nut candidate',hx(xx,y,23.59375,.21875,.4375).cut(cyl(.125,.24,(xx,y,23.58))),'Compatible steel nut candidate',group='c4-station-dock',tip_projection_in=.34375,thread_form_modeled=False)
   for t in [pad,'ST-DOCK',sl,wi,ni]:pair(bi,t,'Dock actual bore / omitted thread')
   pair(sl,'ST-DOCK','Dock crush sleeve clear bore');touch(sl,wi,'Dock sleeve lower land on washer')
  touch(shoe,pad,'Nominal cylinder/flat shoe line bearing');touch(pad,'ST-DOCK','Bearing base on dock top skin')
 for sx,x0,x1 in [(10.25,12.59375,13.28125),(49.75,46.71875,47.40625)]:
  sid=f'BR-HR-SOCKET-{sx}--86'
  cut(sid,box(x0,x1,-91.5,-88.5,29.125,29.25));meta(sid,station_lip_relief={'x_in':[x0,x1],'y_in':[-91.5,-88.5],'z_in':[29.125,29.25],'remaining_top_web_in':.125,'scope':'Bounded underside pocket clears pitched station capture lip; adjacent countersunk heads retain original geometry. Reduced socket-foot strength is unqualified; bridge remains unrated.'})
 for sx in [10.25,49.75]:
  sid=f'BR-HR-SOCKET-{sx}--86'
  for p in list(parts):
   if not p['id'].startswith(f'BR-HR-BASE-SCREW-{sx}-') or p['shape'].BoundingBox().ymax>=-87:continue
   bb=p['shape'].BoundingBox();xx=(bb.xmin+bb.xmax)/2;yy=(bb.ymin+bb.ymax)/2;tip=bb.zmax
   cut(sid,cyl(.390625,.125,(xx,yy,29.125)))
   flush(p['id'],xx,yy,29.25,tip,.1875,[sid,'BR-END--86']);meta(p['id'],head_recess={'bottom_z_in':29.25,'depth_in':.125,'clearance_counterbore_diameter_in':.78125,'head_diameter_in':.75,'countersink_deg':82,'bearing':'Cone spans remaining socket-foot web and endplate; head proof, bearing, preload and net-section qualification open'},tip_position_unchanged=True)
   pair(p['id'],sid,'Recessed head with actual counterbore and cone');pair(p['id'],'BR-END--86','Recessed cone enters real endplate countersink')
 for sx in [10.25,49.75]:
  pid=f'BR-HR-POST-{sx}--86';cut(pid,cyl(.75,8,(sx,-94,67.25),(0,1,0)));meta(pid,top_connection='Fishmouth saddle against retained top rail; weld size/process and handrail strength remain held')
 print('Rear hardware constructed; scoped rigid-pair audit',flush=True)
 # Relevant exact static pair audit; spring retainer contacts with its own shaft are a separately disclosed OEM fit.
 selected=set(new+changed) if audit_only_ids is None else set(audit_only_ids);near=[p for p in parts if p.get('kind','physical')=='physical' and p['group'] in ['c4-bridge','c4-handrails','c4-station-dock'] and p['shape'].BoundingBox().ymin<-87 and p['shape'].BoundingBox().ymax>-96]
 collisions=[];count=0
 for ia,a in enumerate(near):
  aa=a['shape'].BoundingBox()
  for b in near[ia+1:]:
   if a['id'] not in selected and b['id'] not in selected:continue
   # OEM free spring contact with its own keeper/handrail lock is not a rigid clearance assertion.
   if ('COTTER' in a['id'] and ('KEEP' in b['id'] or 'LOCK' in b['id'])) or ('COTTER' in b['id'] and ('KEEP' in a['id'] or 'LOCK' in a['id'])):continue
   bb=b['shape'].BoundingBox()
   if all(min(getattr(aa,d+'max'),getattr(bb,d+'max'))-max(getattr(aa,d+'min'),getattr(bb,d+'min'))>1e-6 for d in 'xyz'):
    count+=1
    if count%25==0:print('Rear rigid pairs',count,a['id'],b['id'],flush=True)
    v=a['shape'].intersect(b['shape']).Volume()
    if v>1e-6:collisions.append({'first':a['id'],'second':b['id'],'intersection_in3':v})
 I=(2**4-1.75**4)/12;netI=I-2*(.125*.65625**3/12+.125*.65625*.125**2)-.40625*(.125**3/12+.125*.9375**2) # sidewall transverse bore near neutral axis; not final local proof
 return {'module':'rear_header.py','revision':'C4-rear-header-R1','new_part_ids':new,'changed_part_ids':list(dict.fromkeys(changed)),'deleted_part_ids':deleted,'pitch_critical_ids':[i for i in new if not i.startswith('ST-')]+['BR-REAR-HEADER'],'mass_change_lb':mass(['c4-bridge','c4-handrails'])-m0,'station_mass_change_lb':mass(['c4-station-dock'])-s0,'checks':checks,'contacts':contacts,'audit_filter':list(audit_only_ids) if audit_only_ids is not None else 'all changed rear interfaces','scoped_overlap_pair_count':count,'rigid_collisions':collisions,'station_geometry':{'lowering_in':.75,'shoe_spacer_in':.75,'shoe_bottom_z_in':28.125,'shoe_top_z_in':28.625,'lip_bottom_z_in':28.875,'lip_top_z_in':29.125,'endplate_bottom_z_in':29.375,'crown_radius_in':2,'crown_center_yz_in':[-90,26.125],'tangent_equation':'37.75sin(beta)+(rise-5.5)cos(beta)+5.5=0','station_flap':'Independent station_pitch.py articulates actual plate and odd hinge knuckles to support contact'},'loadscreen':{'scope':'Designer300lbf local single-rail reaction only; does not envelope850lbf end reaction or near-end wheel. Bridge remains unrated.', 'probe_single_rail_reaction_lbf':300,'probe_multiplier':3,'header_support_pitch_in':32,'gross_I_in4':I,'gross_bending_3x_psi':900*32/4/I,'conservative_net_I_in4':netI,'conservative_net_bending_3x_psi':900*32/4/netI,'cleat_vertical_reaction_line_y_in':[-89,-88.25],'header_center_y_in':-91,'max_pitch_eccentricity_in':2.75,'assumed_cleat_contact_couple_arm_in':1,'horizontal_bolt_3x_axial_from_pitch_lbf':900*2.75,'horizontal_bolt_3x_shear_lbf':900,'bolt_nominal_VM_psi':math.sqrt((2475/.0775)**2+3*(900/(math.pi*.375**2/4))**2),'conditional_3_8_Grade8_proof_lbf':.0775*120000,'pitch_limit':'Conservative single central rail reaction with2.75in eccentricity; assumed1in compression/bolt couple must be established by local contact/deformation analysis; no equal rail load sharing credit','horizontal3_8bolt_900lbf_nominal_shear_psi':900/(math.pi*.375**2/4),'cleat_vertical_ligament_bearing_900lbf_psi':900/(.375*.375),'shoe_spacer_direct_compression_900lbf_psi':900/3.375,'limit':'No pass claim; no rated local wall, bolt-head pocket, captured square-nut thin locating land, Hertz contact, fatigue, torsion or full grillage verification'},'assembly':['Assemble cleats and captured heads through open rail ends before deck closure.','Fit rear header over five bolts, insert full-length through sleeves and install rear washers/nuts with9/16 socket from station side while bridge off dock or transition flap raised.','Rear shoe nuts and socket nuts inside header must be held/accessed through its open X ends before end closure; use long-reach tool and bench assembly.','Fit lowered shoes/spacers and real extended screws before station docking. All nominal steel/aluminum interfaces require isolation.','Station bearing block bolts run through dock crush sleeves; tighten from below with lower dock access.','Station transition hinge/platform remain at original Z32 datum; station structural attachment and movement interlock remain site-specific.'],'sources':['https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6061.pdf','https://www.portlandbolt.com/technical/specifications/sae-j429/'],'holds':['Original dimensioned hardware candidates are not supplier-selected or fabrication-released.','Three pitch states, tool checks and exact contact do not establish continuous tolerance/deformation qualification.','No bearing pressure/wear or capture uplift rating; proof testing and qualified structural review required.']}
