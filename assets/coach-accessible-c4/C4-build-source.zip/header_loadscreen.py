"""Explicit C4 near-end header probes. No geometry edits, rating or hidden load sharing.
Call screen(exact_CAD_coach_dead_reaction_lb, exact_CAD_station_dead_reaction_lb).
"""
import math,json
from pathlib import Path
SOURCES=['https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6061.pdf','https://www.portlandbolt.com/technical/specifications/sae-j429/']
RAILS=[12.5,21.25,30,38.75,47.5]
EDGES=[12,16.875,25.625,34.375,43.125,48]
I=(2**4-1.75**4)/12
FRONT_NET=I-2*.40625*(.125**3/12+.125*.9375**2)
REAR_NET=I-2*(.125*.65625**3/12+.125*.65625*.125**2)-.40625*(.125**3/12+.125*.9375**2)

def trib(total,center):
 lo,hi=center-13,center+13
 return [(x,total*max(0,min(hi,EDGES[i+1])-max(lo,EDGES[i]))/26) for i,x in enumerate(RAILS)]

def case(end,name,live,dead,factor,distribution,basis):
 a,b=(10.5,49.5) if end=='coach' else (14,46);net=FRONT_NET if end=='coach' else REAR_NET
 loads=[(float(x),float(p)) for x,p in distribution if p]+([(30,float(dead))] if dead else[])
 total=sum(p for x,p in loads);right=sum(p*(x-a) for x,p in loads)/(b-a);left=total-right
 nodes=sorted(set([a,b]+[x for x,p in loads]));moments=[(x,left*max(0,x-a)+right*max(0,x-b)-sum(p*max(0,x-xx) for xx,p in loads)) for x in nodes]
 peak=max(abs(m) for x,m in moments);e=6 if end=='coach' else 2.75;shear=factor*total*e/(2*1.875**2*.125)
 checks=[]
 def check(n,d,c,detail):checks.append({'id':n,'demand':d,'comparison':c,'units':'psi' if 'stress' in n or 'equivalent' in n else 'lbf','meets_limited_comparison':d<=c,'detail':detail})
 cmp=38000 if factor==3 else 35000
 check('header_net_bending_stress',factor*peak/net,cmp,'Net nominal elastic bending;3x reference compares38ksi minimum ultimate, wheel1.5 already included compares35ksi minimum yield. No design-code resistance factors.')
 check('header_net_bending_plus_gross_torsion_equivalent',math.hypot(factor*peak/net,math.sqrt(3)*shear),cmp,'Conservative entire-end pitch torque plus peak net bending; gross Bredt closed-cell torsion does not qualify drilled local walls.')
 maxsupport=max(abs(left),abs(right))
 if end=='coach':
  check('tongue_notch_gross_bending_stress',factor*maxsupport*3.05/(.9*.75**2/6),cmp,'Gross notch-root section only; actual corner concentration/fatigue remain open even if comparison is met.')
  check('tongue_half_inch_bolt_ideal_tension',factor*maxsupport*6.5,.1419*120000,'Each two-row tongue group: |R|/2+|R|×6in/1in. No prying credit/bound.')
  check('single_rail_three_eighth_bolt_full_end_pitch_ideal_tension',factor*total*7,.0775*120000,'Explicit adverse bound: entire end reaction and6in pitch torque assigned to one rail bolt with1in compression arm; includes direct force. This is not a proven stiffness distribution.')
 else:
  axial=factor*total*2.75;shearforce=factor*total
  check('single_cleat_bolt_full_end_pitch_equivalent',math.sqrt((axial/.0775)**2+3*(shearforce/(math.pi*.375**2/4))**2),120000,'Adverse entire-end reaction assigned to one cleat; axial2.75R and shearR, assumed1in compression arm. Grade8 proof comparison only; pocket/wall/contact strength unverified.')
  check('single_cleat_three_eighth_bolt_ideal_tension',axial,.0775*120000,'No joint capacity claim;1in contact couple must be established.')
 return {'id':name,'end':end,'live_end_reaction_lbf':live,'dead_end_reaction_lbf':dead,'total_end_reaction_lbf':total,'applied_factor_to_live_plus_dead':factor,'basis':basis,'load_points_x_lbf':loads,'transverse_support_x_in':[a,b],'support_reactions_lbf':[left,right],'force_residual_lbf':left+right-total,'moment_residual_inlb':right*(b-a)-sum(p*(x-a) for x,p in loads),'moment_samples_x_inlb':moments,'net_section_modulus_in3':net,'checks':checks,'failed_strength_screen_count':sum(not q['meets_limited_comparison'] for q in checks),'acceptance':'UNRATED / NOT ACCEPTED; nominal comparisons only; any unmet comparison is an explicit unresolved probe.'}

def screen(dead_coach,dead_station):
 dead_coach=float(dead_coach);dead_station=float(dead_station);cases=[]
 for end,dead,ycenter,wheely in [('coach',dead_coach,-65.125,-52.125),('station',dead_station,-79,-92)]:
  r600=600*((ycenter+90)/37.75 if end=='coach' else(-52.25-ycenter)/37.75)
  r750=750*((wheely+90)/37.75 if end=='coach' else(-52.25-wheely)/37.75)
  for extra in [0,25]:
   dd=dead+extra;tag=f'{end}-CADdead'+('plus25' if extra else '')
   for xc in [25,30,35]:
    cases.append(case(end,f'{tag}-600patch-X{xc}',r600,dd,3,trib(r600,xc),{'live_case':'Uniform600lbf on26×26in patch, as far toward this end as complete patch fits on deckY−92..−52.125.','patch_center_xy_in':[xc,ycenter],'patch_x_in':[xc-13,xc+13],'patch_y_in':[ycenter-13,ycenter+13],'transverse_distribution':'Conditional tributary widths bounded by rail midlines; requires deck/rail attachment verification, not automatic load sharing.','dead_distribution':'Exact CAD end reaction placed conservatively atX30 for header bending;25lbf/end added only in explicitly labeled sensitivity.','ultimate_probe':'3 times combined live and dead, once;38ksi minimum tensile comparison and35ksi yield are distinct.'}))
   cases.append(case(end,f'{tag}-600patch-unshared-end-bound',r600,dd,3,[(30,r600)],{'live_case':'Same nearest-end26in-long600lbf patch reaction, conservatively concentrated on central rail; does not credit transverse sharing.','patch_center_y_in':ycenter,'dead_distribution':'All CAD end reaction plus labeled allowance atX30.'}))
   for xw in [12,30,48]:
    cases.append(case(end,f'{tag}-500wheel-times1p5-X{xw}',r750,dd,1,[(xw,r750)],{'live_case':'Separate500lbf wheel×1.5dynamic=750lbf; no additional3x multiplier. Point at deck-end Y gives adverse reaction including overhang.','wheel_xy_in':[xw,wheely],'transverse_distribution':'Adverse concentrated wheel at clear-route edge or center; contact/effective strip and local deck qualification remain open.','dead_distribution':'CAD end reaction plus labeled allowance atX30; dead load is not multiplied1.5.'}))
  #850 already includes the intended end-interface allowance. Do not add CAD dead twice.
  cases.append(case(end,f'{end}-850-interface-midspan-times3',850,0,3,[(30,850)],{'live_case':'Independent850lbf total end-interface probe; includes dead allowance, not added to600 or750.','distribution':'All850 concentrated at transverse midspan; explicitly exceeds300lbf preliminary reaction screen.'}))
  xpos=10.5 if end=='coach' else 14
  cases.append(case(end,f'{end}-850-one-interface-times3',850,0,3,[(xpos,850)],{'live_case':'Independent850lbf on one receiver/shoe; force-interface bound, not an assumed passenger location.','distribution':'All end force at one support, with same pitch-arm/cleat probes; not combined with midspan case.'}))
 failures=[{'case':c['id'],'check':q['id'],'demand':q['demand'],'comparison':q['comparison'],'units':q['units']} for c in cases for q in c['checks'] if not q['meets_limited_comparison']]
 return {'status':'UNRATED / NOT ACCEPTED — explicit unresolved strength probes; geometry checks are separate.','revision':'C4-header-envelope-R1','dead_weight_basis':{'coach_dead_reaction_lbf':dead_coach,'station_dead_reaction_lbf':dead_station,'moving_total_lbf':dead_coach+dead_station,'source':'Caller supplies physical CAD volume×material-density forces and exactcentroid longitudinal reactions from final moving bridge and handrails.','sensitivity_added_per_end_lbf':25,'sensitivity_note':'Analyst sensitivity only, not a certified miscellaneous-weight allowance or final mass budget.'},'material_comparisons':{'certified_unwelded_6061T6_minimum_yield_psi':35000,'certified_unwelded_6061T6_minimum_ultimate_psi':38000,'SAE_J429_Grade8_proof_psi':120000,'status':'Conditional certified-property comparisons; not code allowables or accepted joint capacity.'},'case_count':len(cases),'failed_strength_screen_count':len(failures),'failed_case_count':sum(c['failed_strength_screen_count']>0 for c in cases),'failures':failures,'cases':cases,'sources':SOURCES,'page_hold_statement':'The boxed headers and physical fasteners are modeled, but the bridge remains unrated and unaccepted. Full near-end/deadweight probes expose unresolved header, tongue and/or connection comparisons, including the850lbf×3 interface envelope. The300lbf single-stringer screen is limited and does not establish the full end-interface capacity.','limitations':['Nominal elastic section and ideal bolt calculations only; neither a passing comparison nor zero CAD interference qualifies a joint.','A failed adverse load-distribution bound is retained explicitly; it may be resolved only by qualified load-distribution/contact analysis or a revised design and validation, not by unproven equal sharing.','Local aluminum rail/box walls, prying, sleeves, notch stress concentration, captured-head/pocket sections, handrail combinations, contact pressure/wear, fatigue and bolt locking/preload remain open.','Wheel750lbf and reference600lbf/3x are separate probes; no double factor and no combined750+600 load.','850lbf is a separate total interface allowance; its deadweight is not counted twice.','Measured operational load criteria, vehicle/station movement limits, structural proof testing and fabrication acceptance remain required.']}

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--coach-dead',type=float,required=True);p.add_argument('--station-dead',type=float,required=True);p.add_argument('--output',default='header-loadscreen.json');a=p.parse_args();r=screen(a.coach_dead,a.station_dead);Path(a.output).write_text(json.dumps(r,indent=2));print(json.dumps({k:r[k] for k in ['status','case_count','failed_strength_screen_count','failed_case_count']}))
