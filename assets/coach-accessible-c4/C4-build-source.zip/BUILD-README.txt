C4 ACCESSIBLE COACH — DEVELOPMENT GEOMETRY
UNRATED. CONCENTRATED NEAR-END / INTERFACE STRUCTURAL SCREENS FAIL.
NOT FOR CONSTRUCTION OR PASSENGER USE.

Coordinate system: inches; coach X front-to-rear, Y transverse, Z above rail.
Proposed loaded floor Z32. STEP exports are millimeters.

Python 3, CadQuery 2.7, NumPy, matplotlib and Shapely are required.
Run in this folder:
  python build_c4.py
  python verify_c4_paths.py
  python issue_c4.py

The main builder starts from development geometry, then applies connected
physical door, frame, bridge, retention, edge, front/rear header and storage
postprocessors. Only the final issued model describes the current arrangement;
intermediate member shapes and dimensions are deliberately superseded.

Station docking is conditional on a surveyed site, restrained train movement,
measured threshold range, handling plan, qualified load paths and full testing.
The drawing/model is a physical fit candidate, not a bridge load rating.
Purchased wheelchair restraint components are bounded reservations; current
OEM installation approval and exact hardware selection remain unresolved.

Read design-record.json, calculations.json and verification.json together.
Geometry/joint checks and failed structural screens are reported separately.
No helical thread form or final tolerance/elasticity qualification is implied.
