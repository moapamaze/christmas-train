"""Threshold-edge bridge pivot: clears the retained perimeter rail and fixes the moving lip.
Called after bridge joint detail and positive-retainer generation; actual final geometry inches.
"""
import math
import cadquery as cq
def reposition(parts,add,box,cyl,tube):
 def get(i):return next(p for p in parts if p['id']==i)
 def put(i,s):get(i)['shape']=s
 def rem(i):parts[:]=[p for p in parts if p['id']!=i]
 # Deck bridges above perimeter rail; no stationary packer traps its pitching underside.
 rem('SD-SILL')
 put('SD-THRESH',box(12,48,-52,-51.25,31.625,32));get('SD-THRESH')['name']='Coach steel threshold edge3/4wide; floor recess required'
 get('SD-THRESH')['definition']={'width_in':36,'depth_y_in':.75,'thickness_in':.375,'outer_edge_y_in':-52,'deck_joint_nominal_in':.125,'floor_recess':'Replace wood at threshold strip; steel top flushZ32'}
 # Steel support angle transfers threshold load to the retained perimeter innerface.
 support=box(12,48,-53,-50,30.753937,31.003937).fuse(box(12,48,-53,-52.75,28.253937,31.003937))
 add('COACH-THRESH-SUPPORT','Threshold backing angle36x3x3x1/4, welded to perimeter innerface','c4-coach-dock',support)
 put('SD-THRESH',box(12,48,-52,-51.25,31.003937,32));get('SD-THRESH')['name']='Machined solid steel threshold bar36x.75x.996063; floor flush'
 get('SD-THRESH')['definition']={'construction':'One-piece steel bar; no unfastened plate/riser interface','dimensions_in':[36,.75,.996063],'top_z_in':32,'attachment':'Two continuous1/8 E70 fillets along lowerYedges to backingangle; weld toe pockets cut into adjacent floor underside; weld/load qualification held','floor_relief_in':{'x':[12,48],'y':[-52,-51.25],'z':[31.003937,32]},'weld_toe_undercut_in':{'x':[12,48],'y':[-52.125,-51.125],'z':[31.003937,31.128937]}}
 get('COACH-THRESH-SUPPORT')['definition']={'horizontal_plate_z_in':[30.753937,31.003937],'vertical_plate_y_in':[-53,-52.75],'weld':'Proposed3/16 E70 continuous fillet to perimeter innerwall; local wall/load qualification open','floor_relief_in':{'x':[12,48],'y':[-52,-51.25],'z':[31.003937,32]}}
 for yy,sgn in [(-52,-1),(-51.25,1)]:
  poly=[(yy,31.003937),(yy+sgn*.125,31.003937),(yy,31.128937)]
  weld=cq.Workplane('YZ').polyline(poly).close().extrude(36).val().translate((12,0,0))
  add('COACH-THRESH-WELD-'+str(yy),'Threshold lower continuous1/8 fillet; explicit floor toe relief','c4-coach-dock',weld,'E70 weld candidate','#aeb6ae')
 # Extend only the deck over the perimeter; full-depth stringers stop outside its face.
 deck=box(11.75,48.25,-92,-52.125,31.625,32)
 for x in [11.75,48]:
  flange=box(11.75,13.5,-92,-52.125,31.625,31.875) if x<30 else box(46.5,48.25,-92,-52.125,31.625,31.875)
  up=box(x,x+.25,-92,-52.125,31.625,34)
  # Keep old bores in curb; extend only the new forward section.
  old=get('BR-CURB-'+str(x))['shape'];extension=up.fuse(flange).intersect(box(0,60,-55,-51,31,35))
  put('BR-CURB-'+str(x),old.fuse(extension));deck=deck.cut(up.fuse(flange))
 # Fresh explicit clearance/countersink cuts preserve the screw pattern.
 for x in [12.5,21.25,30,38.75,47.5]:
  for y in [-87,-79,-71,-63]:
   deck=deck.cut(cyl(.140625,1,(x,y,31.25))).cut(cq.Solid.makeCone(.125,.25,.125/math.tan(math.radians(41)),cq.Vector(x,y,32-.125/math.tan(math.radians(41)))))
 put('BR-DECK',deck);get('BR-DECK')['name']='Bridge deck36.5 x39.875 x3/8; pitching edge joint1/8nominal';get('BR-DECK')['definition']={'dimensions_in':[36.5,39.875,.375],'clear_width_in':36,'coach_edge_y_in':-52.125,'nominal_coach_gap_in':.125,'attachment':'Twenty1/4deck screws with actual countersinks/captive nuts; machined underside edge-angle recesses','nominal_material':'6061-T6 plate, minimum35ksi yield/38ksiultimate to be specified and certified'}
 for x in [12.5,21.25,30,38.75,47.5]:
  rid='BR-RAIL-'+str(x);old=get(rid)['shape'];half=.75 if x in [12.5,47.5] else 1.0;nb=tube(x-half,x+half,-90,-55.25,29.625,31.625,'y',.125)
  # Carry all vertical bolt bores through the now deeper bottom wall.
  for p in parts:
   if p['id'].startswith(('BR-DECK-SCREW-','BR-END-SCREW-','BR-HR-BASE-SCREW-')):
    b=p['shape'].BoundingBox();xx=(b.xmin+b.xmax)/2;yy=(b.ymin+b.ymax)/2
    if x-half<xx<x+half and -90<yy<-55.25:nb=nb.cut(cyl(.203125 if 'HR-BASE' in p['id'] else .140625,4,(xx,yy,28.5)))
  put(rid,nb);get(rid)['definition']={'section_in':[2,2*half,.125],'unwelded':True,'run_y_in':[-90,-55.25],'stop_clearance_to_perimeter_in':.25,'bearing_pitch_in':37.75,'counterpart':'Machined endmember transfers load to threshold-edge pins'}
 # Quarter-inch under-head spacers give inner end screws a real bearing stack.
 for x in [21.25,30,38.75]:
  for y in [-89.5,-58.5]:add(f'BR-END-HEAD-SPACER-{x}-{y}','Inner endmember screw spacer OD3/4 ID9/32 x1/4','c4-bridge',cyl(.375,.25,(x,y,29.125)).cut(cyl(.140625,.27,(x,y,29.115))),'Steel, isolated from aluminum','#b9b9ac')
 # Replace original outboard coach receiver weldments and front tongues.
 for p in list(parts):
  if p['id'].startswith('COACH-EXT-'):rem(p['id'])
 front='BR-END--54';fp=box(9.25,50.75,-60.5,-55.5,29.375,29.625)
 # Preserve drilled endmember screw columns using the final bolt locations.
 for p in parts:
  if p['id'].startswith(('BR-END-SCREW-','BR-HR-BASE-SCREW-')):
   b=p['shape'].BoundingBox();xx=(b.xmin+b.xmax)/2;yy=(b.ymin+b.ymax)/2
   if -60.5<yy<-55.5:fp=fp.cut(cyl(.203125 if 'HR-BASE' in p['id'] else .140625,2,(xx,yy,28.5)))
 for oldx,x,sgn in [(14,10.5,-1),(46,49.5,1)]:
  # Integral tongue webs straddle the perimeter top with a pitch-clearance notch.
  tongue=box(x-.45,x+.45,-58.5,-51.25,29.375,32.25)
  tongue=tongue.cut(box(x-.5,x+.5,-55.3,-52.75,28,31.5)).cut(cyl(.39,1,(x-.5,-52.25,31.625),(1,0,0)))
  fp=fp.fuse(tongue)
  for n,xx in enumerate([x-1,x+.5]):put(f'BR-COACH-LUG-{oldx}-{n}',box(xx,xx+.5,-53,-51.25,30.25,33).cut(cyl(.39,.52,(xx-.01,-52.25,31.625),(1,0,0))))
  # Inboard receiver heel and base weld to perimeter inner face, not through it.
  add(f'COACH-EDGE-HEEL-{x}','Threshold-edge receiver heel4x3x1/4; weld to perimeter inner face','c4-coach-dock',box(x-2,x+2,-53,-52.75,28.25,31.25).cut(box(x-.52,x+.52,-53.01,-50.7,29,33)))
  add(f'COACH-EDGE-BASE-{x}','Threshold-edge receiver base4x2.25x1/4','c4-coach-dock',box(x-2,x+2,-53,-50.75,30,30.25).cut(box(x-.52,x+.52,-53.01,-50.7,29,33)))
  for xx in [x-1.75,x+1.5]:
   sh=cq.Workplane('YZ').polyline([(-52.75,28.75),(-52.75,30),(-51.25,30)]).close().extrude(.25).val().translate((xx,0,0));add(f'COACH-EDGE-GUSSET-{x}-{xx}','Receiver triangular1/4 gusset','c4-coach-dock',sh)
  # Head lies inside its ear but outside36clear; spring retainer is outboard.
  pid=f'BR-PIN-{oldx}';cx=x+sgn*1.25
  shaft=cyl(.375,2.65,(x-sgn*1.2,-52.25,31.625),(sgn,0,0)).cut(cyl(4.5/25.4/2,2,(cx,-53.25,31.625),(0,1,0)))
  put(pid,shaft);put(f'BR-PIN-HEAD-{oldx}',cyl(.5,.2,(x-sgn*1.2,-52.25,31.625),(-sgn,0,0)))
  # Actual4E cotter at new outboard location; orient loop outboard inY/Z after body clearance check.
  from pathlib import Path
  clip=cq.importers.importStep(str(Path(__file__).parent/'GN1024-NI-4-E.step')).val().scale(1/25.4)
  clip=clip.rotate((0,0,0),(1,0,0),90).translate((cx,-52.25+29.5/25.4,31.625));put(f'PIN-COTTER-{oldx}--54',clip)
  get(pid)['definition']={'axis_center_in':[x,-52.25,31.625],'diameter_in':.75,'positive_retainer':'Actual4E spring cotter, installed deflection/proof test held','clear_route_x_in':[12,48]}
 put(front,fp);get(front)['definition']={'construction':'Machined6061-T6 endmember with integral threshold-edge tongues','pin_axes_in':[[10.5,-52.25,31.625],[49.5,-52.25,31.625]],'perimeter_clearance_notch_bottom_z_in':31.5,'load_qualification':'Net section, bolt group, notch and bearing checks held'}
 print('Edge hinge construction complete; pitch checks',flush=True)
 return {'bearing_pitch_in':37.75,'deck_length_in':39.875,'hinge_axes_xyz_in':[[10.5,-52.25,31.625],[49.5,-52.25,31.625]]}

def validate_pitch(parts,box,extra_ids=()):
 # Scoped rigid interfaces, with simple conservative retained-frame solid to avoid
 # repeatedly intersecting the full400in frame's unrelated holes.
 critical_ids=['BR-DECK','BR-END--54','BR-RAIL-12.5','BR-RAIL-47.5']+list(extra_ids)
 moving=[p for p in parts if p['id'] in critical_ids]
 fixed=[p for p in parts if p['id'] in ['FRAME-P1','SD-THRESH','SD-F1','SD-F2'] or p['id'].startswith(('COACH-EDGE-','COACH-THRESH-','BR-COACH-LUG-'))]
 reports=[]
 for rise in [-2.5,0,2.5]:
  from station_pitch import bridge_angle
  angle=math.degrees(bridge_angle(rise));coll=[];count=0
  for a in moving:
   sh=a['shape'].rotate((0,-52.25,31.625),(1,-52.25,31.625),angle);ab=sh.BoundingBox()
   for b in fixed:
    bs=box(-47,353,-55,-53,27.003937,31.003937) if b['id']=='FRAME-P1' else b['shape'];bb=bs.BoundingBox()
    if all(min(getattr(ab,d+'max'),getattr(bb,d+'max'))-max(getattr(ab,d+'min'),getattr(bb,d+'min'))>1e-6 for d in 'xyz'):
     count+=1;v=sh.intersect(bs).Volume()
     if v>1e-6:coll.append({'moving':a['id'],'fixed':b['id'],'intersection_in3':v})
  a=.125;b=.375;t=math.radians(angle);edge_y=-52.25+a*math.cos(t)-b*math.sin(t);edge_z=31.625+a*math.sin(t)+b*math.cos(t)
  print('Pitch state complete',rise,len(coll),flush=True)
  reports.append({'station_minus_coach_floor_in':rise,'pitch_deg':angle,'coach_joint_horizontal_gap_in':-52-edge_y,'deck_tip_step_in':edge_z-32,'boolean_pair_count':count,'rigid_collisions':coll})
 return {'geometry':'Threshold-edge pivot; stationbearingY−90; no6in overhang','bearing_pitch_in':37.75,'deck_length_in':39.875,'hinge_axes_xyz_in':[[10.5,-52.25,31.625],[49.5,-52.25,31.625]],'pitch_reports':reports,'limits':['Scoped deck/endmember/outer-rail critical-interface check at three states. Independent detailed pin/tongue/cotter check is reported separately. Full continuous sweep, deformation and manufacturing tolerances remain open.','Station dock must be set to the station datum for each illustrated difference; no on-coach lift provided.']}
