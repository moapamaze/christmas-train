"""Original, dimensioned C4 door mechanism proposal; not a construction release.
Coordinates inches; source cotter STEP in mm. Portal steel remains in build_c4.
Returns portal clearance cutters. transform_door_shape is used by the exporter.
"""
from pathlib import Path
import math
import cadquery as cq
SOURCE=Path(__file__).resolve().parent/'GN1024-NI-3-E.step'
def transform_door_shape(part,state):
 s=part['shape'];m=part.get('move')
 if not m:return s
 if m[0]=='holdpin':return s if state=='boarding' else s.translate((0,6.5,0))
 if m[0]=='holdclip':return s if state=='boarding' else m[1]
 # Boarding uses the side door only. Enddoor sweeps are separate review states.
 door_open=(m[0]=='side' and state=='boarding') or (m[0]=='end' and state=='enddoors-open')
 if len(m)>4 and m[4]=='slider' and door_open:s=s.translate(m[5])
 if door_open:
  if m[0]=='side':return s.rotate((8.5,-57.5,0),(8.5,-57.5,1),-180)
  return s.rotate((m[1],m[2],0),(m[1],m[2],1),-180*m[3])
 return s

def build_doors(add,box,tube,cyl,bolt,cut_holes):
 cutters=[]
 split_cotter_base=[]
 cotter=cq.importers.importStep(str(SOURCE)).val().scale(1/25.4)
 def build(prefix,L,origin,U,V,move,portal_id):
  ox,oy=origin
  def point(u,v,z):return (ox+U[0]*u+V[0]*v,oy+U[1]*u+V[1]*v,z)
  def world(s):
   # local u/v bases are right-handed for side/front; rear is mirrored using a 180deg rotation.
   if U==(1,0) and V==(0,1):return s.translate((ox,oy,0))
   if U==(0,1) and V==(-1,0):return s.rotate((0,0,0),(0,0,1),90).translate((ox,oy,0))
   # front local u=+Y, v=+X is reflected. Use CAD transformGeometry to preserve circle surfaces as splines.
   return s.mirror('XZ').rotate((0,0,0),(0,0,1),90).translate((ox,oy,0))
  def put(pid,name,group,s,mat='Weldable steel, grade and load qualification open',color='#71868a',kind='physical',moving=True,special=None):
   add(prefix+'-'+pid,name,group,world(s),mat,color,kind,move if moving and special is None else special)
  group='c4-side-leaf' if prefix=='SD' else 'c4-end-leaves'
  # Main frame and two real latch support rails. Aluminum leaf was replaced by weldable steel so hinge/guide welds are compatible.
  for tag,b,axis in [('LF-L',(0,1.5,.5,2,32.25,109.75),'z'),('LF-R',(L-1.5,L,.5,2,32.25,109.75),'z'),('LF-B',(1.5,L-1.5,.5,2,32.25,33.75),'x'),('LF-T',(1.5,L-1.5,.5,2,108.25,109.75),'x'),('LF-M',(1.5,L-1.5,.5,2,67.25,68.75),'x'),('LF-LATCH-RAIL',(1.5,L-1.5,.5,2,79.25,80.75),'x')]:
   put(tag,'Door leaf HSS 1.5 x 1.5 x 0.083; welded steel',group,tube(*b,axis,.083))
  put('PANEL','Lower sheet steel skin 0.063; perimeter stitch-weld candidate',group,box(1.5,L-1.5,.437, .5,33.75,67.25),color='#967c59')
  put('GLASS','Laminated glazing and retention-system reservation',group,box(1.5,L-1.5,1.05,1.3,81,108.25),'Glazing + clips/seal specification unresolved','#8db7bf','reservation')
  put('GLASS-LOWER','Lower glazing and retention-system reservation',group,box(1.5,L-1.5,1.05,1.3,69,79),'Glazing + clips/seal specification unresolved','#8db7bf','reservation')
  for z in [42,70,100]:
   # Two fixed knuckles and one separate moving knuckle, each bored.
   for j,(zz,h) in enumerate([(z,1.5),(z+1.625,1.5),(z+3.25,1.5)]):
    sleeve=cyl(.5,h,(0,0,zz)).cut(cyl(.265,h+.02,(0,0,zz-.01)))
    put(f'HNG-{z}-{j}','Interleaved hinge knuckle OD1 ID0.530; 1/8 axial gaps',group if j==1 else 'c4-door-frame',sleeve,moving=j==1)
   for tag,b,moving in [('FIX1',(-2,-.125,0,3.5,z+.5,z+.75),False),('FIX2',(-2,-.125,0,3.5,z+3.75,z+4),False),('LEAF',(0,1.375,0,1.75,z+1.875,z+2.125),True)]:
    tab=box(*b).cut(cyl(.265,8,(0,0,z-1)))
    put(f'HNG-{tag}-{z}','Hinge attachment tab 1/4 plate, bore clear through; edge weld to sleeve and tube',group if moving else 'c4-door-frame',tab,moving=moving)
   # Compact headed/threaded pin and castellated nut stay inside the hinge-side leaf sweep radius.
   pin=cyl(.25,5.4375,(0,0,z-.625)).fuse(cyl(.4375,.1875,(0,0,z+4.8125)))
   crossz=z-.15625
   pin=pin.cut(cyl(.0390625,1,(-.5,0,crossz),(1,0,0)))
   put(f'PIN-{z}','Hinge pin1/2; lower1/2-20 thread,5/64 split-cotter crosshole; integral7/8 head','c4-door-frame',pin,'17-4PH H1150 candidate, certified properties required','#c7ccc7',moving=False)
   for tag,zz in [('LOWER',z-.0625),('UPPER',z+4.75)]:
    washer=cyl(.4375,.0625,(0,0,zz)).cut(cyl(.265,.08,(0,0,zz-.01)))
    put(f'PIN-WASHER-{tag}-{z}','Hinge washer OD7/8 ID0.530 x1/16','c4-door-frame',washer,moving=False)
   # Custom castellated1/2-20 nut. Helical thread represented by nominal bore and thread callout.
   cr=.75/math.sqrt(3)
   poly=[(cr*math.cos(math.radians(30+60*k)),cr*math.sin(math.radians(30+60*k))) for k in range(6)]
   nut=cq.Workplane('XY').polyline(poly).close().extrude(.4375).val().translate((0,0,z-.5)).cut(cyl(.25,.46,(0,0,z-.51)))
   for deg in [0,60,120]:
    slot=box(-.6,.6,-.0625,.0625,z-.25,z-.05).rotate((0,0,0),(0,0,1),deg)
    nut=nut.cut(slot)
   put(f'PIN-NUT-{z}','Castellated1/2-20 nut,3/4AF x7/16; six1/8 slots; threadform omitted','c4-door-frame',nut,moving=False)
   # Formed soft stainless split cotter: two1/32 wire legs through5/64 hole, eye and spread tails withinR.45.
   if not split_cotter_base:
    def wirepath(points,r=.015625):
     out=None
     for pa,pb in zip(points[:-1],points[1:]):
      d=tuple(pb[j]-pa[j] for j in range(3));length=math.sqrt(sum(t*t for t in d))
      c=cyl(r,length,pa,tuple(t/length for t in d))
      out=c if out is None else out.fuse(c)
     for q in points:out=out.fuse(cq.Solid.makeSphere(r,cq.Vector(*q)))
     return out
    rr=math.hypot(.03125,.015625);aa=math.atan2(.015625,-.03125)
    path=[(-.40625,.125,0.0),(-.40625,.015625,0.0),(-.3125,.015625,0.0),(.3125,.015625,0.0)]
    path +=[(.34375+rr*math.cos(aa-2*aa*k/12),rr*math.sin(aa-2*aa*k/12),0.0) for k in range(1,13)]
    path +=[(-.3125,-.015625,0.0),(-.40625,-.015625,0.0),(-.40625,-.125,0.0)]
    split_cotter_base.append(wirepath(path))
   clip=split_cotter_base[0].translate((0,0,crossz))
   put(f'PIN-COTTER-{z}','Formed1/16 split cotter; spreadtails withinR.45; replaceafterremoval','c4-door-frame',clip,'Annealed stainless cotter candidate; procurement/forming verification open','#d5bd6e',moving=False)
  # Captive manual shoot bolts. Operating key must lift/rotate into axial slot before sliding.
  for z in [68,80]:
   u0=L-7;u1=L-2;vc=2.75
   guide=cyl(.5,u1-u0,(u0,vc,z),(1,0,0)).cut(cyl(.265,u1-u0+.02,(u0-.01,vc,z),(1,0,0)))
   slot=box(L-6.640625,L-4.359375,vc-.7,vc+.7,z-.140625,z+.140625)
   for u in [L-6.5,L-4.5]:
    # Opposed quarter-circle parking branches; relieved boundaries accommodate key diameter.
    slot=slot.fuse(box(u-.140625,u+.140625,vc-.140625,vc+.7,z-.7,z+.140625))
    slot=slot.fuse(box(u-.140625,u+.140625,vc-.7,vc+.140625,z-.140625,z+.7))
   guide=guide.cut(slot)
   put(f'BOLT-GUIDE-{z}','Shoot-bolt guide OD1 ID0.530,2-inch travel with positive L-slot end parks',group,guide)
   for u in [L-6.875,L-2.25]:
    # Upright mounting ears clear the moving bolt, and weld to the added transverse rail.
    ear=box(u-.125,u+.125,1.75,3.25,z-.75,z+.75).cut(cyl(.51,.27,(u-.135,vc,z),(1,0,0)))
    put(f'BOLT-MOUNT-{z}-{u}','1/4 mounting ear, guide-weld ring and leaf rail weld land',group,ear)
   # Pin crosskey is a through fitted pin; both ends prevent escape from the guide slot.
   rod=cyl(.25,8.5,(L-7.5,vc,z),(1,0,0))
   rod=rod.cut(cyl(.125,1,(L-4.5,vc-.5,z),(0,1,0)))
   key=cyl(.125,2.4,(L-4.5,vc-.4,z),(0,1,0))
   knob=cyl(.375,.5,(L-4.5,vc+1.5,z),(0,1,0))
   # Parked down in both endpoint states. Crosskey fit/peening is a manufacturing requirement.
   key=key.rotate((0,vc,z),(1,vc,z),-90);knob=knob.rotate((0,vc,z),(1,vc,z),-90)
   rod=rod.rotate((0,vc,z),(1,vc,z),-90)
   retract=tuple(-2*k for k in (*U,0))
   sm=tuple(move[:4])+('slider',retract)
   # side move is padded to4items, allowing common exporter support.
   for tag,shape in [('BOLT',rod),('BOLT-KEY',key),('BOLT-GRIP',knob)]:
    put(f'{tag}-{z}','Manual captive shoot bolt / fitted crosskey / handgrip; rotate then slide2in',group,shape,special=sm)
   # The strike is an actual receiver sleeve welded through the jamb's drilled near wall.
   strike=cyl(.5,1.25,(L-.5,vc,z),(1,0,0)).cut(cyl(.28,1.27,(L-.51,vc,z),(1,0,0)))
   put(f'STRIKE-{z}','Fixed strike sleeve OD1 ID0.560,1.25in long through drilled jamb wall','c4-door-frame',strike,moving=False)
   cutters.append((portal_id,world(cyl(.51,1.5,(L-.625,vc,z),(1,0,0)))))
  return world,put
 # Origins leave a half-inch gap between leaf inner face and portal front surface.
 world,put=build('SD',43,(8.5,-57.5),(1,0),(0,1),('side',None,None,None),'SD-J2')
 build('FRONT',37.5,(-6.5,-13),(0,1),(1,0),('end',-6.5,-13,-1),'FRONT-J24')
 build('REAR',37.5,(312.5,-13),(0,1),(-1,0),('end',312.5,-13,1),'REAR-J24')
 # Side hold-open receiver: a physical post, outrigger and clevis; pad/anchor connection to coach perimeter retained as a declared custom interface.
 hx,hy=-33.75,-60.5
 post=tube(hx-1,hx+1,-55,-53,31.375,70.5,'z',.125)
 add('SD-HOLD-POST','Hold-open support post HSS2x2x1/8 on front platform perimeter','c4-door-frame',post)
 pad=cut_holes(box(hx-2,hx+2,-56,-52,31.003937,31.375),[(hx-1.5,-54,31),(hx+1.5,-54,31)],.28125)
 add('SD-HOLD-FOOT','Hold-open post foot4x4x3/8, drilled1/2-inch anchors','c4-door-frame',pad)
 for x in [hx-1.5,hx+1.5]:
  bolt(f'SD-HOLD-ANCHOR-{x}',(x,-54,26.5),(0,0,1),5.25,.25)
  add(f'SD-HOLD-SLEEVE-{x}','Hold-open frame crush sleeve OD3/4 ID9/16','c4-door-frame',cyl(.375,4,(x,-54,27.003937)).cut(cyl(.28125,4.02,(x,-54,26.993937))))
 arm=box(hx-.75,hx+.75,hy-.75,hy+.75,69.5,69.75)
 arm=arm.fuse(box(hx-3,hx+.75,-54.5,-53.5,69.5,69.75)).fuse(box(hx-3,hx-2,hy-.75,-53.5,69.5,69.75)).fuse(box(hx-3,hx+.75,hy-.75,hy+.75,69.5,69.75))
 upper=box(hx-.75,hx+.75,hy-.75,hy+.75,70.25,70.5)
 upper=upper.fuse(box(hx-.75,hx-.625,hy-.75,hy+.75,69.5,70.5))
 for pid,s in [('LOWER',arm),('UPPER',upper)]:
  add('SD-HOLD-'+pid,'Hold-open clevis plate1/4,9/16 pin bore','c4-door-frame',s.cut(cyl(.28125,2,(hx,hy,69))))
 # Leaf tongue is modeled in closed coordinates, transformed into the receiver at180deg.
 tongue=box(41.75,42.75,2,3.5,69.875,70.125).cut(cyl(.28125,1,(42.25,3,69.5)))
 add('SD-HOLD-TONGUE','Hold-open leaf tongue1/4 plate,9/16 bore, welded to free-edge leaf tube','c4-side-leaf',world(tongue),move=('side',None,None,None))
 holdpin=cyl(.25,1.75,(hx,hy,69.0625)).fuse(cyl(.4375,.1875,(hx,hy,70.8125)))
 holdpin=holdpin.cut(cyl(3.5/25.4/2,1,(hx-.5,hy,69.25),(1,0,0)))
 add('SD-HOLD-PIN','Removable headed1/2 hold-open pin; withdrawbeforedoorrotation','c4-door-frame',holdpin,move=('holdpin',))
 clip=cotter.rotate((0,0,0),(1,0,1),180).translate((hx-29.75/25.4,hy,69.25))
 parkplate=box(hx-1,hx+1,-55,-53,70.5,70.75).cut(cyl(.28125,.3,(hx,-54,70.48)))
 add('SD-HOLD-PARK','Drilled posttop parkingplate for removed hold-open pin','c4-door-frame',parkplate)
 stud=cyl(.25,.75,(hx,-55.75,67),(0,1,0)).cut(cyl(3.5/25.4/2,1,(hx,-55.625,66.5)))
 add('SD-HOLD-COTTER-PARK-STUD','Drilled1/2 parkingstud for removedhold-open cotter','c4-door-frame',stud)
 parkclip=cotter.rotate((0,0,0),(1,1,0),180).translate((hx,-55.625,67+29.75/25.4))
 add('SD-HOLD-COTTER','Actual3mm spring cotter throughholdpin; removebeforewithdrawal','c4-door-frame',clip,move=('holdclip',parkclip))
 return cutters
