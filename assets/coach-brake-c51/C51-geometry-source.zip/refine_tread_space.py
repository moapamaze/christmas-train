"""Exact circular tread-space probes; not manufactured brake parts or a qualified contact profile."""
from pathlib import Path
import json, math, hashlib
import cadquery as cq
import numpy as np
H=Path(__file__).resolve().parent
B=H.parent/'coach-truck-c5'
parts=json.loads((B/'parts.json').read_text())
shapes=cq.importers.importBrep(str(B/'checkpoint.brep')).val().Solids()
assert len(parts)==len(shapes)
S={p['id']:s for p,s in zip(parts,shapes)}; M={p['id']:p for p in parts}
def obsolete(k): return '-BRAKE-' in k or '-TORQUE-' in k or k.startswith('AXLE')
keep=[k for k in S if not obsolete(k)]
def bb(s):
 b=s.BoundingBox(); return np.array([[getattr(b,a+'min'),getattr(b,a+'max')] for a in 'xyz'])
def overlap(a,b):return np.all(np.minimum(a[:,1],b[:,1])-np.maximum(a[:,0],b[:,0])>1e-6)
def bboxgap(a,b):return np.linalg.norm(np.maximum(np.maximum(a[:,0]-b[:,1],b[:,0]-a[:,1]),0))
def state(k,d):
 return S[k] if M[k]['metadata']['kinematics'].startswith('axle') else S[k].translate((0,0,-d))
def probe(q,ss,bbs,include_wheel=False):
 qb=bb(q);hits=[];near=None;gap=1e6;wheelhits=[]
 for k,s in ss.items():
  sb=bbs[k]
  wheel=M[k]['group']=='wheel'
  if overlap(qb,sb):
   v=q.intersect(s).Volume()
   if v>1e-5:(wheelhits if wheel else hits).append({'part':k,'volume_mm3':v})
  if not wheel and bboxgap(qb,sb)<gap:
   g=q.distance(s)
   if g<gap:gap=g;near=k
 return {'minimum_nonwheel_gap_mm':gap,'nearest_part':near,'intersections':hits,'wheel_penetrations':wheelhits}
def shoe(ax,side,front):
 y0=455 if side>0 else -525
 def p(r,a):
  t=math.radians(a);return (ax+front*r*math.cos(t),300+r*math.sin(t))
 plane=cq.Plane(origin=(0,y0,0),xDir=(1,0,0),normal=(0,-1,0))
 return cq.Workplane(plane).moveTo(*p(300,-25)).threePointArc(p(300,0),p(300,25)).lineTo(*p(340,25)).threePointArc(p(340,0),p(340,-25)).close().extrude(-70).val()
shoes=[]; beams=[]
for d in [-60,-40,0,35]:
 ss={k:state(k,d)for k in keep}; bbs={k:bb(s)for k,s in ss.items()}
 for ax in [-600,600]:
  for side in [-1,1]:
   for front in [-1,1]:
    q=shoe(ax,side,front)
    r={'axle_x_mm':ax,'side':side,'fore_aft':front,'inner_facing':ax*front<0,'jounce_mm':d,'radial_mm':[300,340],'angle_deg':[-25,25],'Y_mm':[455,525]if side>0 else[-525,-455],**probe(q,ss,bbs)}
    shoes.append(r)
 for xc in [-940,-260,260,940]:
  for halfY in [530,550,620]:
   q=cq.Solid.makeCylinder(25,halfY*2,cq.Vector(xc,-halfY,300),cq.Vector(0,1,0))
   beams.append({'x_mm':xc,'diameter_mm':50,'Y_mm':[-halfY,halfY],'Z_center_mm':300,'jounce_mm':d,**probe(q,ss,bbs)})
 print('TREAD_STATE',d,flush=True)
r={'status':'Geometric reservations only; no brake architecture selected','shoes':shoes,'beams':beams,'excluded_part_ids':[k for k in S if obsolete(k)],'notes':['70 mm axial band avoids the current flange-stock band by5 mm. Actual machined tread, flange, shoe face and back-to-back are not specified.','The circular shoe-probe innerface is exactly radius300; zero own-wheel penetration is checked, but tangential contact is intentional.','Each probe follows its axle through relative vertical travel. No actual axle-tracking linkage is modeled, so this is a placement condition, not an achieved mechanism.','The32 shoe and48 beam checks use full,35 mm jounce,40 mm working rebound and60 mm captured droop. Truck yaw rotates the local frame and probes together; body roll/yaw interference for these low/outboard probes has not been separately demonstrated.','Old outboard brake/torque hardware and entire axles are excluded from retained obstacles. A replacement axle is required; its mount details are not modeled.']}
(H/'tread-space.json').write_text(json.dumps(r,indent=2));print('DONE',flush=True)
