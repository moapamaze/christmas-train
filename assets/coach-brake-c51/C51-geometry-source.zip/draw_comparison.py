"""C51 bounded space study. Existing CAD edges are referenced, not regenerated."""
from pathlib import Path
import json, math, gzip, hashlib, shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Rectangle, Circle, Wedge
H=Path(__file__).resolve().parent; B=H.parent/'coach-truck-c5'; OUT=H.parents[1]/'dist/assets/coach-brake-c51'; OUT.mkdir(parents=True,exist_ok=True)
M={p['id']:p for p in json.loads((B/'parts.json').read_text())}
E=json.loads((B/'drawing-edges.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'})
C={'frame':'#697987','wheel':'#263641','spring':'#a57938','axlebox':'#697987','guide':'#83929b','context':'#a2adb4'}
def chosen(k):
 return M[k]['group']=='wheel' or k.endswith('-BOX') or '-TRAY'in k or '-COIL'in k or k.startswith('CB-') and 'WELD'not in k or k.startswith('SF-')and'-WEB'in k or k.startswith('CTX-MAIN') or k.startswith('CTX-CROSS')
def edges(ax,axes,filter=None,alpha=.7):
 for k in E:
  if not chosen(k)or filter and not filter(k):continue
  pts=[np.asarray(e)*25.4 for e in E[k]]
  ax.add_collection(LineCollection([p[:,axes]for p in pts],colors=C.get(M[k]['group'],'#888'),linewidths=.42,alpha=alpha))
def dims(ax,a,b,text,off=0,vertical=False,col='#425666'):
 a=np.array(a,dtype=float);b=np.array(b,dtype=float)
 ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'<->','lw':.7,'color':col})
 m=(a+b)/2
 ax.text(m[0]+(off if vertical else 0),m[1]+(0 if vertical else off),text,ha='left'if vertical else'center',va='center'if vertical else'bottom',fontsize=8,color=col,rotation=90 if vertical else 0,bbox={'facecolor':'white','edgecolor':'none','pad':1,'alpha':.85})
def setup(ax,title):
 ax.set_aspect('equal');ax.set_title(title,loc='left',fontweight='bold',fontsize=11,pad=12);ax.grid(alpha=.12);ax.tick_params(labelsize=7);ax.set_xlabel('X · mm',fontsize=8);ax.set_ylabel('Y · mm',fontsize=8)
fig=plt.figure(figsize=(17,12),facecolor='white')
fig.text(.045,.958,'C51–G01  |  COMPACT BRAKE SPACE COMPARISON',fontsize=20,weight='bold',color='#203947')
fig.text(.045,.932,'R0 · Actual C5 checkpoint geometry + explicitly provisional reservations · All dimensions mm',fontsize=11,color='#5b6d77')
fig.text(.045,.906,'NO BRAKE IS SELECTED.  These are placement studies, not manufactured parts, capacity approval or a fabrication drawing.',fontsize=10,weight='bold',color='#a44c25')
ax=fig.add_axes([.045,.235,.49,.635]);setup(ax,'PLAN  /  retained truck and rejected outboard extent')
edges(ax,(0,1));ax.set_xlim(-1150,1150);ax.set_ylim(-1430,1430)
for xc in[-600,600]:
 for s in[-1,1]:
  y=200 if s>0 else-400;ax.add_patch(Rectangle((xc-210,y),420,200,facecolor='#329bb8',edgecolor='#12738c',alpha=.23,lw=1.2))
  y=1080 if s>0 else-1290;ax.add_patch(Rectangle((xc-210,y),420,210,facecolor='#dd6a44',edgecolor='#b14e31',alpha=.15,lw=1.1,ls='--'))
  for end in[-1,1]:
   xx=xc+end*320;ax.add_patch(Rectangle((xx-20,455 if s>0 else-525),40,70,facecolor='#40a879',edgecolor='#20794d',alpha=.6))
for xc in[-245,245]:ax.add_patch(Rectangle((xc-25,-530),50,1060,facecolor='#40a879',edgecolor='#20794d',alpha=.2,lw=.8))
dims(ax,(-600,1360),(600,1360),'1200 axle spacing',off=10)
dims(ax,(1030,-1290),(1030,1290),'2580 rejected drum allocation',off=18,vertical=True,col='#b14e31')
ax.text(-1020,1000,'Old drum reservation\nØ420 ×210 at |Y|1080–1290',color='#a34d31',fontsize=8)
ax.text(-1020,770,'Main body girders\ninner faces |Y|812.8',color='#677983',fontsize=8)
ax.text(-1030,-1150,'Dashed red: superseded outboard proposal.\nExisting main journal/axlebox stays at |Y|620.',fontsize=8,color='#a34d31')
ax2=fig.add_axes([.58,.55,.375,.32]);setup(ax2,'SIDE  /  +X axle, projected at several Y bands');ax2.set_ylabel('Z · mm',fontsize=8)
edges(ax2,(0,2),lambda k:not k.startswith('CTX-MAIN')and(not M[k]['group']=='wheel'or k=='A2R-WHEEL-BLANK'),alpha=.65)
ax2.set_xlim(-100,1090);ax2.set_ylim(0,850)
ax2.add_patch(Circle((600,300),210,facecolor='#329bb8',edgecolor='#12738c',alpha=.23,lw=1.2))
ax2.add_patch(Wedge((600,300),340,155,205,width=40,facecolor='#40a879',edgecolor='#20794d',alpha=.55))
ax2.add_patch(Circle((245,300),25,facecolor='#40a879',edgecolor='#20794d',alpha=.5))
ax2.axhline(650.9,ls='--',lw=.7,color='#b56440');ax2.text(360,660,'Crossmember underside at +35 jounce:650.9',fontsize=7.2,color='#a34d31')
dims(ax2,(610,90),(610,510),'Ø420 disc package PROBE',off=10,vertical=True,col='#12738c')
ax2.annotate('Ø600 unfinished tread\nØ640 flange stock',xy=(600,620),xytext=(790,740),fontsize=8,arrowprops={'arrowstyle':'-','lw':.7})
ax2.annotate('70 wide shoe probe\nR300–340, ±25°',xy=(280,300),xytext=(40,600),fontsize=8,color='#20794d',arrowprops={'arrowstyle':'-','lw':.7,'color':'#20794d'})
ax2.annotate('Ø50 beam probe\nX245; no linkage designed',xy=(245,300),xytext=(20,85),fontsize=8,color='#20794d',arrowprops={'arrowstyle':'-','lw':.7,'color':'#20794d'})
dims(ax2,(80,190),(220,190),'140 to crossbeam',off=7)
ax3=fig.add_axes([.58,.235,.375,.24]);setup(ax3,'AXIAL CORRIDOR  /  +Y wheel');ax3.set_xlabel('Y · mm');ax3.set_ylabel('Z · mm')
edges(ax3,(1,2),lambda k:k.startswith('A2R')and(M[k]['group']=='wheel'or k.endswith('-BOX'))or k.startswith('SF-R-WEB'),alpha=.6)
ax3.set_xlim(160,740);ax3.set_ylim(80,650)
ax3.add_patch(Rectangle((200,90),200,420,facecolor='#329bb8',edgecolor='#12738c',alpha=.23,lw=1.2))
ax3.add_patch(Rectangle((455,280),70,40,facecolor='#40a879',edgecolor='#20794d',alpha=.6))
dims(ax3,(200,555),(400,555),'200 allocated axial width',off=10,col='#12738c')
ax3.annotate('10 to hub faceY410',xy=(405,300),xytext=(205,170),fontsize=8,color='#12738c',arrowprops={'arrowstyle':'-','lw':.7})
ax3.annotate('Shoe band455–525\n5 from flange stock450',xy=(485,300),xytext=(500,100),fontsize=8,color='#20794d',arrowprops={'arrowstyle':'-','lw':.7})
ax3.annotate('Inner frame web538\nwheel rim ends530:8 gap',xy=(538,450),xytext=(565,555),fontsize=8,arrowprops={'arrowstyle':'-','lw':.7})
notes=[
 'BLUE: Ø420 ×200 inboard allocation;144 checks /36 heave–yaw–roll states; no retained-solid penetration; nominal minimum10 mm to wheel hub.',
 'GREEN: tread / beam reservations only. Inner beam atX260 failed on flange stock; X245 provides10 mm nominal flange spacing. Ends remain withinY±530.',
 'Wheel profile, replacement axle, shoe articulation, lateral motion/axle tilt, actuator mount, wear, hoses, torque, strength and stopping/thermal duty remain open.',
 'Caliper / shoe tracking is not established by free space. The200 mm disc allocation does not demonstrate fit of a Twiflex MXA13 (207 mm new-pad overall width).',
 'Sources: C5 checkpoint.brep + parts.json + drawing-edges.json. Shadows of different Y sections are superposed in side view; no new hardware is implied.'
]
for i,t in enumerate(notes):fig.text(.045,.172-i*.025,t,fontsize=8.5,color='#3f515b')
fig.text(.045,.025,'Geometry study only · C51 R0 · PROBES NOT COMPONENTS',fontsize=9,weight='bold',color='#a44c25')
fig.text(.955,.025,'C51–G01',ha='right',fontsize=12,weight='bold',color='#203947')
for ext in['svg','png']:
 fig.savefig(OUT/f'C51-G01.{ext}',dpi=150,facecolor='white')
plt.close(fig)
print(OUT/'C51-G01.png')
