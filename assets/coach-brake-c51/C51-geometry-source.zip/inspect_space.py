"""Read-only C5 checkpoint space probes, not a proposed brake CAD assembly."""
from pathlib import Path
import json,hashlib,math,time
import cadquery as cq
import numpy as np
H=Path(__file__).resolve().parent
B=H.parent/'coach-truck-c5'
parts=json.loads((B/'parts.json').read_text())
shapes=cq.importers.importBrep(str(B/'checkpoint.brep')).val().Solids()
assert len(parts)==len(shapes),(len(parts),len(shapes))
S={p['id']:s for p,s in zip(parts,shapes)};M={p['id']:p for p in parts}
def bb(s):
 b=s.BoundingBox();return np.array([[getattr(b,a+'min'),getattr(b,a+'max')]for a in 'xyz'])
def bboxgap(a,b):return np.linalg.norm(np.maximum(np.maximum(a[:,0]-b[:,1],b[:,0]-a[:,1]),0))
def overlap(a,b):return np.all(np.minimum(a[:,1],b[:,1])-np.maximum(a[:,0],b[:,0])>1e-6)
def obsolete(k):return '-BRAKE-' in k or '-TORQUE-' in k or k.startswith('AXLE')
keep=[k for k in S if not obsolete(k)]
print('READ',len(parts),flush=True)
summary={k:{'group':M[k]['group'],'kinematics':M[k]['metadata']['kinematics'],'bounds_mm':{a:bb(S[k])[i].tolist()for i,a in enumerate('xyz')}}for k in S if M[k]['group']=='context' or k in ['CB-TOP','CB-BOTTOM','CB-WEB1','A2R-WHEEL-BLANK','A2R-BOX','SF-R-WEB1','A2R-TRAY1','A2R-TRAY-1','A2R-COIL1','A2R-COIL-1']}
def state(k,d=0,yaw=0,roll=0):
 s=S[k];kin=M[k]['metadata']['kinematics']
 # For these probes coil shape may remain undeformed: its entire Y band is outside probe corridors.
 if not kin.startswith(('axle','carrier')):s=s.translate((0,0,-d))
 if kin=='body' or M[k]['group']=='context':
  if roll:s=s.rotate((0,0,830.7-d),(1,0,830.7-d),roll)
 elif yaw:s=s.rotate((0,0,0),(0,0,1),yaw)
 return s
# Conservative complete package cylinders inboard of each wheel; includes hub space, so axle excluded.
probes=[]
for ax in [-600,600]:
 for side in [-1,1]:
  y0=200 if side>0 else -400
  probes.append((f'AX{ax}_SIDE{side}',cq.Solid.makeCylinder(210,200,cq.Vector(ax,y0,300),cq.Vector(0,1,0))))
rows=[]
for d in [-60,-40,0,35]:
 for yaw in [-7,0,7]:
  for roll in [-2,0,2]:
   ss={k:state(k,d,yaw,roll)for k in keep};bbs={k:bb(s)for k,s in ss.items()}
   for pid,base in probes:
    q=base.rotate((0,0,0),(0,0,1),yaw)if yaw else base;qb=bb(q);near=None;gap=1e9;hits=[]
    for k,s in ss.items():
     low=bboxgap(qb,bbs[k])
     if overlap(qb,bbs[k]):
      v=q.intersect(s).Volume()
      if v>1e-5:hits.append({'part':k,'volume_mm3':v})
     if low<gap:
      dg=q.distance(s)
      if dg<gap:gap=dg;near=k
    rows.append({'probe':pid,'relative_jounce_mm':d,'yaw_deg':yaw,'body_roll_deg':roll,'minimum_gap_mm':gap,'nearest_part':near,'intersections':hits})
   print('STATE',d,yaw,roll,flush=True)
result={'status':'Read-only nominal space feasibility; no brake architecture selected','runtime':{'python':'primary runtime','cadquery':cq.__version__},'checkpoint':{'parts':len(parts),'sha256':hashlib.sha256((B/'checkpoint.brep').read_bytes()).hexdigest(),'parts_sha256':hashlib.sha256((B/'parts.json').read_bytes()).hexdigest()},'selected_obstacle_bounds':summary,'disc_package_probe':{'definition':'OD420 x axial width200, Y+200..400 and-400..-200 at both axle centres; axle body and obsolete outboard brake hardware excluded because replacement is required','state_count':36,'package_checks':len(rows),'minimum_gap_mm':min(r['minimum_gap_mm']for r in rows),'intersections':[r for r in rows if r['intersections']],'results':rows},'limits':['Probes are temporary envelopes, not a brake component design or OEM fit assertion.','Current wheel is only an unfinished blank; tread/flange profile and actual back-to-back remain open.','Disc caliper suspension tracking, torque reaction, rotor/hub/axle joint, flexible services and maintenance removal are not resolved by clear space.','Tread geometry/contact, suspension/lateral/tilt articulation and wear adjustment need a selected brake architecture.','Combined yaw/roll/vertical samples do not certify a continuous dynamic envelope; no strength or brake capacity is claimed.']}
(H/'space-feasibility.json').write_text(json.dumps(result,indent=2));print('DONE',result['disc_package_probe']['minimum_gap_mm'],len(result['disc_package_probe']['intersections']),flush=True)
