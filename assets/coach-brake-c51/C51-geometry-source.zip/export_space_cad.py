"""Export a small, distinctly named reference/probe assembly; no fabrication parts."""
from pathlib import Path
import gzip, json, hashlib
H=Path(__file__).resolve().parent
exec((H/'refine_tread_space.py').read_text().split('shoes=[]; beams=[]')[0])
OUT=H.parents[1]/'dist/assets/coach-brake-c51'; OUT.mkdir(parents=True,exist_ok=True)
rows=[]
for d in[-60,-40,0,35]:
 ss={k:state(k,d)for k in keep};bbs={k:bb(s)for k,s in ss.items()}
 for xc in[-245,245]:
  q=cq.Solid.makeCylinder(25,1060,cq.Vector(xc,-530,300),cq.Vector(0,1,0))
  rows.append({'x_mm':xc,'Y_mm':[-530,530],'Z_mm':300,'diameter_mm':50,'jounce_mm':d,**probe(q,ss,bbs)})
result={'status':'Corrected straight beam reservation, not a manufactured beam or achieved tracking linkage','rows':rows,'minimum_nonwheel_gap_mm':min(r['minimum_nonwheel_gap_mm']for r in rows),'all_penetrations':[r for r in rows if r['intersections']or r['wheel_penetrations']],'nominal_flange_gap_mm':10,'notes':['Replacing the failedX±260 corridor withX±245 gives355 mm axle-centre separation; flangeR320+beamR25 leaves10 mm.','Probe is held in the axle frame. Its actual support/motion linkage is unspecified.','Beam endpointsY±530 retain8 mm toinner sideframewebs where their projection overlaps.']}
(H/'corrected-beam-space.json').write_text(json.dumps(result,indent=2))
A=cq.Assembly(name='C51_R0_SPACE_STUDY_PROBES_NOT_COMPONENTS')
refids=[k for k in S if M[k]['group']=='wheel' or k.endswith('-BOX')or k in['CB-TOP','CB-BOTTOM','CB-WEB-1','CB-WEB1','SF-L-WEB1','SF-L-WEB2','SF-R-WEB1','SF-R-WEB2','CTX-CROSS-609.6','CTX-CROSS609.6']]
for k in refids:A.add(S[k],name='REFERENCE_C5_'+k,color=cq.Color(.55,.60,.64))
for ax in[-600,600]:
 for side in[-1,1]:
  y0=200 if side>0 else-400
  A.add(cq.Solid.makeCylinder(210,200,cq.Vector(ax,y0,300),cq.Vector(0,1,0)),name=f'PROBE_DISC_ALLOCATION_{ax}_{side}',color=cq.Color(.2,.6,.75,.25))
  A.add(shoe(ax,side,-1 if ax>0 else 1),name=f'PROBE_INNER_TREAD_{ax}_{side}',color=cq.Color(.2,.65,.4,.5))
for xc in[-245,245]:A.add(cq.Solid.makeCylinder(25,1060,cq.Vector(xc,-530,300),cq.Vector(0,1,0)),name=f'PROBE_BEAM_CORRIDOR_{xc}',color=cq.Color(.2,.65,.4,.4))
target=H/'C51-space-study-R0.step';A.save(str(target))
with target.open('rb')as fi,gzip.open(OUT/(target.name+'.gz'),'wb',compresslevel=9)as fo:fo.write(fi.read())
record={'status':'Reference bodies and geometric reservations only; not fabrication CAD','format':'STEP assembly, millimetres','file':target.name+'.gz','reference_part_ids':refids,'probe_count':10,'source_checkpoint_sha256':hashlib.sha256((B/'checkpoint.brep').read_bytes()).hexdigest(),'raw_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'gzip_sha256':hashlib.sha256((OUT/(target.name+'.gz')).read_bytes()).hexdigest(),'notes':['Blue cylinders are allocated space, not rotors/calipers or an OEM fit. Green solids are provisional shoe/beam corridors, not designed components.','Only selected existing reference parts are present. The clearance calculations use the complete retained C5 checkpoint as documented separately.','Old axles and outboard brake hardware are deliberately not present; no replacement axle is designed in this issue.']}
(H/'space-cad-record.json').write_text(json.dumps(record,indent=2));print('EXPORTED',len(refids),result['minimum_nonwheel_gap_mm'],len(result['all_penetrations']),flush=True)
