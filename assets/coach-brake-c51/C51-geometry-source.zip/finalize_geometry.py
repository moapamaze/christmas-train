from pathlib import Path
import json,hashlib,shutil,zipfile,xml.etree.ElementTree as ET
H=Path(__file__).resolve().parent;B=H.parent/'coach-truck-c5';OUT=H.parents[1]/'dist/assets/coach-brake-c51'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
disc=json.loads((H/'space-feasibility.json').read_text());tread=json.loads((H/'tread-space.json').read_text());beam=json.loads((H/'corrected-beam-space.json').read_text())
ET.parse(OUT/'C51-G01.svg')
limits=[
 'This is a geometric reservation comparison, not a brake selection, capacity assessment or fabrication release.',
 'The disc probes are axle-fixed OD420 by200 mm cylinders atX±600,Z300,Y200..400 and−400..−200. Four vertical positions−60,−40,0,+35 mm, three truck yaw values−7,0,+7° and three body roll values−2,0,+2° give36 states and144 package checks.',
 'The tread/beam probes are held with the axles; actual axle-tracking articulation is not modeled. They are checked only at four vertical positions in the unyawed/unrolled local truck frame.',
 'No axle lateral translation, axle roll/tilt, full body resultant tilt cone, continuous motion/tolerance envelope, wheel wear, flexible services, removal/access, thermal growth or brake application motion is included.',
 'All old brake/torque parts and complete existing axles are removed from obstacles. Replacement axle shoulders, rotor attachments and torque reactions are unresolved.',
 'Coils retain their full-load shape translated with the frame rather than being reformed; their entireY band is outside the probes. No spring performance claim is made.',
 'The wheels are unfinished stock: final tread/flange profile and back-to-back are unspecified. Exact radius300 shoe-probe contact is not a released shoe/wheel interface.',
 'The200 mm disc allocation is not a verified Twiflex package. MXA13 new-pad axial width207 mm exceeds it; radial shape, worn envelope, mounting and railway suitability remain unproven.'
]
verification={
 'issue':'C51-R0','status':'Bounded nominal clearance study only; no brake selected','cadquery':'2.7.0','source_part_count':660,
 'disc':{'states':36,'package_checks':144,'minimum_gap_mm':disc['disc_package_probe']['minimum_gap_mm'],'penetrating_checks':len(disc['disc_package_probe']['intersections']),'record':'space-feasibility.json'},
 'tread_shoe':{'checks':32,'radial_mm':[300,340],'angle_deg':[-25,25],'positiveY_mm':[455,525],'minimum_nonwheel_gap_mm':min(r['minimum_nonwheel_gap_mm']for r in tread['shoes']),'penetrating_checks':sum(bool(r['intersections']or r['wheel_penetrations'])for r in tread['shoes']),'intended_contact':'Radius300 inner arc tangent to unfinished wheel tread; zero wheel volume penetration checked.','record':'tread-space.json'},
 'rejected_beams':{'checks':48,'wheel_penetrating_checks':sum(bool(r['wheel_penetrations'])for r in tread['beams']),'other_penetrating_checks':sum(bool(r['intersections'])for r in tread['beams']),'reason':'X±260/±940,Ø50 intersectsØ640 flange stock. Inner beams extending toY±550 or±620 additionally meet sideframe webs in some travel states.','record':'tread-space.json'},
 'corrected_inner_beam':{'checks':8,'X_mm':[-245,245],'Y_mm':[-530,530],'Z_center_mm':300,'diameter_mm':50,'minimum_nonwheel_gap_mm':beam['minimum_nonwheel_gap_mm'],'nominal_flange_gap_mm':10,'penetrating_checks':len(beam['all_penetrations']),'record':'corrected-beam-space.json'},
 'excluded_part_ids':tread['excluded_part_ids'],'limits':limits,
 'source_hashes':{n:sha(B/n)for n in['build_c5.py','checkpoint.brep','parts.json','drawing-edges.json']},
 'drawing_review':{'sheets':['C51-G01.svg','C51-G01.png'],'review':'Parent and geometry agent visually reviewed final PNG: readable projections, dimensions, probe labels and unqualified scope. SVG XML parsed.','artifacts_sha256':{n:sha(OUT/n)for n in['C51-G01.svg','C51-G01.png']}}
}
(H/'verification.json').write_text(json.dumps(verification,indent=2))
record={'issue':'C51-R0','title':'Compact brake research and geometric space comparison','status':'Research / architecture decision; no compact brake selected or approved','completed_scope':['Read actual C5 checkpoint:660 part solids and canonical edge projections.','Compared an inboard disc package allocation with tread-shoe and transverse beam corridors.','Preserved failed beam probes and checked the corrected inner beam corridor.','Produced dimensioned plan, side and axial sheet plus named reference/probe STEP assembly.'],'unfinished':limits,'checks':verification,'mass':{'added_component_mass_kg':None,'reason':'Reservations are space probes, not manufactured components. Existing reference parts are not added mass.'},'drawing_sheets':[{'file':'C51-G01.svg','preview':'C51-G01.png','title':'Compact brake space comparison'}],'cad_files':[{'file':'C51-space-study-R0.step.gz','title':'Reference CAD + probes, not components','record':'space-cad-record.json'}],'reproduction':{'dependency':'../coach-truck-c5 checkpoint.brep,parts.json,drawing-edges.json,build_c5.py','commands':['python inspect_space.py','python refine_tread_space.py','python export_space_cad.py','python draw_comparison.py','python finalize_geometry.py'],'runtime':'Python3.12 / CadQuery2.7 / NumPy / Matplotlib'},'sourcepaths':['cad/coach-brake-c51','cad/coach-truck-c5'],'practical_next_step':'Choose a railway-compatible tread/shoe architecture and finish the wheel profile before designing axle tracking, beams, hangers and actuator mount. Retain inboard disc as an alternative subject to actual caliper shape, width and tracking. A shorter axle requires a new retained-journal/end-retention drawing; none is frozen here.'}
(H/'design-record.json').write_text(json.dumps(record,indent=2))
for n in ['space-feasibility.json','tread-space.json','corrected-beam-space.json','space-cad-record.json','verification.json','design-record.json','research-calculations.json','research-calculations.md']:
 if(H/n).exists():shutil.copy2(H/n,OUT/n)
sourcefiles=[p for p in H.iterdir()if p.suffix in['.py','.json','.md']and p.name!='geometry-source-manifest.json']
with zipfile.ZipFile(OUT/'C51-geometry-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(sourcefiles):z.write(p,p.name)
manifest={'issue':'C51-R0','source_dependencies':verification['source_hashes'],'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(OUT.iterdir())if p.is_file()and p.name!='geometry-source-manifest.json'],'source_files':[{'path':p.name,'sha256':sha(p)}for p in sorted(sourcefiles)]}
(OUT/'geometry-source-manifest.json').write_text(json.dumps(manifest,indent=2));shutil.copy2(OUT/'geometry-source-manifest.json',H/'geometry-source-manifest.json')
print(json.dumps({'disc_min_mm':verification['disc']['minimum_gap_mm'],'tread_min_mm':verification['tread_shoe']['minimum_nonwheel_gap_mm'],'beam_min_mm':verification['corrected_inner_beam']['minimum_nonwheel_gap_mm'],'public_bytes':sum(p.stat().st_size for p in OUT.iterdir()if p.is_file())}))
