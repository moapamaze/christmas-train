# C51 R0 — geometric space study

This issue compares actual C5 retained geometry with named space probes. It does not select a brake, replace the truck, specify a finished wheel or release parts for fabrication.

Run the five scripts listed in design-record.json from this folder with CadQuery2.7, NumPy and Matplotlib. They read the sibling coach-truck-c5 checkpoint and canonical metadata/edges without modifying them. The source package deliberately does not duplicate those existing inputs.

C51-space-study-R0.step.gz contains eighteen named C5 reference solids and ten named PROBE solids. Blue cylinders are allocated space, not OEM calipers or rotors. Green solids represent provisional tread contact and beam corridors. The STEP has millimetre units. Use the verification JSON for the much larger set of retained obstacles used for the clearance calculations.

The first straight beam reservations fail on the unfinished wheel flange stock; those results remain in tread-space.json. Corrected inner corridors atX±245,Ø50,Y±530 pass the eight tested heave cases with8 mm toretained nonwheel solids and10 mm nominal flange spacing. No support or tracking linkage is modeled. The current wheel stock still needs a finished tread/flange profile and back-to-back definition.

The disc-space result does not establish Twiflex fit: the tested200 mm axial allocation is smaller than theMXA13's207 mm new-pad overall width. Source research and conditional brake calculations are separate records. No strength, stopping, thermal, wear or supplier suitability claim follows from the space checks.
