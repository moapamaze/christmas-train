# C5 passenger coach truck — R0

This package contains a preliminary physical development candidate. It is not a fabrication or passenger-operation release. CAD and STEP use millimetres; viewer schema 3 uses inches.

The candidate uses a 1200 mm wheelbase, 600 mm nominal wheel blanks and four guided axleboxes with eight springs. It replaces earlier display dimensions; the wheel/rail running profile and back-to-back remain unselected. The 812.8 mm floor is proposed at each coach's upper design load. Empty views use the current 8040 kg regular and 8585 kg accessible budget sensitivities, not measured tare.

The exact CAD includes the frame members and representative joints, guide wear pads and screws, coil pilots and capture hardware, damper attachment hardware, spherical center support and retained kingpin, body sleeves/bolts/service hatches, compliant sidebearer cartridges and separate yaw shoes. It also includes axle-riding brake carriers, their bearings, articulated torque links and frame anchors. The actual D1 drum/spider/chamber/slack fit and required braking performance remain local open items. The visible hub and carrier blanks do not establish working brakes.

The front accessible mounting accommodates the existing C31 bolster collar. `model-interface-plain.json.gz` and `C5-body-plain-R0.step.gz` contain the plain rear/standard-coach mounting. That variant reflects the checked positive plain track and gussets to the other side and removes collar context; it adds 0.9251 kg of body-attached hardware. The truck is unchanged.

## Drawings and models

- C5-A01: arrangement and dimensions.
- C5-A02: guided axlebox, springs, damper and capture.
- C5-M01: axle, main bearings and outboard brake support.
- C5-B01: center joint, sidebearers, body attachments and service access.

The 2° body-joint limit is a resultant tilt cone. Simultaneous 2° roll plus 2° pitch lies outside it and interferes. The ±7° yaw study is a packaging probe; no operating minimum curve is selected. The 60 mm drop state is abnormal retention, with no tensile spring force credited.

`design-record.json`, `mass-budget.json`, `geometry-verification.json`, `plain-interface-verification.json`, and the independent review/body-interface records define the results and remaining qualifications. Nominal checks found no intersections in four representative suspension positions, 32 combined yaw/heave/cone samples and 64 allocated drum-envelope samples. These are bounded sampled checks, not a complete tolerance or continuous-motion proof.

## Reproduce

Python dependencies: CadQuery, NumPy and CairoSVG. Keep the sibling `c31-foundation/foundation-geometry.json` input alongside this folder, as laid out in the source ZIP. Run these in order:

```sh
python build_c5.py
python postprocess_models.py
python prepare_drawing_edges.py
python draw_c5.py
python verify_c5_final.py
```

The exact frozen BRep checkpoint and part ledger are included for inspection without rebuilding. The builder creates large intermediate edge caches; only the canonical drawing edge file is included here. A rebuilt export may differ in tessellation or STEP text ordering while retaining the same physical shapes.

`expand_c5_model.js` resolves the compact viewer schema. Resolve the full model's coil templates first; for each derived state pass that resolved base to `expandC5Model`. The function clones the base, applies explicit part replacements/removals and transforms, and recomputes bounds. The cached base must remain unchanged. The plain variant uses five direct mesh replacements and eight context removals; other travel states reuse the base and a single coil prototype.
