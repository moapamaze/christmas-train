"""C5 drawing issue generated from canonical CAD edges and parameters.

No drawn part is used as geometry input. Solid outlines are exact CAD edges;
colored occupancy boxes are explicitly identified planning envelopes.
"""
from pathlib import Path
import html
import re
import json
import math
import textwrap

H = Path(__file__).resolve().parent
INK = "#21443e"
GRAY = "#6a7c77"
ACC = "#a34b27"
TEAL = "#167d88"
PALE = "#eaf3f2"
WARM = "#fff1e6"
LIGHT = "#edf0eb"
PAGE_W, PAGE_H = 2000, 1400


def esc(value):
    return html.escape(str(value))


def tx(x, y, value, size=19, weight="normal", color=INK, anchor="start"):
    value=re.sub(r'([a-z])(\d)', r'\1 \2',str(value))
    value=re.sub(r'(\d)(mm|kg|kN|N/mm)',r'\1 \2',value)
    value=re.sub(r'([:;])(?=\S)',r'\1 ',value)
    value=re.sub(r'(?<=[A-Za-z])(Ø|±|≤|≥)',r' \1',value)
    value=value.replace('pertruck','per truck').replace('atY','at Y').replace('SKF22218E','SKF 22218 E').replace('SKF22216E','SKF 22216 E')
    return (f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" '
            f'font-weight="{weight}" fill="{color}" text-anchor="{anchor}">'
            f'{esc(value)}</text>')


def ln(x1, y1, x2, y2, color=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<path d="M{x1:.2f},{y1:.2f}L{x2:.2f},{y2:.2f}" fill="none" '
            f'stroke="{color}" stroke-width="{width}"{attr}/>')


def rect(x, y, w, h, fill="none", stroke=INK, width=1.2, dash=""):
    attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"{attr}/>')


def circle(x, y, r, fill="white", stroke=INK, width=1.2):
    return (f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')


def lines(x, y, rows, size=19, leading=30, color=INK):
    return "".join(tx(x, y + i * leading, row, size, color=color)
                   for i, row in enumerate(rows))


def paragraph(x, y, value, width=65, size=19, leading=29, color=INK):
    return lines(x, y, textwrap.wrap(value, width), size, leading, color)


def title(x, y, value, subtitle=None):
    result = tx(x, y, value, 22, "bold")
    if subtitle:
        result += tx(x, y + 29, subtitle, 17, color=GRAY)
    return result


def dim(a, b, label, vertical=False, label_shift=0, size=18):
    x1, y1 = a
    x2, y2 = b
    result = ln(x1, y1, x2, y2, ACC, 1.4)
    for x, y in (a, b):
        result += ln(x - 5, y - 5, x + 5, y + 5, ACC, 1.4)
    if vertical:
        x, y = (x1 + x2) / 2 - 13 + label_shift, (y1 + y2) / 2
        result += (f'<text transform="translate({x:.2f},{y:.2f}) rotate(-90)" '
                   f'font-size="{size}" fill="{ACC}" text-anchor="middle">'
                   f'{esc(label)}</text>')
    else:
        result += tx((x1 + x2) / 2 + label_shift, (y1 + y2) / 2 - 10,
                     label, size, color=ACC, anchor="middle")
    return result


def leader(target, elbow, end, label, anchor="start", color=ACC, size=18):
    result = ln(*target, *elbow, color) + ln(*elbow, *end, color)
    result += circle(*target, 3, color, color)
    result += tx(end[0], end[1] - 8, label, size, "bold", color, anchor)
    return result


def table(x, y, widths, headers, rows, row_h=35, size=17):
    total = sum(widths)
    result = rect(x, y, total, row_h, INK, INK)
    xx = x
    for width, value in zip(widths, headers):
        result += tx(xx + 12, y + row_h * 0.7, value, size, "bold", "white")
        xx += width
    for i, row in enumerate(rows):
        yy = y + (i + 1) * row_h
        result += rect(x, yy, total, row_h, LIGHT if i % 2 == 0 else "white", "none")
        xx = x
        for width, value in zip(widths, row):
            result += tx(xx + 12, yy + row_h * 0.7, value, size)
            xx += width
    result += rect(x, y, total, (len(rows) + 1) * row_h, "none", "#ccd7d2")
    return result


class Projection:
    """Orthographic projection of an unmodified CAD-edge cache."""
    def __init__(self, edges, ids, axes, box, bounds=None):
        self.edges, self.ids, self.axes = edges, list(ids), axes
        a, b = axes
        pp = [p for pid in self.ids for edge in edges.get(pid, []) for p in edge]
        if not pp:
            raise ValueError(f"No CAD edges for projection: {self.ids}")
        self.bounds = bounds or ((min(p[a] for p in pp), max(p[a] for p in pp)),
                                 (min(p[b] for p in pp), max(p[b] for p in pp)))
        (u0, u1), (v0, v1) = self.bounds
        x, y, w, h = box
        self.scale = min(w / max(u1 - u0, .0001), h / max(v1 - v0, .0001))
        self.ox = x + (w - (u1 - u0) * self.scale) / 2 - u0 * self.scale
        self.oy = y + (h + (v1 - v0) * self.scale) / 2 + v0 * self.scale

    def xy(self, point):
        return self.ox + point[0] * self.scale, self.oy - point[1] * self.scale

    def draw(self, ids=None, color=INK, width=1.1, opacity=1, shift=(0, 0, 0)):
        a, b = self.axes
        result = f'<g opacity="{opacity}">'
        for pid in (self.ids if ids is None else ids):
            for edge in self.edges.get(pid, []):
                points = [self.xy((p[a] + shift[a], p[b] + shift[b])) for p in edge]
                result += ('<polyline points="' + " ".join(f"{u:.2f},{v:.2f}" for u, v in points)
                           + f'" fill="none" stroke="{color}" stroke-width="{width}"/>')
        return result + "</g>"

    def envelope(self, bounds, fill=PALE, stroke=TEAL, dash="8 5", width=1.5):
        (u0, u1), (v0, v1) = bounds
        x, y = self.xy((u0, v1))
        return rect(x, y, (u1 - u0) * self.scale, (v1 - v0) * self.scale,
                    fill, stroke, width, dash)


def sheet(name, heading, body, notes):
    source = ('<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="1400" '
              'viewBox="0 0 2000 1400"><rect width="2000" height="1400" fill="white"/>'
              '<g font-family="DejaVu Sans,Arial,sans-serif">')
    source += tx(50, 45, "PULSIPHER FARMS  /  PASSENGER COACH ENGINEERING", 19, "bold")
    source += tx(50, 91, heading, 31, "bold")
    source += tx(50, 124, "C5 R0  ·  19 OCT 2026  ·  MILLIMETRES UNLESS MARKED  ·  PRELIMINARY — NOT FOR FABRICATION", 17, color=ACC)
    source += ln(50, 143, 1950, 143, INK, 1.5) + body
    source += ln(50, 1190, 1950, 1190, INK, 1.5)
    source += lines(50, 1223, notes, 17, 27)
    source += ln(50, 1347, 1950, 1347, INK, 1.5)
    source += tx(50, 1377, name + "  ·  CAD: build_c5.py / parameters.json / parts.json / drawing-edges.json", 16)
    source += tx(1950, 1377, "Dimensions govern. Do not scale.", 16, anchor="end")
    source += "</g></svg>"
    (H / (name + ".svg")).write_text(source)
    import cairosvg
    cairosvg.svg2png(bytestring=source.encode(), write_to=str(H / (name + ".png")))


E={k:[[[v*25.4 for v in p]for p in edge]for edge in es]for k,es in json.loads((H/'drawing-edges.json').read_text()).items()}
P=json.loads((H/'parameters.json').read_text());M={p['id']:p for p in json.loads((H/'parts.json').read_text())}
G=lambda gs:[k for k,m in M.items()if m['group']in gs and not m['display_only']]
COL={'frame':INK,'wheel':'#456a80','axle':'#456a80','axlebox':'#995c22','bearing':'#995c22','guide':'#995c22','spring':'#ae7615','damper':'#a34b27','pivot':'#72618a','sidebearer':'#72618a','brake-interface':'#a34b27','hardware':GRAY,'context':'#b8c1bd'}
def draw_groups(p,ids=None,opacity=1,width=1):
 ids=ids or p.ids;s=''
 for g in COL:s+=p.draw([k for k in ids if M[k]['group']==g],COL[g],width,opacity)
 return s

def crop(p,body,box,id):
 x,y,w,h=box
 return f'<defs><clipPath id="{id}">{rect(x,y,w,h,"white","none")}</clipPath></defs><g clip-path="url(#{id})">{body}</g>'
def dline(p,a,b,label,vertical=False,ext=()):
 s=dim(p.xy(a),p.xy(b),label,vertical)
 for aa,bb in ext:s+=ln(*p.xy(aa),*p.xy(bb),ACC,.8)
 return s

# A01: whole physical truck with a separately identified brake allocation.
ids=G(['frame','axle','wheel','axlebox','bearing','spring','guide','damper','pivot','sidebearer','brake-interface'])
s=title(60,190,'PLAN — TRUCK DATUM X=0 AT BODY PIVOT','Exact part edges. Amber dashed rectangles reserve unverified OEM brake packages.')
p=Projection(E,ids,(0,1),(150,255,750,800),((-1050,1050),(-1350,1350)))
s+=draw_groups(p,width=.7)
for ax in(-600,600):
 for side in(-1,1):
  y=1080 if side>0 else-1290;s+=p.envelope(((ax-210,ax+210),(y,y+210)),"none",ACC,"7 5",1.7)
s+=dline(p,(-600,-1330),(600,-1330),'1200 wheelbase')
s+=dline(p,(1020,-620),(1020,620),'1240 journal centres',True)
s+=dline(p,(-1010,-1120),(-1010,1120),'2240 brake-carrier centres',True)
s+=tx(525,1120,'Gauge 914.4 is not wheel back-to-back; running profile remains held.',17,color=ACC,anchor='middle')
s+=title(1080,190,'SIDE ELEVATION — FULL DESIGN LOAD','Wheel blanks shown; full-load floor812.8 is a proposed design datum.')
q=Projection(E,[k for k in ids if M[k]['group']not in('brake-interface','pivot','sidebearer')],(0,2),(1110,290,780,350),((-1000,1000),(0,750)))
s+=draw_groups(q,width=.75)
s+=dline(q,(-600,680),(600,680),'1200')
s+=dline(q,(-950,0),(-950,600),'Ø600 nominal tread',True)
s+=title(1080,720,'BOUNDED PRELIMINARY CANDIDATE')
s+=table(1080,750,[390,470],['ITEM','DIMENSION / STATUS'],[
['Coils / journal boxes','8 coils / 4 guided boxes'],['Spring full height / rate','250 / 148.091 N/mm each'],['Primary travel','+35 jounce; −40 regular / −30 access'],['Captured abnormal drop','−60; unloaded coil gap is allowed'],['Body motion study','Yaw ±7°; resultant tilt cone2°'],['Brake reservation / hub','Ø≤420 ×210 axial; OEM mating held'],['Mass development allowance','2000 kg truck / 1400 kg unsprung'],['Status','Custom study; no fabrication release']],row_h=40,size=16)
sheet('C5-A01','PASSENGER TRUCK — GENERAL ARRANGEMENT',s,[
'CAD units mm. Viewer geometry uses inches. Schematic bearing internals and lightweight viewer coils do not change the exact STEP envelopes.',
'Actual D1 drum/spider/chamber/slack mating dimensions are not invented. Allocated brake space is a design constraint, not proof the OEM package fits.',
'Route minimum radius, wheel/rail profile, press fits, brakes, fatigue, dynamic ride and passenger-operation acceptance remain open.',
'Truck body hardware is counted separately from nonbody truck mass. See mass-budget.json and the independent review records.'])

# A02: one journal, guides, captured spring seats and physical damper attachments.
ids=[k for k in M if k.startswith('A2R')and M[k]['group']in('axlebox','guide','spring','damper','hardware')and 'BRAKE'not in k and'TORQUE'not in k]
ids += [k for k in M if k.startswith('SF-R-600')]
s=title(60,190,'ONE JOURNAL — FRAME-RELATIVE TRAVEL','Solid: full-load position. Blue dashed box outlines:35mm jounce and60mm captured drop.')
p=Projection(E,ids,(0,2),(140,285,800,760),((300,950),(110,700)))
s+=draw_groups(p,width=.9)
mov=[k for k in ids if k.endswith('-BOX')or'-TRAY'in k]
s+=p.draw(mov,TEAL,1.4,.5,shift=(0,0,35));s+=p.draw(mov,TEAL,1.4,.5,shift=(0,0,-60))
s+=dline(p,(330,320),(330,570),'250 spring installed height',True)
s+=dline(p,(410,680),(790,680),'380 coil centres')
s+=dline(p,(920,140),(920,200),'60 max capture',True)
s+=dline(p,(920,400),(920,435),'35 bump clearance',True)
s+=title(1060,190,'SPRING + GUIDE CONTRACT')
s+=table(1060,225,[380,480],['FEATURE','PROPOSED DIMENSION'],[
['Coil wire / mean / active','18 / 100 / 7 (9 total)'],['OD / ID / nominal solid','118 / 82 / 162'],['Regular / access free length',f"{P['spring_free_regular_mm']:.3f} / {P['spring_free_accessible_mm']:.3f}"],['Upper and lower pilots','Ø78 ×18; Ø82 spring ID'],['Core / tray passage','Ø60 core / Ø64 tray hole'],['Guide / wear pads','20 plate / 5 bronze;0.5 face gap'],['Tray window','116 wide ×120 high, Z240..360'],['Positive retention','16 keeper +24 tie rods/capture'],['Damper eye centres','205 nominal /170 at35 jounce'],['Damper procurement range','Closed≤165 / open≥270'],['Damping / bump absorption','Supplier curves and force law held']],row_h=44,size=16)
s+=title(1060,790,'REAL HARDWARE, LOCAL ENGINEERING HOLDS')
s+=paragraph(1060,828,'Counterflush guide and cover screws, drilled clevises, pin washers/nuts, coil centering pilots, tube cores and positive drop keepers are modeled. All final fits, locking, spring fatigue and damper selection remain qualification items.',78,18,28)
s+=paragraph(1060,990,'The prismatic journal box follows the frame. The main spherical bearing admits axle inclination; seals, axial float and combined wheelset tilt still require full application review.',78,18,28)
sheet('C5-A02','SUSPENSION — GUIDES, COILS AND CAPTURE',s,[
'Coil free lengths use1400kg unsprung development allowance pertruck; they are custom geometry proposals, not rated catalogue springs.',
'Working rebound retains compression. At60mm abnormal capture the coil can be loose; core and washer retain it, and no tensile spring force is credited.',
'Spring end-form and viewer tessellation are simplified; material, winding, grinding, heat treatment and load/fatigue tests require qualification.',
'Damper cylinder/rod/eyes are a physical procurement envelope with5mm nominal stop reserve; valving and a commercial part are not selected.'])

# M01: axle assembly and axle-riding brake carrier.
ids=['AXLE2']+[k for k in M if k.startswith('A2R')and M[k]['group']in('wheel','axle','axlebox','bearing','brake-interface','hardware')and'TORQUE-LINK'not in k and'TORQUE-FRAME'not in k and'ANCHOR'not in k and'TRAY'not in k and'DAMPER'not in k and'SPRING'not in k and'KEEPER'not in k and'WEAR'not in k]
s=title(60,190,'AXIAL ELEVATION — POSITIVE SIDE','Exact CAD edges, cropped atY400. Box/frame bearings and outboard axle-riding carrier remain separate.')
p=Projection(E,ids,(1,2),(120,270,1750,480),((400,1300),(60,540)))
ax0,ay0=p.xy((400,540));s+=crop(p,draw_groups(p,width=.8),(ax0,ay0,900*p.scale,480*p.scale),'axial')
s+=p.envelope(((1080,1290),(90,510)),"none",ACC,"8 5",1.8)
s+=dline(p,(620,525),(1120,525),'500 carrier overhang from main bearing')
s+=dline(p,(1080,55),(1160,55),'80 carrier bearing centres')
s+=dline(p,(410,150),(550,150),'140 hub blank width')
s+=title(60,835,'FIT AND RETENTION STACK')
s+=table(60,870,[350,540],['ASSEMBLY','DEFINED / HELD'],[
['Main bearing SKF22218E','90×160×40; right locates, left±3 float'],['Main shaft abutment','Ø104; fillet≤2; fits held'],['Outboard bearings2×SKF22216E','80×140×33; second outer±2 float'],['Outboard abutments','RemovableØ96 collar; housing ID129'],['Axle stem / carrier housing','Ø90 to1060; Ø80 seats; housingØ180'],['Service access','Remove hub, covers, nut, bearing stack outward']],row_h=38,size=16)
s+=title(1020,835,'BRAKE INTERFACE: DEFINED PHYSICS / OPEN OEM FIT')
s+=paragraph(1020,877,'Carrier plateØ280 and a200mm torque arm connect through a500mm articulated link to the transverse frame box. Two axle-mounted carrier bearings keep the spider support coaxial with the rotating drum.',85,18,27)
s+=paragraph(1020,1008,'Reserved drum envelope: |Y|1080..1290 and OD≤420. D1 friction ID311.15 / width101.6 are verified; drum OD, pilot, PCD, spider holes, chamber brackets and hub torque joint remain uncut local items.',85,18,27)
sheet('C5-M01','AXLE, BEARINGS AND OUTBOARD BRAKE SUPPORT',s,[
'Drum reservation is not an OEM model. No brake torque, stopping distance or working-brake claim follows from the visible carrier/hub blanks.',
'At6kNm sensitivity the200mm arm produces about30kN link reaction; axle overhang, rotating fatigue, joint notches and braking/twist interaction remain open.',
'Catalogue bearing C/C0 values are not application acceptance. Carrier minimum-load/skidding, lubrication, axial accommodation and heat require review.',
'Wheel blank and axle fits require wheel/rail profile, steel/heat-treatment/NDT, interference, pressing, fatigue and inspection specifications.'])

# B01: actual spherical support, sidebearers and C31 front-collar variant.
ids=G(['pivot','sidebearer'])+[k for k in M if k.startswith('CB-')or k.startswith('BODY-')or k.startswith('KINGPIN')or k.startswith('FLOOR-')or k.startswith('CTX-C45_20')or k=='CTX-BODY-BOLSTER']
s=title(60,190,'TRANSVERSE ELEVATION — FRONT ACCESSIBLE INTERFACE','C31 collar included. Rear/standard-coach track uses the plain, unrelieved mounting variant.')
p=Projection(E,ids,(1,2),(100,260,1100,620),((-650,650),(140,850)))
s+=crop(p,draw_groups(p,width=.85),(100,260,1100,620),'body')
s+=dline(p,(-500,165),(500,165),'1000 sidebearer centres')
s+=dline(p,(625,214.7),(625,482.7),'268 body / frame stack',True)
s+=title(1280,190,'CENTRE JOINT')
s+=table(1280,225,[290,340],['FEATURE','DIMENSION'],[
['Spherical surface / centre','R400 / Z830.7'],['Contact annulus / liner','r90..120 /3'],['Body adapter','280×440×18'],['Sleeves / main screws','26/18 ×304.8 /4×M16'],['Kingpin / passage','Ø50 /Ø110'],['Uplift gap / tilt','8 /2° resultant cone'],['Retention','M50 nut +cross keeper'],['Floor service cover','200×120×8, supported']],row_h=41,size=16)
s+=title(1280,645,'SIDEBEARER CARTRIDGE')
s+=table(1280,680,[290,340],['FEATURE','DIMENSION'],[
['Pad / target stiffness','100×50×50 /1000N/mm'],['Sliding shoe','6 bronze candidate'],['Running gap / reserve','Shim zero /20mm target'],['Upper yaw wear track','280×150×12'],['Front collar pocket','Top relieved6.35'],['Track wing gussets','12 thick /160 root'],['Gusset lower root centres','Y−540 /−473'],['Required qualification','Bulge, friction, wear, fatigue']],row_h=41,size=16)
s+=paragraph(60,960,'The annular spherical bearing carries compression. The separate kingpin, lower washer, M50 nut and cross keeper retain uplift. Four sleeved M16 body bolts and external cheeks connect the18mm adapter to the existing bolster. Floor hatches expose the upper nut pairs.',120,19,29)
s+=paragraph(60,1080,'Two compliant cartridges stabilize roll through bronze sliding shoes. Zero running gap and1000N/mm are development requirements, not a measured rubber law. Body-tilt analysis uses the actual sphere centre and a2° resultant cone.',120,19,29)
sheet('C5-B01','BODY SUPPORT — PIVOT, SIDEBEARERS AND RETENTION',s,[
'2° is a resultant tilt cone, not simultaneous independent±2° roll and±2° pitch. The yaw study is±7°; no operating curve or track twist is accepted.',
'Front accessible left track pocket accommodates C31 collar underside476.35. Rear / ordinary bolster attachment is a distinct plain-track variant.',
'20mm cartridge compression is a procurement target. Equal-biaxial volume expansion is only a clearance probe; actual bulge/friction law must be tested.',
'Body-interface proof includes defined sensitivity cases; contact, prying, local HSS wall behavior, floor foot loading, weld procedure and fatigue remain open.'])
print('FOUR_SHEETS_WRITTEN')
