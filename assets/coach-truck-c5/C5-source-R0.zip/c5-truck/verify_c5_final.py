from pathlib import Path
import cadquery as cq,json,math,itertools,hashlib
H=Path(__file__).parent;parts=json.loads((H/'parts.json').read_text());solids=cq.importers.importBrep(str(H/'checkpoint.brep')).val().Solids()
assert len(parts)==len(solids),(len(parts),len(solids))
M={p['id']:p for p in parts};S=dict(zip(M,solids));K={k:v['metadata']['kinematics']for k,v in M.items()}
# Verify one-to-one checkpoint/metadata order before relying on selected parts.
assert all(s.isValid()for s in solids)
BB={k:s.BoundingBox()for k,s in S.items()}
def beta(d,ax):
 sg=1 if ax>0 else-1
 def f(b):return(ax+200*math.sin(b)-sg*100)**2+(300+d-200*math.cos(b)-100)**2-500**2
 lo,hi=(-.35,0)if ax>0 else(0,.35)
 for _ in range(60):
  mid=(lo+hi)/2
  if f(lo)*f(mid)<=0:hi=mid
  else:lo=mid
 return(lo+hi)/2

def pose(k,d=0,yaw=0,azimuth=None):
 s=S[k];kin=K[k]
 if kin.startswith('axle'):s=s.translate((0,0,d))
 elif kin.startswith('carrier'):
  ax=(-600,600)[int(kin[-1])-1];s=s.rotate((ax,0,300),(ax,1,300),-math.degrees(beta(d,ax))).translate((0,0,d))
 elif kin.startswith('link'):
  ax=(-600,600)[int(kin[-1])-1];x0=100 if ax>0 else-100;b=beta(d,ax);ex=ax+200*math.sin(b);ez=300+d-200*math.cos(b)
  a=-math.atan2(ez-100,ex-x0)if ax>0 else math.atan2(ez-100,x0-ex)
  s=s.rotate((x0,0,100),(x0,1,100),math.degrees(a))
 s=s.translate((0,0,-d))
 if kin=='body'or M[k]['group']=='context':
  if azimuth is not None:
   a=math.radians(azimuth);s=s.rotate((0,0,830.7-d),(math.cos(a),math.sin(a),830.7-d),2)
 elif yaw:s=s.rotate((0,0,0),(0,0,1),yaw)
 return s

def overlaps(s,t):
 a=s.BoundingBox();b=t.BoundingBox()
 if any(getattr(a,c+'max')<=getattr(b,c+'min')+1e-5 or getattr(b,c+'max')<=getattr(a,c+'min')+1e-5 for c in'xyz'):return 0
 return s.intersect(t).Volume()
# Symmetric suspension unit with exact shared frame and one outboard carrier.
ids=[k for k,m in M.items()if (k.startswith('A2R')or k.startswith('SF-R')or k=='AXLE2')and m['group']in('frame','wheel','axle','axlebox','guide','damper','brake-interface')]
internal=[]
for d in(0,35,-40,-60):
 ss={k:pose(k,d)for k in ids};cl=[]
 for i,k in enumerate(ids):
  for j in ids[i+1:]:
   # Same-rigid-assembly welded members are intentional; damper interior and eye connections are supplier targets.
   if K[k]==K[j]or('DAMPER'in k and'DAMPER'in j):continue
   if 'DAMPER-ROD'in k or'DAMPER-ROD'in j:continue
   v=overlaps(ss[k],ss[j])
   if v>.1:cl.append([k,j,round(v,4)])
 internal.append({'relative_box_travel_mm':d,'intersections':cl});print('INTERNAL',d,len(cl),flush=True)
# Complete bodycontext against structural/highmoving components on the2deg resultant cone rim.
# Check yaw extremes at maximum jounce and captured drop; straight yaw is also checked at four cone axes.
bodyids=[k for k in M if M[k]['group']=='context']
truckids=[k for k,m in M.items()if m['group']in('frame','wheel','axlebox','damper','brake-interface')and K[k]!='body'and BB[k].zmax>=430]
compound=[]
for d in(35,-60):
 for yaw in(-7,7):
  ts={k:pose(k,d,yaw)for k in truckids}
  for az in range(0,360,45):
   bs={k:pose(k,d,0,az)for k in bodyids};cl=[]
   for k,t in ts.items():
    for b,s in bs.items():
     v=overlaps(t,s)
     if v>.1:cl.append([k,b,round(v,4)])
   compound.append({'jounce_mm':d,'yaw_deg':yaw,'tilt_resultant_deg':2,'tilt_axis_azimuth_deg':az,'intersections':cl})
   print('CONE',d,yaw,az,len(cl),flush=True)
# Conservative allocated outer drum volumes, not OEM drum geometry.
drum=[]
for yaw in(-7,7):
 for az in range(0,360,45):
  bs={k:pose(k,35,0,az)for k in bodyids}
  for ax,side in itertools.product((-600,600),(-1,1)):
   low=1080 if side>0 else-1290
   s=cq.Solid.makeCylinder(210,210,cq.Vector(ax,low,300),cq.Vector(0,1,0)).rotate((0,0,0),(0,0,1),yaw);cl=[]
   for b,t in bs.items():
    v=overlaps(s,t)
    if v>.1:cl.append([b,round(v,4)])
   drum.append({'axle_x':ax,'side':side,'yaw_deg':yaw,'tilt_axis_azimuth_deg':az,'intersections':cl})
record={'status':'Exact nominal CAD intersection checks; not tolerance, strength or operational acceptance','part_count':len(parts),'valid_part_shapes':len(solids),'suspension_unit_checks':internal,'compound_body_checks':compound,'allocated_brake_envelope_checks':drum,'scope':['One mirrored suspension unit is representative of shared profile geometry; all carrier/link planar closure values are separately recorded.','Body cone checks sample8azimuths at2deg resultant with±7yaw and35jounce/60capture. Intermediates and tolerances are not implied.','Front accessible collar is included; rearbody without thatcollar has noadded obstacle in this localcontext.','Sidebearer compression is constitutive, not treated as undeformed rigid-body collision.','OEMbrake mating fit, chamber/slack/hoses and actualwheelrailprofile remain open.'],'hashes':{n:hashlib.sha256((H/n).read_bytes()).hexdigest()for n in('build_c5.py','parameters.json','parts.json')}}
(H/'geometry-verification.json').write_text(json.dumps(record,indent=2));print('FINAL_GEOMETRY_AUDIT_WRITTEN',flush=True)
