from pathlib import Path
import cadquery as cq,json,numpy as np
h=Path(__file__).parent;m=json.loads((h/'parts.json').read_text());s=cq.importers.importBrep(str(h/'checkpoint.brep')).val().Solids();assert len(m)==len(s)
e=json.loads((h/'drawing-edges.json').read_text())
for p,sh in zip(m,s):
 if not p['metadata']['kinematics'].startswith('coil'):continue
 es=[]
 for edge in sh.Edges():
  n=2 if edge.geomType()=='LINE'else max(33,min(401,int(edge.Length()/5)+1))
  es.append([[round(v/25.4,6)for v in edge.positionAt(float(t)).toTuple()]for t in np.linspace(0,1,n)])
 e[p['id']]=es
(h/'drawing-edges.json').write_text(json.dumps(e,separators=(',',':')))
