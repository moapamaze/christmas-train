"""C5 preliminary custom passenger truck. CAD/STEP millimetres, web schema3 inches.
Designer dimensions are proposals, not supplier drawings or a fabrication release.
"""
from pathlib import Path
import json, math, gzip, copy, itertools, os as c5os
import cadquery as cq
import numpy as np
H=Path(__file__).resolve().parent; MM=25.4
P={'revision':'PF-C5-R0','status':'PRELIMINARY — NOT FOR FABRICATION','units':'mm',
'wheelbase':1200,'nominal_tread_diameter':600,'wheel_flange_blank_diameter':640,'wheel_blank_centres_y':[-480,480],
'wheel_profile_status':'Rough structural wheel blank only; final tread/flange, back-to-back and interference fit not selected.',
'journal_centres_y':[-620,620],'axle_centres_x':[-600,600],'axle_z_full':300,
'full_load_floor_z':812.8,'floor_datum_status':'New proposed full-upper-load datum; not measured or accepted station interface',
'body_bolster_bottom_z':482.7,'body_pivot_spacing':5486.4,'truck_yaw_working_deg':7,
'normal_curve_radius_selected':None,'spring_wire':18,'spring_mean_diameter':100,'spring_active_coils':7,'spring_total_coils':9,
'spring_installed_height_full':250,'spring_lower_seat_z':320,'spring_upper_seat_z':570,'spring_x_offset_from_axle':190,
'spring_rate_each_N_mm':148.091142857,'spring_free_regular_mm':293.043239298564,'spring_free_accessible_mm':283.937938677711,
'working_jounce_mm':35,'working_rebound_regular_mm':40,'working_rebound_accessible_mm':30,'captured_drop_mm':60,
'coil_end_guide_OD':78,'coil_ID':82,'spring_core_OD':60,'sidebearer_y':[-500,500],'sidebearer_gap':0,
'sidebearer_pad_mm':[100,50,50],'sidebearer_nominal_rate_N_mm':1000,'sidebearer_rate_status':'Unvalidated sensitivity; rubber stiffness, damping, strain limits and friction not supplier selected',
'centre_bearing_sphere_radius':400,'centre_bearing_contact_radii':[90,120],'bronze_liner_radial_thickness':3,
'kingpin_diameter':50,'kingpin_clear_hole':110,'kingpin_uplift_gap':8,'joint_resultant_tilt_cone_limit_deg':2,'sphere_center_z':830.7,
'brake_carrier_journal_OD':140,'brake_carrier_bush_OD':180,'brake_carrier_OD':280,'brake_arm_radius':200,'brake_torque_link_length':500,
'brake_carrier_centres_y':[-1120,1120],'brake_reserved_envelope':{'absolute_y':[1080,1290],'OD_max':420,'status':'Design allocation; actual OEM part dimensions must fit this bounded envelope'},'brake_torque_screen_Nm':6000,'brake_OEM_interfaces':{'drum_OD':None,'drum_depth':None,'drum_pilot':None,'drum_PCD':None,'spider_holes':None,'S_cam_chamber_brackets':None,'hub_torque_joint':None},
'bearing':'SKF 22218 E: verified envelope 90×160×40; C331kN,C0 375kN; application/fits held',
'axle_shoulder_OD':104,'bearing_shoulder_fillet_max':2,'float_box_end_clearance_each':3,
'crossbeam_mm':{'width_x':160,'depth_z':200,'plate_t':12,'inside_sideweb_face_span_y':1076,'top_z':414.7},
'damper_target':{'nominal_eye_centres':205,'closed_target':165,'open_target':270,'body_OD':60,'rod_OD':20,'mount_pin':20,'status':'Procurement envelope only, no damping curve or commercial part selected'},
'rail_contact_halfspan_proxy':480,'rail_contact_status':'Calculation proxy; not gauge or accepted wheel/rail contact spacing'}
COL={'frame':'#386653','axle':'#56778b','wheel':'#465965','axlebox':'#b48342','bearing':'#9ba7ae','spring':'#ce9c43','guide':'#976e42','damper':'#b75242','pivot':'#7e719c','sidebearer':'#7b6272','brake-interface':'#b66239','hardware':'#8d989e','context':'#aeb7b1'}
GROUPS=[{'id':k,'label':k.replace('-',' ').title(),'explosion_vector_in':v,'default_visible':k!='context'} for k,v in [('frame',[0,0,0]),('axle',[0,0,-4]),('wheel',[0,6,0]),('axlebox',[2,7,0]),('bearing',[0,12,0]),('spring',[0,0,8]),('guide',[4,4,0]),('damper',[0,5,5]),('pivot',[0,0,8]),('sidebearer',[0,0,7]),('brake-interface',[0,15,0]),('hardware',[0,10,2]),('context',[0,0,12])]]
S={}; META={}; EDGE={}; FAMILIES={}; KIN={}; REPS={}
def box(b): return cq.Solid.makeBox(*(b[a][1]-b[a][0] for a in 'xyz'),cq.Vector(*(b[a][0] for a in 'xyz')))
def cyl(r,l,p,a=(0,0,1)): return cq.Solid.makeCylinder(r,l,cq.Vector(*p),cq.Vector(*a))
def ring(od,di,l,p,a=(0,0,1)):return cyl(od/2,l,p,a).cut(cyl(di/2,l+2,tuple(p[i]-a[i] for i in range(3)),a))
def ec(s): return [[[round(q.x/MM,6),round(q.y/MM,6),round(q.z/MM,6)] for q in [e.positionAt(t) for t in np.linspace(0,1,2 if e.geomType()=='LINE' else 33)]] for e in s.Edges()]
def add(pid,g,s,d=None,material='A36 plate candidate',density=7850,kin='fixed',display=False):
 if not s.isValid(): raise ValueError('Invalid '+pid)
 d=d or {}; fam=d.get('family',pid)
 S[pid]=s;KIN[pid]=kin
 META[pid]={'id':pid,'name':d.get('name',pid.replace('-',' ')),'group':g,'color':COL[g],'opacity':.6 if display else 1,'display_only':display,'metadata':{'family':fam,'definition':d,'material':{'candidate':material},'solid_mass_kg':s.Volume()/1e9*density,'kinematics':kin,'engineering_status':'PRELIMINARY — NOT RELEASED'}}
 FAMILIES.setdefault(fam,{'id':fam,'name':d.get('name',fam),'quantity_per_truck':0,'material':material,'definition':d,'representative':pid})['quantity_per_truck']+=1
 REPS.setdefault(fam,pid)
 return s

def plate(pid,g,b,holes=(),axis='z',d=None,mat='A36 plate candidate',kin='fixed'):
 s=box(b); uv={'x':('y','z'),'y':('x','z'),'z':('x','y')}[axis]; av={'x':(1,0,0),'y':(0,1,0),'z':(0,0,1)}[axis]
 for u,v,dia in holes:
  q={axis:b[axis][0]-1,uv[0]:u,uv[1]:v};s=s.cut(cyl(dia/2,b[axis][1]-b[axis][0]+2,[q[a] for a in 'xyz'],av))
 return add(pid,g,s,{'bounds_mm':b,'holes_mm':list(holes),'hole_axis':axis,**(d or {})},mat,kin=kin)
def poly_xz(points,y,t):return cq.Workplane(cq.Plane(origin=(0,y,0),xDir=(1,0,0),normal=(0,-1,0))).polyline(points).close().extrude(-t).val()
def bolt(pid,point,axis,dia,length,kin='fixed',grade='Class 10.9 candidate'):
 # Nominal smooth shank plus six-sided head. Threads represented by metadata.
 v=cq.Vector(*axis); p=cq.Vector(*point); s=cyl(dia/2,length,point,axis)
 plane=cq.Plane(origin=p-v*(.65*dia),normal=v);head=cq.Workplane(plane).polygon(6,1.73*dia).extrude(.65*dia).val()
 return add(pid,'hardware',s.fuse(head),{'family':f'BOLT-M{dia:g}-{length:g}','diameter_mm':dia,'under_head_mm':length,'thread':'Nominal metric; final pitch/grip/locking/tightening qualification held'},grade,kin=kin)
def flush_bolt(pid,point,axis,dia,length,kin,target):
 #90deg countersunk custom metric screw, outer face flush; exact standard/grip/locking held.
 v=cq.Vector(*axis);p=cq.Vector(*point)
 head=cq.Solid.makeCone(dia,dia/2,dia/2,p,v)
 sh=cyl(dia/2,length-dia/2,(p+v*(dia/2)).toTuple(),axis).fuse(head)
 S[target]=S[target].cut(cq.Solid.makeCone(dia+.3,dia/2,dia/2+.3,p,v))
 add(pid,'hardware',sh,{'family':f'CSK-M{dia:g}-{length:g}','head':'90deg countersunk flush face','diameter_mm':dia,'under_face_mm':length,'status':'Candidate dimensions; thread/locking/driver access qualify'},kin=kin)
def axis_cylinder(r,p1,p2):
 v=cq.Vector(*p2)-cq.Vector(*p1);return cyl(r,v.Length,p1,v.normalized().toTuple())
# Two fabricated drop-centre sideframes, individual webs/caps and actual transverse joints.
profile=[(-950,430),(-950,470),(-865,470),(-865,600),(-350,600),(-200,450),(200,450),(350,600),(865,600),(865,470),(950,470),(950,430),(350,430),(200,200),(-200,200),(-350,430)]
for side in (-1,1):
 yc=side*620; lab='L' if side<0 else 'R'
 for j,yy in enumerate((yc-82,yc+70),1):
  web=poly_xz(profile,yy,12)
  if (side>0 and j==2)or(side<0 and j==1):
   web=web.intersect(poly_xz([(-790,0),(790,0),(790,430),(840,560),(840,610),(-840,610),(-840,560),(-790,430)],yy-1,14))
  if (side>0 and j==1)or(side<0 and j==2):
   for axc in(-600,600):web=web.cut(cyl(108,14,(axc,yy-1,335),(0,1,0)))
  add(f'SF-{lab}-WEB{j}','frame',web,{'family':'SF-WEB','thickness_mm':12,'profile_xz_mm':profile,'inner_web_hub_relief':{'radius':108,'centres_xz':[[-600,335],[600,335]]},'outer_web_end_taper':{'xmax':840,'lower_ramp_from':[790,430],'upper_ramp_to':[840,560]},'role':'Custom welded sideframe web; corner radii, local buckling and fatigue detail still require review'})
 # Central closing plates make a local box around transverse beam load path.
 for z,name in [(200,'BOTTOM'),(438,'TOP')]:
  plate(f'SF-{lab}-CENTRE-{name}','frame',{'x':[-200,200],'y':[yc-70,yc+70],'z':[z,z+12]},d={'family':'SF-CENTRE-CAP'})
 for x in (-600,600):
  for off in (-190,190):
   xx=x+off
   plate(f'SF-{lab}-{x}-{off}-SPRING-CAP','frame',{'x':[xx-70,xx+70],'y':[yc-70,yc+70],'z':[570,586]},[(xx,yc,62)],d={'family':'SPRING-UPPER-PLATE','role':'16mm seat plate tied to both side webs; welds unqualified'})
  # Guide bridge and damper bridge have true passage holes.
  plate(f'SF-{lab}-{x}-GUIDE-BRIDGE','frame',{'x':[x-125.5,x+125.5],'y':[yc-70,yc+70],'z':[490,506]},[(x,yc,66)],d={'family':'GUIDE-BRIDGE'})
  plate(f'SF-{lab}-{x}-DAMPER-BRIDGE','frame',{'x':[x-90,x+90],'y':[yc-70,yc+70],'z':[590,606]},[(x,yc,66)],d={'family':'DAMPER-BRIDGE'})
 # Main crossbeam ends meet inside sideweb faces; no penetrating full-length box.
# Transverse box: four walls and interior diaphragms, centre opening reserved for retained pin.
cbz=214.7; cbt=414.7
plate('CB-TOP','frame',{'x':[-80,80],'y':[-538,538],'z':[cbt-12,cbt]},[(0,0,110)],d={'family':'CB-TOP','role':'12mm top skin; centre bearing load spreads through diaphragms'})
plate('CB-BOTTOM','frame',{'x':[-80,80],'y':[-538,538],'z':[cbz,cbz+12]},[(0,0,110)],d={'family':'CB-BOTTOM'})
for sx in (-1,1):plate(f'CB-WEB{sx}','frame',{'x':[-80,-68] if sx<0 else [68,80],'y':[-538,538],'z':[cbz+12,cbt-12]},d={'family':'CB-WEB'})
for yy in (-250,-90,90,250):plate(f'CB-DIAPHRAGM{yy}','frame',{'x':[-68,68],'y':[yy-6,yy+6],'z':[cbz+12,cbt-12]},d={'family':'CB-DIAPHRAGM'})
# Axles: custom rough turning; final press fits/fatigue transitions remain held.
for ai,ax in enumerate((-600,600),1):
 kin=f'axle{ai}'; s=cyl(50,810,(ax,-405,300),(0,1,0))
 for side in (-1,1):
  def axial_piece(dia,a,b):
   nonlocal_dummy=None
   lo,hi=sorted((side*a,side*b));return cyl(dia/2,hi-lo,(ax,lo,300),(0,1,0))
  for dia,a,b in [(110,405,550),(104,550,600),(90,600,1060),(80,1060,1280)]:s=s.fuse(axial_piece(dia,a,b))
 add(f'AXLE{ai}','axle',s,{'family':'AXLE','body_diameter_mm':100,'wheel_seat_diameter_mm':110,'journal_diameter_mm':90,'shoulder_diameter_mm':104,'bearing_shoulder_radius_max_mm':2,'wheel_fit':None,'journal_fit':None,'brake_hub_torque_joint':None,'role':'Custom stepped axle blank; fatigue, transition fillets, steel/NDT/pressing specification not released'},'Normalized axle steel candidate; grade/toughness held',kin=kin)
 for side in (-1,1):
  lab=f'A{ai}'+('L' if side<0 else 'R'); yc=side*620; wc=side*480
  # Structural wheel blank with rim, hub, web and excess flange stock; not a service profile.
  s=ring(600,500,100,(ax,wc-50,300),(0,1,0)).fuse(ring(200,110,140,(ax,wc-70,300),(0,1,0))).fuse(ring(500,200,25,(ax,wc-12.5,300),(0,1,0)))
  fy=wc-50 if side>0 else wc+30;s=s.fuse(ring(640,600,20,(ax,fy,300),(0,1,0)))
  add(lab+'-WHEEL-BLANK','wheel',s,{'family':'WHEEL-BLANK','nominal_tread_mm':600,'flange_stock_OD_mm':640,'rim_width_mm':100,'hub_width_mm':140,'web_t_mm':25,'bore_blank_mm':110,'running_profile':None,'back_to_back':None,'status':'Structural rough wheel blank. It is not a finished rail wheel or a compatibility claim.'},'Wheel steel grade, heat treatment and NDT held',kin=kin)
  # Bearing cartridge: envelope separated into rings, rolling envelope explicitly non-OEM internal representation.
  for name,od,di in [('INNER',106,90),('ROLLING',148,108),('OUTER',160,149)]:
   add(lab+'-BRG-'+name,'bearing',ring(od,di,40,(ax,yc-20,300),(0,1,0)),{'family':'BRG-'+name,'catalogue':'SKF 22218 E','catalogue_envelope_mm':[90,160,40],'internal_shape':'Schematic ring partition only; actual rollers/cage omitted','C_kN':331,'C0_kN':375},'Bearing steel OEM envelope',kin=kin,display=name=='ROLLING')
  for bn in('INNER','OUTER'):META[lab+'-BRG-'+bn]['metadata']['solid_mass_kg']=1.7
  META[lab+'-BRG-ROLLING']['metadata']['solid_mass_kg']=0
  # Machined box and removable covers. Right bearing locates; left outer ring has 3mm at either end.
  shell=box({'x':[ax-100,ax+100],'y':[yc-55,yc+55],'z':[200,400]}).cut(cyl(80,112,(ax,yc-56,300),(0,1,0)))
  coverholes=[(ax+dx,300+dz,11) for dx,dz in [(-88,-30),(-88,30),(88,-30),(88,30)]]
  carrierholes=[]
  for u,v,dia in coverholes+carrierholes:shell=shell.cut(cyl(dia/2,114,(u,yc-57,v),(0,1,0)))
  add(lab+'-BOX','axlebox',shell,{'family':'AXLEBOX','outer_mm':[200,110,200],'bearing_bore_nominal_mm':160,'fit_interval':None,'locating':side>0,'float_each_end_mm':0 if side>0 else 3,'guide_kinematics':'Upright prismatic box follows frame orientation; spherical bearing permits axle tilt inside box'},'Machined steel casting/forging candidate; material held',kin=kin)
  fl=0 if side>0 else 3
  for end in (-1,1):
   yy=yc-55 if end<0 else yc+20+fl; ll=35-fl
   add(lab+f'-OUTER-ABUT{end}','bearing',ring(160,149,ll,(ax,yy,300),(0,1,0)),{'family':'OUTER-ABUT','housing_abutment_ID_mm':149,'length_mm':ll,'role':'Outer-ring abutment; floating side deliberately has two 3mm end gaps'},kin=kin)
   cy=yc-67 if end<0 else yc+55
   # Static labyrinth openings use actual shaft-side geometry; exact seal selection remains held.
   inner_end=(end*side<0); dia=107 if inner_end else 93
   plate(lab+f'-COVER{end}','axlebox',{'x':[ax-100,ax+100],'y':[cy,cy+12],'z':[200,400]},[(ax,300,dia)]+coverholes+carrierholes,'y',{'family':'BOX-COVER','labyrinth_ID_mm':dia,'seal_status':'Nominal noncontact labyrinth opening; grease/seal/gasket qualification unfinished'},kin=kin)
   for n,(u,v,_) in enumerate(coverholes,1):
    start=(u,cy if end<0 else cy+12,v);axis=(0,1,0) if end<0 else (0,-1,0)
    flush_bolt(lab+f'-COVER{end}-B{n}',start,axis,10,30,kin,lab+f'-COVER{end}')
  # Inner-ring shoulder104 and nut thread90, lock tab are custom dimensions, not SKF locknut catalog geometry.
  ny0,ny1=sorted((side*640,side*660))
  add(lab+'-BEARING-NUT','hardware',ring(125,90,20,(ax,ny0,300),(0,1,0)),{'family':'AXLE-NUT','thread':'M90×2 proposed; exact tolerance and locking method held','OD_mm':125,'thickness_mm':20},kin=kin)
  # Fore/aft spring trays pass through real guide-column travel windows.
  for sg in (-1,1):
   xr=[ax-260,ax-100] if sg<0 else [ax+100,ax+260]
   plate(lab+f'-TRAY{sg}','axlebox',{'x':xr,'y':[yc-55,yc+55],'z':[304,320]},[(ax+sg*190,yc,64)],d={'family':'BOX-SPRING-TRAY','role':'16mm welded cantilever tray; 110mm wide through116mm guide window; local weld/fatigue held'},kin=kin)
   # Guide columns have a window for the tray over -60/+35 travel.
   gx=[ax-125.5,ax-105.5] if sg<0 else [ax+105.5,ax+125.5]
   gs=box({'x':gx,'y':[yc-70,yc+70],'z':[140,490]}).cut(box({'x':[gx[0]-1,gx[1]+1],'y':[yc-58,yc+58],'z':[240,360]}))
   add(lab+f'-GUIDE{sg}','guide',gs,{'family':'GUIDE-COLUMN','thickness_mm':20,'tray_window_mm':[116,120],'tray_window_z_mm':[240,360],'guide_face_clearance_each_mm':.5,'role':'Replaceable bronze strips, prismatic box travel; friction not zero'},kin='fixed')
   px=[ax-105.5,ax-100.5] if sg<0 else [ax+100.5,ax+105.5]
   for zz,hh in [(145,90),(365,120)]:
    plate(lab+f'-WEAR{sg}-{zz}','guide',{'x':px,'y':[yc-54,yc+54],'z':[zz,zz+hh]},[(yc-40,zz+20,9),(yc+40,zz+20,9),(yc-40,zz+hh-20,9),(yc+40,zz+hh-20,9)],'x',{'family':'GUIDE-WEAR','role':'5mm bronze wear plate; countersunk M8 fasteners proposed, exact flush seat must be detailed'},'Bronze candidate')
    for jj,(yy,zzz) in enumerate([(yc-40,zz+20),(yc+40,zz+20),(yc-40,zz+hh-20),(yc+40,zz+hh-20)]):
     start=(ax+sg*100.5,yy,zzz);flush_bolt(lab+f'-WEAR{sg}-{zz}-B{jj}',start,(sg,0,0),8,20,'fixed',lab+f'-WEAR{sg}-{zz}')
   # Four spring guiding/retention parts, both ends centred; rod retains coil after free height.
   sx=ax+sg*190
   add(lab+f'-SPRING-LOWER-PILOT{sg}','spring',ring(78,64,18,(sx,yc,320)),{'family':'COIL-END-PILOT','OD_mm':78,'coil_ID_mm':82,'diametral_clearance_mm':4,'height_mm':18,'role':'Positive lateral spring-end location'},kin=kin)
   add(lab+f'-SPRING-UPPER-PILOT{sg}','spring',ring(78,62,18,(sx,yc,552)),{'family':'COIL-END-PILOT','OD_mm':78,'coil_ID_mm':82,'diametral_clearance_mm':4,'height_mm':18},kin='fixed')
   add(lab+f'-SPRING-CORE{sg}','spring',ring(60,24,326,(sx,yc,244)),{'family':'COIL-CORE','OD_mm':60,'coil_ID_mm':82,'role':'Buckling guide/capture tube; 11mm nominal radial clearance, not a contact-stress proof'},kin='fixed')
   add(lab+f'-SPRING-CAPTURE{sg}','hardware',ring(92,24,12,(sx,yc,232)),{'family':'COIL-CAPTURE','OD_mm':92,'role':'Lower retention washer below tray; springs may unload during abnormal captured droop'},kin='fixed')
   bolt(lab+f'-SPRING-ROD{sg}',(sx,yc,590),(0,0,-1),24,380)
   add(lab+f'-SPRING-TOP-WASHER{sg}','hardware',ring(100,25,4,(sx,yc,586)),{'family':'COIL-TOP-WASHER'})
   add(lab+f'-SPRING-LOCK-NUT{sg}','hardware',ring(40,24,20,(sx,yc,212)),{'family':'COIL-LOCK-NUT','thread':'M24; positive locking/strength held'})
  # Keeper plate plus four actual retaining bolts; service removal keeps wheels/boxes captive.
  plate(lab+'-KEEPER','guide',{'x':[ax-140,ax+140],'y':[yc-70,yc+70],'z':[124,140]},[(ax+dx,yc+dy,14) for dx in (-115.5,115.5) for dy in (-45,45)],d={'family':'AXLEBOX-KEEPER','role':'Positive60mm droop capture; keeper bolt fatigue/locking/inspection not qualified'})
  for n,(dx,dy) in enumerate(itertools.product((-115.5,115.5),(-45,45))):bolt(lab+f'-KEEPER-B{n}',(ax+dx,yc+dy,121),(0,0,1),12,48)
  # Bump pads touch box roof at35mm jounce; their compression/force law is not invented.
  for sg in (-1,1):
   bx=ax+sg*75
   plate(lab+f'-BUMP-PEDESTAL{sg}','frame',{'x':[bx-20,bx+20],'y':[yc-25,yc+25],'z':[450,490]},d={'family':'BUMP-PEDESTAL'})
   add(lab+f'-BUMP-PAD{sg}','guide',box({'x':[bx-20,bx+20],'y':[yc-25,yc+25],'z':[435,450]}),{'family':'BUMP-PAD','contact_jounce_mm':35,'force_curve':None,'role':'Elastomer procurement target; no impact absorption rating'},'Elastomer specification held',1100)
  # Damper eye brackets, bushes and bolts. Damper cylinder is explicitly a target envelope.
  for upper,z in [(False,420),(True,625)]:
   prefix=lab+('-DAMPER-UP' if upper else '-DAMPER-LOW'); kk='fixed' if upper else kin
   for ss in (-1,1):
    yb=[yc-42,yc-30] if ss<0 else [yc+30,yc+42]
    plate(prefix+f'-LUG{ss}','damper',{'x':[ax-40,ax+40],'y':yb,'z':[606,650] if upper else [400,450]},[(ax,z,22)],'y',{'family':'DAMPER-LUG-UP' if upper else 'DAMPER-LUG-LOW','role':'12mm clevis plates; attachment weld sizing held'},kin=kk)
   bolt(prefix+'-PIN',(ax,yc-46,z),(0,1,0),20,110,kk)
   add(prefix+'-PIN-WASHER','hardware',ring(40,22,3,(ax,yc+42,z),(0,1,0)),{'family':'DAMPER-PIN-WASHER'},kin=kk)
   add(prefix+'-PIN-NUT','hardware',ring(34,20,16,(ax,yc+45,z),(0,1,0)),{'family':'DAMPER-PIN-NUT','thread':'M20 candidate; positive locking and fatigue qualification held'},kin=kk)
   for yy in (yc-30,yc+20):add(prefix+f'-BUSH{yy}','damper',ring(30,20.2,10,(ax,yy,z),(0,1,0)),{'family':'DAMPER-SPACER','nominal_running_pin_fit':None},'Bronze candidate',8800,kk)
# Centre spherical compression bearing: true concentric contact surfaces, independent retained pin.
sphere400=cq.Solid.makeSphere(400,cq.Vector(0,0,830.7),angleDegrees1=-90,angleDegrees2=90)
sphere403=cq.Solid.makeSphere(403,cq.Vector(0,0,830.7),angleDegrees1=-90,angleDegrees2=90)
zone=ring(240,180,60,(0,0,414.7))
upper=zone.cut(sphere400).intersect(box({'x':[-121,121],'y':[-121,121],'z':[414.7,464.7]}))
# Lower hemisphere exterior above surface is inside sphere, not outside. Keep lower-cap solid between spherical surface and upper plane.
upper=zone.intersect(sphere400).intersect(box({'x':[-121,121],'y':[-121,121],'z':[414.7,464.7]}))
add('PIVOT-UPPER-SPHERE','pivot',upper,{'family':'PIVOT-UPPER-SPHERE','radius_mm':400,'contact_radii_mm':[90,120],'role':'Custom annular convex compression bearing; pressure/wear/rocking analysis preliminary'},kin='body')
liner=zone.intersect(sphere403).cut(sphere400);add('PIVOT-BRONZE-LINER','pivot',liner,{'family':'PIVOT-LINER','radial_t_mm':3,'role':'Concentric bronze wear liner; lubricated friction and durability unqualified'},'Bronze candidate',8800)
lower=ring(280,180,36,(0,0,414.7)).cut(sphere403);add('PIVOT-LOWER-CUP','pivot',lower,{'family':'PIVOT-LOWER-CUP','role':'Steel concave cup; attaches to CB top skin/diaphragms'})
plate('BODY-ADAPTER','pivot',{'x':[-140,140],'y':[-220,220],'z':[464.7,482.7]},[(0,0,52)]+[(x,y,18) for x in(-18,18) for y in(-160,160)],d={'family':'BODY-ADAPTER','role':'18mm A572Grade50 candidate adapter with actual cheeks/sleeves; local/fatigue qualification held'},mat='A572 Grade50 candidate',kin='body')
# Flanged50mm kingpin lives inside the180mm central bearing void; separate from compression bearing.
kp=cyl(25,304,(0,0,144.7)).fuse(cyl(80,16,(0,0,448.7)))
add('KINGPIN','pivot',kp,{'family':'KINGPIN','shaft_mm':50,'flange_OD_mm':160,'flange_t_mm':16,'role':'Separate uplift retention. Four M12 flange screws into adapter; thread/positive retention strength not released; does not imply centre-bearing uplift capacity'},'4140-type pin steel candidate, properties held',kin='body')
add('KINGPIN-LOWER-WASHER','pivot',ring(150,52,16,(0,0,190.7)),{'family':'KINGPIN-RETAINER','nominal_gap_under_CB_mm':8,'role':'Captures body after8mm uplift; washer and nut joint unqualified'},kin='body')
add('KINGPIN-LOCK-NUT','hardware',ring(85,50,30,(0,0,160.7)),{'family':'KINGPIN-NUT','thread':'M50 candidate; transverseM8secondarykeeper physically captures nut, threadfatigue/preload/locking qualification held'},kin='body')
# Secondary transverse keeper prevents the large retaining nut from passing the pin end.
S['KINGPIN']=S['KINGPIN'].cut(cyl(4.5,52,(-26,0,156.7),(1,0,0)))
bolt('KINGPIN-CROSS-KEEPER',(-35,0,156.7),(1,0,0),8,80,'body')
add('KINGPIN-CROSS-KEEPER-NUT','hardware',ring(14,8,7,(35,0,156.7),(1,0,0)),{'family':'KP-CROSS-KEEPER-NUT','thread':'M8 prevailing torque candidate; actual retention qualification held'},kin='body')
# Zero-gap compliant cartridge and full yaw wear track. Front accessible negative-Y track has collar pocket.
for sy in (-1,1):
 yy=sy*500
 plate(f'SB{sy}-BASE','sidebearer',{'x':[-80,80],'y':[yy-38,yy+38],'z':[408.7,414.7]},d={'family':'SB-BASE','role':'6mm cartridge base welded to crossbeam and end support ribs'})
 add(f'SB{sy}-PAD','sidebearer',box({'x':[-50,50],'y':[yy-25,yy+25],'z':[414.7,464.7]}),{'family':'SB-PAD','gap_mm':0,'target_rate_N_mm':1000,'working_compression_target_mm':20,'rate_status':'Unvalidated procurement target; test compression/bulge/fatigue curve and shim zero contact'},'Elastomer specification held',1100)
 S['CB-TOP']=S['CB-TOP'].cut(box({'x':[-80,80],'y':[yy-38,yy+38],'z':[408.7,415.7]}))
 plate(f'SB{sy}-SLIDING-SHOE','sidebearer',{'x':[-50,50],'y':[yy-30,yy+30],'z':[464.7,470.7]},d={'family':'SB-SLIDING-SHOE','thickness_mm':6,'role':'Replaceable bronze sliding shoe over compliant cartridge; friction/wear/bond or retention design not qualified'},mat='Bronze wear candidate')
 for xx in(-70,70):
  tab=box({'x':[xx-8,xx+8],'y':[yy-10,yy+10],'z':[460.7,466.7]})
  tab=tab.fuse(box({'x':[-70,-50]if xx<0 else[50,70],'y':[yy-10,yy+10],'z':[460.7,466.7]}))
  add(f'SB{sy}-SHOE-TAB{xx}','sidebearer',tab,{'family':'SB-SHOE-TAB','role':'Machined integral shoe tab with4mm recess below slidingplane; positive shoe capture only, notbody uplift. Material/contact qualification held'},material='Bronze candidate',density=8800)
  flush_bolt(f'SB{sy}-SHOE-ROD{xx}',(xx,yy,466.7),(0,0,-1),8,76,'fixed',f'SB{sy}-SHOE-TAB{xx}')
  S[f'SB{sy}-BASE']=S[f'SB{sy}-BASE'].cut(cyl(7,8,(xx,yy,407.7)))
  S['CB-TOP']=S['CB-TOP'].cut(cyl(7,14,(xx,yy,401.7)))
  add(f'SB{sy}-SHOE-CAPTURE-WASHER{xx}','hardware',ring(22,8.5,3,(xx,yy,398.7)),{'family':'SB-CAPTURE-WASHER','role':'Shoe capture after7mm lift; moves with shoe compression in physical cartridge, mesh shows unloaded geometry'})
  add(f'SB{sy}-SHOE-CAPTURE-NUT{xx}','hardware',ring(14,8,7,(xx,yy,391.7)),{'family':'SB-CAPTURE-NUT','thread':'M8 positive locking qualification held'})
 # Low side cheeks retain the pad while allowing upper half to bulge. Actual elastomer fit and bonding held.
 for xx in(-80,76):plate(f'SB{sy}-CARTRIDGE-CHEEK{xx}','sidebearer',{'x':[xx,xx+4],'y':[yy-38,yy+38],'z':[414.7,434.7]},d={'family':'SB-CARTRIDGE-CHEEK','role':'Positive lateral retention below pad working surface; bulge clearance6mm nominal'})
 for zz in(-38,34):plate(f'SB{sy}-CARTRIDGE-END{zz}','sidebearer',{'x':[-76,76],'y':[yy+zz,yy+zz+4],'z':[414.7,434.7]},d={'family':'SB-CARTRIDGE-END'})
 track=box({'x':[-140,140],'y':[yy-75,yy+75],'z':[470.7,482.7]})
 if sy<0:track=track.cut(box({'x':[-60.325,60.325],'y':[-558.8,-457.2],'z':[476.35,483]}))
 add(f'SB{sy}-BODY-TRACK','sidebearer',track,{'family':'SB-BODY-TRACK-FRONT-ACCESS'if sy<0 else'SB-BODY-TRACK','overall_mm':[280,150,12],'underside_z_mm':470.7,'local_collar_pocket_mm':6.35 if sy<0 else 0,'role':'Body-mounted full-yaw wear track. Front access negative-Y pocket bears under C31 collar; supported gussets carry outboard contact.'},kin='body')
 for yyoff in((-40,27)if sy<0 else(-35,35)):
  for sx in(-1,1):
   face=60.325 if sy<0 else 50.8
   pts=[(sx*face,482.7),(sx*140,482.7),(sx*140,497.7),(sx*face,642.7)]
   add(f'SB{sy}-BODY-GUSSET{yyoff}-{sx}','sidebearer',poly_xz(pts,yy+yyoff-6,12),{'family':'SB-BODY-GUSSET','material_candidate':'A572 Grade50','thickness_mm':12,'attachment_face_x_mm':sx*face,'weld_leg_proposed_mm':6,'role':'Track wing to collar face (front-access left) or bolster face; local fatigue/contact proof held'},material='A572 Grade50 candidate',kin='body')
 # Direct upper-track wear inserts/replaceable pad connection require friction/vendor selection, not invented rating.
print('BASE_SOLIDS',len(S),flush=True)
# Additional variable-state parts: real helix/closed-end idealization, dampers and floating brake torque links.
def spring_shape(height):
 path=cq.Wire.makeHelix((height-18)/7,height-18,50)
 helix=cq.Workplane('XZ',origin=(50,0,0)).circle(9).sweep(cq.Workplane(obj=path),isFrenet=True).val().translate((0,0,9))
 end1=cq.Solid.makeTorus(50,9).translate((0,0,9));end2=cq.Solid.makeTorus(50,9).translate((0,0,height-9))
 return helix.fuse(end1).fuse(end2).intersect(box({'x':[-60,60],'y':[-60,60],'z':[0,height]}))
def brake_beta(dz,ax):
 # arm initially down, link500 horizontal; solve stable small-angle branch.
 sg=1 if ax>0 else -1
 def f(b):
  ex=ax+200*math.sin(b);ez=300+dz-200*math.cos(b)
  return (ex-sg*100)**2+(ez-100)**2-500**2
 lo,hi=(-.35,0) if ax>0 else (0,.35)
 for _ in range(60):
  mid=(lo+hi)/2
  if (f(lo)*f(mid))<=0:hi=mid
  else:lo=mid
 return (lo+hi)/2
# Coil full-load geometry is included in the same canonical part set.
coil=spring_shape(250)
for ai,ax in enumerate((-600,600),1):
 for side in(-1,1):
  yc=side*620;lab=f'A{ai}'+('L'if side<0 else'R');kin=f'axle{ai}'
  for sg in(-1,1):
   add(lab+f'-COIL{sg}','spring',coil.translate((ax+sg*190,yc,320)),{'family':'COIL','wire_mm':18,'mean_D_mm':100,'active_turns':7,'total_turns':9,'working_height_mm':250,'free_height_regular_mm':P['spring_free_regular_mm'],'status':'Custom coil proposal; end rings/helix are an idealized CAD end form. Heat treatment, fatigue, buckling, end grinding and load test not released'},'Hot-coiled spring steel candidate; grade/condition to qualify',7850,'coil'+str(ai))
  # Target damper physical envelope, separate body/rod/eyes.
  add(lab+'-DAMPER-BODY','damper',cyl(30,130,(ax,yc,480)),{'family':'DAMPER-BODY','role':'Target body envelope only; no internal valving or commercial damper selected'},'Procurement envelope',1000)
  add(lab+'-DAMPER-ROD','damper',cyl(10,130,(ax,yc,440)),{'family':'DAMPER-ROD','role':'Telescoping rod target, intended internal overlap with body'},'Damper rod target',7850,kin)
  for upper,z in[(True,625),(False,420)]:add(lab+('-DAMPER-EYE-UP'if upper else'-DAMPER-EYE-LOW'),'damper',ring(40,20.2,40,(ax,yc-20,z),(0,1,0)),{'family':'DAMPER-EYE','nominal_eye_bore_mm':20.2,'role':'Target eye/bushing envelope; actual damper mounting remains local hold'},kin='fixed'if upper else kin)
  os=side;ycarr=side*1120
  # Axle-riding outboard carrier follows axle tilt; mainbox is not a rigid long quill.
  lo,hi=sorted((side*1053.5,side*1186.5))
  add(lab+'-BRAKE-CARTRIDGE','brake-interface',ring(180,140,hi-lo,(ax,lo,300),(0,1,0)),{'family':'BRAKE-CARTRIDGE','OD_ID_mm':[180,140],'bearing_centres_abs_y_mm':[1080,1160],'role':'Nonrotating torque carrier, supported coaxially by two axle-mounted SKF22216E bearings. Reaction taken by articulated torque link.'},kin='carrier'+str(ai))
  for n,bc in enumerate((1080,1160)):
   for name,od,di in [('INNER',100,80),('OUTER',140,129)]:
    lo,hi=sorted((side*(bc-16.5),side*(bc+16.5)))
    pid=lab+f'-BRAKE-BRG{n}-{name}'
    add(pid,'bearing',ring(od,di,33,(ax,lo,300),(0,1,0)),{'family':'BRAKE-BRG-'+name,'catalogue':'SKF22216E','catalogue_envelope_mm':[80,140,33],'catalogue_mass_kg':2.1,'inner_abutment_min_mm':91,'outer_abutment_max_mm':129,'role':'Schematic ring geometry; first outer bearing locates, second outer has±2mm axial float; application/fits/lubrication held'},kin=kin if name=='INNER'else'carrier'+str(ai))
    META[pid]['metadata']['solid_mass_kg']=1.05
  for name,a,b in [('IN',1053.5,1063.5),('MID',1096.5,1141.5),('OUT',1178.5,1186.5)]:
   lo,hi=sorted((side*a,side*b));add(lab+'-BRAKE-OUTER-ABUT-'+name,'brake-interface',ring(140,129,hi-lo,(ax,lo,300),(0,1,0)),{'family':'BRAKE-OUTER-ABUT','role':'Separate bearing outer abutment, second bearing has2mm endfloat each direction'},kin='carrier'+str(ai))
  for name,a,b in [('SHOULDER',1060,1063.5),('INNER-SPACER',1096.5,1143.5)]:
   lo,hi=sorted((side*a,side*b));add(lab+'-BRAKE-'+name,'axle',ring(96,80,hi-lo,(ax,lo,300),(0,1,0)),{'family':'BRAKE-INNER-SPACER','OD_ID_mm':[96,80],'role':'Removable≥91mm abutment after mainbearing passes90mmstem; pressure/fit proof held'},kin=kin)
  lo,hi=sorted((side*1176.5,side*1196.5));add(lab+'-BRAKE-INNER-NUT','hardware',ring(104,80,20,(ax,lo,300),(0,1,0)),{'family':'BRAKE-INNER-NUT','thread':'M80×2 candidate; positive locking and bearing preload method held'},kin=kin)
  for end,a,b,di in [('IN',1041.5,1053.5,93),('OUT',1186.5,1198.5,106)]:
   lo,hi=sorted((side*a,side*b));cover=ring(180,di,12,(ax,lo,300),(0,1,0))
   for j in range(6):
    t=j*math.tau/6;xx=ax+80*math.cos(t);zz=300+80*math.sin(t);cover=cover.cut(cyl(4.5,14,(xx,lo-1,zz),(0,1,0)))
    direction=side if end=='IN'else-side;face=side*(a if end=='IN'else b)
    bolt(lab+f'-BRAKE-COVER-{end}-B{j}',(xx,face,zz),(0,direction,0),8,25,'carrier'+str(ai))
   add(lab+'-BRAKE-COVER-'+end,'brake-interface',cover,{'family':'BRAKE-COVER','labyrinth_ID_mm':di,'role':'SixM8 retained service cover; seal/lube and tapped engagement not supplier released'},kin='carrier'+str(ai))
  lo,hi=sorted((side*1201,side*1251));hub=ring(130,80,50,(ax,lo,300),(0,1,0));lo,hi=sorted((side*1251,side*1271));hub=hub.fuse(ring(200,80,20,(ax,lo,300),(0,1,0)))
  add(lab+'-BRAKE-HUB-BLANK','brake-interface',hub,{'family':'BRAKE-HUB-BLANK','pilot':None,'drum_PCD':None,'shaft_torque_joint':None,'role':'Removable outboard custom blank;80mm shaft joint and OEM drum mating geometry require precision design before brake torque can be credited'},kin=kin)
  # Carrier ring and downward arm are one rough plate; no OEM bolt pattern invented.
  cr=ring(280,180,20,(ax,ycarr-10,300),(0,1,0)).fuse(box({'x':[ax-35,ax+35],'y':[ycarr-10,ycarr+10],'z':[135,170]}))
  add(lab+'-TORQUE-CARRIER','brake-interface',cr,{'family':'TORQUE-CARRIER','plate_t_mm':20,'arm_radius_mm':200,'OEM_spider_mating_holes':None,'role':'Floating custom carrier blank. D1 spider/flange interface remains uncut.'},kin='carrier'+str(ai))
  for loc,xx,zz,kk in[('CARRIER',ax,100,'carrier'+str(ai)),('FRAME',100 if ax>0 else-100,100,'fixed')]:
   for sd in(-1,1):
    yb=[ycarr-28,ycarr-16]if sd<0 else[ycarr+16,ycarr+28]
    plate(lab+f'-TORQUE-{loc}-LUG{sd}','brake-interface',{'x':[xx-35,xx+35],'y':yb,'z':[75,135]},[(xx,zz,26)],'y',{'family':'TORQUE-LUG','role':'12mm double-shear clevis; weld/fatigue proof open'},kin=kk)
   bolt(lab+f'-TORQUE-{loc}-PIN',(xx,ycarr-32,zz),(0,1,0),25,90,kk)
   add(lab+f'-TORQUE-{loc}-PIN-WASHER','hardware',ring(44,26,3,(xx,ycarr+28,zz),(0,1,0)),{'family':'TORQUE-PIN-WASHER'},kin=kk)
   add(lab+f'-TORQUE-{loc}-PIN-NUT','hardware',ring(42,25,20,(xx,ycarr+31,zz),(0,1,0)),{'family':'TORQUE-PIN-NUT','thread':'Custom25mmshoulderpin thread/positive locking/fatigue held'},kin=kk)
  # Frame anchor hangs from a transverse sideframe extension, all below J1a girder bottom.
  xx=100 if ax>0 else-100
  plate(lab+'-TORQUE-ANCHOR-WEB','frame',{'x':[xx-35,xx+35],'y':[ycarr-8,ycarr+8],'z':[135,200]},d={'family':'TORQUE-ANCHOR','role':'Frame torque reaction bracket; attachment box/gussets below frame need local proof'})
  # Closed transverse extension from outer sideweb to outboard torque anchor.
  ya,yb=sorted((side*702,ycarr));bb={'x':[xx-60,xx+60],'y':[ya,yb],'z':[200,360]}
  tube=box(bb).cut(box({'x':[xx-48,xx+48],'y':[ya-1,yb+1],'z':[212,348]}))
  add(lab+'-TORQUE-ANCHOR-TIE','frame',tube,{'family':'TORQUE-ANCHOR-TIE','section_mm':[120,160,12],'span_mm':418,'role':'Closed transverse box from sideframe to outboard link anchor; weld/local torsion/fatigue proof held'})
  x0=100 if ax>0 else-100
  rod=axis_cylinder(15,(x0,ycarr,100),(ax,ycarr,100))
  for xx in(x0,ax):
   eye=cyl(30,30,(xx,ycarr-15,100),(0,1,0)).cut(cq.Solid.makeSphere(20,cq.Vector(xx,ycarr,100),angleDegrees1=-90,angleDegrees2=90)).cut(cyl(12.8,32,(xx,ycarr-16,100),(0,1,0)))
   rod=rod.fuse(eye)
  for xx in(x0,ax):rod=rod.cut(cq.Solid.makeSphere(20,cq.Vector(xx,ycarr,100),angleDegrees1=-90,angleDegrees2=90)).cut(cyl(12.8,32,(xx,ycarr-16,100),(0,1,0)))
  add(lab+'-TORQUE-LINK','brake-interface',rod,{'family':'TORQUE-LINK','eye_spacing_mm':500,'rod_dia_mm':30,'eye_ID_mm':35,'role':'Fixed-length link; carrier rotation closes linkage during suspension travel'},'Steel link candidate',7850,'link'+str(ai))
  for loc,xx,kk in[('FRAME',x0,'fixed'),('CARRIER',ax,'carrier'+str(ai))]:
   ball=cq.Solid.makeSphere(20,cq.Vector(xx,ycarr,100),angleDegrees1=-90,angleDegrees2=90).intersect(box({'x':[xx-21,xx+21],'y':[ycarr-12,ycarr+12],'z':[79,121]})).cut(cyl(12.6,26,(xx,ycarr-13,100),(0,1,0)))
   add(lab+f'-TORQUE-BALL-{loc}','brake-interface',ball,{'family':'TORQUE-SPHERICAL-EYE','sphere_OD_mm':40,'pin_bore_mm':25.2,'role':'Custom spherical articulation envelope, procurement/load/fretting qualification held'},'Spherical bearing steel candidate',7850,kk)
print('FULL_SOLIDS',len(S),flush=True)
# Retained J1a local context around one pivot, with correct bottom elevation and girder offsets.
for yy in(-863.6,863.6):
 b={'x':[-1400,1400],'y':[yy-50.8,yy+50.8],'z':[482.7,787.5]};inner={'x':[-1401,1401],'y':[yy-44.45,yy+44.45],'z':[489.05,781.15]}
 add(f'CTX-MAIN-{yy}','context',box(b).cut(box(inner)),{'family':'CTX-MAIN','role':'J1a HSS12×4×1/4 context; not added truck mass'},kin='body',display=True)
b={'x':[-50.8,50.8],'y':[-812.8,812.8],'z':[482.7,787.5]};inn={'x':[-44.45,44.45],'y':[-813,813],'z':[489.05,781.15]}
add('CTX-BODY-BOLSTER','context',box(b).cut(box(inn)),{'family':'CTX-BOLSTER','role':'J1a retained bolster, holes/doublers for new interface are not yet incorporated'},kin='body',display=True)
for x in(-609.6,609.6):
 b={'x':[x-25.4,x+25.4],'y':[-812.8,812.8],'z':[685.9,787.5]};inn={'x':[x-22.225,x+22.225],'y':[-813,813],'z':[689.075,784.325]}
 add(f'CTX-CROSS{x}','context',box(b).cut(box(inn)),{'family':'CTX-CROSS','role':'Conservative full-width HSS4×2 crossmember envelope; exact segment joints from J1a need final transform audit'},kin='body',display=True)
# Accessible-front C31 collars, expressed in truck-local coordinates from canonical foundation geometry.
cf=H.parent/'c31-foundation/foundation-geometry.json'
if cf.exists():
 for c in json.loads(cf.read_text())['collars']:
  if c['center_x']!=45:continue
  for p in c['parts']:
   bb={a:[v*25.4-(1143 if a=='x'else 0)for v in p['bounds_in'][a]]for a in'xyz'}
   add('CTX-'+p['id'],'context',box(bb),{'family':'CTX-C31-COLLAR','source':'C31-FND-R1','role':'Actual front accessible collar context; omitted at rear and standard-coach interfaces'},kin='body',display=True)
# Four through-sleeves make the body adapter connection physically explicit. The surrounding HSS joint is not capacity released.
for n,(xx,yy)in enumerate(itertools.product((-18,18),(-160,160))):
 cut=cyl(14,306.8,(xx,yy,481.7))
 S['CTX-BODY-BOLSTER']=S['CTX-BODY-BOLSTER'].cut(cut)
 for face,az in[(482.7,1),(787.5,-1)]:
  cone=cq.Solid.makeCone(17,14,3,cq.Vector(xx,yy,face),cq.Vector(0,0,az))
  S['CTX-BODY-BOLSTER']=S['CTX-BODY-BOLSTER'].cut(cone)
  weld=cone.cut(cyl(13,5,(xx,yy,face-az),(0,0,az)))
  add(f'BODY-SLEEVE-PJP{n}-{face}','pivot',weld,{'family':'BODY-SLEEVE-PJP','surface_diameter_mm':34,'root_hole_mm':28,'depth_mm':3,'angle_deg':45,'credited_effective_throat_mm':2.121,'rootgap_radial_mm':1,'role':'Custom annular PJP preparation and flush fill; actual penetration/WPS/inspection held. Flush machine before nut and adapter contact.'},'Weld metal candidate',kin='body')
 add(f'BODY-BOLT-SLEEVE{n}','pivot',ring(26,18,304.8,(xx,yy,482.7)),{'family':'BODY-BOLT-SLEEVE','OD_ID_mm':[26,18],'length_mm':304.8,'role':'Crush sleeve through J1a bolster; weld/hole/local wall proof held'},kin='body')
 bolt(f'BODY-BOLT{n}',(xx,yy,461.7),(0,0,1),16,345,'body',grade='ISO898-1 Class8.8 candidate')
 add(f'BODY-WASHER{n}','hardware',ring(34,18,3,(xx,yy,461.7)),{'family':'BODY-WASHER'},kin='body')
 add(f'BODY-NUT{n}','hardware',ring(34.5,16,16,(xx,yy,787.5)),{'family':'BODY-NUT','thread':'M16×2 STANLEYSpiralockM16200M; height15.3..16/AF24/flange34.5 catalog; actual coated torque-tension qualification held'},kin='body')
for sx in(-1,1):
 xx=50.8 if sx>0 else-60.8
 plate(f'BODY-CHEEK{sx}','pivot',{'x':[xx,xx+10],'y':[-220,220],'z':[482.7,582.7]},d={'family':'BODY-CHEEK','thickness_mm':10,'weld_leg_mm':6,'role':'External adapter support cheek with6mm base/end welds; no credit as replacement for truck/body global proof'},kin='body')
 # Exposed basefillet on outside edge of each cheek, alongY.
 outer=60.8*sx;pts=[(outer,482.7),(outer+6*sx,482.7),(outer,488.7)]
 add(f'BODY-CHEEK-WELD{sx}','pivot',poly_xz(pts,-220,440),{'family':'BODY-CHEEK-WELD','leg_mm':6,'length_mm':440,'role':'Proposed structural fillet; qualified WPS and fatigue required'},kin='body')
# Two supported flush floor access covers, one per sleeve-bolt pair. Local foot-load proof is held.
for yc in(-160,160):
 bb={'x':[-100,100],'y':[yc-60,yc+60],'z':[787.5,793.5]}
 base=box(bb).cut(box({'x':[-45,45],'y':[yc-30,yc+30],'z':[786.5,794.5]}))
 add(f'FLOOR-ACCESS-BASE{yc}','pivot',base,{'family':'FLOOR-ACCESS-BASE','opening_mm':[90,60],'role':'6mm A572Gr50 candidate base;3mm fillets to actual HSS topflat zones, local floor proof held'},'A572 Grade50 candidate',kin='body')
 stand=box({'x':[-100,100],'y':[yc-60,yc+60],'z':[793.5,804.8]}).cut(box({'x':[-84,84],'y':[yc-44,yc+44],'z':[792.5,805.8]}))
 add(f'FLOOR-ACCESS-RING{yc}','pivot',stand,{'family':'FLOOR-ACCESS-RING','height_mm':11.3,'role':'Continuous16mm-wide support ring;4mm fillets to base, through-tapped M6 holes, floorproof held'},'A572 Grade50 candidate',kin='body')
 cover=box({'x':[-100,100],'y':[yc-60,yc+60],'z':[804.8,812.8]})
 for xx in(-18,18):cover=cover.cut(cyl(11,4.5,(xx,yc,804.8)))
 pid=f'FLOOR-ACCESS-COVER{yc}'
 add(pid,'pivot',cover,{'family':'FLOOR-ACCESS-COVER','thickness_mm':8,'underside_pockets_mm':[22,4.5],'pocket_residual_mm':3.5,'bolt_tip_gap_mm':2.6,'role':'Flush removable cover, actual floorproof/finish/locking qualification held'},'A572 Grade50 candidate',kin='body')
 for n,(xx,yy)in enumerate(itertools.product((-85,85),(yc-45,yc+45))):
  S[pid]=S[pid].cut(cyl(3.3,10,(xx,yy,803.8)))
  S[f'FLOOR-ACCESS-RING{yc}']=S[f'FLOOR-ACCESS-RING{yc}'].cut(cyl(2.5,11.3,(xx,yy,793.5)))
  flush_bolt(f'FLOOR-ACCESS-SCREW{yc}-{n}',(xx,yy,812.8),(0,0,-1),6,16,'body',pid)
# Kingpin flange is bolted into a machined/tapped adapter, independent of compression annulus.
for n,(xx,yy)in enumerate(itertools.product((-45,45),(-45,45))):
 S['KINGPIN']=S['KINGPIN'].cut(cyl(7,18,(xx,yy,447.7)))
 S['BODY-ADAPTER']=S['BODY-ADAPTER'].cut(cyl(5.1,18,(xx,yy,464.7)))
 bolt(f'KINGPIN-FLANGE-B{n}',(xx,yy,444.2),(0,0,1),12,35,'body',grade='ISO898-1 Class8.8 candidate')
 add(f'KINGPIN-FLANGE-WASHER{n}','hardware',ring(26,13,2.5,(xx,yy,444.2)),{'family':'KP-FLANGE-WASHER'},kin='body')
lock=ring(150,52,2,(0,0,446.7))
for xx,yy in itertools.product((-45,45),(-45,45)):lock=lock.cut(cyl(7,4,(xx,yy,445.7)))
add('KINGPIN-TAB-PLATE','hardware',lock,{'family':'KP-TAB-LOCK','OD_ID_t_mm':[150,52,2],'role':'Common bend-tab plate; tab bend geometry and torque qualification held'},kin='body')
# Annular6mm triangular fillet around upper convex insert to adapter.
wf=cq.Workplane('XZ').polyline([(120,464.7),(126,464.7),(120,458.7)]).close().revolve(360,(0,0),(0,1)).val()
add('PIVOT-UPPER-WELD','pivot',wf,{'family':'PIVOT-UPPER-WELD','leg_mm':6,'radius_mm':120,'role':'Continuous proposed annular fillet; WPS/fatigue/contact proof held'},kin='body')
# Explicit representative6mm fillets at crossbeam-to-sideweb joints; fatigue detail and WPS remain engineering gates.
for side in(-1,1):
 for sx in(-1,1):
  # Triangular fillet at the outside of the crossbeam vertical web, extruded vertically.
  xx=sx*80;yy=side*538
  tri=[(xx,yy),(xx+sx*6,yy),(xx,yy-side*6)]
  sh=cq.Workplane('XY',origin=(0,0,226.7)).polyline(tri).close().extrude(176).val()
  add(f'CB-JOINT-WELD-{side}-{sx}','frame',sh,{'family':'CB-JOINT-WELD','leg_mm':6,'length_mm':176,'role':'Proposed double-side fillet load path at transverse-box/inner-sideweb joint; actual fatigue/WPS/inspection not released'},'Weld metal candidate',7850)
# Parameter/source and mass data, one physical part record each.
def writej(name,data): (H/name).write_text(json.dumps(data,indent=2))
def coil_view_mesh(height,sx,yc,z0):
 # Wire circular cross-section18mm;7active helical turns plus2closed end rings.
 # Lightweight viewer tessellation only. Exact CAD uses its analytic swept solid.
 vv=[];ff=[]
 def tube(path,normal):
  start=len(vv);n=len(path)
  for j,(x,y,z)in enumerate(path):
   tangent=np.array(path[min(j+1,n-1)])-np.array(path[max(0,j-1)])
   tangent=tangent/np.linalg.norm(tangent);u=np.array(normal[j]);u=u-tangent*np.dot(u,tangent);u=u/np.linalg.norm(u);w=np.cross(tangent,u)
   for k in range(10):
    q=np.array([x,y,z])+9*(math.cos(k*math.tau/10)*u+math.sin(k*math.tau/10)*w)
    vv.append([q[0]+sx,q[1]+yc,q[2]+z0])
  for j in range(n-1):
   for k in range(10):
    a=start+j*10+k;b=start+j*10+(k+1)%10;c=a+10;d=b+10;ff.extend([[a,b,c],[b,d,c]])
 steps=224;pp=[];nn=[]
 for j in range(steps+1):
  t=j/steps*math.tau*7;pp.append([50*math.cos(t),50*math.sin(t),9+(height-18)*j/steps]);nn.append([math.cos(t),math.sin(t),0])
 tube(pp,nn)
 for zz in(9,height-9):
  pp=[];nn=[]
  for j in range(49):
   t=j/48*math.tau;pp.append([50*math.cos(t),50*math.sin(t),zz]);nn.append([math.cos(t),math.sin(t),0])
  tube(pp,nn)
 return vv,ff
VIEW_STATE=(0,0,0)
def mesh(pid,s):
 p=copy.deepcopy(META[pid]);bb=s.BoundingBox()
 if KIN[pid].startswith('coil'):
  d,yaw,roll=VIEW_STATE;orig=S[pid].BoundingBox();sx=(orig.xmin+orig.xmax)/2;yc=(orig.ymin+orig.ymax)/2
  vv,ff=coil_view_mesh(min(250-d,P['spring_free_regular_mm']),sx,yc,320)
  if yaw:
   c=math.cos(math.radians(yaw));sn=math.sin(math.radians(yaw));vv=[[c*x-sn*y,sn*x+c*y,z]for x,y,z in vv]
  pos=[round(v/MM,6)for q in vv for v in q];bounds={a:[min(q[j]for q in vv)/MM,max(q[j]for q in vv)/MM]for j,a in enumerate('xyz')}
  p['metadata']['viewer_geometry']='Compact circular-wire tessellation; exact swept CAD/STEP is authoritative.'
 else:
  vv,ff=s.tessellate(1.2,.22);pos=[round(v/MM,6)for q in vv for v in(q.x,q.y,q.z)];bounds={a:[getattr(bb,a+'min')/MM,getattr(bb,a+'max')/MM]for a in'xyz'}
 p.update({'positions':pos,'indices':[i for tri in ff for i in tri],'bounds_in':bounds});p['centre_in']=[sum(p['bounds_in'][a])/2 for a in'xyz'];p['dimensions_xyz_in']=[p['bounds_in'][a][1]-p['bounds_in'][a][0]for a in'xyz'];return p
physical_mass={k:m for k,m in META.items()if not m['display_only']and m['group']!='context'}
body_mass=sum(m['metadata']['solid_mass_kg']for k,m in physical_mass.items()if KIN[k]=='body')
truck_mass=sum(m['metadata']['solid_mass_kg']for k,m in physical_mass.items()if KIN[k]!='body')
unsprung_mass=sum(m['metadata']['solid_mass_kg']for k,m in physical_mass.items()if KIN[k].startswith(('axle','carrier')))
links_mass=sum(m['metadata']['solid_mass_kg']for k,m in physical_mass.items()if KIN[k].startswith('link'))
LEDGER={'represented_truck_nonbody_kg':truck_mass,'body_attached_hardware_kg':body_mass,'represented_moving_unsprung_kg':unsprung_mass,'links_total_kg':links_mass,'link_unsprung_half_allocation_kg':links_mass/2,'OEM_brake_mass_allowance_total_kg':200,'represented_truck_plus_OEM_allowance_kg':truck_mass+200,'represented_unsprung_plus_half_links_plus_OEM_kg':unsprung_mass+links_mass/2+200,'development_complete_truck_allowance_kg':2000,'development_unsprung_allowance_kg':1400,'status':'CAD mass with assigned candidate densities and catalog bearing replacement; no measured complete-truck tare. Damper internals, final wheel finishing, brake mating joint and fabrication consumables remain uncertain.'}
writej('mass-budget.json',LEDGER)
print('MASS_LEDGER',json.dumps(LEDGER),flush=True)
writej('parameters.json',P);writej('parts.json',list(META.values()));writej('bom.json',list(FAMILIES.values()))
writej('drawing-edges.json',{k:ec(v)for k,v in S.items()})
cq.exporters.export(cq.Compound.makeCompound(list(S.values())),str(H/'checkpoint.brep'))
print('CANONICAL_WRITTEN',flush=True)
if c5os.getenv('C5_GEOMETRY_ONLY'):
 raise SystemExit(0)
# State transform: whole sprung frame/body heaves relative to rail; journal boxes stay at nominal wheelheight.
# Relativebox travel d: positive jounce. Frame displacement is -d; body follows frame.
def state(d=0,yaw=0,roll=0,free=P['spring_free_regular_mm'],coils=True):
 ss={}; cs=(spring_shape(min(250-d,free))if d else coil)if coils else None
 for pid,s in S.items():
  k=KIN[pid];sh=s
  if k.startswith('coil'):
   meta=META[pid]['metadata'];bb=s.BoundingBox();sx=(bb.xmin+bb.xmax)/2;yc=(bb.ymin+bb.ymax)/2
   sh=cs.translate((sx,yc,320+d)) if coils else s
  elif k.startswith('carrier'):
   ai=int(k[-1]);ax=(-600,600)[ai-1];beta=brake_beta(d,ax)
   sh=s.rotate((ax,0,300),(ax,1,300),-math.degrees(beta)).translate((0,0,d))
  elif k.startswith('link'):
   ai=int(k[-1]);ax=(-600,600)[ai-1];beta=brake_beta(d,ax);x0=100 if ax>0 else-100
   # transform complete rigid link about its fixed endpoint, using computed movingeye centre.
   ex=ax+200*math.sin(beta);ez=300+d-200*math.cos(beta);ang=-math.degrees(math.atan2(ez-100,ex-x0))
   if ax<0:ang=math.degrees(math.atan2(ez-100,x0-ex))
   sh=s.rotate((x0,0,100),(x0,1,100),ang)
  elif k.startswith('axle'):sh=s.translate((0,0,d))
  # Reference frame moves -d, leaving wheels/boxes at nominal track height.
  sh=sh.translate((0,0,-d))
  if META[pid]['group']=='context' or k=='body':
   if roll:sh=sh.rotate((0,0,830.7-d),(1,0,830.7-d),roll)
  else:
   if yaw:sh=sh.rotate((0,0,0),(0,0,1),yaw)
  ss[pid]=sh
 return ss
STATES={'full':(0,0,0),'empty':(-21.3560687,0,0),'jounce':(35,0,0),'rebound-working':(-40,0,0),'rebound-captured':(-60,0,0),'interface-yaw':(0,7,0),'empty-accessible':(-9.9951368,0,0),'rebound-accessible':(-30,0,0)}
def transform_matrix(pid,d,yaw,roll):
 def T(x=0,y=0,z=0):
  m=np.eye(4);m[:3,3]=np.array([x,y,z])/MM;return m
 def R(axis,a):
  c=math.cos(a);s=math.sin(a);m=np.eye(4)
  if axis=='x':m[1:3,1:3]=[[c,-s],[s,c]]
  if axis=='y':m[0,0]=c;m[0,2]=s;m[2,0]=-s;m[2,2]=c
  if axis=='z':m[:2,:2]=[[c,-s],[s,c]]
  return m
 k=KIN[pid];m=np.eye(4)
 if k.startswith('coil'):return R('z',math.radians(yaw)).T.flatten().tolist()
 if k.startswith('axle'):m=T(z=d)
 elif k.startswith('carrier'):
  ax=(-600,600)[int(k[-1])-1];m=T(z=d)@T(ax,0,300)@R('y',-brake_beta(d,ax))@T(-ax,0,-300)
 elif k.startswith('link'):
  ax=(-600,600)[int(k[-1])-1];x0=100 if ax>0 else-100;b=brake_beta(d,ax);ex=ax+200*math.sin(b);ez=300+d-200*math.cos(b)
  a=-math.atan2(ez-100,ex-x0)if ax>0 else math.atan2(ez-100,x0-ex)
  m=T(x0,0,100)@R('y',a)@T(-x0,0,-100)
 m=T(z=-d)@m
 if k=='body'or META[pid]['group']=='context':m=T(z=830.7-d)@R('x',math.radians(roll))@T(z=-830.7+d)@m
 else:m=R('z',math.radians(yaw))@m
 return [round(float(x),12)for x in m.T.flatten()]
for name,(d,yaw,roll)in STATES.items():
 free=P['spring_free_accessible_mm']if 'accessible'in name else P['spring_free_regular_mm'];height=min(250-d,free)
 cv,cf=coil_view_mesh(height,0,0,0);template={'positions':[round(v/MM,6)for q in cv for v in q],'indices':[i for t in cf for i in t]}
 coilparts=[]
 for pid in S:
  if not KIN[pid].startswith('coil'):continue
  bb=S[pid].BoundingBox();coilparts.append({'id':pid,'geometry_template':'coil','translation_in':[(bb.xmin+bb.xmax)/2/MM,(bb.ymin+bb.ymax)/2/MM,320/MM]})
 if name=='full':
  VIEW_STATE=(0,0,0);parts=[mesh(pid,sh)for pid,sh in S.items()]
  byid={p['id']:p for p in coilparts}
  for p in parts:
   if p['id']in byid:p.pop('positions');p.pop('indices');p.update(byid[p['id']])
  model={'schemaVersion':3,'units':'inches','title':'C5 passenger truck / full design load','groups':GROUPS,'parts':parts,'geometry_templates':{'coil':template},'notes':['Preliminary custom physical geometry; not fabrication or passenger-operation release.','Bounded OEM brake envelope is allocated space, not an invented complete brake assembly.','Full-load32in floor is a proposed datum; empty and travel states show height changes.']}
 else:
  model={'schemaVersion':3,'units':'inches','base_model':'model-full.json.gz','title':'C5 passenger truck / '+name,'state':{'relative_box_travel_mm':d,'yaw_deg':yaw,'roll_deg':roll,'coil_height_mm':height},'geometry_templates':{'coil':template},'part_overrides':coilparts,'part_transforms':{pid:transform_matrix(pid,d,yaw,roll)for pid in S}}
 with gzip.open(H/f'model-{name}.json.gz','wt')as f:json.dump(model,f,separators=(',',':'))
 if name=='full':writej('drawing-edges-full.json',{k:ec(v)for k,v in S.items()})
 if name=='interface-yaw':
  ss=state(d,yaw,roll,coils=False);writej('drawing-edges-interface-yaw.json',{k:ec(v)for k,v in ss.items()})
 print('MODEL',name,len(S),flush=True)
# Compressed STEP, only physical truck components, context omitted.
step=H/'C5-passenger-truck-R0.step';cq.exporters.export(cq.Compound.makeCompound([s for k,s in S.items()if META[k]['group']!='context']),str(step))
with step.open('rb')as a,gzip.open(str(step)+'.gz','wb')as b:
 import shutil;shutil.copyfileobj(a,b)
step.unlink()
# Convenient prototype STEP for bearingbox service and frame fabrication review.
for nm,pred in [('C5-frame-R0',lambda k:META[k]['group']=='frame'),('C5-axlebox-R0',lambda k:k.startswith('A2R') and META[k]['group']in('axlebox','bearing','guide','hardware'))]:
 pp=H/(nm+'.step');cq.exporters.export(cq.Compound.makeCompound([s for k,s in S.items()if pred(k)]),str(pp))
 with pp.open('rb')as a,gzip.open(str(pp)+'.gz','wb')as b:
  import shutil;shutil.copyfileobj(a,b)
 pp.unlink()
print('STEP_DONE',flush=True)
# Basic mass and state clearances; exact intersections require deliberate contact classifications.
physical={k:m for k,m in META.items()if m['group']!='context'and not m['display_only']}
unsprung=sum(m['metadata']['solid_mass_kg']for k,m in physical.items()if KIN[k].startswith(('axle','carrier')))
mass={'model_total_kg':sum(m['metadata']['solid_mass_kg']for m in physical.values()),'modeled_unsprung_kg':unsprung,'groups_kg':{g:sum(m['metadata']['solid_mass_kg']for m in physical.values()if m['group']==g)for g in COL},'missing_mass':'D1 drums/shoes/spiders/chambers/slacks, final hub joint, welds/coatings, internal damper and lubrication; do not use CAD total as finished truck tare'}
writej('mass-budget.json',LEDGER)
checks={'part_count':len(S),'solids':sum(len(s.Solids())for s in S.values()),'invalid':[k for k,s in S.items()if not s.isValid()],'brake_link_kinematics':[],'nominal_frame_to_body_yaw':[],'not_claimed':['Structural, fatigue, spring, brake, wheel profile or fabrication acceptance','Collision-free complete OEM brake installation','Validated dynamic wheel unloading or track radius']}
for d in[-60,-40,0,35]:
 for ax in(-600,600):
  b=brake_beta(d,ax);ex=ax+200*math.sin(b);ez=300+d-200*math.cos(b);x0=100 if ax>0 else-100;err=math.hypot(ex-x0,ez-100)-500
  checks['brake_link_kinematics'].append({'box_travel_mm':d,'axle_x':ax,'carrier_angle_deg':math.degrees(b),'link_length_error_mm':err,'link_slope_deg':math.degrees(math.atan2(ez-100,abs(ex-x0)))})
# Exact truck-to-underframe context checks; sidebearer/bodyinterface intentional contacts excluded.
for yaw in[-7,0,7]:
 for roll in[-2,0,2]:
  ss=state(0,yaw,roll,coils=False);coll=[];minD=1e9
  for k,s in ss.items():
   if META[k]['group']in('context','pivot','sidebearer'):continue
   bb=s.BoundingBox()
   if bb.zmax<470:continue
   for c,t in ss.items():
    if META[c]['group']!='context':continue
    tb=t.BoundingBox()
    if any(getattr(bb,a+'max')<getattr(tb,a+'min')or getattr(tb,a+'max')<getattr(bb,a+'min')for a in'xyz'):continue
    vv=s.intersect(t).Volume()
    if vv>1e-4:coll.append({'truck_part':k,'body_part':c,'volume_mm3':vv})
  checks['nominal_frame_to_body_yaw'].append({'yaw_deg':yaw,'body_roll_deg':roll,'intersections':coll})
writej('verification.json',checks)
print('COMPLETE',json.dumps(mass),flush=True)
