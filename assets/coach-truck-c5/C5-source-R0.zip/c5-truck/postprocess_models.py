"""Export metadata correction and a narrow plain-bolster body variant; no prototype CAD changes."""
from pathlib import Path
import json,gzip,copy,math
import cadquery as cq
H=Path(__file__).parent;P=json.loads((H/'parameters.json').read_text())
def read(n):return json.load(gzip.open(H/n,'rt'))
def write(n,d):
 tmp=H/(n+'.tmp')
 with gzip.open(tmp,'wt')as f:json.dump(d,f,separators=(',',':'))
 json.load(gzip.open(tmp,'rt'))
 tmp.replace(H/n)
# Reconcile a candidate-material label; densities and all physical shapes are unchanged.
for name in ('parts.json','bom.json'):
 data=json.loads((H/name).read_text())
 for p in data:
  if name=='parts.json' and p['metadata']['family']=='SB-BODY-GUSSET':p['metadata']['material']['candidate']='A572 Grade50 candidate'
  if name=='bom.json' and p['id']=='SB-BODY-GUSSET':p['material']='A572 Grade50 candidate'
 (H/name).write_text(json.dumps(data,indent=2))
b=read('model-full.json.gz')
for p in b['parts']:
 if p['metadata']['family']=='SB-BODY-GUSSET':p['metadata']['material']['candidate']='A572 Grade50 candidate'
for p in b['parts']:
 if p['metadata']['kinematics'].startswith('coil'):
  p['metadata']['definition']['free_height_accessible_mm']=P['spring_free_accessible_mm'];p['metadata']['definition']['working_height_mm']=250
b['state']={'spring_kit':'both','relative_box_travel_mm':0,'coil_height_mm':250,'full_load_floor_mm':812.8,'datum_status':'Proposed upper-design-load datum'}
write('model-full.json.gz',b)
for name in('empty','empty-accessible','jounce','rebound-working','rebound-accessible','rebound-captured','interface-yaw'):
 f='model-'+name+'.json.gz';d=read(f);d['state']['spring_kit']='accessible'if'accessible'in name else('both'if name in('jounce','interface-yaw')else'regular')
 if name=='empty':d['state'].update({'tare_basis_kg':8040,'tare_basis_status':'Parallel current budget sensitivity; not measured tare','superseded_legacy_tare_kg':7040});d['title']='C5 regular empty / 8040 kg budget sensitivity'
 if name=='empty-accessible':d['state'].update({'tare_basis_kg':8585,'tare_basis_status':'Parallel current budget sensitivity; not measured tare','superseded_legacy_tare_kg':7535});d['title']='C5 accessible empty / 8585 kg budget sensitivity'
 write(f,d)
# Mirror only the verified positive plain track and four gussets. Truck, body center, sleeves and floor covers unchanged.
parts=json.loads((H/'parts.json').read_text());solids=cq.importers.importBrep(str(H/'checkpoint.brep')).val().Solids();assert len(parts)==len(solids)
M={p['id']:p for p in parts};S=dict(zip(M,solids));replacement={'SB-1-BODY-TRACK':'SB1-BODY-TRACK'}
for oldoff,newsrc in[(-40,35),(27,-35)]:
 for sx in(-1,1):replacement[f'SB-1-BODY-GUSSET{oldoff}-{sx}']=f'SB1-BODY-GUSSET{newsrc}-{sx}'
overrides=[];newsh={};delta=0
for target,source in replacement.items():
 sh=S[source].mirror('XZ');assert sh.isValid();newsh[target]=sh
 vv,ff=sh.tessellate(1.2,.22);p=copy.deepcopy(M[target]);p['positions']=[round(v/25.4,6)for q in vv for v in q.toTuple()];p['indices']=[i for tri in ff for i in tri]
 p['metadata']=copy.deepcopy(M[source]['metadata']);p['metadata']['definition'].update({'variant':'Plain bolster, rear accessible or standard coach','source_reflection':source+' reflected across XZ'});p['metadata']['definition']['local_collar_pocket_mm']=0
 if source.endswith('BODY-TRACK'):p['metadata']['definition']['role']='Plain bolster full-yaw wear track, supported by four A572 Grade50 candidate wing gussets.'
 delta+=p['metadata']['solid_mass_kg']-M[target]['metadata']['solid_mass_kg'];overrides.append(p)
removed=[k for k,m in M.items()if m['metadata']['definition'].get('family')=='CTX-C31-COLLAR']
ledger=json.loads((H/'mass-budget.json').read_text())
variant={'schemaVersion':3,'units':'inches','title':'C5 plain bolster / rear or standard-coach interface','base_model':'model-full.json.gz','state':{'spring_kit':'both','coil_height_mm':250,'relative_box_travel_mm':0,'body_variant':'Plain bolster'},'geometry_templates':{},'removed_part_ids':removed,'part_overrides':overrides,'variant_mass':{'prototype_body_hardware_kg':ledger['body_attached_hardware_kg'],'plain_body_hardware_kg':ledger['body_attached_hardware_kg']+delta,'difference_kg':delta,'source':'Exact mirrored plain-track/gusset masses; truck mass unchanged'}}
write('model-interface-plain.json.gz',variant)
body={k:newsh.get(k,s)for k,s in S.items()if M[k]['metadata']['kinematics']=='body'and M[k]['group']!='context'}
f=H/'C5-body-plain-R0.step';cq.exporters.export(cq.Compound.makeCompound(list(body.values())),str(f))
with f.open('rb')as src,gzip.open(str(f)+'.gz','wb')as out:out.write(src.read())
f.unlink()
# Nominal local fit: new parts touch unchanged bolster faces; no positive-volume penetration.
checks=[]
for k,s in newsh.items():checks.append({'part':k,'valid':s.isValid(),'bolster_overlap_mm3':s.intersect(S['CTX-BODY-BOLSTER']).Volume()})
record={'variant':'plain-bolster','body_parts_replaced':replacement,'removed_context_ids':removed,'local_fit_checks':checks,'mass':variant['variant_mass'],'scope':'Reflection of checked positive plain mounting geometry; prototype truck and center joint are unchanged. It removes front collar obstacles. Weld/contact/local HSS proof holds remain.'}
(H/'plain-interface-verification.json').write_text(json.dumps(record,indent=2))
print('POSTPROCESS_COMPLETE',json.dumps(variant['variant_mass']))
