"""Recover/re-export the compact full viewer model atomically from the frozen CAD checkpoint."""
from pathlib import Path
import json,gzip,copy,os
import cadquery as cq
H=Path(__file__).parent;parts=json.loads((H/'parts.json').read_text());shapes=cq.importers.importBrep(str(H/'checkpoint.brep')).val().Solids();assert len(parts)==len(shapes)
y=json.load(gzip.open(H/'model-interface-yaw.json.gz','rt'));over={p['id']:p for p in y['part_overrides']};groups=[{'id':k,'label':k.replace('-',' ').title(),'explosion_vector_in':v,'default_visible':k!='context'}for k,v in [('frame',[0,0,0]),('axle',[0,0,-4]),('wheel',[0,6,0]),('axlebox',[2,7,0]),('bearing',[0,12,0]),('spring',[0,0,8]),('guide',[4,4,0]),('damper',[0,5,5]),('pivot',[0,0,8]),('sidebearer',[0,0,7]),('brake-interface',[0,15,0]),('hardware',[0,10,2]),('context',[0,0,12])]]
for p,s in zip(parts,shapes):
 if p['id']in over:p.update(copy.deepcopy(over[p['id']]));continue
 vv,ff=s.tessellate(1.2,.22);p['positions']=[round(x/25.4,6)for q in vv for x in q.toTuple()];p['indices']=[i for t in ff for i in t]
 bb=s.BoundingBox();p['bounds_in']={a:[getattr(bb,a+'min')/25.4,getattr(bb,a+'max')/25.4]for a in'xyz'};p['centre_in']=[sum(p['bounds_in'][a])/2 for a in'xyz'];p['dimensions_xyz_in']=[p['bounds_in'][a][1]-p['bounds_in'][a][0]for a in'xyz']
m={'schemaVersion':3,'units':'inches','title':'C5 passenger truck / full design load','groups':groups,'parts':parts,'geometry_templates':copy.deepcopy(y['geometry_templates']),'notes':['Preliminary custom physical geometry; not fabrication or passenger-operation release.','Bounded OEM brake envelope is allocated space, not an invented complete brake assembly.','Full-load 32 in floor is a proposed datum; empty and travel states show height changes.']}
f=H/'model-full.json.gz';tmp=f.with_suffix('.tmp')
with gzip.open(tmp,'wt')as out:json.dump(m,out,separators=(',',':'))
assert len(json.load(gzip.open(tmp,'rt'))['parts'])==660
os.replace(tmp,f);print('ATOMIC_BASE_WRITTEN',f.stat().st_size,flush=True)
