/** Pure C5 schema3 extension resolver. Caller loads raw.base_model relative to rawURL first.
 * Do not mutate a cached base model: each result owns new part/position/index arrays.
 */
export function expandC5Model(raw, baseModel=null) {
  const clone=o=>JSON.parse(JSON.stringify(o));
  const model=raw.base_model?clone(baseModel):clone(raw);
  if(raw.base_model && !baseModel)throw new Error('C5 base_model must be loaded first');
  const templates=raw.geometry_templates||{};
  const expand=(p,def)=>{
    const t=templates[def.geometry_template];
    if(!t)throw new Error('Missing C5 geometry template '+def.geometry_template);
    const off=def.translation_in||[0,0,0];
    p.positions=t.positions.map((v,i)=>v+off[i%3]);p.indices=t.indices.slice();
    delete p.geometry_template;delete p.translation_in;
  };
  if(!raw.base_model)for(const p of model.parts)if(p.geometry_template)expand(p,p);
  if(raw.removed_part_ids){const gone=new Set(raw.removed_part_ids);model.parts=model.parts.filter(p=>!gone.has(p.id));}
  const byId=new Map(model.parts.map(p=>[p.id,p]));
  for(const def of raw.part_overrides||[]) {
    const p=byId.get(def.id);if(!p)throw new Error('Missing C5 part '+def.id);
    if(def.geometry_template)expand(p,def);
    else Object.assign(p,clone(def));
  }
  for(const [id,m] of Object.entries(raw.part_transforms||{})) {
    const p=byId.get(id);if(!p)throw new Error('Missing C5 transformed part '+id);
    for(let i=0;i<p.positions.length;i+=3){
      const [x,y,z]=p.positions.slice(i,i+3);
      p.positions[i]=m[0]*x+m[4]*y+m[8]*z+m[12];
      p.positions[i+1]=m[1]*x+m[5]*y+m[9]*z+m[13];
      p.positions[i+2]=m[2]*x+m[6]*y+m[10]*z+m[14];
    }
  }
  for(const p of model.parts){
    const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
    for(let i=0;i<p.positions.length;i++){const a=i%3;lo[a]=Math.min(lo[a],p.positions[i]);hi[a]=Math.max(hi[a],p.positions[i]);}
    p.bounds_in={x:[lo[0],hi[0]],y:[lo[1],hi[1]],z:[lo[2],hi[2]]};
    p.centre_in=lo.map((v,i)=>(v+hi[i])/2);p.dimensions_xyz_in=lo.map((v,i)=>hi[i]-v);
  }
  model.title=raw.title||model.title;model.state=raw.state;
  if(raw.state){for(const p of model.parts){if(p.metadata?.kinematics?.startsWith('coil')){p.metadata.definition.working_height_mm=raw.state.coil_height_mm;p.metadata.definition.spring_kit=raw.state.spring_kit;}}}
  if(raw.variant_mass)model.variant_mass=clone(raw.variant_mass);
  delete model.geometry_templates;delete model.base_model;delete model.part_overrides;delete model.part_transforms;delete model.removed_part_ids;
  return model;
}
