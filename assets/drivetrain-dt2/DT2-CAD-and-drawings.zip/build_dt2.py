from pathlib import Path
import cadquery as cq, json, math, csv, ezdxf
A=Path(__file__).parent
P={'issue':'PF-DT2-R0','units':'mm','truck_centres_global_x':[3300,6000],'axle_offsets_x':[-600,600],'axle_z':500,'wheel_diameter':1000,'wheel_centres_y':[-507.2,507.2],'wheel_rim_width':100,'wheel_hub_width':140,'axle_half_length':840,'frame_side_centres_y':[-730,730],'frame_z':1050,'side_length':2000,'side_hss':[200,100,8],'end_cross_x':[-950,950],'end_hss':[100,100,8],'centre_hss':[200,200,10],'cross_cut_length':1360,'top_plate':[400,400,20],'top_plate_z':1160,'primary_spring_envelope_diameter':140,'primary_spring_envelope_z':[630,935],'spring_pocket_plate':[200,180,15],'status':'Preliminary designer geometry; not for fabrication','profile_status':'Wheel blank only: no accepted tread/flange/back-to-back or press fit','mount_status':'Top plate undrilled. Pivot, sidebearers, guide and torque-link joints not sized.'}
(A/'parameters.json').write_text(json.dumps(P,indent=2))
parts=[]; assembly=cq.Assembly(name='DT2_powered_truck_proposal'); frame=cq.Assembly(name='DT2_frame_proposal')
def add(id,name,shape,material,category='custom'):
 assert shape.isValid(),id
 color={'frame':(.16,.30,.39),'wheel':(.5,.58,.63),'axle':(.65,.70,.73)}.get(category,(.68,.5,.24))
 assembly.add(shape,name=id,color=cq.Color(*color))
 if category=='frame':frame.add(shape,name=id,color=cq.Color(*color))
 verts,tris=shape.tessellate(2,0.15)
 parts.append({'id':id,'name':name,'category':category,'material_proposal':material,'volume_mm3':shape.Volume(),'mass_kg':shape.Volume()*7.85e-6,'vertices':[[v.x,v.y,v.z] for v in verts],'triangles':[list(t) for t in tris]})
 cq.exporters.export(shape,str(A/(id+'.step')))
 return shape
def box(l,w,h,x,y,z):return cq.Workplane('XY').box(l,w,h).val().translate((x,y,z))
def hss_x(l,w,h,t,x,y,z):return box(l,w,h,x,y,z).cut(box(l+2,w-2*t,h-2*t,x,y,z))
def hss_y(l,w,h,t,x,y,z):return box(w,l,h,x,y,z).cut(box(w-2*t,l+2,h-2*t,x,y,z))
def cyl(r,length,x,y,z):return cq.Solid.makeCylinder(r,length,cq.Vector(x,y-length/2,z),cq.Vector(0,1,0))
for i,y in enumerate(P['frame_side_centres_y']):add(f'DT2-F0{i+1}','Side member HSS 200 × 100 × 8, cut 2000',hss_x(2000,100,200,8,0,y,1050),'Structural HSS, 250 MPa minimum yield proposal','frame')
for i,x in enumerate([-950,950]):add(f'DT2-F0{i+3}','End crossmember HSS 100 × 100 × 8, cut 1360',hss_y(1360,100,100,8,x,0,1050),'Structural HSS, 250 MPa minimum yield proposal','frame')
add('DT2-F05','Centre crossmember HSS 200 × 200 × 10, cut 1360',hss_y(1360,200,200,10,0,0,1050),'Structural HSS, 250 MPa minimum yield proposal','frame')
add('DT2-P01','Top bearing interface plate 400 × 400 × 20, undrilled',box(400,400,20,0,0,1160),'Structural plate, 250 MPa minimum yield proposal','frame')
for i,(x,y) in enumerate(( (x,y) for x in [-600,600] for y in [-730,730] )):
 add(f'DT2-P0{i+2}','Spring pocket backing plate 200 × 180 × 15',box(200,180,15,x,y,942.5),'Structural plate, 250 MPa minimum yield proposal','frame')
for k,x in enumerate([-600,600]):
 shaft=cyl(60,1180,x,0,500)
 for sign in [-1,1]:
  # Correct taper grows toward centre; transition 590 to 620 from local centre.
  y0=590 if sign>0 else -620
  r1,r2=(60,50) if sign>0 else (50,60)
  taper=cq.Solid.makeCone(r1,r2,30,cq.Vector(x,y0,500),cq.Vector(0,1,0))
  shaft=shaft.fuse(taper).fuse(cyl(50,220,x,sign*730,500))
 add(f'DT2-A0{k+1}','Axle blank: Ø120 centre, Ø100 ends; fits/fillets pending',shaft,'Axle steel grade / heat treatment unselected','axle')
 for j,y in enumerate([-507.2,507.2]):
  rim=cyl(500,100,x,y,500).cut(cyl(430,102,x,y,500))
  web=cyl(430,25,x,y,500).cut(cyl(110,27,x,y,500))
  hub=cyl(110,140,x,y,500).cut(cyl(60,142,x,y,500))
  wheel=rim.fuse(web).fuse(hub)
  add(f'DT2-W{k*2+j+1:02}','Disc wheel blank Ø1000; rail profile and fit pending',wheel,'Wheel steel grade / manufacture route unselected','wheel')
assembly.save(str(A/'DT2-powered-truck.step'));frame.save(str(A/'DT2-frame.step'))
# Include both trucks in global locomotive datum, preserving a single common shape source.
pair=cq.Assembly(name='DT2_two_truck_arrangement')
for i,x in enumerate(P['truck_centres_global_x']):pair.add(assembly,name=f'truck_{i+1}',loc=cq.Location(cq.Vector(x,0,0)))
pair.save(str(A/'DT2-two-trucks.step'))
(A/'model.json').write_text(json.dumps({'parameters':P,'parts':parts},separators=(',',':')))
with (A/'DT2-parts.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['Part','Description','Qty per truck','Material proposal','Model mass kg','Status'])
 for p in parts:w.writerow([p['id'],p['name'],1,p['material_proposal'],round(p['mass_kg'],3),'Preliminary; joints/fits/profile pending'])
# DXF nominal plate outlines, not released CNC; no unverified holes.
for id,l,w in [('DT2-P01',400,400),('DT2-P02',200,180)]:
 doc=ezdxf.new('R2010');doc.units=4;ms=doc.modelspace();ms.add_lwpolyline([(0,0),(l,0),(l,w),(0,w)],close=True);ms.add_text(id+' PRELIMINARY - OUTLINE ONLY',dxfattribs={'height':8,'insert':(0,w+20)});doc.saveas(A/(id+'.dxf'))
# Arrangement DXF drawn from shared dimensions, separate layers for frame and wheel blanks.
doc=ezdxf.new('R2010');doc.units=4;ms=doc.modelspace()
def dr(x,y,l,w,layer):ms.add_lwpolyline([(x-l/2,y-w/2),(x+l/2,y-w/2),(x+l/2,y+w/2),(x-l/2,y+w/2)],close=True,dxfattribs={'layer':layer})
for y in [-730,730]:dr(0,y,2000,100,'FRAME')
for x in [-950,950]:dr(x,0,100,1360,'FRAME')
dr(0,0,200,1360,'FRAME');dr(0,0,400,400,'PLATE')
for x in [-600,600]:
 dr(x,0,120,1680,'AXLE_BLANK')
 for y in [-507.2,507.2]:dr(x,y,1000,100,'WHEEL_BLANK')
ms.add_text('DT2 PLAN - mm - PRELIMINARY; WHEEL PROFILE / JOINTS NOT RELEASED',dxfattribs={'height':35,'insert':(-1100,1000)});doc.saveas(A/'DT2-plan.dxf')
# First-pass screening, not fatigue or full frame proof.
g=9.80665; W=5000*g; I=(100*200**3-84*184**3)/12
calc={'load_basis':'LT1 allocated 5000 kg per powered truck; applied entirely as carried load for conservative side-beam screening. Not a weighed mass.','dynamic_multiplier_trial':2,'side_beam_span_mm':1200,'side_beam_I_mm4':I,'side_beam_Z_mm3':I/100,'static_central_point_load_each_side_N':W/2,'screen_peak_bending_stress_MPa':(W/2*2*1200/4)/(I/100),'screen_deflection_mm':(W/2*2*1200**3)/(48*200000*I),'limits':'Ideal simply supported beam only; ignores connection/local wall stress, torsion, braking, sidebearers, buckling, fatigue, hunting, derailment, actual axle load equalization and primary suspension. Does not release members or welds.','new_frame_member_mass_kg':sum(p['mass_kg'] for p in parts if p['category']=='frame'),'wheel_blank_mass_each_kg':next(p['mass_kg'] for p in parts if p['category']=='wheel'),'axle_blank_mass_each_kg':next(p['mass_kg'] for p in parts if p['category']=='axle'),'full_modeled_truck_mass_kg':sum(p['mass_kg'] for p in parts),'excluded_mass':'Bearings, axleboxes, guides, springs, dampers, stops, pivot/sidebearers, motors, reductions, shafts, brakes, hoses, guards, weld metal and fasteners.'}
# LT1 mainframe at y850 ±80 and z990 ±140 intersects new truck envelope even at zero yaw.
calc['LT1_clearance_conflict']={'existing_mainframe_z_extent':[850,1130],'existing_mainframe_inner_abs_y':770,'proposed_sideframe_outer_abs_y':780,'straight_sideframe_overlap_y_mm':10,'spring_plate_overlap_y_mm':50,'proposed_top_plate_z':1170,'resolution':'Locomotive frame arrangement must be revised/coordinated. Do not drill/weld to LT1 frame. No agreed final mainframe underside elevation or truck pivot exists. Rotated envelope and sidebearer motion require further work.'}
(A/'calculations.json').write_text(json.dumps(calc,indent=2))
# SVG drawing helpers: fixed-size sheets with linework and readable dimensions.
INK='#17364a';GRAY='#65737d';GOLD='#a06b24'
def start(title,number):
 return [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1100" role="img" aria-label="{title}"><defs><marker id="arr" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto-start-reverse"><path d="M8 0 L0 4 L8 8" fill="none" stroke="{INK}"/></marker></defs><rect width="1600" height="1100" fill="white"/><rect x="25" y="25" width="1550" height="1050" fill="none" stroke="{INK}" stroke-width="2"/><style>text{{font-family:Arial,sans-serif;fill:{INK}}}.dim{{stroke:{INK};fill:none;stroke-width:1.4}}.obj{{stroke:{INK};fill:#e4ebee;stroke-width:2}}.void{{stroke:#17364a;fill:white;stroke-width:2}}.centre{{stroke:{GRAY};stroke-dasharray:10 5;stroke-width:1}}.env{{stroke:{GOLD};fill:#f8eddc;fill-opacity:.5;stroke-dasharray:8 5;stroke-width:2}}</style><text x="55" y="70" font-size="29" font-weight="bold">{number} · {title}</text><text x="55" y="104" font-size="19">PULSIPHER FARMS • DT2 R0 • 19 OCT 2026 • ALL DIMENSIONS mm • DO NOT SCALE</text><path d="M25 990H1575" stroke="{INK}"/><text x="55" y="1026" font-size="22" font-weight="bold">PRELIMINARY DESIGN — NOT FOR FABRICATION</text><text x="55" y="1055" font-size="17">Nominal geometry only. Final welds, fits, rail profile, bearings, suspension and brake/drive hardware remain to develop.</text>']
def text(s,x,y,t,size=19):s.append(f'<text x="{x}" y="{y}" font-size="{size}">{t}</text>')
def line(s,x1,y1,x2,y2,cls='dim'):s.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="{cls}"/>')
def rect(s,x,y,w,h,cls='obj'):s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" class="{cls}"/>')
def circle(s,x,y,r,cls='obj'):s.append(f'<circle cx="{x}" cy="{y}" r="{r}" class="{cls}"/>')
def dh(s,x1,x2,y,label):
 line(s,x1,y-14,x1,y+14);line(s,x2,y-14,x2,y+14);s.append(f'<path d="M{x1} {y}H{x2}" class="dim" marker-start="url(#arr)" marker-end="url(#arr)"/>');text(s,(x1+x2)/2-40,y-10,label,19)
def dv(s,y1,y2,x,label):
 line(s,x-12,y1,x+12,y1);line(s,x-12,y2,x+12,y2);s.append(f'<path d="M{x} {y1}V{y2}" class="dim" marker-start="url(#arr)" marker-end="url(#arr)"/>');text(s,x+15,(y1+y2)/2,label,19)
def save(s,name):s.append('</svg>');(A/name).write_text(''.join(s).replace('&','&amp;'))
s=start('POWERED TRUCK — SIDE ELEVATION','DT2-A01');sc=.4;ox=600;oz=650
text(s,80,150,'SIDE VIEW · X local to truck pivot',22)
for x in [-600,600]:
 circle(s,ox+x*sc,oz-500*sc,500*sc);circle(s,ox+x*sc,oz-500*sc,110*sc);circle(s,ox+x*sc,oz-500*sc,60*sc)
 rect(s,ox+x*sc-40,oz-590*sc,80,180*sc,'env');rect(s,ox+x*sc-28,oz-935*sc,56,305*sc,'env')
rect(s,ox-400,oz-1150*sc,800,200*sc);rect(s,ox-80,oz-1170*sc,160,20*sc)
line(s,100,oz,1100,oz);text(s,1250,oz+8,'RAIL Z=0')
dh(s,ox-240,ox+240,710,'1200 axle centres');dh(s,ox-400,ox+400,760,'2000 frame');dv(s,oz-1000*sc,oz,1100,'Ø1000');dv(s,oz-1170*sc,oz,1200,'1170 plate top')
text(s,80,820,'Wheel blanks shown; actual rail tread/flange not defined.',20);text(s,80,850,'Amber: bearing/axlebox and spring space only — not manufactured parts.',20)
text(s,80,890,'LOCAL DATUM: X=0 truck pivot; Y=0 track centre; Z=0 rail top.',20)
text(s,80,925,'Truck A global X=3300; Truck B global X=6000. Axles at ±600 from each pivot.',20)
save(s,'DT2-A01.svg')
s=start('TRUCK FRAME — PLAN, SECTIONS & CUTS','DT2-F01');sc=.43;ox=570;oy=560
text(s,70,150,'PLAN · top plate shown in outline',22)
for y in [-730,730]:rect(s,ox-1000*sc,oy+y*sc-50*sc,2000*sc,100*sc)
for x in [-950,950]:rect(s,ox+x*sc-50*sc,oy-680*sc,100*sc,1360*sc)
rect(s,ox-100*sc,oy-680*sc,200*sc,1360*sc);rect(s,ox-200*sc,oy-200*sc,400*sc,400*sc)
for x in [-600,600]:
 line(s,ox+x*sc,200,ox+x*sc,920,'centre')
 for y in [-730,730]:rect(s,ox+x*sc-100*sc,oy+y*sc-90*sc,200*sc,180*sc,'env')
dh(s,ox-1000*sc,ox+1000*sc,190,'2000');dh(s,ox-600*sc,ox+600*sc,930,'1200 spring centres');dv(s,oy-730*sc,oy+730*sc,1040,'1460')
text(s,1140,160,'MEMBER SECTIONS',23)
rect(s,1170,190,100,200);rect(s,1178,198,84,184,'void');text(s,1135,425,'F01/F02: 200 × 100 × 8',19)
rect(s,1170,465,100,100);rect(s,1178,473,84,84,'void');text(s,1135,600,'F03/F04: 100 × 100 × 8',19)
rect(s,1150,640,200,200);rect(s,1160,650,180,180,'void');text(s,1110,875,'F05: 200 × 200 × 10',19)
text(s,150,303,'F01 · side member',18);text(s,150,820,'F02 · side member',18);text(s,605,430,'F05',18);text(s,525,573,'P01',18);text(s,80,962,'2 side cuts: 2000. 2 end cuts + 1 centre cut: 1360. Square ends. Weld sizes and joint details HOLD.',19)
save(s,'DT2-F01.svg')
s=start('WHEEL & AXLE BLANKS — SECTION','DT2-W01');sc=.62;ox=760;oy=520
text(s,65,150,'TRANSVERSE SECTION · wheel and shaft nominal proposal',22)
# wheel section across Y, radius vertical relative axle centre
for y in [-507.2,507.2]:
 for rr in [-1,1]:rect(s,ox+(y-50)*sc,oy+(430 if rr>0 else -500)*sc,100*sc,70*sc)
 rect(s,ox+(y-12.5)*sc,oy-430*sc,25*sc,860*sc)
 rect(s,ox+(y-70)*sc,oy-110*sc,140*sc,220*sc)
 rect(s,ox+(y-71)*sc,oy-60*sc,142*sc,120*sc,'env')
rect(s,ox-590*sc,oy-60*sc,1180*sc,120*sc)
for y in [-840,620]:rect(s,ox+y*sc,oy-50*sc,220*sc,100*sc)
for sg in [-1,1]:
 x1=ox+sg*590*sc;x2=ox+sg*620*sc
 s.append(f'<path d="M{x1} {oy-60*sc}L{x2} {oy-50*sc}V{oy+50*sc}L{x1} {oy+60*sc}Z" class="obj"/>')
line(s,150,oy,1380,oy,'centre');dh(s,ox-840*sc,ox+840*sc,890,'1680 shaft overall');dh(s,ox-590*sc,ox+590*sc,855,'1180 centre');dh(s,ox+620*sc,ox+840*sc,820,'220');dh(s,ox-507.2*sc,ox+507.2*sc,170,'1014.4 wheel centre spacing')
text(s,80,270,'W01 / W02',19);text(s,80,300,'rim Ø1000',19);text(s,80,330,'hub Ø220',19);text(s,80,605,'A01 / A02',19);text(s,80,635,'Ø100 ends',19);text(s,70,935,'Ø120 central shaft / hub bore trial; Ø100 end blanks; 30 long tapered transitions. No fit tolerances assigned.',18)
text(s,70,962,'Rim 100 wide × 70 radial; web 25; hub Ø220 × 140. Rail profile, wheel fixing, fillets and bearing seats HOLD.',18)
save(s,'DT2-W01.svg')
s=start('MOUNTING DATUMS & DRIVE RESERVATIONS','DT2-M01');sc=.45;ox=600;oy=540
text(s,60,150,'PLAN · reserved components in amber; no motor bolt pattern inferred',22)
for y in [-730,730]:rect(s,ox-450,oy+y*sc-22.5,900,45)
rect(s,ox-90,oy-90,180,180)
# motor reservation offset from pivot; centered reducer conflicts flagged clearly
rect(s,ox-180,oy-112.5,360,225,'env');text(s,ox-155,oy+160,'MOTOR / REDUCTION BELOW PLATE',17);text(s,ox-150,oy+190,'800 × 500 × 240 space trial',18)
for x in [-600,600]:
 line(s,ox+x*sc,170,ox+x*sc,900,'centre')
 for y in [-730,730]:circle(s,ox+x*sc,oy+y*sc,70*sc,'env')
dh(s,ox-600*sc,ox+600*sc,195,'1200');dv(s,oy-730*sc,oy+730*sc,100,'1460')
text(s,1160,220,'HARDPOINT TABLE',22)
for j,t in enumerate(['Top plate: X0, Y0','Top surface: Z1170','400 × 400 × 20','Undrilled; pivot HOLD','','Spring axes:','X=−600 and +600','Y=−730 and +730','Pocket underside Z935','','One motor per truck','7.5:1 total ratio trial','Shaft routes / joints HOLD']):text(s,1135,260+j*36,t,19)
text(s,65,925,'LT1 MAINFRAME CONFLICT: existing frame at Y±850 / Z990 overlaps this proposal. Interface revision required.',19)
text(s,65,957,'No motor, gearbox, spring, bearing or brake procurement is authorized by these reservation envelopes.',19)
save(s,'DT2-M01.svg')
verification={'all_solids_valid':True,'part_count':len(parts),'step_exports':len(list(A.glob('*.step'))),'geometry_source':'build_dt2.py + parameters.json','nominal_frame_size_mm':[2000,1640,235],'wheel_blank_no_profile':True,'construction_approved':False}
(A/'verification.json').write_text(json.dumps(verification,indent=2))
print(json.dumps({'parts':len(parts),'mass':calc['full_modeled_truck_mass_kg'],'frame_mass':calc['new_frame_member_mass_kg'],'beam_stress_MPa':calc['screen_peak_bending_stress_MPa']}))
